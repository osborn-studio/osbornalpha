# dsh-trade-strategy-evaluator

交易策略生命周期管理与分析师绩效评估 Agent —— DeepSeek Harness **Bundle 插件**（同时也是一个可独立启动的 Demo）。

> 本系统**不是**交易执行系统：不推荐股票、不自动下单、不决定真实资金配置。
> 它管理分析师提交的策略、固化当时决策、跟踪真实市场结果、用确定性规则量化评价，
> 并产出可审计的绩效报告与完整 Replay。

```sh
git clone https://github.com/osborn-studio/dsh-trade-strategy-evaluator.git
cd dsh-trade-strategy-evaluator

npm run demo                       # ① 零安装看效果：http://127.0.0.1:8787
node scripts/install.js --profile web   # ② 装进 DeepSeek Harness（需重启一次）
npm ci && npm run check            # ③ 197 项测试（断言 0 跳过）+ Harness 挂载验证
```

> `npm run demo` 与插件本体的**运行时依赖为 0**，不装任何包即可跑。
> `npm ci` 只装 `devDependencies`（jsdom / React），供**真实 DOM 测试**使用；
> 不装也不会报错，但 DOM 测试会整组跳过 —— 而 `npm run check` 会把"有跳过"当失败，
> 因此 CI 里这一步是硬性的。

| | |
|---|---|
| 运行时依赖 | **零**（不 import 任何第三方包，也不需要构建步骤） |
| 交付形态 | 30 个 Agent 工具 · 1 个 Skill · 1 段系统提示词 · 39 个 REST 端点 · 2 套 UI |
| 模拟盘组合 | 每个分析师一套**权重/净值式**组合账本（起始净值 100），买卖闭环、按分析师可配仓位上限、超限自动挤出并留痕（见 [§9.2](#92-模拟盘组合权重--净值式)） |
| 中英文 | 界面与报告均支持 zh/en 切换 |
| 可复现性 | 确定性 Mock 行情 + 确定性评价引擎，同一输入必然同一结果 |
| 数值口径 | 报告与两套界面共用**一张显式类型表**，由逐值一致性测试锁死（见 [§9.1](#91-第四道闸门数值类型不许靠字段名猜)） |
| 身份 | `actor` 来源（config / tool / request）进审计；`identity.requireVerified` 可拒绝自述的高权角色（见 [§10.1](#101-身份从哪来以及为什么现在还不是真正的鉴权)） |
| CI | GitHub Actions：Node 22 / 24 / 26 × sqlite，外加"零依赖"与"JSON 回退驱动"两关（见 [§14](#14-测试)） |

---

## 目录

- [1. 它做了什么](#1-它做了什么)
- [2. 架构](#2-架构)
- [3. 快速开始（两种方式）](#3-快速开始两种方式)
- [4. Demo 操作步骤（3~5 分钟）](#4-demo-操作步骤35-分钟)
- [5. 在 Harness 里用 Agent 操作](#5-在-harness-里用-agent-操作)
- [6. REST API](#6-rest-api)
- [7. 数据模型](#7-数据模型)
- [8. 评分模型](#8-评分模型)
- [9. 三条硬性不变量](#9-三条硬性不变量)（+ [9.1 数值类型不许靠字段名猜](#91-第四道闸门数值类型不许靠字段名猜)、[9.2 模拟盘组合（权重/净值式）](#92-模拟盘组合权重--净值式)）
- [10. 权限](#10-权限)（+ [10.1 身份从哪来](#101-身份从哪来以及为什么现在还不是真正的鉴权)）
- [11. 数据维护（三种视角）](#11-数据维护三种视角)
- [12. Mock 行情](#12-mock-行情)
- [13. Demo Seed 分布](#13-demo-seed-分布)
- [14. 测试](#14-测试)
- [15. 配置](#15-配置)
- [16. 中英文语言切换](#16-中英文语言切换)
- [17. 前端界面](#17-前端界面)
- [18. 与实施方案的差异与调整（含踩到的 Harness 坑）](#18-与实施方案的差异与调整含踩到的-harness-坑)
- [19. 目录结构](#19-目录结构)
- [20. 卸载与排错](#20-卸载与排错)
- [21. 参考](#21-参考)

---

## 1. 它做了什么

一次完整的业务链路：

```
Analyst 提交策略
   ↓  strategy_create
校验输入（方向一致性是结构性校验，不是建议）
   ↓
捕获 Market Snapshot（固化"提交当时"的市场状态）
   ↓
冻结策略（此后核心决策字段永久不可修改）
   ↓  strategy_monitor / 内置调度
跟踪真实行情：更新浮动表现 → 检查目标价 → 检查止损 → 检查持仓期满 → 推进状态
   ↓  evaluation_run
确定性 Evaluation Engine 计算
   Return / P&L / Benchmark Return / Alpha / Maximum Drawdown /
   Target Achievement / Stop Loss / Holding Days / Risk-Reward / Score
   ↓  report_strategy / report_analyst / report_team
报告（FACTUAL METRICS 与 LLM COMMENTARY 物理分区）
   ↓  manager_dashboard
Manager Dashboard（Analyst → Analyst Detail → Strategy Detail）
   ↓  strategy_replay
Replay（完整生命周期 + 11 项审计问答 + 重算一致性校验）
```

交付形态：

| 形态 | 说明 |
|---|---|
| **Harness Bundle 插件** | 安装进 DSH profile 后：30 个业务工具进入模型工具目录、`trade-strategy-evaluation` Skill 进入技能目录、`AGENT.md` 成为系统提示词段落、`/api/trade-eval` REST API 挂到宿主 webserver、GUI 的 Conversation 标签环出现「策略评估」Dashboard |
| **独立 Demo** | `npm run demo` 一条命令启动，自带 Manager Dashboard 与同一套 REST API，零外部依赖 |

两者共用**同一个业务内核**（同一 Service、同一评价引擎、同一 Seed），所以两边看到的事实数字永远一致。

---

## 2. 架构

```
                          DeepSeek Harness
                                 │
                     trade-strategy-evaluator (Bundle 插件)
                                 │
        ┌───────────────┬────────┴────────┬───────────────┐
        ▼               ▼                 ▼               ▼
  trade-strategy   market-data      evaluation     strategy-monitor / report
   (生命周期)        (行情抽象)      (确定性指标)      (监控 / 报告)
        │               │                 │               │
        └───────────────┴────────┬────────┴───────────────┘
                                 ▼
                    TradeEvaluationService（唯一组合点）
                                 │
        ┌────────────────────────┼────────────────────────┐
        ▼                        ▼                        ▼
   Repository              Audit Event Log          MarketDataProvider
 (sqlite / json)        （Replay 的唯一真源）      (Mock，可替换真实供应商)
                                 │
        ┌────────────────────────┴────────────────────────┐
        ▼                                                 ▼
  /api/trade-eval (宿主 webserver 路由)          Harness 扩展点
        │                                         · ctx.tools.register()   → 30 个工具
        ▼                                         · ctx.skills.register()  → Skill（global 层）
  Manager Dashboard                               · ctx.systemPrompt.section() → AGENT.md
  · GUI conversation.view 标签页                  · ctx.webServer.register()   → REST 路由
  · 独立 Demo 页面
```

**设计要点**

- **业务能力全是插件**：5 个业务插件各自是独立的 Cordis 插件单元（`ctx.plugin()` 挂载），
  各自向 `ctx.tools` 注册自己的工具；根插件只负责组合与 Harness 集成。
- **数值只出自一个地方**：`src/core/evaluation/` 是纯函数集合（不读时间、不读随机数），
  同一输入必然同一输出。LLM 没有"写 Evaluation"的能力。
- **行情只有一层抽象**：业务层依赖 `MarketDataProvider`，不依赖任何具体供应商。
  换成 Polygon / Alpha Vantage / Yahoo / Bloomberg / 内部行情服务时业务代码零改动。
- **审计先于功能**：任何影响评价结果的变化都产生 Event，Replay 从 Event Log 重建，
  所以"事后改口"在数据结构上就不可行。

---

## 3. 快速开始（两种方式）

### 方式 A：独立 Demo（零安装，推荐先跑这个）

```sh
cd trade-strategy-evaluator
npm run demo            # 等价于 node scripts/demo-server.js
```

打开 <http://127.0.0.1:8787>。默认 `127.0.0.1:8787`，可用环境变量覆盖：

```sh
PORT=9000 npm run demo
TRADE_EVAL_DATA_DIR=/tmp/tse npm run demo      # 数据目录
npm run demo -- --reset                        # 清库并重新灌入 Seed
```

启动时会打印存储驱动、模拟时钟、行情上界、Seed 分布。

### 方式 B：装进 DeepSeek Harness

```sh
cd trade-strategy-evaluator
node scripts/install.js --profile web
```

脚本做两件事（**默认路径不需要改 profile 的 package.json，也不改任何 Harness 核心代码**）：

1. 在 `<DSH_HOME>/profiles/web/node_modules/` 里建立指向本包的符号链接；
2. 把加载行写进 `<DSH_HOME>/profiles/web/cordis.patch.yml`（profile 声明了 `patchReload: live`）。

```sh
# 需要重启后依然存在时（写入 profile 的 dependencies + dsh.profile.bundles）
node scripts/install.js --profile web --permanent

# 指定 home（本机有两个 DSH home：PATH 上的 dsh 默认用 ~/.dsh，
# 而 Desktop GUI 用 ~/Library/Application Support/dsh-desktop/harness）
DSH_HOME="$HOME/Library/Application Support/dsh-desktop/harness" node scripts/install.js --profile web
```

> **本机实测结论（重要）**：装进**已经在运行的** DSH Desktop 后，
> 该 Desktop 构建不会为"新增插件行"做热加载（它的模块级热替换需要 `--expose-internals`，
> 打包版拿不到 Node 内部加载器）。**重启一次 DSH Desktop 即可生效** ——
> 已用一份隔离的 harness home 完整验证过：插件装载成功、`/api/trade-eval/health` 返回 200、
30 个工具进入工具目录、Skill 进入技能目录、客户端 bundle 被 `/plugins/...` 正确提供。

验证安装：

```sh
curl http://127.0.0.1:<你的端口>/api/trade-eval/health
# {"ok":true,"service":"dsh-trade-strategy-evaluator","version":1}
```

### 环境要求

- Node `^22.19.0 || >=24.0.0`（本地验证于 v24.18.1 与 v26.8.1；CI 额外覆盖 v22.19）
- **运行时零依赖**：不 import 任何第三方包，也不需要构建步骤
  （原因见[第 18 节](#18-与实施方案的差异与调整含踩到的-harness-坑)）
- `devDependencies`（`jsdom` / `react` / `react-dom`）**只用于本地 DOM 测试**，
  不参与插件运行，也不会被打进客户端 bundle。
- ⚠️ 但**测试**层面它们不是可选的：不装时 23 项 DOM 测试会整组跳过，
  而"跳过"和"通过"在汇总行里几乎看不出区别（见 §14 的 `test:strict`）。

---

## 4. Demo 操作步骤（3~5 分钟）

启动 `npm run demo` 后：

1. **Analyst Performance Dashboard**
   顶部是总体指标（38 策略 / 30 已评价 / 胜率 / 平均收益 / 平均 Alpha / 最大回撤 / 平均评分），
   下面是 5 名分析师一行一人的汇总表，再下面是团队汇总与最近的审计事件。

2. **点 John** → Analyst Detail
   看到 John 的策略历史：每条的 Return / Benchmark / Alpha / Score / 状态。

3. **点任意一条 NVDA 策略** → Strategy Detail
   - **Strategy**：Strategy ID、Analyst、提交时间、冻结时间、Benchmark、提交前仓位
   - **Original Strategy**：Entry / Target / Stop / Holding Period / 提交时的市场快照
   - **Performance**：Entry → Exit、Return、Benchmark、Alpha、Max Drawdown、P&L、持仓天数、退出原因
   - **Result**：Target 是否达成、Stop Loss 是否触发、Benchmark 相对表现、评分公式版本
   - **Analyst Reasoning**：分析师提交时的**原始**理由（永不被改写）
   - **Price Timeline**：持有期每个交易日的收盘价
   - **Replay**：完整生命周期事件（含操作者身份）+ 11 项审计问答
   - **Evaluation Report**：§22 模板的 Markdown，事实区在上、模型评论区在下

4. **点顶部 `Run Monitor`**
   对所有 ACTIVE 策略拉最新行情、更新浮动表现、推进状态。会弹出本次监控结论。

5. **点 `Advance 1 Day`**
   推进模拟时钟一个交易日，然后自动跑一次监控。
   连续点几次即可看到 ACTIVE 策略走完持仓期 → `COMPLETED`。

6. **点 `Reset Demo`**（ADMIN）
   清库并重新灌入 Seed，回到初始状态。

7. **点 John 详情页的 `📈 模拟盘`** → Portfolio（权重 / 净值式）
   净值、累计收益率、当前敞口 / 仓位上限、持仓明细、已平仓明细、挤出与被拒指令。
   页面**只出现净值与收益率，不出现任何金额**。点 `重算校验` 会当场从策略流重算一遍
   并与落库快照逐字段比对，证明这条曲线可复现。
   深链：`#/portfolio/john`。
   **看 `Michael` 的模拟盘**（他的上限被刻意配成 30%）能直接看到**超限挤出**：
   系统按 `fifo` 平掉了最早那一手，并记下"为哪条指令腾的位置"。

8. **点团队表里任意一行** → Team Detail
   团队汇总 + **按分析师分组**：每个成员一块（成员名可点进该分析师），下面是他的策略表。
   深链：`#/team/TMT`。返回按钮逐层退回（策略 → 团队 → Dashboard）。

8. **点右上角语言切换器（中文 / English）**
   整页文案立即切换，**报告 Markdown 也变成所选语言**（报告由服务端按语言渲染）。
   数字完全不变——语言只影响文案。在 GUI 里同一个切换器会同时改变标签页文案，
   因为标签是 locale thunk，而不是写死的字符串。

9. **把右上角身份切成 `ANALYST`** → 视角变成"我的策略"
   出现 **「提交策略」** 按钮与"当前分析师"选择器；分析师表与团队表隐藏（那是管理视角）。
   点「提交策略」→ 填 NVDA BUY 250 / Target 290 / Stop 235（或点「用当前价」自动填）
   → 「提交并冻结」→ 直接跳到该策略详情，取消按钮已在。
   故意把 Target 填成低于入场价，会看到 **BUY 要求：止损 < 入场价 < 目标价** 的即时提示。
   选「存为草稿」则留在 DRAFT：详情页出现「编辑策略」与「冻结」两个按钮。

10. **把身份切成 `ADMIN`** → 看板顶部出现**评分规则面板**，可直接改四个权重与版本号并保存
    （只影响之后的评价；历史 Evaluation 保留自己的 `calculation_version`）。

11. **切换右上角 Role 为 `ANALYST`**
   视图立刻收窄到 `john` 自己的策略；此时调用越权接口会返回 403 —— 权限是真的在服务层强制。

**在 GUI 里演示（装了插件之后）**：Conversation 标签环里选「策略评估」，同样是三层下钻
（Dashboard → Analyst → Strategy，内含 Performance / Replay / Report 三个页签）。

---

## 5. 在 Harness 里用 Agent 操作

装好插件后，模型会看到 30 个工具，并自动获得 `trade-strategy-evaluation` Skill 与
`AGENT.md` 指令段落。可以直接对 Agent 说：

```
把 NVDA BUY 165 → Target 190 / Stop 155 / 20 天 / Benchmark QQQ 这条策略提交，理由写完整一点
```

```
评价 STR-20260616-003，并把事实数据和你的分析分开写
```

```
生成 John 的分析师绩效报告，重点说清楚 Alpha 而不是绝对收益
```

```
把 STR-20260616-003 的 Replay 展开，回答审计的 11 个问题，并验证重算是否一致
```

工具清单：

| 能力 | 工具 |
|---|---|
| 策略生命周期 | `strategy_create` `strategy_get` `strategy_list` `strategy_freeze` `strategy_cancel` `strategy_status` |
| 行情 | `market_get_quote` `market_get_history` `market_get_benchmark` `market_get_snapshot` `market_universe` |
| 确定性评价 | `evaluation_run` `evaluation_get` `evaluation_list` `evaluation_rules_get` `evaluation_rules_update` `strategy_verify_replay` |
| 监控 | `strategy_monitor` `strategy_monitor_all` `demo_advance_clock` |
| 报告与 Replay | `report_strategy` `report_analyst` `report_team` `analyst_performance` `team_performance` `manager_dashboard` `strategy_replay` |

---

## 6. REST API

前缀：`/api/trade-eval`。所有响应都是 JSON，业务失败返回
`{ "ok": false, "error": { "code", "message", "details" } }` + 语义化状态码
（400 / 403 / 404 / 409 / 422 / 500 / 502）。

调用方身份：请求体里的 `actor` 字段，或请求头 `x-actor-role` + `x-actor-id`，或查询串 `role` + `actor_id`。
缺省为 `MANAGER`。

```jsonc
{ "actor": { "actor_id": "john", "role": "ANALYST" } }   // role ∈ ANALYST | MANAGER | ADMIN
```

### 端点总览（39 个）

| 方法 | 路径 | 说明 |
|---|---|---|
| GET | `/health` | 健康检查 |
| GET | `/meta` | 插件元数据、端点清单、存储与时钟状态 |
| POST | `/strategies` | 创建策略（默认创建即冻结；`auto_freeze: false` 只建 DRAFT） |
| GET | `/strategies` | 列出策略（`analyst_id` / `status` / `ticker` / `limit`） |
| GET | `/strategies/:id` | 读取策略（含评价） |
| PATCH | `/strategies/:id` | 修改策略 —— **冻结后必定 409** |
| POST | `/strategies/:id/freeze` | 冻结（DRAFT → ACTIVE） |
| POST | `/strategies/:id/cancel` | 取消 |
| GET | `/strategies/:id/status` | 生命周期状态 |
| GET | `/strategies/:id/performance` | 浮动表现 + 已完成评价 |
| POST | `/strategies/:id/evaluate` | 执行确定性评价（可带 `as_of`） |
| GET | `/strategies/:id/replay` | Replay（时间线 + 11 项问答） |
| GET | `/strategies/:id/replay/verify` | 重算并与落库结果逐字段比对 |
| GET | `/evaluations` `/evaluations/:id` | 评价记录 |
| GET | `/rules` · PUT `/rules` | 评分规则（写入仅 ADMIN） |
| GET | `/market/universe` `/market/quote/:ticker` `/market/history/:ticker` | 行情 |
| GET | `/analysts` · `/analysts/:id/performance` · `/capabilities` | 分析师与角色能力矩阵 |
| GET | `/teams` · `/teams/:team/performance` | 团队列表；团队明细（汇总 + **按分析师分组**的策略） |
| GET | `/meta` 内 `language` / `languages` | 当前默认语言与可用语言清单 |
| GET | `/dashboard` | Manager Dashboard 数据 |
| GET | `/reports/strategies/:id` · `/reports/analysts/:id` · `/reports/teams` · `/reports` | 报告（`?lang=zh\|en` 切语言） |
| GET | `/portfolios` · `/portfolios/:analyst_id` | 模拟盘汇总；单个分析师的组合（净值/持仓/挤出/被拒指令） |
| GET | `/portfolios/:analyst_id/nav` | 组合净值曲线（`?from=&to=` 切片） |
| GET | `/portfolios/:analyst_id/verify` | 组合**重算校验**：能否从策略流算出同一份净值 |
| GET | `/events` | 审计事件 |
| POST | `/monitor/run` · `/monitor/:id` | 监控 |
| POST | `/demo/advance-clock` · `/demo/reset` | Demo 时钟 / 重置 |

### 示例

**创建策略（§15 的形状）**

```sh
curl -s -X POST http://127.0.0.1:8787/api/trade-eval/strategies \
  -H 'content-type: application/json' \
  -d '{
    "analyst_id": "john",
    "ticker": "NVDA",
    "action": "BUY",
    "position_before": 0,
    "entry_price": 165,
    "target_price": 190,
    "stop_loss": 155,
    "holding_period": 20,
    "benchmark": "QQQ",
    "reason": "AI server demand is expected to increase...",
    "actor": { "actor_id": "john", "role": "ANALYST" }
  }'
```

```json
{
  "ok": true,
  "strategy_id": "STR-20260916-009",
  "status": "ACTIVE",
  "frozen": true,
  "frozen_at": "2026-09-16T09:30:00Z",
  "market_snapshot": { "price": 278.7505, "timestamp": "2026-09-16T20:00:00Z", "volume": 141557995, "as_of": "2026-09-16", "source": "mock" }
}
```

**冻结后修改 → 必须失败**

```sh
curl -s -o /dev/null -w '%{http_code}\n' -X PATCH http://127.0.0.1:8787/api/trade-eval/strategies/STR-20260916-009 \
  -H 'content-type: application/json' -d '{"patch":{"entry_price":1}}'
# 409
# {"ok":false,"error":{"code":"FROZEN_STRATEGY_IMMUTABLE",
#   "message":"frozen strategy STR-20260916-009 cannot be modified: attempted change to entry_price",
#   "details":{"fields":["entry_price"]}}}
```

**用未来行情评价 → 必须失败**

```sh
curl -s -o /dev/null -w '%{http_code}\n' -X POST http://127.0.0.1:8787/api/trade-eval/strategies/STR-20260916-009/evaluate \
  -H 'content-type: application/json' -d '{"as_of":"2027-03-01"}'
# 422
# {"ok":false,"error":{"code":"LOOKAHEAD_VIOLATION",
#   "message":"refusing to read NVDA up to 2027-03-01: market data beyond 2026-09-16 is not available yet",
#   "details":{"ticker":"NVDA","requestedTo":"2027-03-01","boundary":"2026-09-16"}}}
```

**执行评价**

```sh
curl -s -X POST http://127.0.0.1:8787/api/trade-eval/strategies/STR-20260616-003/evaluate \
  -H 'content-type: application/json' -d '{"actor":{"actor_id":"m","role":"MANAGER"}}' | jq '.evaluation | {strategy_return, benchmark_return, alpha, max_drawdown, score, calculation_version}'
```

**Replay 一致性校验**

```sh
curl -s http://127.0.0.1:8787/api/trade-eval/strategies/STR-20260616-003/replay/verify | jq '.verification | {matches, differences, calculation_version}'
# { "matches": true, "differences": [], "calculation_version": "v1" }
```

**改评分规则（仅 ADMIN）**

```sh
curl -s -X PUT http://127.0.0.1:8787/api/trade-eval/rules \
  -H 'content-type: application/json' \
  -d '{"version":"v2","weights":{"return":0.5,"alpha":0.2,"risk":0.2,"target":0.1},
       "actor":{"actor_id":"admin","role":"ADMIN"}}'
```

---

## 7. 数据模型

**Strategy**

```jsonc
{
  "strategy_id": "STR-20260916-001",
  "analyst_id": "john",
  "ticker": "NVDA",
  "action": "BUY",                 // BUY | SELL
  "position_before": 0,
  "quantity": 100,                 // 用于 P&L
  "entry_price": 165,
  "target_price": 190,
  "stop_loss": 155,
  "holding_period": 20,            // 交易日
  "benchmark": "QQQ",
  "reason": "AI server demand is expected to increase...",   // 原样保存，永不改写
  "created_at": "2026-09-16T09:30:00Z",
  "created_by": "john",
  "market_snapshot": { "price": 165.32, "timestamp": "...", "volume": 1234567, "as_of": "...", "source": "mock" },
  "status": "ACTIVE",              // DRAFT ACTIVE COMPLETED STOPPED EXPIRED CANCELLED
  "frozen": true,
  "frozen_at": "2026-09-16T09:30:00Z",
  "frozen_by": "john",
  "updated_at": "...",
  "performance": { ... },          // 监控写入的浮动表现（非决策数据）
  "evaluation_id": "EVAL-...",
  "status_reason": "HOLDING_PERIOD_END"
}
```

**Evaluation**

```jsonc
{
  "evaluation_id": "EVAL-20261016-001",
  "strategy_id": "STR-20260916-001",
  "entry_price": 165, "exit_price": 185,
  "strategy_return": 0.1212,
  "benchmark_return": 0.063,
  "alpha": 0.0582,
  "max_drawdown": -0.034,
  "pnl": 2000,
  "target_price": 190, "target_reached": false, "target_reached_on": null,
  "stop_loss": 155, "stop_loss_triggered": false, "stop_loss_triggered_on": null,
  "holding_days": 20, "holding_period_planned": 20,
  "risk_reward_ratio": 2.5, "volatility": 0.217,
  "exit_reason": "PERIOD_END",     // STOP_LOSS | PERIOD_END | TARGET_AND_PERIOD_END
  "window": { "from": "...", "to": "...", "as_of": "..." },
  "score": 72,
  "score_components": { "return": 73.7, "alpha": 72.1, "risk": 77.3, "target": 60 },
  "score_weights": { "return": 0.4, "alpha": 0.25, "risk": 0.2, "target": 0.15 },
  "calculation_version": "v1",
  "price_timeline": [ { "date": "...", "close": 168 } ],
  "benchmark_timeline": [ { "date": "...", "close": 601.2 } ],
  "evaluation_time": "..."
}
```

**退出语义（POC 明确定义）**

- 触发止损 → 视为仓位在止损价被平掉：`exit_price = stop_loss`，`exit_reason = STOP_LOSS`；
- 未触发止损 → 持有到评价交易日收盘：`exit_price = 该日收盘价`，`exit_reason = PERIOD_END`；
- 达到目标价是"目标事件"，不强制平仓，但会影响 Target 子分数；
- Benchmark 使用与策略**完全相同的窗口**，保证 Alpha 可比。

---

## 8. 评分模型

```
Total Score =
  40% × Return 得分
+ 25% × Alpha 得分
+ 20% × Risk 得分
+ 15% × Target 得分
```

每个子分数先由**分段线性映射**归一到 0-100，再按权重加权。
全部阈值来自 `config/evaluation-rules.json`，**不硬编码在代码或 Prompt 里**：

```json
{
  "version": "v1",
  "weights": { "return": 0.40, "alpha": 0.25, "risk": 0.20, "target": 0.15 },
  "return_scale": { "zero_score_return": -0.10, "full_score_return": 0.20 },
  "alpha_scale":  { "zero_score_alpha": -0.05, "full_score_alpha": 0.10 },
  "risk_scale":   { "max_drawdown_tolerance": 0.15, "stop_loss_penalty_points": 30 },
  "target_scale": { "target_reached": 100, "holding_ended_without_target": 60, "stop_loss_triggered": 0 },
  "rounding":     { "score_decimals": 0, "ratio_decimals": 6 }
}
```

规则 `version` 会写进每条 Evaluation 的 `calculation_version`。改规则只影响之后的评价，
历史评价保留自己的版本号，因此**将来改了公式也仍然能解释历史结果**。

`weights` 之和必须是 1，否则配置直接报错（防止"权重悄悄漂移"）。

---

## 9. 三条硬性不变量

这三条不是文档约定，是**代码层面的闸门**，被单元/集成/Replay 测试与 mounting 验证共同覆盖。

| 不变量 | 实现位置 | 失败表现 |
|---|---|---|
| **冻结后不可篡改**：核心决策字段永久不可修改 | `src/core/monitor/immutability.js` 的字段级白名单 + 深比较，在**每次写库前**运行 | `409 FROZEN_STRATEGY_IMMUTABLE`，并列出被改动的字段 |
| **禁止使用未来信息**：评价只能使用提交之后、评价时点之前的行情 | 双层闸门：`MarketDataProvider.assertWithinBoundary()`（数据层）+ `as_of ≥ frozen_at`（引擎层） | `422 LOOKAHEAD_VIOLATION`，并给出请求上界与真实上界 |
| **Evaluation 只由引擎写入**：任何角色都不能修改 | `CAPABILITIES['evaluation.write'] = []`，`assertCapability` 对空能力集一律拒绝 | `403 UNAUTHORIZED` |

### 9.1 第四道闸门：数值类型不许靠字段名猜

报告与两套界面都要把同一批指标印成百分比、金额、计数或评分。这里出过一次**真事故**，
因此它现在也是一道被测试锁死的闸门：

报告层曾用 `/(rate|return|alpha|drawdown)/.test(字段名)` 猜数值类型 —— 而正则做的是**子串匹配**，
于是 `strategies`（st-**rate**-gies）被当成比例，印出 `策略总数 +800.00%`（真值 8）；
`positive_alpha_count`（含 alpha）印成 `+400.00%`（真值 4）；
同时**计数被强制两位小数**，印出 `已完成评价 6.00`。
**报告里出现了错误数字，而当时的单元测试全绿**（它们只断言表头与分节存在）。

根因不是正则写错，而是接受了"字段名能表达类型"这个假设。所以修法不是换更聪明的正则，
而是**把"字段 → 类型"写成一张显式表**（`src/core/report/format.js` 的 `METRIC_TYPES`）：

| 类型 | 含义 | 渲染 | 例 |
|---|---|---|---|
| `SIGNED` | 有方向的量 | 正数带 `+`，2 位小数 | `average_return` → `+2.10%` |
| `MAGNITUDE` | 幅度量 | **不加 `+`**，负号由数值自带 | `volatility` → `40.66%`；`max_drawdown` → `-20.31%` |
| `SCORE` | 评分（0–100） | 普通数，不补零、**不带 `%`** | `average_score 46.5` → `46.5`；`score 35` → `35` |
| `NUMBER` | 无量纲数 | 固定小数位 | `risk_reward_ratio 1.0` → `1.00`（不是 `100.00%`） |
| `COUNT` | 计数 | 整数 + 千分位，**绝无小数** | `strategies 8` → `8` |
| `MONEY` | 金额 | 2 位小数 + 千分位 | `total_pnl -3457.33` → `-3,457.33` |

未声明的字段**抛错而不是猜**：报告里出现一个来源不明的数字，比报告生成失败更糟 ——
前者会被当真，后者会被人发现。

两套界面（DSH 面板与独立 Demo 页）因为载体限制**无法 import 报告层那份 ESM**
（客户端 bundle 是注册式 CJS 工厂，只能 require 平台 seed 模块），因此**必然**各有一份副本。
"副本不许漂移"这件事不靠注释，靠 `tests/integration/metric-format-parity.test.js`：
它按每个已声明类型**逐值**比对报告层与两个界面的输出，并额外做源码扫描，
禁止把幅度量交给会加 `+` 的格式化函数。

三条相关测试：`tests/unit/report-format.test.js`（类型表穷尽性 + 事故字符串逐条回归）、
`tests/integration/metric-format-parity.test.js`（三方一致性）、以及 `tests/unit/contrast.test.js`（配色对比度）。

### 9.2 模拟盘组合（权重 / 净值式）

需求原文（会议纪要 05:22）：「他其实只给了一个 text 和百分比对吧？像净值一样」。
因此组合层**不是金额记账**，而是权重/净值式：

| 规则 | 取值 | 为什么 |
|---|---|---|
| 起始净值 | `NAV = 100`（可配） | 净值式；不出现金额，与真实资金保持距离（C6 / F1） |
| 一条指令 | = 一个"手"，占**当时净值**的 `weight_pct` | 与"像净值一样"的口径一致，且天然复利 |
| 建仓价 | 策略记录的 `entry_price`（不另算一遍） | 让"这一手的收益率 == 该策略的评价收益率"**逐字段相等**，两层可对账 |
| 平仓 | ① 策略终结（用评价的出场价）② 反向指令（C5）③ 超限挤出（C4） | 三个来源都记 `close_reason`，能区分"市场结束"与"系统砍仓" |
| 挤出价 | **当时市价** | 挤出的语义就是"卖掉旧持仓"。按建仓价平仓会把已发生的盈亏抹掉 —— 那是篡改，不是调仓 |
| 仓位上限 | `max_position_pct`，**可按分析师覆盖**（C3） | 纪要 04:47「你最大仓位有百%，你自己看着放吧」 |
| 挤出策略 | `fifo` / `largest_weight` / `worst_performer` 可配（C4） | 默认自动；无论选哪种都落 `POSITION_EVICTED` |
| 单条权重 > 上限 | **拒绝**并记 `INSTRUCTION_REJECTED`，不夹紧 | 夹紧会让"分析师到底要求了多少"变得不可考 |
| 撤销的手 | 按建仓价平仓、收益率 0 | 撤销意味着指令从未生效；**不编造**一个它本该成交的价格 |
| DRAFT 策略 | 不进组合 | 从未冻结 ⇒ 不构成指令 |

**三条可验证的性质**（都有测试）：

1. **可复算** —— `portfolio_nav` 的曲线能由 `portfolio_recompute` 从策略流完全重算，
   与落库快照逐字段一致。指令流的**指纹**（`instruction_digest`）证明两次算的是同一份输入。
2. **可对账** —— `已实现盈亏 + 浮动盈亏 = 净值变动`，**差额恒为 0**。
   已实现盈亏取自账面实际变动而不是再用平行公式算一遍，所以这个恒等式在构造上成立。
   它比"数字看起来对"强得多：它证明组合层与逐笔层没有各算各的。
3. **不篡改** —— 组合层的任何操作都不改已冻结策略的一个字节；挤出只进事件日志。

**顺带修掉的一个真实漏洞**：`immutability.js` 的文件头声明"即使有人绕过 Service 写库也会失败"，
但守卫原先只在 Service 里调用 —— 测试实测证明，直接 `repository.put('strategies', ...)`
**是能改掉已冻结策略的核心字段的**。守卫已下沉到 `Repository.put`，那句声明现在才成立。
新增的 `weight_pct`（建仓规模，直接决定测评结果）也一并纳入 `CORE_FIELDS`。

补充的守卫：

- **方向一致性**是结构性校验：`BUY` 要求 `stop_loss < entry_price < target_price`，`SELL` 取反。不满足直接拒绝。
- **重复评价幂等**：同一 (策略, 窗口, 规则版本) 重复调用返回同一份 Evaluation，且逐字段相同。
- **审计全覆盖**：创建 / 快照 / 冻结 / 表现更新 / 达成目标 / 触发止损 / 完成 / 过期 / 取消 /
  评价完成 / 报告生成 / 监控运行 / 时钟推进 / 规则更新 都产生事件，事件带全局单调序号、时间戳与操作者。

---

## 10. 权限

| 角色 | 可以 | 不可以 |
|---|---|---|
| `ANALYST` | 创建策略、查看自己的策略、运行评价、读自己的报告与 Replay | 修改已冻结策略、修改 Evaluation、查看他人策略、改评分规则 |
| `MANAGER` | 查看团队策略、分析师绩效、团队报告、Replay、运行监控、取消策略 | 创建/冻结策略、修改 Evaluation、改评分规则 |
| `ADMIN` | 配置评分规则、管理分析师、重置 Demo 数据、代录策略 | 修改 Evaluation（**任何角色都不行**） |

### 10.1 身份从哪来，以及为什么现在还不是真正的鉴权

把这件事说在明处：**DeepSeek Harness 目前不提供用户身份** ——
session / agent 上下文里没有 userId，唯一能拿到的是 `session.header` 里的 `seedLength` / `cwd`。
所以本插件里的 `actor` 一律是**自述身份**：谁调用就声明自己是谁。

工程上能做的三件事已经做了：

1. **解析收敛到一个点**：`resolveActor()`（`src/core/auth.js`）。
   优先级 `调用方自述 > 配置层 identity.actor > 内置默认`，服务层所有入口共用它。
   此前 21 个调用点各写一遍 `normalizeActor(options.actor)`，默认身份写死在代码里，
   部署者没法改，来源信息也当场丢掉。
2. **来源进审计**：每个 `actor` 带 `source` ∈ `config` | `tool` | `request`，
   写进审计事件的 `actor` 字段。事后能区分"部署配置给的身份"和"调用方自述的身份"。
   HTTP 层只在**一个出口**打这个标记，避免 20 处逐个加参数时漏掉一处
   —— 漏掉的那一处就是 `requireVerified` 打开时的提权口子。
3. **可配置的可信闸门**：`config.identity.requireVerified: true` 时，
   来源不是 `config` 的高权角色（MANAGER / ADMIN）**直接拒绝**，低权角色与主流程不受影响。

```yaml
# cordis.patch.yml
config:
  identity:
    actor: { actor_id: john, role: ANALYST }   # 工具/HTTP 未显式传 actor 时使用
    requireVerified: true                      # 自述的 MANAGER/ADMIN 一律拒绝
```

**真正的认证必须接客户 SSO**：代码层面到此为止，再往前推只能靠信任边界
（浏览器鉴权围栏 / 共享令牌），不能靠在 `auth.js` 里多加判断 ——
在没有身份来源的前提下，任何"更严格的判断"都只是对自述字段的再解读。

#### 权限报错必须"可直接照做"

`DEFAULT_ACTOR` 是 MANAGER，而 `strategy.create` / `strategy.freeze` 只允许 ANALYST / ADMIN，
`rules.write` 只允许 ADMIN —— 所以不带 `actor` 的写操作**必然**失败。
曾经的报错只有 `role MANAGER may not perform "strategy.create"`，
调用方（尤其 Agent）只能拿同一个身份反复重试。现在错误里带 `suggestedActor` 与 `hint`：

```json
{ "code": "UNAUTHORIZED",
  "details": {
    "capability": "strategy.create",
    "allowed": ["ANALYST", "ADMIN"],
    "suggestedActor": { "actor_id": "david", "role": "ANALYST" },
    "hint": "retry with actor={\"actor_id\":\"david\",\"role\":\"ANALYST\"}",
    "howToFix": "capability \"strategy.create\" is allowed for: ANALYST, ADMIN" } }
```

有两条属性被测试强制（`tests/unit/identity.test.js`）：

- **照 `suggestedActor` 重试一定成功**。因此 `strategy.create` 的建议身份必须取自库里的
  **真实分析师**（`actor_id` 不是分析师的话，照做会撞上 `unknown analyst` —— 报错等于没说，
  甚至把人引到第二个错误上）。
- **能力名要对得上**。`createStrategy` 里"ANALYST 替别人建策略"曾经复用
  `assertCapability(actor, 'strategy.read.any')`，于是报的是**读权限**错误，
  调用方会朝完全错误的方向修。现在报的是 create 语义的错，并给出
  `actingAnalyst` / `targetAnalyst` 与"改成自己的 analyst_id"的修法。

`evaluation.write` 是结构性禁止，**不存在**能写 Evaluation 的角色，因此它**不**给"换个角色"的假建议。

能力矩阵在 `src/core/auth.js` 里集中声明，**服务层强制**，不依赖 UI。可直接读取：

```sh
curl -s http://127.0.0.1:8787/api/trade-eval/capabilities | jq
# { "ok": true, "roles": ["ANALYST","MANAGER","ADMIN"],
#   "capabilities": { "strategy.create": ["ANALYST","ADMIN"], ...,
#                     "evaluation.write": [] } }
```

---

## 11. 数据维护（三种视角）

系统有三种身份，**界面只负责"不显示不该有的入口"，权限全部由服务端强制**（能力矩阵见下一节）。
Demo 没有真实登录，所以身份是显式选择的：顶栏切角色；选 ANALYST 时再选"当前分析师"。

| 视角 | 能看到什么 | 能做什么 |
|---|---|---|
| **ANALYST** | 只有**自己的**策略（列表 / 详情 / Replay / 报告） | **提交策略**、编辑草稿、冻结、取消；看不到他人策略，也看不到分析师表与团队表 |
| **MANAGER** | 全部：分析师表、团队表、审计事件、任意下钻、报告 | 监控、评价、取消；**不能创建或修改策略**（界面无入口，接口 403） |
| **ADMIN** | 与 MANAGER 相同 | 以上全部 + **界面内编辑评分规则**（版本号随之变化，只影响之后的评价）+ 重置 Demo |

### 11.1 加策略

三条路径完全等价：

| 入口 | 行为 |
|---|---|
| **界面**「提交策略」（ANALYST/ADMIN 可见） | 表单 → 「提交并冻结」或「存为草稿」；「用当前价」一键填入入场/目标/止损；**本地先校验方向一致性**，服务端仍会再校验一次 |
| **Agent** `strategy_create` | 提交即冻结，自动抓当时快照 |
| **REST** `POST /strategies` | `"auto_freeze": false` 建 DRAFT（可改后再冻结） |

```sh
B=http://127.0.0.1:8787/api/trade-eval

# 以分析师身份建草稿（界面「存为草稿」走的就是这条）
curl -s -X POST $B/strategies -H 'content-type: application/json' \
  -H 'x-actor-role: ANALYST' -H 'x-actor-id: john' -d '{
    "analyst_id":"john","ticker":"NVDA","action":"BUY",
    "entry_price":250,"target_price":290,"stop_loss":235,
    "holding_period":20,"reason":"AI 服务器需求上修","auto_freeze":false}'
# → STR-20260916-009  DRAFT，已自动写入当时的市场快照

# 改草稿（仅 DRAFT；冻结后 409 FROZEN_STRATEGY_IMMUTABLE）
curl -s -X PATCH $B/strategies/STR-20260916-009 -H 'content-type: application/json' \
  -H 'x-actor-role: ANALYST' -H 'x-actor-id: john' -d '{"patch":{"target_price":300}}'

# 冻结
curl -s -X POST $B/strategies/STR-20260916-009/freeze \
  -H 'content-type: application/json' -H 'x-actor-role: ANALYST' -H 'x-actor-id: john' -d '{}'
```

### 11.2 删策略：没有硬删除

这是**有意的**：策略一旦冻结就是"当时决策"的证据，硬删除会让 Evaluation 变孤儿、Replay 断链，
并让分析师的历史成绩可以被"删差留好"地悄悄优化。因此只有：

- **取消**（软删；界面「取消策略」按钮，仅 ACTIVE）：状态变 `CANCELLED`，记录保留、仍在列表中
- **整库重置**（ADMIN；界面「重置 Demo」）：清空并重灌演示数据
- 终态（COMPLETED / STOPPED / EXPIRED）**不能取消**——界面直接给出说明，而不是摆一个必然失败的按钮

已取消的策略计入"策略数"但**不计入"已评价"**，因此不污染胜率 / 平均收益 / Alpha / 评分口径。

若确实需要受控删除（例如只允许删 DRAFT/CANCELLED + ADMIN + 必填原因 + 写审计事件），
可作为后续增强，规则见[第 18.13 节](#1813-未实现受控删除有意的缺口)。

### 11.3 身份如何传到服务端

界面在**每个请求**上都带 `x-actor-role` 与 `x-actor-id`；服务端按
`body.actor → 查询串 → 请求头` 合并解析（三条都支持，便于 curl 与前端各取所需）。
ANALYST 只能以自己的 id 提交，冒用他人身份会 403。

## 12. Mock 行情

`MockMarketDataProvider` 是一个**确定性纯函数**价格模型：

```
log P(i) = log(base_price)
         + drift · i                                  // 趋势
         + cycle_amp · sin(2π (i + phase) / period)    // 周期，造出上涨/下跌阶段
         + sigma · Σ_{k=1..i} gauss(seed, k)           // 可复现随机游走
```

其中 `i` 是自 `history_epoch`（`2026-01-02`）起的第 i 个交易日。

- 同一 `(ticker, 日期)` **永远**得到同一价格 → 评价、Replay、重算全部可复现；
- 与查询顺序无关（无状态语义），可以随机访问任意区间；
- 交易日历跳过周末与节假日；
- 提供 5 个 Demo 标的：`AAPL` `NVDA` `MSFT` `TSLA` `AMZN`；2 个 Benchmark：`QQQ` `SPY`；
- 数据上界 = 当前模拟时钟所在/之前最近的交易日，**越过上界的请求一律拒绝**。

**模拟时钟**：Demo 默认 `simulated` 模式，从 `demo-config.json` 的 `clock.start_date`
（`2026-09-16`）出发按**交易日**推进，所以 3~5 分钟就能演示 20 个交易日的完整生命周期，
并且每次运行结果完全一致。Demo 时钟状态持久化，重启进程不会"穿越"。

换成真实行情：实现 `MarketDataProvider` 的 4 个方法（`getQuote` / `getHistory` /
`getBenchmark` / `getSnapshot`）与 `boundary()`，替换 `service.provider` 即可，业务代码零改动。

---

## 13. Demo Seed 分布

Seed 不是"随机编 30 条"：它在确定性行情上枚举候选、算出每条候选**真实**的后续路径特征，
再按目标分布贪心挑桶并反推 `target/stop`，最后用**真实的 Evaluation Engine** 落库。
因此 Seed 数据与引擎结果天然一致 —— `strategy_verify_replay` 对种子策略同样通过。

实测分布（`npm run check` 每次都断言）：

```
38 条策略 / 30 条评价 / 5 名分析师
{ "total_evaluated": 30,
  "profitable": 16, "losing": 14,
  "outperform_benchmark": 16, "underperform_benchmark": 14,
  "target_reached": 5, "stop_loss_triggered": 3 }
```

要求（§17）：≥10 盈利 / ≥10 亏损 / ≥5 跑赢 / ≥5 跑输 / 3 止损 / 5 达目标 —— 全部满足并有余量。
其余 8 条是 4 条 ACTIVE（用于演示监控）、2 条 CANCELLED、2 条 DRAFT（用于演示冻结端点）。

每条种子数据都带 `seeded: true` 标记与专门的审计事件 payload，**不会被伪装成真实发生的分析师提交**。

---

## 14. 测试

```sh
npm ci                    # 只需一次：jsdom / react / react-dom（DOM 测试用）
npm test                  # 全部 197 个测试
npm run test:strict       # 同上，但**断言 fail=0 且 skipped=0**（CI 用这个）

npm run test:unit         # 指标 / 评分 / 行情 / 不可篡改 / 数值格式化 / 身份 / bundle 契约
npm run test:integration  # 生命周期主链路 + REST API 契约
npm run test:replay       # 事件时间线 / 重算一致性 / 双驱动一致 / 重启一致
npm run test:dom          # 真实 DOM 测试：独立 Demo 页（13 项）+ DSH 面板（10 项）

# 依赖装在别处时可用环境变量指路（仓库内不含任何机器相关路径）
JSDOM_MODULE=/path/to/pkg.json DSH_APP_NODE_MODULES=/path/to/node_modules npm run test:dom

# 压到回退驱动 / 断言真实驱动（用于验证"没有 node:sqlite 也能跑"）
TSE_TEST_DRIVER=json npm run test:strict
TSE_EXPECT_DRIVER=sqlite npm run check

npm run check             # 语法 + 清单自检 + 全部测试 + mounting 验证 + Seed 冒烟
node scripts/verify-mount.js   # 只跑 Harness 真实注册表的 mounting 验证（21 项）
```

#### 为什么 `test:strict` 要单独看 `skipped`

一次真实的假绿事故：DOM 测试在缺 jsdom/React 时会"优雅跳过"，但跳过条件是用
`test(name, skip, fn)` 传的，而 `skip` 在依赖可用时是 `{}` —— `{ skip: {} }` 里的
`options.skip` 是**真值空对象**，node:test 会**静默跳过整组测试且不打印原因**。
于是"依赖装好了"和"依赖没装"的输出几乎一样：汇总行看着正常，实际 23 项 DOM 测试全没跑。

结论是：**静默跳过比失败更危险**（失败有人看，假绿没人看）。因此：

- `scripts/assert-tests-ran.js` 同时断言 `fail=0`、`skipped=0`、`tests ≥ 下限`；
- `npm run check` 与 CI 都走这个脚本，而不是直接 `node --test`；
- CI 里 `TSE_EXPECT_DRIVER` 也写死期望驱动 —— `auto` 在 `node:sqlite` 不可用时是**静默回退**到 json 的，
  不写死就会出现"以为在验 sqlite、其实跑的是 json"这另一种假绿。

#### 新增的三组测试（对应 §9.1 与 §10.1）

| 文件 | 覆盖 |
|---|---|
| `tests/unit/report-format.test.js` | 类型表**穷尽性**（聚合器新增指标未声明类型即失败）、事故字符串逐条回归（`策略总数` 不再是 `+800.00%`、评分不再是 `4650.0%`、波动率不再带 `+`）、非有限值统一 `n/a` |
| `tests/integration/metric-format-parity.test.js` | 报告层 ↔ DSH 面板 ↔ 独立 Demo 页**逐值一致**，外加源码扫描禁止把幅度量交给会加 `+` 的格式化函数 |
| `tests/unit/identity.test.js` | `resolveActor` 优先级与来源、`requireVerified` 闸门、报错可操作性（照 `suggestedActor` 重试必须成功）、能力矩阵与实际判定一致、审计事件带 `actor.source` |

CI（`.github/workflows/ci.yml`）四个关卡：

| 关卡 | 内容 |
|---|---|
| `check` | Node **22 / 24 / 26** × sqlite（`TSE_EXPECT_DRIVER=sqlite`）：`npm ci` → `test:strict` → `check` |
| `no-runtime-deps` | **不安装任何包**：先断言 `dependencies` 为空，再跑不依赖 jsdom 的 124 项测试 |
| `json-driver` | `TSE_TEST_DRIVER=json`：整组测试压到 JSON 回退驱动，证明没有 `node:sqlite` 也能完整工作 |

**单元测试**覆盖的方案要求项：Return / Alpha / Drawdown / Target detection /
Stop Loss detection / Score calculation，外加评分单调性、边界夹紧、规则版本隔离、
客户端 bundle 契约、i18n 的三张文案表键集合一致性，以及**前端配色的 WCAG AA 对比度**（16 组令牌对 × 2 套主题）。

**集成测试**覆盖：Create → Freeze → Monitor → Evaluate → Report 全链路，
以及"冻结后修改必须失败""使用未来行情必须失败""任何角色不能写 Evaluation"三条关键断言。

**Replay 测试**覆盖：事件日志重建完整生命周期、11 项审计问答、重算逐字段一致、
重复评价幂等、**进程重启后仍一致**（证明数据来自持久化而非内存）、
**sqlite 与 json 两个驱动结果完全相同**、Seed 数据同样通过一致性校验。

**mounting 验证**（`scripts/verify-mount.js`，21 项）用 Harness **真实的** Cordis 容器与
**真实的**服务注册表（`dsh-tools` / `dsh-skill` / `dsh-system-prompt` / `dsh-host-webserver`）挂载本插件并断言：

- 30 个工具进入工具注册表，schema 是合法 object 根 JSON Schema；
- 工具定义体真的能执行（创建策略 / 读评分规则 / 未来评价被拒 / 越权被拒 / 非法参数被拒）；
- Skill 进入技能目录且 `provider` 正确、正文可加载；
- `AGENT.md` 段落确实注册（用注册表的唯一性约束反证）且未覆盖 `deployment:persona`；
- `/api/trade-eval` 确实在真实 webserver 的前缀路由表里，重复注册会被拒绝；
- **客户端 bundle 按 Harness 的装载协议被真实加载**：`__ModuleLoader__.load` 注册、
  id 逐字等于包名、只 require 平台 seed 词表、插件面导出 `apply/inject`、
  `apply` 注册进 `conversation.view` 且带 `id/label/order`、样式带正确的 `data-plugin`，
  并用 shell 的 **React 18.3.1** 真的渲染出 HTML。

---

## 15. 配置

`cordis.patch.yml` 的 `config`（全部可选，整对象替换语义）：

| 字段 | 默认 | 说明 |
|---|---|---|
| `enabled` | `true` | `false` 时完全不挂载（不注册工具/技能/路由/调度） |
| `label` | `策略评估` | GUI Conversation 视图标签文案 |
| `order` | `40` | 视图在标签环中的排序值 |
| `dataDir` | `$DSH_HOME/trade-strategy-evaluator` | 数据目录 |
| `storage` | `auto` | `auto` \| `sqlite` \| `json`；`auto` 优先 `node:sqlite`，不可用则回退 JSON |
| `monitor` | `true` | 是否起内置监控调度 |
| `monitorIntervalMs` | `60000` | 调度间隔（毫秒） |
| `seedOnStart` | `true` | 库为空时是否灌入 Demo Seed |
| `language` | `zh` | 报告与界面默认语言：`zh` \| `en` |
| `identity.actor` | `{ actor_id: demo_manager, role: MANAGER }` | 工具/HTTP 未显式传 `actor` 时使用的默认身份 |
| `identity.requireVerified` | `false` | `true` 时，来源不是配置层的高权角色（MANAGER/ADMIN）一律拒绝（见 [§10.1](#101-身份从哪来以及为什么现在还不是真正的鉴权)） |
| `identity.elevatedRoles` | `["MANAGER","ADMIN"]` | 受 `requireVerified` 约束的高权角色集合 |
| `portfolio.startNav` | `100` | 组合起始净值（权重/净值式记账的基准） |
| `portfolio.defaultWeightPct` | `10` | 策略未指定 `weight_pct` 时的默认建仓权重（百分点） |
| `portfolio.defaultMaxPositionPct` | `100` | 全局仓位上限；`analysts[].max_position_pct` 可按分析师覆盖（C3） |
| `portfolio.evictionStrategy` | `fifo` | 超限挤出策略：`fifo` \| `largest_weight` \| `worst_performer`（C4） |
| `rulesPath` / `demoPath` / `universePath` | 包内 `config/*.json` | 覆盖配置文件路径 |

`config/evaluation-rules.json` 是**评分规则**（管理者可改）；
`config/demo-config.json` 是**Demo/时钟/分析师**配置；
`config/market-universe.json` 是**Mock 行情宇宙**（标的、参数、节假日）。

**存储驱动实测**：在 DSH Desktop 的 harness 里 `node:sqlite` 可用，实际用的是 **sqlite**；
独立 Demo 在同一台机器上也用 sqlite。两个驱动有测试断言结果完全一致，所以换介质不改变业务事实。
（`auto` 的回退是**静默**的，所以 CI 用 `TSE_EXPECT_DRIVER` 把期望驱动写死，
否则"其实跑在 json 上"这件事不会被发现。）

---

## 16. 中英文语言切换

### 16.1 界面语言：与 GUI 的「设置 → 常规 → 语言」是同一个偏好

插件**不自己造一套语言状态**，而是接进 shell 的 locale 服务（`@deepseek-ai/dsh-client-locale`）：

```js
export const inject = ['slots', 'locale']

function apply(ctx, config) {
  const t = ctx.locale.bind(NS)
  ctx.effect(() => ctx.locale.register(NS, { zh: UI.zh, en: UI.en }), '…: dictionaries')
  ctx.slots.register({
    name: 'conversation.view', id: PLUGIN_ID, order,
    label: () => t('tab'),        // thunk：GUI 切语言时标签环自己刷新
  }, Shell)
}
```

因此有三条路径可以切语言，效果完全一致：

| 路径 | 说明 |
|---|---|
| GUI **设置 → 常规 → 语言** | 官方入口，选择持久化到 `$DSH_HOME/settings.yaml` |
| **插件面板顶栏的语言切换器** | 调的是同一个 `ctx.locale.setLocale()`，不是自建开关 |
| **独立 Demo 页顶栏** | 选择存 `localStorage`，并作为 `Accept-Language` / `?lang=` 发给服务端 |

切换是**即时生效**的：`conversation.view` 的标签文案声明成 `label: () => t('tab')`，
而 conversation 包自己订阅了 locale 变化，所以标签环会跟着变；
面板内的组件也订阅了 locale 快照，切换后重渲染并重新拉取报告，**不需要重载插件或刷新页面**。

> ⚠️ 若在 `cordis.patch.yml` 里显式设置 `label: 策略评估`，标签就锁定为该字符串、
> 不再跟随语言（这是给"想固定文案"的部署方留的口子）。默认**不设** `label`。
> `scripts/verify-mount.js` 对两条路径都有断言。

### 16.2 报告语言：服务端渲染，`?lang=` / `Accept-Language` / 工具参数三选一

报告 Markdown 由服务端按语言渲染（不是前端拼字符串），所以 API 直接调用也能拿到对应语言：

```sh
curl "$B/api/trade-eval/reports/strategies/STR-20260304-001?lang=zh"
curl "$B/api/trade-eval/reports/strategies/STR-20260304-001?lang=en"
curl -H 'accept-language: en-US,en;q=0.9' "$B/api/trade-eval/reports/analysts/john"
```

Agent 工具同理，`report_strategy` / `report_analyst` / `report_team` 都多了一个 `language` 参数：

```jsonc
{ "strategy_id": "STR-20260304-001", "language": "en", "commentary": "Risk control was too tight." }
```

优先级：**工具/请求参数 → `Accept-Language` → 插件配置 `language` → `zh`**。
认不出的语言（如 `fr`）回落到默认值而**不报错** —— 语言偏好不该让业务失败。

### 16.3 保证了什么

| 保证 | 实现 | 测试 |
|---|---|---|
| 每种语言文案键集合**完全一致** | 三张表（策略报告 / 绩效报告 / UI 词典） | `tests/unit/i18n.test.js` 逐表断键集合相等 |
| 界面不会露出裸 key | bundle 里 `t('...')` 用到的每个键都必须存在 | 同上（正则扫出全部 `t('…')` 调用点核对） |
| 两套 UI 不漂移 | 客户端 bundle 与独立 Demo 页的键名对齐；bundle 导出 `dictionaries` 供断言 | 同上（断言 Demo 页是 bundle 词典的超集） |
| **语言只影响文案，不影响数值** | 数值全部来自 Engine，报告渲染只选文案字符串 | 断两种语言下 `strategy_return`/`alpha`/`score`/目标与止损判定逐字节相同，且渲染出的百分比字符串集合一致 |
| Replay/审计不受影响 | 事件、Evaluation、`calculation_version` 都不含语言 | 现有 197 项测试不区分语言，仍然全绿 |

### 16.4 刻意不做 i18n 的部分

- **错误码与错误 `message`** 保持英文单表述。它们是诊断信息，混进语言会让日志、测试与排错反馈
  变得不可搜；UI 负责把它翻译成人话。
- **`AGENT.md` / `SKILL.md`** 是模型指令而非 UI。给模型两种语言的同一份规则只会浪费上下文，
  并让两边逐渐漂移。
- **`calculation_version`、`exit_reason`、状态枚举** 是机器可读的稳定标识，不翻译
  （报告的"规则判定"一节负责把它们呈现成对应语言的人话）。

## 17. 前端界面

两套 UI 共享一套**设计语言**，但各自贴合宿主：

| | DSH GUI 面板（`conversation.view`） | 独立 Demo 页 |
|---|---|---|
| 技术 | React 18（shell 提供）+ 手写 `createElement` | 无框架 vanilla ESM |
| 配色 | **全部使用 shell 的 `--dsw-*` 设计令牌**，自动跟随 GUI 浅色/深色主题与品牌色 | 自带令牌 + 跟随系统/浅色/深色三态切换 |
| 主题切换 | GUI 的「设置 → 外观」 | 顶栏切换器（`auto`/`light`/`dark`，存 localStorage） |
| 路由 | 面板内导航栈 + 返回按钮 + 面包屑 | hash 路由（可深链、可刷新、浏览器前进后退可用）+ 返回按钮 + `Esc` |

### 17.1 设计令牌

DSH 面板**不写死配色**，而是消费 shell 的设计令牌（带回退值，缺令牌时也不崩）：

```css
.tse-root {
  --tse-panel:  var(--dsw-alias-bg-layer-1, #131b26);
  --tse-line:   var(--dsw-alias-border-l1, #24303f);
  --tse-text:   var(--dsw-alias-label-primary, #e8eef7);
  --tse-accent: var(--dsw-alias-brand-primary, #4da3ff);
  --tse-good:   var(--dsw-alias-state-success-primary, #35d07f);
  --tse-bad:    var(--dsw-alias-state-error-primary, #ff6b6b);
  /* …面板内部只用 --tse-* 这层语义别名 */
}
```

好处：GUI 切主题时面板**不需要任何插件代码**就跟着变；独立页则用同一套语义命名，
换主题只改 `:root[data-theme]` 的变量值，组件样式一行不动。

### 17.2 导航

- **返回按钮**：根视图禁用，下钻后可用；DSH 面板用内部导航栈，独立页用 hash + `history`
- **面包屑**是真实链接（可点回任意一层），不是纯文本
- 独立页额外支持：**深链**（`#/strategy/STR-20260616-003/replay` 可直接打开并停在 Replay 页签）、
  **刷新保持**、**浏览器前进后退**、**`Esc` 返回**
- DSH 面板刻意不写 `location.hash`：GUI 是 SPA，改 hash 可能与其自己的路由打架，
  因此只在面板内部维护导航栈（这是刻意的取舍，不是遗漏）

### 17.3 下钻层级

```
Manager Dashboard
├── Analyst 行 ──→ Analyst Detail ──→ Strategy Detail（Performance / Replay / Report）
└── Team 行   ──→ Team Detail ──→ 按分析师分组的成员块 ──→ Strategy Detail
                                  └── 点成员名 ──→ Analyst Detail
```

**团队明细**（`#/team/<name>`）内容：团队汇总卡片 → 每个成员一块（可点的成员名 + 该成员的关键指标
一行 + 该成员的策略表）。分组结构由服务端算好（`GET /teams/:team/performance`），
前端不重复聚合，避免两处口径分叉；有测试断言**分组求和等于团队汇总**（不漏人、不重复计数）。

### 17.4 表格

- **点表头排序**（升/降序切换、方向箭头、`aria-sort`），数值列按数值排、文本列按本地化比较
- **表头固定**（`position: sticky`），长列表滚动时表头不跑
- **过滤**（策略历史）：标的/策略 ID 搜索 + 状态 + 方向，附「显示 N / M 条」计数与一键清除
- 整行可点、**键盘可达**（`Enter` / `Space` 打开），`tabindex` 与焦点环齐备
- 数字列统一 `tabular-nums`，货币千分位按当前语言本地化

### 17.5 图表与可视化

- **价格走势 SVG**（手写，无图表库）：收盘价折线 + **入场/目标/止损三条参考线** +
  **达标点/止损点标记** + **Benchmark 归一化对照线**（以入场价归一，才可与价格同轴比较）+ 图例
- **评分环**：环形进度随分数变色（≥70 绿、≥45 蓝、否则红）+ 分项条形分解（子分数 × 权重）
- 状态色：盈利/亏损、达标/止损、四种策略状态各有语义色（不再是一律灰）

### 17.6 状态与可读性

- **骨架屏**代替"loading…"（`aria-busy` 标记），完成后被真实内容替换
- **错误卡片带重试按钮**（`role="alert"`），不再是一行裸文本
- **空状态**分两种："该分析师暂无策略" vs "没有符合筛选条件的策略"
- **报告 Markdown 渲染成结构化排版**（h1/h2/表格/引用/列表）而不是塞进 `<pre>`；
  渲染前先 HTML 转义再解析，注入标签会被转义
- 打印样式：隐藏顶栏与页签，报告可直接打印

### 17.7 无障碍与响应式

- `role="tablist"/"tab"` + `aria-selected`、`aria-sort`、`aria-label`、`role="alert"`、
  `:focus-visible` 焦点环、跳转到内容链接（skip link）
- 窄屏（<900px）自动单列、表格横向滚动、卡片 2 列；`prefers-reduced-motion` 下关闭骨架动画

### 17.8 配色与对比度

配色不是"看着顺眼就行"：低对比度是**看不见的回归**——构建、类型、功能测试全绿，
用户却读不出按钮上的字。所以关键配色按 WCAG 2.1 AA（正文/UI 文字 4.5:1）要求，
并用 `tests/unit/contrast.test.js` 把两套 UI 的设计令牌读出来**算**对比度。

修复过两个真实缺陷（都由用户反馈或测试发现）：

| 缺陷 | 实测对比度 | 原因 | 修法 |
|---|---|---|---|
| 独立 Demo 页暗色主按钮 | **2.63:1** | 强调色 `#4da3ff`（为浅底上的**文字**设计）被直接当作**填充底色**，配白字 | 新增 `--on-accent` 令牌：暗色近黑字（7.18:1）、亮色白字（5.44:1） |
| DSH 面板主按钮 | **1.05:1**（几乎不可见） | 硬编码 `color:#fff`；而 shell 的 `button-primary-fill` 在暗色主题是**近白** `#f9fafb` | 改用 shell 成对令牌：填充取主文字色、文字取面板底色，两端天然反色 |

顺带修掉的弱对比：亮色主题的 `--text-faint` 在页面底色上只有 **2.83:1**（页脚/提示文字读不出来），
暗色 4.37:1；浅色底上的状态色（`good-soft` 3.75、`bad-soft` 4.19）也都不达标——现已全部提到 4.5:1 以上。

`contrast.test.js` 覆盖 16 组令牌对 × 2 套主题，并额外断言"主按钮不得再出现硬编码 `#fff`"，
因此这个缺陷不可能悄悄回来。

### 17.9 这些是"测过"的，不是"看起来改了"

新增两组**真实 DOM 测试**（jsdom + 真实 React + 打到真实 HTTP 服务）：

- `tests/integration/ui.test.js`（13 项）——独立 Demo 页：挂载渲染、下钻/返回/`Esc`、深链（策略与团队）、
  排序（含 `aria-sort`）、过滤计数、**团队行 → 团队明细按分析师分组**、主题三态、
  语言切换且数字不变、报告排版
- `tests/integration/client-panel.test.js`（10 项）——DSH 面板：真实 React 挂载并渲染卡片与三张表、
  下钻/返回、排序、**团队行 → 团队明细（成员块 + 成员链接）**、三个页签
  （评分环 + 图表 + prose 报告 + Replay 时间线）、语言切换、`markdownToHtml` 的转义正确性

两组都在这台离线机器上真的跑起来了（jsdom 从本机插件开发目录解析）；缺依赖时优雅跳过，不误报。

## 18. 与实施方案的差异与调整（含踩到的 Harness 坑）

方案 §29 第 7 条要求：发现 Harness API 与方案存在差异时，以当前源码与官方文档为准，并在 README 记录调整。
以下是**实测得到**的差异，全部基于本机已安装的 DSH `0.1.2-alpha.1` 源码，不是推测。

### 18.1 客户端 bundle 无构建步骤（方案建议 TypeScript + 构建）

客户端 bundle 的格式**不是 ESM**，而是 Harness 客户端模块系统要求的注册式 CJS 工厂：

```js
window.__ModuleLoader__.load({
  id: "dsh-trade-strategy-evaluator",     // 必须逐字等于 package.json 的 name
  factory: (require) => { /* ... */ return module.exports },   // 导出 { name, inject, apply }
})
```

而且这台机器上**没有 esbuild**（`npx esbuild` 需要联网），参考插件的 tsdown 只存在于另一个仓库的
`node_modules` 里。因此客户端采用**零构建**方案：手写 `React.createElement`（别名 `h`）的单文件 bundle，
只 `require('react')`（React 由平台 seed 词表提供，实测 shell 运行的是 **18.3.1**）。
好处是没有构建链、没有依赖、`lib/client.js` 即产物；代价是 JSX 的写法不如编译版紧凑。

### 18.2 宿主侧零 import：不能 import `@deepseek-ai/*`

profile 的 `node_modules` 只暴露了 `@deepseek-ai/dsh-client-ui-slots` 一个包，
从第三方插件 `import '@deepseek-ai/dsh-tools'` 会解析失败。因此：

- 工具的 **JSON Schema 手写**（与 `defineTool()` 的产物同形：`{ type:'object', properties, required }`），
  直接调用 `ctx.tools.register(definition)`；
- 客户端 bundle 只 require 平台 seed 词表里的模块；
- `scripts/check.js` 里有一条自检，禁止任何 `@deepseek-ai/*` 运行时 import 混进来。

### 18.3 ⚠️ async `apply` 不能有返回值（踩坑，导致"插件不生效"）

`apply` 是 async 时，Cordis 会把它的 **resolve 值**交给内部 `safeCollect()`，
而 `safeCollect` 只接受「函数（disposer）/ `null` / `undefined`」。
一开始 `apply` 末尾写了 `return { service }`，结果抛 `TypeError: Invalid effect`，
**整个插件被判定为装载失败并回滚已注册的路由与工具** —— 表面现象是"插件根本没生效"（路由 401）。
现在 `apply` 什么都不返回，资源清理一律通过 `ctx.effect()` 声明。

### 18.4 ⚠️ profile 的 `cordis.patch.yml` 有一行 `[]` 占位符（踩坑）

profile 模板的 patch 文件以一行 `[]`（空列表）结尾。往**后面追加** `- insert:` 会在同一个文件里
产生第二个 YAML 文档，loader 只读到 `[]`，插件**静默不加载**。`install.js` 现在会**替换**该占位符，
并用哨兵注释包裹自己写入的块，因此重复安装/卸载都只影响自己那一段。

### 18.5 新增插件行需要重启 DSH Desktop

profile 声明了 `patchReload: live`，配置**改动**是热加载的；但打包版 macOS Desktop 拿不到
Node 内部模块加载器（模块级热替换需要 `--expose-internals`），因此**新增**插件行后需要重启一次。
（已用一份隔离的 harness home 完整验证：重启后插件装载成功、路由 200、客户端 bundle 被正确提供。）

### 18.6 Skill 用 `ctx.skills.register()` 而不是 filesystem 根

Web profile 在宿主平面**禁用了** `skill-filesystem` 与 `tool-skill`（它们改由 agent preset 挂载），
所以插件不能靠"往某个目录丢 SKILL.md"来生效。方案 §6 要的是"Skill 定义 Agent 的业务流程"，
这里用 `ctx.skills.register()` 把 `skills/trade-strategy-evaluation/SKILL.md` 注册进
**global 层**（无 scope 的调用进入 global 层，全部 agent 可见），并带上
`resourceBase: { kind: 'directory' }` 让模型知道相对路径该往哪解析。
内容是运行时从磁盘读的，所以**改 SKILL.md 即改行为**，不存在"文档一套、Prompt 另一套"。

### 18.7 `AGENT.md` 用提示词段落追加，不覆盖 persona

`dsh-persona` 不能在宿主平面全局挂载（会与提示词注册表自己的 `deployment:persona` 冲突并**启动失败**）。
因此 `agents/trade-strategy-evaluator/AGENT.md` 通过
`ctx.systemPrompt.section({ name, order: 700, text })` **追加**为一个独立段落，
deployment persona 原样保留 —— 这是"追加"而不是"替换"，属于刻意选择。

### 18.8 `dsh.configTrees` 在本机没有消费者

方案 §24 建议的 `config/`（agent presets 树）在本机不成立：`@deepseek-ai/dsh/package.json` 里的
`dsh.configTrees` 在整个已安装应用中**只出现在它自己的声明里**，没有任何运行时消费者；
用户级 preset 目录是 `$DSH_HOME/.agent-presets/<id>/`，bundle 无法从自己的 `cordis.patch.yml` 里可靠地
注册它（`baseUrl` 在 bundle patch 里解析为 **profile 目录**，不是 bundle 目录）。
因此本插件不提供 preset，而是提供 Skill + 提示词段落 + 工具，这三者在宿主平面都可用且已验证。

### 18.9 前端一套设计语言、两种实现

方案没有规定前端技术。现实约束是：DSH 面板必须走 shell 的客户端模块系统（CJS 工厂 + 只读
平台 seed 模块），而独立 Demo 页要能在没有 React 的环境里跑。因此是两个实现，
但**共用一套设计语义**（同名 CSS 变量、同名文案键、同样的交互约定），并有测试保证
文案键集合对齐、两边的关键交互都被真实 DOM 断言覆盖。

### 18.10 语言切换走 shell 的 locale 服务，不自建开关

方案没有提 i18n。实现上刻意**不**在插件里维护语言状态，而是 `inject: ['locale']`
并使用 `ctx.locale.register/bind/setLocale`，理由是：GUI 已经有官方语言选择（写入
`settings.yaml`），自建一套会立刻出现"面板是英文、标签环是中文"这种自相矛盾的状态。
代价是客户端 bundle 多了一个 `locale` 服务依赖（web profile 必然存在）。

### 18.11 报告里的示例分数与方案 §8 不同

方案 §8 的示例（Return 12.12% / Alpha 5.82% / MDD -3.4% / Score 82）是示意值。
按本项目 `config/evaluation-rules.json` 的规则，同一组输入得到 **72 分** —— 因为
`Target` 子分数在"未达目标价"时是 60（而非 100），并且 Risk 有回撤惩罚。
这不是算错，而是规则本身；管理者可以改规则文件，`calculation_version` 会记录版本，
历史结果仍然可解释。

### 18.12 SELL（做空）的回撤口径修正

做空仓位直接用 `-price` 作为 mark-to-market 序列会得到**负数峰值**，
导致 `(price - peak) / peak` 符号翻转、**最大回撤恒为 0**（实测踩到）。
现在空头以入场价为轴做镜像（`2·entry − price`），起点等于入场价、量纲与多头一致，
峰谷回撤的百分比含义与多头完全相同。

---

### 18.13 未实现受控删除（有意的缺口）

方案没有规定数据删除。当前实现**没有** `DELETE /strategies/:id`：策略只能被"取消"（软删）
或整库重置，理由是审计完整性（见[第 11.2 节](#112-删策略没有硬删除)）。
如果之后确实需要，建议的最小规则是：只允许 `DRAFT`/`CANCELLED`、限 `ADMIN`、
必填 reason、写一条审计事件、并明确有 Evaluation 的策略要不要连带处理
（连带删除会让 Replay 断链，必须显式选择）。

## 19. 目录结构

```
trade-strategy-evaluator/
├── package.json                 # dsh.bundle.patch + dsh.client(platform: web)；零依赖
├── cordis.patch.yml             # Bundle patch：一行 insert
├── lib/
│   └── index.js                 # 宿主入口：挂载 5 个业务插件 + Skill + 提示词段落 + 路由 + 调度
├── src/
│   ├── core/                    # 纯业务内核（不依赖 Harness，测试与 Demo 共用）
│   │   ├── config.js            # 配置装载与校验（评分规则权重必须和为 1）
│   │   ├── errors.js            # 稳定错误码 → HTTP 状态码映射
│   │   ├── time.js              # 交易日历 + 模拟/系统时钟
│   │   ├── ids.js               # STR/EVAL/RPT 业务 ID 分配
│   │   ├── auth.js              # 角色能力矩阵 + resolveActor（身份唯一解析点）+ 身份策略
│   │   ├── audit.js             # 审计事件与时间线
│   │   ├── skill.js             # SKILL.md / AGENT.md 装载
│   │   ├── service.js           # TradeEvaluationService：唯一组合点
│   │   ├── market/              # MarketDataProvider 抽象 + 确定性 Mock
│   │   ├── evaluation/          # metrics（纯函数）+ scoring（可配置）+ engine
│   │   ├── monitor/             # monitorStrategy + 不可篡改守卫
│   │   ├── portfolio/           # ⭐ 模拟盘组合账本（批次 1）
│   │   │   ├── ledger.js        #   纯会计：权重/净值式 + 挤出 + 可复算指纹
│   │   │   └── manager.js       #   装配（价格查询/仓位上限）与逐字段比对
│   │   └── report/              # 聚合 + 报告构建（事实/评论分区）
│   │       ├── aggregate.js     #   按策略/分析师/团队聚合
│   │       ├── builder.js       #   三份报告的事实区与评论区
│   │       └── format.js        #   ⭐ 指标类型表（数值口径的唯一定义，见 §9.1）
│   ├── storage/repository.js    # sqlite 驱动 + JSON 回退，原子写
│   ├── api/router.js            # 39 个 REST 端点（无框架，吃裸 node:http）
│   ├── server/                  # 6 个 Cordis 业务插件
│   │   ├── trade-strategy.js  market-data.js  evaluation.js
│   │   ├── portfolio.js  strategy-monitor.js  report.js  toolkit.js
│   └── client/
│       ├── dashboard.js         # GUI bundle（conversation.view，零构建）
│       └── standalone/          # 独立 Demo 的无框架页面
├── skills/trade-strategy-evaluation/SKILL.md
├── agents/trade-strategy-evaluator/AGENT.md
├── config/{evaluation-rules,demo-config,market-universe}.json
├── seed/demo-data.js            # 确定性 Seed 生成
├── tests/{unit,integration,replay}/
│   ├── unit/portfolio.test.js                     # 组合会计口径 / 挤出 / 可复算 / 对账
│   ├── unit/report-format.test.js                 # 类型表穷尽性 + 事故字符串回归
│   ├── unit/identity.test.js                      # 身份解析 / 可信闸门 / 报错可操作性
│   ├── integration/metric-format-parity.test.js   # 报告 ↔ 两套界面 逐值一致
│   └── integration/{ui,client-panel}.test.js      # 真实 DOM（jsdom + React 18）
├── scripts/
│   ├── demo-server.js  install.js  uninstall.js  check.js  verify-mount.js
│   └── assert-tests-ran.js      # ⭐ 断言 fail=0 且 skipped=0（防假绿，见 §14）
├── .github/workflows/ci.yml     # Node 22/24/26 + 零依赖 + JSON 回退驱动
└── docs/PLAN.md                 # 实施前的 Harness 能力勘察与阶段计划
```

---

## 20. 卸载与排错

```sh
npm run install:plugin                                     # = node scripts/install.js --profile web
npm run uninstall:plugin                                   # = node scripts/uninstall.js --profile web
node scripts/install.js --profile web --permanent          # 额外写入 profile 的 dependencies/bundles
DSH_HOME="..." node scripts/uninstall.js --profile web      # 指定 home 卸载
```

`scripts/uninstall.js` 只是把 `--uninstall` 前置后转调 `install.js`：
装与卸必须对**同一段内容**负责，拆成两套逻辑迟早会漏删。

**排错清单**

| 现象 | 原因与处理 |
|---|---|
| `/api/trade-eval/*` 返回 `401 unauthorized` | 插件没加载，请求被 `dsh-client-connection` 的 `/api` 前缀接走了。检查：`node scripts/verify-mount.js` 是否通过；profile 的 `cordis.patch.yml` 是否被写在了 `[]` **后面**（必须替换那一行）；新增插件行后**重启** Desktop |
| GUI 标签环里没有「策略评估」 | 同上；另外确认 `package.json` 的 `dsh.client.platform === 'web'` 与 `exports['./client']` 指向真实文件 |
| 装到了错误的 home | 本机有两个 DSH home。PATH 上的 `dsh` 默认 `~/.dsh`，Desktop GUI 用 `~/Library/Application Support/dsh-desktop/harness`。用 `DSH_HOME=...` 显式指定 |
| 工具里看不到 `strategy_*` | 检查 `cordis.patch.yml` 的 `config.enabled` 是否为 `true`；工具是宿主平面注册的，任何 preset 都应可见 |
| 数据看起来"回到初始" | 数据在 `dataDir`（默认 `$DSH_HOME/trade-strategy-evaluator`）。删掉该目录或调 `/demo/reset` 就会重新 Seed |
| `Cannot find module '@deepseek-ai/...'` | 不应发生：本插件零 `@deepseek-ai/*` 运行时依赖，`scripts/check.js` 有自检禁止引入 |

---

## 21. 参考

- 实施前的能力勘察（Harness 扩展点实测）与阶段计划：[`docs/PLAN.md`](docs/PLAN.md)
- Harness 扩展点的具体证据（文件与代码位置）都写在 `docs/PLAN.md` 里，便于对照当前 DSH 版本复核

## 投研判断台交互 Demo（2026-09-18）

新增基于客户产品资料的离线交互产品原型：观点确认、模拟现金账本、表现、团队复盘与证据链。

- 单文件入口：[`demo/investment-review.html`](demo/investment-review.html)，可直接用浏览器打开。
- 本地预览：`npm run demo:review` → `http://127.0.0.1:8790`。旧 Demo 服务下可打开 `/review`。
- 专项验证：`npm run test:review`。
- [演示说明与边界](docs/review-demo/README.md) / [后续真实接入接缝](docs/review-demo/INTEGRATION.md)。

这是 Mock 数据的完整交互原型；未连接飞书、Ostag、Supabase，不执行真实交易。原策略评估器 API 和 w1 权重账本保留。

## S5：同一引擎，两个宿主

`OSanalyst` 与本 GitHub 仓库为同一项目。0.2.0 新增独立子路径
`dsh-trade-strategy-evaluator/engine`（无宿主 I/O）与 `/adapters`，
Promise Repository 保持本地磁盘 schema v1。`local` 使用 DSH 本地库；
`alpha-connected` 经三操作 HTTP EvaluationStore 访问 Alpha，未配置或断网明确失败。
当前仅合成样例通过本地联调，Alpha 真实服务端留 S6。

- [API、行情证据与错误语义](docs/handoffs/s5/API.md)
- [本地升级与回滚](docs/handoffs/s5/MIGRATION.md)
- [验收证据](docs/handoffs/s5/ACCEPTANCE.md)
- [第六站交接](docs/handoffs/s5/HANDOFF-S6.md)

验证：`npm run test:engine`、`npm run test:strict`、`npm run test:replay`、
`npm run check`。`npm run pack:engine` 生成本地 tarball，并在干净临时 consumer
中安装、执行 S4 golden / 离线 Replay / TypeScript 契约检查；不发布 npm。
