import assert from 'node:assert/strict'
import { evaluateObservation, digest } from '../src/engine/index.js'
import { RPC_VERSION } from '../src/adapters/evaluator-http.js'
export function commitFor(input,{key='synthetic-conformance',revision=0}={}) {
 const computed=evaluateObservation(input);assert.equal(computed.ok,true)
 return {schema_version:RPC_VERSION,observation_ref:{id:input.observation.id,sha256:input.observation_sha256},market_snapshot_refs:input.market_snapshots.map((m,i)=>({id:m.id,sha256:input.market_snapshot_sha256s[i]})),engine_version:computed.result.engine_version,rule_version:computed.result.rule_version,input_sha256:input.input_sha256,input,result:computed.result,result_sha256:computed.result_sha256,expected_revision:revision,idempotency_key:key,request_key:key}
}
/** Run against an isolated S4-golden registration at revision 0; works for S5 fake or S6 real store. */
export async function assertEvaluationStoreConformance({store,input}) {
 const o=await store.readObservation(input.observation.id);assert.equal(o.sha256,digest(input.observation));assert.equal(o.observation.actual_start_at,null)
 for(const m of input.market_snapshots)assert.equal((await store.readMarketSnapshot(m.id)).sha256,digest(m))
 const body=commitFor(input),accepted=await store.commitEvaluationResult(body),duplicate=await store.commitEvaluationResult(body)
 assert.equal(accepted.status,'accepted');assert.equal(duplicate.status,'duplicate');assert.equal(duplicate.evaluation_ref,accepted.evaluation_ref)
 await assert.rejects(()=>store.commitEvaluationResult({...body,expected_revision:1}),e=>e.code==='idempotency_conflict')
 await assert.rejects(()=>store.commitEvaluationResult(commitFor(input,{key:'different-key',revision:0})),e=>e.code==='revision_conflict')
 const unchanged=await store.readObservation(input.observation.id);assert.deepEqual(unchanged.observation,input.observation);assert.equal(unchanged.revision,1)
 return {passed:true,read_operations:3,commit_receipt:accepted,registration_unchanged:true}
}
