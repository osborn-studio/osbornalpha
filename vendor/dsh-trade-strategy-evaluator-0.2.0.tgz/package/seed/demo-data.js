/**
 * Demo Seed（实施方案 §17）。
 *
 * 目标分布（必须稳定命中，否则 Dashboard 演示会「看运气」）：
 *   ≥10 盈利 / ≥10 亏损 / ≥5 跑赢 Benchmark / ≥5 跑输 / 3 触发止损 / 5 达到目标
 *   5 名 Analyst，≥30 个历史策略
 *
 * 做法不是"随机编 30 条"，而是：
 *   1. 在**确定性 Mock 行情**上枚举候选（标的 × 入场交易日 × 方向）；
 *   2. 对每个候选算出真实后续路径的收益 / 有利偏移 / 不利偏移；
 *   3. 按目标分布**贪心挑桶**，并据此反推 target/stop 参数
 *      （宽目标宽止损 = 纯收益策略；近目标 = 命中目标；近止损 = 触发止损）；
 *   4. 用真实 Evaluation Engine 落库评价 —— 因此 Seed 数据与引擎结果**天然一致**，
 *      `strategy_verify_replay` 对种子策略同样能通过。
 *
 * 诚实的边界：这些是**回填的历史演示数据**，每条都带 `seeded: true` 与专门的审计事件，
 * 不会被伪装成"真实发生的分析师提交"。行情与判定都是确定性的，所以它们可复现、可审计。
 */

import { evaluateFrozenStrategy } from '../src/core/evaluation/engine.js'
import { formatDate, formatTimestamp, parseDate } from '../src/core/time.js'
import { appendEvent } from '../src/core/audit.js'
import { createIdFactory } from '../src/core/ids.js'
import { pathToFileURL } from 'node:url'

const REASON_BANK = {
  BUY: [
    'AI 服务器需求超预期，管理层给出上修指引，判断未来一个季度存在估值修复空间。',
    '渠道调研显示库存周期见底，订单能见度提升，风险回报比具备吸引力。',
    '产品周期临近，预计毛利率环比改善，当前位置的隐含预期偏低。',
    '行业资本开支上行，公司作为核心供应商份额提升，看好中期业绩弹性。',
    '技术面突破关键阻力位，成交量配合，短期动能与基本面形成共振。',
    '自由现金流改善叠加回购节奏加快，估值下限被抬升。',
    '大客户订单落地，收入确认节奏前置，短期业绩确定性提高。',
    '成本端原材料价格回落，利润率有望超出市场一致预期。',
  ],
  SELL: [
    '竞争格局恶化，价格战导致份额与毛利率同时承压，判断存在下行风险。',
    '关键客户流失订单被下调，市场一致预期仍有下修空间。',
    '估值处于历史高位而增速放缓，风险回报比不利，建议做空或减持。',
    '库存高企且终端需求疲弱，预计出现连续两个季度的负增长。',
    '一次性收益掩盖了主业走弱，剔除后盈利质量明显劣化。',
    '监管风险上升，潜在罚款与合规成本可能超预期。',
  ],
}

function mulberry32(seed) {
  let state = seed >>> 0
  return () => {
    state = (state + 0x6d2b79f5) >>> 0
    let t = state
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function round(value, decimals = 4) {
  return Math.round((value + Number.EPSILON) * 10 ** decimals) / 10 ** decimals
}

/**
 * 枚举候选：所有 (标的, 入场日, 方向, 持仓期) 组合，并算出该组合的**真实**后续路径特征。
 *
 * 性能与确定性考量：先把每个标的与 Benchmark 的完整日线一次性算出来（对齐到同一个
 * 交易日下标轴），之后所有窗口统计都是纯数组运算，不再逐候选回调行情接口。
 * 这既让 Seed 生成很快，也保证特征与后续 Engine 评价用的是同一批数字。
 */
function buildCandidatePool({ service, minEntryGapDays = 40 }) {
  const provider = service.provider
  const calendar = service.calendar
  const boundary = parseDate(provider.boundary())
  const epoch = parseDate(service.historyEpoch)
  const benchmarks = provider.listBenchmarks()
  const tickers = provider.listTickers().filter((ticker) => !benchmarks.includes(ticker))

  const allDays = calendar.tradingDaysBetween(epoch, boundary)
  const seriesOf = (ticker) => allDays.map((day) => provider.series.get(ticker).bar(day))

  const tickerBars = new Map(tickers.map((ticker) => [ticker, seriesOf(ticker)]))
  const benchmarkBars = new Map(benchmarks.map((ticker) => [ticker, seriesOf(ticker)]))
  const indexOfDate = new Map(allDays.map((day, index) => [formatDate(day), index]))

  // 入场日留出足够后续窗口，否则策略尚未走完，无法构成"历史评价"。
  const lastEntryIndex = Math.max(1, allDays.length - minEntryGapDays - 1)
  const pool = []

  for (const ticker of tickers) {
    const bars = tickerBars.get(ticker)
    for (let entryIndex = 8; entryIndex <= lastEntryIndex; entryIndex += 1) {
      for (const holding of HOLDING_CHOICES) {
        const exitIndex = entryIndex + holding
        if (exitIndex >= allDays.length) continue
        const entry = bars[entryIndex].close
        const exit = bars[exitIndex].close
        let maxHigh = -Infinity
        let minLow = Infinity
        for (let i = entryIndex; i <= exitIndex; i += 1) {
          if (bars[i].high > maxHigh) maxHigh = bars[i].high
          if (bars[i].low < minLow) minLow = bars[i].low
        }
        const benchmarkReturns = {}
        for (const benchmark of benchmarks) {
          const bench = benchmarkBars.get(benchmark)
          const benchEntry = bench[entryIndex].close
          const benchExit = bench[exitIndex].close
          benchmarkReturns[benchmark] = round((benchExit - benchEntry) / benchEntry, 6)
        }
        for (const action of ['BUY', 'SELL']) {
          const rawReturn = action === 'BUY' ? (exit - entry) / entry : (entry - exit) / entry
          const favorable = action === 'BUY' ? (maxHigh - entry) / entry : (entry - minLow) / entry
          const adverse = action === 'BUY' ? (entry - minLow) / entry : (maxHigh - entry) / entry
          pool.push({
            ticker,
            action,
            holding,
            entryIndex,
            exitIndex,
            entry_date: bars[entryIndex].date,
            entry_price: entry,
            exit_date: bars[exitIndex].date,
            exit_price: exit,
            raw_return: round(rawReturn, 6),
            favorable: round(favorable, 6),
            adverse: round(adverse, 6),
            benchmark_returns: benchmarkReturns,
          })
        }
      }
    }
  }
  return { pool, benchmarks, allDays, indexOfDate }
}

const HOLDING_CHOICES = [12, 15, 20, 25]

/**
 * 计算一条候选在给定了 target/stop 之后的**真实**结论（与 Engine 同口径），
 * 用于挑选阶段做桶判定。挑完桶后落库仍走真实 Engine，这里只是选择器。
 */
function classify({ candidate, targetMultiplier, stopMultiplier, benchmark }) {
  const { action, entry_price: entry } = candidate
  const target = action === 'BUY' ? entry * targetMultiplier : entry * (2 - targetMultiplier)
  const stop = action === 'BUY' ? entry * stopMultiplier : entry * (2 - stopMultiplier)
  const targetHit = candidate.favorable >= Math.abs(target / entry - 1)
  const stopHit = candidate.adverse >= Math.abs(stop / entry - 1)
  const benchmarkReturn = candidate.benchmark_returns[benchmark] ?? 0
  const returnIfStop = action === 'BUY' ? stop / entry - 1 : 1 - stop / entry
  const effectiveReturn = stopHit ? returnIfStop : candidate.raw_return
  const alpha = round(effectiveReturn - benchmarkReturn, 6)
  return {
    target,
    stop,
    targetHit,
    stopHit,
    effectiveReturn: round(effectiveReturn, 6),
    alpha,
    win: effectiveReturn > 0,
    outperform: alpha > 0,
  }
}

/**
 * 从池里按**标的轮转**取满足谓词的候选。
 *
 * 曾经的写法是"顺着池子取前 N 个满足谓词的候选"，而池子是按 标的→日期→持仓期→方向
 * 生成的，于是同一个桶的候选几乎全落在第一个标的上（实测 38 条里 31 条是 AAPL），
 * Dashboard 看起来只有一个股票池 —— 对演示是致命的。
 *
 * 现在按轮次（round）轮流从每个标的取：第 r 轮取每个标的匹配列表里的第 r 个候选。
 * 一举解决三件事：
 *   1. 标的均匀分布；
 *   2. 入场日期随轮次自然向前推进（每个标的的匹配列表按日期升序）；
 *   3. 方向按 轮次+标的序号 交替，不会整桶都是 BUY。
 */
function take(pool, used, predicate, count) {
  const keyOf = (candidate) => `${candidate.ticker}|${candidate.entry_date}|${candidate.holding}|${candidate.action}`
  const matches = new Map()
  for (const candidate of pool) {
    if (used.has(keyOf(candidate))) continue
    if (!predicate(candidate)) continue
    if (!matches.has(candidate.ticker)) matches.set(candidate.ticker, [])
    matches.get(candidate.ticker).push(candidate)
  }

  const tickers = [...matches.keys()].sort()
  const picked = []
  let round = 0
  let idleRounds = 0
  while (picked.length < count && idleRounds < 3) {
    let progressed = false
    for (const [index, ticker] of tickers.entries()) {
      if (picked.length >= count) break
      const list = matches.get(ticker)
      const preferred = (round + index) % 2 === 0 ? 'BUY' : 'SELL'
      const candidate =
        list.find((row, position) => position >= round && row.action === preferred && !used.has(keyOf(row)))
        ?? list.find((row, position) => position >= round && !used.has(keyOf(row)))
      if (candidate === undefined) continue
      used.add(keyOf(candidate))
      picked.push(candidate)
      progressed = true
    }
    round += 1
    idleRounds = progressed ? 0 : idleRounds + 1
  }
  return picked
}

/**
 * 灌入 Demo 数据。
 * @param {import('../src/core/service.js').TradeEvaluationService} service
 * @param {{ actor?: object, sessionId?: string }} [options]
 */
export async function seedDemoData(service, options = {}) {
  const actor = options.actor ?? { actor_id: 'seed', role: 'ADMIN' }
  const repository = service.repository
  const provider = service.provider
  const rules = service.rules
  const calendar = service.calendar
  const clock = service.clock
  const ids = createIdFactory({ nextSequence: async (kind, dayKey) => (await repository.nextSequence(kind, dayKey)) })

  // Analyst 是只读参考数据，reset 后需要重建。
  for (const analyst of service.demo.analysts) {
    ;(await repository.put('analysts', { ...analyst, created_at: formatTimestamp(clock.now()) }))
  }

  const { pool, benchmarks } = buildCandidatePool({ service })
  const random = mulberry32(20260916)
  const selectionBenchmark = benchmarks[0]

  const used = new Set()
  const plan = []

  // ── A. 纯收益策略：宽目标宽止损，不触发任何事件，纯粹的收益/Alpha 对比 ──────
  // 阈值取 ±2%（收益）与 ±1%（Alpha），避免把近乎打平的样本算进任何一边，
  // 这样"盈利/亏损/跑赢/跑输"四个桶都是干净的。
  const quadrants = [
    { name: 'win_outperform', want: (v) => v.effectiveReturn > 0.02 && v.alpha > 0.01, count: 6 },
    { name: 'win_underperform', want: (v) => v.effectiveReturn > 0.02 && v.alpha < -0.01, count: 5 },
    { name: 'lose_outperform', want: (v) => v.effectiveReturn < -0.02 && v.alpha > 0.01, count: 5 },
    { name: 'lose_underperform', want: (v) => v.effectiveReturn < -0.02 && v.alpha < -0.01, count: 6 },
  ]
  for (const quadrant of quadrants) {
    const picked = take(
      pool,
      used,
      (candidate) => quadrant.want(classify({ candidate, targetMultiplier: 1.5, stopMultiplier: 0.5, benchmark: selectionBenchmark })),
      quadrant.count,
    )
    for (const candidate of picked) {
      plan.push({ candidate, benchmark: selectionBenchmark, kind: 'pure', targetMultiplier: 1.5, stopMultiplier: 0.5, bucket: quadrant.name })
    }
  }

  // ── B. 5 条达到目标价：目标放在真实有利偏移之内，止损放得很远 ──────────────
  const targetPicked = take(pool, used, (candidate) => candidate.favorable >= 0.09 && candidate.raw_return > -0.15, 5)
  for (const candidate of targetPicked) {
    plan.push({ candidate, benchmark: selectionBenchmark, kind: 'target', targetMultiplier: 1.05, stopMultiplier: 0.6, bucket: 'target_reached' })
  }

  // ── C. 3 条触发止损：止损放在真实不利偏移之内，目标放得很远 ────────────────
  const stopPicked = take(pool, used, (candidate) => candidate.adverse >= 0.09 && candidate.favorable < 0.09, 3)
  for (const candidate of stopPicked) {
    plan.push({ candidate, benchmark: selectionBenchmark, kind: 'stop', targetMultiplier: 1.6, stopMultiplier: 0.97, bucket: 'stop_loss' })
  }

  // ── D. ACTIVE：入场在最近几天，持仓期未走完，用于演示监控 ─────────────────
  const boundary = parseDate(provider.boundary())
  const activeEntries = []
  for (const offset of [4, 3, 2, 1]) {
    const entryDay = calendar.advanceTradingDays(boundary, -offset)
    activeEntries.push({ day: formatDate(entryDay), offset })
  }

  const analysts = service.demo.analysts
  const assignments = [
    'john', 'mary', 'david', 'sarah', 'michael',
    'john', 'mary', 'david', 'sarah', 'michael',
    'john', 'mary', 'david', 'sarah', 'michael',
    'john', 'mary', 'david', 'sarah', 'michael',
    'john', 'mary', 'david', 'sarah', 'michael', 'john', 'mary', 'david', 'sarah', 'michael',
  ]

  const strategies = []
  const evaluations = []

  /**
   * 种子策略的建仓权重（C2：以权重/百分比建仓）。
   *
   * 循环取值而不是随机：Seed 必须**可复现**，随机会让净值曲线每次都不同，
   * 而"同一 Seed → 同一曲线"正是批次 1 的一条验收标准。
   * 取值跨 6%~16%，使不同分析师的并发敞口不同 —— 于是 C4 的超限挤出
   * 在 Demo 里会**真实发生**（michael 的上限被配成 30%），而不是只存在于测试里。
   */
  const WEIGHT_CYCLE = [8, 10, 12, 6, 15, 10, 16, 9]

  /** 按序号取权重：稳定、可复现。 */
  const weightFor = (index) => WEIGHT_CYCLE[index % WEIGHT_CYCLE.length]

  // 历史（已评价）策略
  for (const [index, item] of plan.entries()) {
    const analystId = assignments[index % assignments.length]
    const { candidate, benchmark } = item
    const bars = await provider.getHistory(candidate.ticker, candidate.entry_date, candidate.entry_date)
    const snapshot = bars[0]
    const createdAt = `${candidate.entry_date}T09:30:00Z`
    const strategyId = await ids.strategy(parseDate(candidate.entry_date))
    const target = round(item.candidate.action === 'BUY' ? candidate.entry_price * item.targetMultiplier : candidate.entry_price * (2 - item.targetMultiplier), 4)
    const stop = round(item.candidate.action === 'BUY' ? candidate.entry_price * item.stopMultiplier : candidate.entry_price * (2 - item.stopMultiplier), 4)

    const strategy = {
      strategy_id: strategyId,
      analyst_id: analystId,
      ticker: candidate.ticker,
      action: candidate.action,
      position_before: item.candidate.action === 'BUY' ? 0 : 500,
      quantity: 100,
      weight_pct: weightFor(index),
      entry_price: round(candidate.entry_price, 4),
      target_price: target,
      stop_loss: stop,
      holding_period: candidate.holding,
      benchmark,
      reason: REASON_BANK[candidate.action][Math.floor(random() * REASON_BANK[candidate.action].length)],
      created_at: createdAt,
      created_by: analystId,
      market_snapshot: { price: snapshot.close, timestamp: snapshot.timestamp, volume: snapshot.volume, as_of: candidate.entry_date, source: provider.name },
      status: 'ACTIVE',
      frozen: true,
      frozen_at: createdAt,
      frozen_by: analystId,
      updated_at: createdAt,
      performance: null,
      evaluation_id: null,
      status_reason: null,
      session_id: null,
      seeded: true,
      seed_bucket: item.bucket,
    }

    ;(await repository.put('strategies', strategy))
    ;(await emit(repository, { at: createdAt, type: 'STRATEGY_CREATED', strategy_id: strategyId, analyst_id: analystId, actor, payload: { seeded: true, bucket: item.bucket, ticker: candidate.ticker, action: candidate.action, entry_price: strategy.entry_price, target_price: target, stop_loss: stop, holding_period: candidate.holding, benchmark } }))
    ;(await emit(repository, { at: createdAt, type: 'MARKET_SNAPSHOT_CAPTURED', strategy_id: strategyId, analyst_id: analystId, actor, payload: { ...strategy.market_snapshot, seeded: true } }))
    ;(await emit(repository, { at: createdAt, type: 'STRATEGY_FROZEN', strategy_id: strategyId, analyst_id: analystId, actor, payload: { status: 'ACTIVE', frozen: true, seeded: true } }))

    // 用真实 Engine 评价（同一份确定性行情），保证 Seed 与重算一致。
    const computed = await evaluateFrozenStrategy({
      strategy,
      provider,
      rules,
      calendar,
      asOf: candidate.exit_date,
      quantity: strategy.quantity,
    })
    const evaluationTime = `${candidate.exit_date}T20:30:00Z`
    const evaluation = {
      ...computed,
      evaluation_id: await ids.evaluation(parseDate(candidate.exit_date)),
      evaluation_time: evaluationTime,
      evaluated_by: 'seed_engine',
      session_id: null,
      seeded: true,
    }
    ;(await repository.put('evaluations', evaluation))

    const finalStatus = evaluation.stop_loss_triggered ? 'STOPPED' : 'COMPLETED'
    const finalized = {
      ...strategy,
      status: finalStatus,
      status_reason: evaluation.stop_loss_triggered ? 'STOP_LOSS' : 'HOLDING_PERIOD_END',
      evaluation_id: evaluation.evaluation_id,
      updated_at: evaluationTime,
      performance: {
        as_of: evaluation.exit_date,
        price: evaluation.exit_price,
        unrealized_return: evaluation.strategy_return,
        unrealized_alpha: evaluation.alpha,
        holding_days: evaluation.holding_days,
        peak_price: Math.max(...evaluation.price_timeline.map((p) => p.close)),
        trough_price: Math.min(...evaluation.price_timeline.map((p) => p.close)),
        target_reached: evaluation.target_reached,
        target_reached_on: evaluation.target_reached_on,
        stop_loss_triggered: evaluation.stop_loss_triggered,
        stop_loss_triggered_on: evaluation.stop_loss_triggered_on,
        updated_at: evaluationTime,
      },
    }
    ;(await repository.put('strategies', finalized))
    ;(await emit(repository, { at: evaluationTime, type: 'EVALUATION_COMPLETED', strategy_id: strategyId, evaluation_id: evaluation.evaluation_id, analyst_id: analystId, actor, payload: { seeded: true, strategy_return: evaluation.strategy_return, benchmark_return: evaluation.benchmark_return, alpha: evaluation.alpha, max_drawdown: evaluation.max_drawdown, score: evaluation.score, calculation_version: evaluation.calculation_version, window: evaluation.window } }))
    ;(await emit(repository, { at: evaluationTime, type: finalStatus === 'STOPPED' ? 'STRATEGY_STOPPED' : 'STRATEGY_COMPLETED', strategy_id: strategyId, evaluation_id: evaluation.evaluation_id, analyst_id: analystId, actor, payload: { status: finalStatus, seeded: true } }))

    strategies.push(finalized)
    evaluations.push(evaluation)
  }

  // ACTIVE 策略（未评价，持仓期未走完）
  const activeTickers = ['NVDA', 'TSLA', 'AMZN', 'MSFT']
  for (const [index, entry] of activeEntries.entries()) {
    const analystId = assignments[(plan.length + index) % assignments.length]
    const ticker = activeTickers[index % activeTickers.length]
    const entryBar = await provider.getBar(ticker, entry.day)
    const action = index % 3 === 2 ? 'SELL' : 'BUY'
    const entryPrice = round(entryBar.close, 4)
    const target = action === 'BUY' ? round(entryPrice * 1.12, 4) : round(entryPrice * 0.9, 4)
    const stop = action === 'BUY' ? round(entryPrice * 0.9, 4) : round(entryPrice * 1.1, 4)
    const createdAt = `${entry.day}T09:30:00Z`
    const strategyId = await ids.strategy(parseDate(entry.day))
    const strategy = {
      strategy_id: strategyId,
      analyst_id: analystId,
      ticker,
      action,
      position_before: action === 'BUY' ? 0 : 300,
      quantity: 100,
      weight_pct: weightFor(plan.length + index),
      entry_price: entryPrice,
      target_price: target,
      stop_loss: stop,
      holding_period: 20,
      benchmark: benchmarks[0],
      reason: REASON_BANK[action][Math.floor(random() * REASON_BANK[action].length)],
      created_at: createdAt,
      created_by: analystId,
      market_snapshot: { price: entryBar.close, timestamp: entryBar.timestamp, volume: entryBar.volume, as_of: entry.day, source: provider.name },
      status: 'ACTIVE',
      frozen: true,
      frozen_at: createdAt,
      frozen_by: analystId,
      updated_at: createdAt,
      performance: null,
      evaluation_id: null,
      status_reason: null,
      session_id: null,
      seeded: true,
      seed_bucket: 'active',
    }
    ;(await repository.put('strategies', strategy))
    ;(await emit(repository, { at: createdAt, type: 'STRATEGY_CREATED', strategy_id: strategyId, analyst_id: analystId, actor, payload: { seeded: true, bucket: 'active', ticker, action, entry_price: entryPrice, target_price: target, stop_loss: stop, holding_period: 20 } }))
    ;(await emit(repository, { at: createdAt, type: 'MARKET_SNAPSHOT_CAPTURED', strategy_id: strategyId, analyst_id: analystId, actor, payload: { ...strategy.market_snapshot, seeded: true } }))
    ;(await emit(repository, { at: createdAt, type: 'STRATEGY_FROZEN', strategy_id: strategyId, analyst_id: analystId, actor, payload: { status: 'ACTIVE', frozen: true, seeded: true } }))
    strategies.push(strategy)
  }

  // 两条已取消 + 两条草稿（用于演示 cancel 与 freeze 端点）
  const extras = [
    { status: 'CANCELLED', ticker: 'AMZN', action: 'BUY', offset: 6 },
    { status: 'CANCELLED', ticker: 'TSLA', action: 'SELL', offset: 5 },
    { status: 'DRAFT', ticker: 'NVDA', action: 'BUY', offset: 2 },
    { status: 'DRAFT', ticker: 'MSFT', action: 'BUY', offset: 1 },
  ]
  for (const [index, extra] of extras.entries()) {
    const day = formatDate(calendar.advanceTradingDays(boundary, -extra.offset))
    const bar = await provider.getBar(extra.ticker, day)
    const analystId = assignments[(plan.length + activeEntries.length + index) % assignments.length]
    const entryPrice = round(bar.close, 4)
    const createdAt = `${day}T09:30:00Z`
    const strategyId = await ids.strategy(parseDate(day))
    const frozen = extra.status !== 'DRAFT'
    const strategy = {
      strategy_id: strategyId,
      analyst_id: analystId,
      ticker: extra.ticker,
      action: extra.action,
      position_before: 0,
      quantity: 100,
      weight_pct: weightFor(plan.length + activeEntries.length + index),
      entry_price: entryPrice,
      target_price: extra.action === 'BUY' ? round(entryPrice * 1.15, 4) : round(entryPrice * 0.88, 4),
      stop_loss: extra.action === 'BUY' ? round(entryPrice * 0.92, 4) : round(entryPrice * 1.08, 4),
      holding_period: extra.status === 'DRAFT' ? 30 : 20,
      benchmark: benchmarks[0],
      reason: REASON_BANK[extra.action][0],
      created_at: createdAt,
      created_by: analystId,
      market_snapshot: { price: bar.close, timestamp: bar.timestamp, volume: bar.volume, as_of: day, source: provider.name },
      status: extra.status,
      frozen,
      frozen_at: frozen ? createdAt : null,
      frozen_by: frozen ? analystId : null,
      updated_at: createdAt,
      performance: null,
      evaluation_id: null,
      status_reason: null,
      session_id: null,
      seeded: true,
      seed_bucket: extra.status.toLowerCase(),
    }
    ;(await repository.put('strategies', strategy))
    ;(await emit(repository, { at: createdAt, type: 'STRATEGY_CREATED', strategy_id: strategyId, analyst_id: analystId, actor, payload: { seeded: true, bucket: strategy.seed_bucket, ticker: extra.ticker, action: extra.action } }))
    ;(await emit(repository, { at: createdAt, type: 'MARKET_SNAPSHOT_CAPTURED', strategy_id: strategyId, analyst_id: analystId, actor, payload: { ...strategy.market_snapshot, seeded: true } }))
    if (frozen) (await emit(repository, { at: createdAt, type: 'STRATEGY_FROZEN', strategy_id: strategyId, analyst_id: analystId, actor, payload: { status: 'ACTIVE', seeded: true } }))
    if (extra.status === 'CANCELLED') {
      const cancelledAt = `${formatDate(calendar.advanceTradingDays(parseDate(day), 1))}T15:00:00Z`
      ;(await repository.put('strategies', { ...strategy, cancelled_at: cancelledAt, cancelled_by: analystId, cancel_reason: '分析师撤回（Demo 数据）' }))
      ;(await emit(repository, { at: cancelledAt, type: 'STRATEGY_CANCELLED', strategy_id: strategyId, analyst_id: analystId, actor, payload: { seeded: true, reason: '分析师撤回（Demo 数据）' } }))
    }
    strategies.push((await repository.get('strategies', strategyId)))
  }

  const distribution = summarizeDistribution(evaluations)
  return {
    seeded_at: formatTimestamp(clock.now()),
    analysts: service.demo.analysts.length,
    strategies: strategies.map((row) => row.strategy_id),
    evaluations: evaluations.map((row) => row.evaluation_id),
    distribution,
  }
}

function summarizeDistribution(evaluations) {
  return {
    total_evaluated: evaluations.length,
    profitable: evaluations.filter((row) => row.strategy_return > 0).length,
    losing: evaluations.filter((row) => row.strategy_return < 0).length,
    outperform_benchmark: evaluations.filter((row) => row.alpha > 0).length,
    underperform_benchmark: evaluations.filter((row) => row.alpha < 0).length,
    target_reached: evaluations.filter((row) => row.target_reached).length,
    stop_loss_triggered: evaluations.filter((row) => row.stop_loss_triggered).length,
  }
}

async function emit(repository, event) {
  return (await appendEvent(repository, event))
}

/** 直接运行本文件时（`node seed/demo-data.js --reset`）创建一个独立服务并灌数据。 */
async function main() {
  const { normalizePluginConfig } = await import('../src/core/config.js')
  const { TradeEvaluationService } = await import('../src/core/service.js')
  const { homedir } = await import('node:os')
  const { join } = await import('node:path')

  const config = normalizePluginConfig({})
  const dataDir = process.env.TRADE_EVAL_DATA_DIR ?? join(process.env.DSH_HOME ?? join(homedir(), '.dsh'), 'trade-strategy-evaluator')
  const service = new TradeEvaluationService({ config, dataDir })
  await service.initialize()
  if (process.argv.includes('--reset')) (await service.repository.reset())
  const result = await seedDemoData(service, { actor: { actor_id: 'seed', role: 'ADMIN' } })
  console.log(JSON.stringify({ data_dir: dataDir, driver: service.driver, ...result }, null, 2))
  ;(await service.close())
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) {
  ;main().catch((error) => {
    console.error(error)
    process.exitCode = 1
  })
}
