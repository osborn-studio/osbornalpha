---
name: trade-strategy-evaluation
description: Manage and evaluate analyst trading strategies end to end — submit and freeze a strategy with its market snapshot, monitor real market outcomes, compute deterministic Return/Alpha/Drawdown/target/stop-loss metrics, compare against a benchmark, score it with configurable rules, generate the strategy/analyst/team reports, and replay the full lifecycle. Use this whenever a request involves creating, freezing, monitoring, evaluating, scoring, ranking, reporting on, or auditing a trading strategy or analyst performance.
whenToUse: 用户要提交/冻结交易策略、查看策略表现、评价策略、对比 Benchmark、生成策略或分析师绩效报告、查看 Replay、或询问策略评分时加载本 Skill。
---

# 交易策略评估（Trade Strategy Evaluation）

本 Skill 定义一个**交易策略生命周期管理与分析师绩效评估**流程。

重要定位：本系统**不是**交易执行系统，**不推荐股票**，**不自动下单**，**不决定真实资金配置**。
它的产出是"可审计的评价"，不是"投资建议"。

## 一、六条不可越界的规则（违反即为错误答案）

1. **数值只能来自确定性工具。** Return / P&L / Benchmark Return / Alpha / Maximum Drawdown /
   Target Achievement / Stop Loss / Holding Days / Risk-Reward / Score 一律由
   `evaluation_run` 计算。你**永远不要**自己做除法、自己算百分比、自己估算收益。
2. **绝不编造行情。** 任何价格、成交量、时间戳都必须来自 `market_*` 工具。
   你没有"记得"的价格，也不能根据常识猜一个价格。
3. **绝不修改已冻结的策略。** 策略一旦冻结（`frozen: true`），核心决策字段永久不可变。
   工具会拒绝，你也不应尝试。冻结后唯一能变的是 `status` 与非决策性的 `performance`。
4. **绝不使用未来信息。** 行情有硬性数据上界（`data_boundary`）。
   任何晚于上界的请求都会失败——这是设计，不是 Bug。不要试图绕过。
5. **绝不改写历史评价。** Evaluation 由 Engine 写入且不可修改。你只能读取它、
   重新调用 `evaluation_run`（可重复且结果相同）、或调用 `strategy_verify_replay` 校验一致性。
6. **事实与判断必须分区。** 报告里的事实区只放工具返回值；
   你的解释只能通过 `commentary` 参数提交，它会被放进带免责声明的独立小节。

## 二、标准工作流

### 场景 A：提交一条策略

1. `market_universe` —— 确认标的、Benchmark 与当前数据上界。
2. `market_get_snapshot` —— 取当前快照（说明"提交当时"的市场状态）。
3. `strategy_create` —— 提交。工具会自动捕获快照并冻结策略，返回 `STR-YYYYMMDD-NNN`。
   - **方向一致性是硬校验**：BUY 必须 `stop_loss < entry_price < target_price`；
     SELL 必须 `target_price < entry_price < stop_loss`。不满足会失败，不要试图绕过。
   - `reason` 会被原样保存，永不被改写，所以它应当完整记录分析师当时的判断依据。
4. 向用户复述 Strategy ID、冻结时间、当时的市场快照与核心决策参数。

### 场景 B：查看 / 跟踪一条策略

1. `strategy_get` 取完整记录；`strategy_status` 取生命周期状态。
2. `strategy_monitor` 拉最新行情、更新浮动表现、检查目标/止损/持仓期满。
3. 需要看全部在跟踪策略时用 `strategy_monitor_all`。

### 场景 C：评价一条策略

1. `strategy_status` 确认已冻结；未冻结的策略**不能**评价。
2. `evaluation_run` 执行确定性评价。若同一窗口已有评价，会返回 `reused: true`
   且结果与上次完全相同——这是特性，不是缓存 Bug。
3. 需要证据时调用 `strategy_verify_replay`，它会重算并逐字段比对。
4. 用 `report_strategy` 生成报告；你的解释通过 `commentary` 传入。

### 场景 D：分析师 / 团队绩效

1. `manager_dashboard` 取全员汇总（策略数/完成数/胜率/平均收益/平均 Alpha/最大回撤/评分）。
2. `analyst_performance` 或 `report_analyst` 深入单个分析师。
3. `report_team` 看团队维度。
4. 排序与对比请基于**工具返回的数字**，不要用你自己的印象排序。

### 场景 D2：模拟盘组合（权重 / 净值式）

每个分析师有一套**独立的模拟盘组合**：起始净值 100，每条已冻结策略 = 一个"手"，
占当时净值的 `weight_pct`。买卖都在组合内闭环。

1. `portfolio_get` —— 净值、累计收益率、当前持仓、已平仓明细、挤出与被拒指令。
2. `portfolio_nav` —— 净值曲线（可用 `from`/`to` 切片）与该区间最大回撤。
3. `portfolio_recompute` —— **从策略流重算**并与落库快照逐字段比对。

三条必须记住的口径：

- **绝不出金额。** 组合是权重/净值式记账：只谈收益率与净值。不要换算成"多少钱"。
- **超限挤出是系统决定，不是分析师的操作。** 当新指令会使总敞口超过该分析师的
  `max_position_pct` 时，系统按配置策略（`fifo` 最旧优先 / `largest_weight` 最大权重优先 /
  `worst_performer` 最差表现优先）自动平掉旧仓，并落 `POSITION_EVICTED` 事件。
  平仓价是**当时市价**。你可以解释这件事，但不要把它说成分析师自己的卖出决定。
- **净值可复算。** 说"这个组合赚了多少"之前，用 `portfolio_recompute` 拿证据 ——
  它同时返回对账恒等式（各手盈亏之和 = 净值变动），证明组合层与逐笔层没有各算各的。

权重与逐笔的关系：某一手的收益率**逐字段等于**该策略的评价收益率，
因此"组合净值变动 = Σ(权重 × 该手收益率)"这条对账可以直接复核。

### 场景 E：Replay / 审计

1. `strategy_replay` 返回完整生命周期时间线与 11 项审计问答。
2. 时间线里每条事件都带 `at` 与 `actor`，可以直接复述"谁在什么时候做了什么"。

## 三、角色与权限

| 角色 | 能做什么 | 不能做什么 |
|---|---|---|
| ANALYST | 创建策略、查看**自己的**策略、运行评价 | 修改已冻结策略、修改 Evaluation、查看他人策略 |
| MANAGER | 查看团队策略、分析师绩效、Replay、报告、运行监控 | 修改 Evaluation、改评分规则 |
| ADMIN | 配置评分规则、管理分析师、重置 Demo 数据 | 修改 Evaluation（任何角色都不能） |

调用工具时可以用 `actor` 参数声明身份：`{ "actor_id": "john", "role": "ANALYST" }`。
权限不足会返回 `UNAUTHORIZED`；这是正确行为，不要重试同一个越权调用。

## 四、报告语言要求

生成报告或总结时，严格按以下顺序组织：

1. **FACTUAL METRICS 事实数据** —— 全部来自工具返回，逐条列出，不做解释。
2. **BENCHMARK COMPARISON** —— 策略收益 / Benchmark 收益 / Alpha 三者并列。
   务必强调 Alpha：市场普涨时所有人看起来都不错，只有 Alpha 能区分真实能力。
3. **RISK METRICS** —— Maximum Drawdown、是否触发止损、Risk/Reward。
4. **RULE-BASED SCORE** —— Score 与权重分解、`calculation_version`。
5. **LLM COMMENTARY 模型分析** —— 放在最后，并明确标注
   "以下内容为模型生成的分析性解释，不属于原始事实数据。"

## 四之二、组合层的说法边界

组合数字（净值、收益率、回撤、挤出）**全部来自确定性账本**。
规则与逐笔指标相同：不要自己算、不要估算、不要把不同 `accounting_version` 的净值混着比较。
`accounting_version`（当前 `w1`）标识口径版本；口径改了，历史净值就不再可比 —— 引用时要带上它。

## 五、解释 Alpha 时的注意事项

- Alpha = 策略收益 − Benchmark 收益。它剥离了市场整体涨跌。
- 正 Alpha 表示跑赢 Benchmark；负 Alpha 表示跑输，即使绝对收益为正。
- 不要用"表现不错"掩盖负 Alpha。忠实报告。

## 六、Demo 提示

系统默认运行在**模拟时钟**上，从 `demo-config.json` 的 `clock.start_date` 按交易日推进。
Demo 情境下可以用 `demo_advance_clock` 推进时间，让策略走完持仓期后再评价。
`demo_reset`（ADMIN）会清空并重新灌入 Seed 数据。
