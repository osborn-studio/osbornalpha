import schema from './kline-schema.js'
import { validateSchema } from '../engine/schema.js'
import { parseStrict, bytesDigest, timestamp, requireInput, InputError } from '../engine/canonical.js'
import { validateMarketSnapshot } from '../engine/observation.js'
export const ALPHA_KLINE_ADAPTER_VERSION = 'alpha-kline-adapter/1.0'
/** Host DTO adapter. UTC seconds are not a session date or evidence of public availability. */
export function mapAlphaKline({raw,security,calendar,request,id,providerVersion,evidence,as_of}) {
  try {
    const dto=parseStrict(raw)
    validateSchema(dto,schema)
    requireInput(dto && typeof dto==='object')
    if(dto.error || !Array.isArray(dto.bars)) return {ok:false,error:{code:'data_insufficient',reason:'provider_missing'}}
    if(!dto.bars.length)return {ok:false,error:{code:'data_insufficient',reason:'empty_bars'}}
    requireInput(dto.source === dto.meta.source && dto.meta.returnedBars === dto.bars.length,'invalid_schema','bar_count_mismatch')
    requireInput(dto.meta && dto.ticker===security.ticker && dto.meta.currencyCode===security.currency && dto.meta.timezone==='America/New_York' && dto.meta.market==='US','data_insufficient','market_mismatch')
    requireInput(dto.meta.adjustment==='none','data_insufficient','adjustment_unsupported')
    requireInput(evidence && Array.isArray(evidence.bars) && evidence.bars.length===dto.bars.length,'data_insufficient','missing_split_factors')
    requireInput(evidence.raw_sha256===bytesDigest(raw),'hash_mismatch')
    requireInput(evidence.algorithm==='raw_close_times_verified_split_factor_no_cash_dividend','data_insufficient','adjustment_unsupported')
    const mapped=dto.bars.map((b,i)=>{
      requireInput(Number.isSafeInteger(b.time) && b.time>0 && Number.isFinite(b.time*1000))
      const proof=evidence.bars[i],session=calendar.sessions.find(s=>s.date===proof.session_date)
      requireInput(session && proof.source_time===b.time && new Date(b.time*1000).toISOString().slice(0,10)===session.date,'invalid_schema','bar_session_mismatch')
      requireInput(typeof proof.receipt_ref==='string' && proof.receipt_ref.length>0,'data_insufficient','missing_availability_evidence')
      timestamp(proof.available_at)
      return {session_date:session.date,open:b.open,high:b.high,low:b.low,close:b.close,volume:b.volume,split_factor:proof.split_factor,split_factor_verified:proof.verified,available_at:proof.available_at,receipt_ref:proof.receipt_ref}
    })
    requireInput(typeof dto.meta.fallbackUsed==='boolean' && ['complete','partial'].includes(dto.meta.completeness) && Array.isArray(dto.meta.warnings))
    const snapshot={schema_version:'market-snapshot/1.0',id,security:structuredClone(security),provider:{name:dto.source,version:providerVersion},adapter_version:ALPHA_KLINE_ADAPTER_VERSION,request,timezone:dto.meta.timezone,currency:dto.meta.currencyCode,calendar_version:calendar.version,adjustment:'none_with_verified_split_factors',fetched_at:dto.meta.fetchedAt,available_at:evidence.available_at,coverage:{from:dto.meta.coverageStart,to:dto.meta.coverageEnd,complete:dto.meta.completeness==='complete'},fallback:dto.meta.fallbackUsed,warnings:dto.meta.warnings,raw_sha256:bytesDigest(raw),bars:mapped,session_status:evidence.session_status??[]}
    validateMarketSnapshot(snapshot,calendar,as_of)
    return {ok:true,snapshot}
  }catch(e){return {ok:false,error:{code:e instanceof InputError?e.code:'invalid_schema',reason:e instanceof InputError?e.reason:'invalid_kline_dto'}}}
}
