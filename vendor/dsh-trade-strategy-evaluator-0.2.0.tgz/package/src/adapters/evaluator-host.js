import { createEvaluationHttpClient, EvaluationStoreError, RPC_VERSION } from './evaluator-http.js'
import { evaluateObservation, inputDigest } from '../engine/observation.js'
import { requireInput, digest } from '../engine/canonical.js'
import { exactKeys } from '../engine/schema.js'
/** Remote results have exactly one authority. There is intentionally no local fallback. */
export function createEvaluatorHost({mode='local',remote,localStore}={}) {
  requireInput(['local','alpha-connected'].includes(mode))
  const store=mode==='alpha-connected'?createEvaluationHttpClient(remote):localStore
  return Object.freeze({
    mode,
    status(){return {mode,authority:mode==='local'?'dsh-local':'alpha',configured:mode==='local'?!!localStore:!!(remote?.baseUrl&&remote?.tokenProvider&&remote?.ownerScope),decision_write:false}},
    async evaluate(request){
      exactKeys(request,['observation_id','market_snapshot_ids','calendar','information_set','as_of','expected_revision','idempotency_key'])
      if(!store)throw new EvaluationStoreError('not_configured',503)
      requireInput(Array.isArray(request.market_snapshot_ids)&&request.market_snapshot_ids.length<=2&&new Set(request.market_snapshot_ids).size===request.market_snapshot_ids.length)
      const frozen=await store.readObservation(request.observation_id)
      const snapshots=await Promise.all(request.market_snapshot_ids.map(id=>store.readMarketSnapshot(id)))
      const input={schema_version:'evaluator-input-output/1.0',observation:frozen.observation,observation_sha256:frozen.sha256,calendar:request.calendar,market_snapshots:snapshots.map(x=>x.snapshot),market_snapshot_sha256s:snapshots.map(x=>x.sha256),information_set:request.information_set,as_of:request.as_of,input_sha256:''}
      input.input_sha256=inputDigest(input)
      const computed=evaluateObservation(input)
      if(!computed.ok)throw new EvaluationStoreError(computed.error.code,422)
      const body={schema_version:RPC_VERSION,observation_ref:{id:frozen.observation.id,sha256:frozen.sha256},market_snapshot_refs:snapshots.map(x=>({id:x.snapshot.id,sha256:x.sha256})),engine_version:computed.result.engine_version,rule_version:computed.result.rule_version,input_sha256:input.input_sha256,input,result:computed.result,result_sha256:computed.result_sha256,expected_revision:request.expected_revision,idempotency_key:request.idempotency_key,request_key:request.idempotency_key}
      const receipt=await store.commitEvaluationResult(body)
      return {mode,receipt,...computed}
    }
  })
}
