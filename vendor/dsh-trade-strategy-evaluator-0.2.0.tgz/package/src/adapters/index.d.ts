import type {EvaluationInput,EvaluationOutcome,InformationSet,FrozenCalendar,MarketSnapshot,Security} from '../engine/index.js';
import type {EvaluationStore,EvaluatorTokenProvider,OwnerScope} from '../ports/evaluation-store.js';
import type {RepositoryPort} from '../ports/repository.js';
export interface RemoteOptions {baseUrl?:string;ownerScope?:OwnerScope;tokenProvider?:EvaluatorTokenProvider;timeoutMs?:number;maxResponseBytes?:number;fetchImpl?:typeof fetch}
export declare function createEvaluationHttpClient(options?:RemoteOptions):EvaluationStore;
export declare function createLocalEvaluationStore(repository:RepositoryPort):EvaluationStore;
export declare function stageSyntheticInput(repository:RepositoryPort,input:EvaluationInput,approval:{confirmed:boolean;mapping:{source_observation_ref:string;local_ref:string};operator:string}):Promise<{status:string}>;
export interface HostRequest {observation_id:string;market_snapshot_ids:string[];calendar:FrozenCalendar;information_set:InformationSet;as_of:string;expected_revision:number;idempotency_key:string}
export declare function createEvaluatorHost(options?:{mode?:'local'|'alpha-connected';remote?:RemoteOptions;localStore?:EvaluationStore}):{mode:string;status():{mode:string;authority:string;configured:boolean;decision_write:false};evaluate(request:HostRequest):Promise<EvaluationOutcome & {mode:string;receipt:unknown}>};
export declare class EvaluationStoreError extends Error {code:string;status:number;retryable:boolean}
export declare const RPC_VERSION:'evaluator-rpc/1.0';
export declare const ALPHA_KLINE_ADAPTER_VERSION:'alpha-kline-adapter/1.0';
export declare function mapAlphaKline(input:{raw:string;security:Security;calendar:FrozenCalendar;request:MarketSnapshot['request'];id:string;providerVersion:string;evidence:unknown;as_of:string}):{ok:true;snapshot:MarketSnapshot}|{ok:false;error:{code:string;reason:string}};
export type {EvaluationStore,EvaluatorTokenProvider,OwnerScope};
