import { SerialExecutor } from './serial-executor.js'
import { RPC_VERSION, EvaluationStoreError, validateCommit } from './evaluator-http.js'
import { digest, requireInput } from '../engine/canonical.js'
import { evaluateObservation } from '../engine/observation.js'
const KEY='observation-evaluation/v1',queues=new WeakMap()
function queue(repo){if(!queues.has(repo))queues.set(repo,new SerialExecutor());return queues.get(repo)}
const initial=()=>({observations:{},snapshots:{},results:{},audit:[],outbox:[]})
/** Explicit operator-only synthetic import for local conformance. No history sync or real import. */
export async function stageSyntheticInput(repository,input,{confirmed=false,mapping,operator}={}) {
  requireInput(confirmed===true && typeof operator==='string' && operator.length>0 && mapping?.source_observation_ref===input.observation.id && typeof mapping.local_ref==='string' && mapping.local_ref.length>0,'scope_denied')
  requireInput(input.observation.synthetic===true && input.observation.research_stream==='descriptive','policy_blocked')
  const checked=evaluateObservation(input);requireInput(checked.ok,checked.error?.code??'invalid_schema')
  return queue(repository).run(async()=>{
    const state=(await repository.readMeta(KEY))??initial(),id=input.observation.id
    if(state.observations[id]){
      requireInput(state.observations[id].sha256===input.observation_sha256,'idempotency_conflict')
      return {status:'duplicate'}
    }
    state.observations[id]={schema_version:RPC_VERSION,owner_scope:input.observation.owner_scope,revision:0,sha256:input.observation_sha256,observation:input.observation,mapping,operator}
    input.market_snapshots.forEach((m,i)=>{
      const existing=state.snapshots[m.id];requireInput(!existing||existing.sha256===input.market_snapshot_sha256s[i],'idempotency_conflict')
      state.snapshots[m.id]={schema_version:RPC_VERSION,owner_scope:input.observation.owner_scope,revision:0,sha256:input.market_snapshot_sha256s[i],snapshot:m}
    })
    await repository.writeMeta(KEY,state);return {status:'accepted'}
  })
}
export function createLocalEvaluationStore(repository) {
  const read=async(kind,id)=>{const s=(await repository.readMeta(KEY))??initial(),r=s[kind][id];if(!r)throw new EvaluationStoreError('not_found',404);const {mapping:_mapping,operator:_operator,...envelope}=r;return envelope}
  return Object.freeze({
    readObservation:id=>read('observations',id),readMarketSnapshot:id=>read('snapshots',id),
    async commitEvaluationResult(body){
      validateCommit(body)
      return queue(repository).run(async()=>{
        const state=(await repository.readMeta(KEY))??initial(),o=state.observations[body.observation_ref.id]
        if(!o)throw new EvaluationStoreError('not_found',404)
        requireInput(o.sha256===body.observation_ref.sha256,'hash_mismatch')
        for(const ref of body.market_snapshot_refs)requireInput(state.snapshots[ref.id]?.sha256===ref.sha256,'hash_mismatch')
        const key=digest({owner:o.owner_scope,key:body.idempotency_key}),old=state.results[key],bodyHash=digest(body)
        if(old){if(old.body_sha256!==bodyHash)throw new EvaluationStoreError('idempotency_conflict',409);return {...old.receipt,status:'duplicate'}}
        if(o.revision!==body.expected_revision)throw new EvaluationStoreError('revision_conflict',409)
        const receipt={schema_version:RPC_VERSION,owner_scope:o.owner_scope,status:'accepted',observation_ref:o.observation.id,revision:o.revision+1,idempotency_key:body.idempotency_key,input_sha256:body.input_sha256,result_sha256:body.result_sha256,evaluation_ref:`local-eval-${bodyHash}`}
        state.results[key]={body_sha256:bodyHash,body,receipt};o.revision++
        state.audit.push({type:'evaluation.append',evaluation_ref:receipt.evaluation_ref,input_sha256:body.input_sha256})
        state.outbox.push({evaluation_ref:receipt.evaluation_ref,result_sha256:body.result_sha256,status:'local_only'})
        // One schema-v1 meta document write commits result, projection, audit and outbox together.
        await repository.writeMeta(KEY,state);return receipt
      })
    }
  })
}
