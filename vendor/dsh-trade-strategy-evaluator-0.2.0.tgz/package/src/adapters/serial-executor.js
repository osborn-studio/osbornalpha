import { AsyncLocalStorage } from 'node:async_hooks'
/** Per-host serialization; nested service calls share a task, independent callers queue. */
export class SerialExecutor {
  #context = new AsyncLocalStorage()
  #tail = Promise.resolve()
  run(fn) {
    if (this.#context.getStore() === this) return fn()
    const task = this.#tail.then(() => this.#context.run(this,fn))
    this.#tail = task.catch(() => {})
    return task
  }
}
