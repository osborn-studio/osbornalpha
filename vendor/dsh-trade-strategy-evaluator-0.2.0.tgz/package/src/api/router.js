/**
 * REST API（实施方案 §14 / §15）。
 *
 * 无框架实现：直接吃 `node:http` 的 (req, res)，因为 DSH 的 webserver 路由
 * 交给插件的就是裸 IncomingMessage/ServerResponse。路由表用"精确 + 最长前缀"
 * 之外的一层内部匹配（方法 + 路径模式），因此新增端点不需要改动 webserver 注册。
 *
 * 全部端点在同一个前缀 `/api/trade-eval` 下；DSH 的 webserver 先匹配精确路由、
 * 再匹配最长前缀，所以本前缀优先于 `dsh-client-connection` 的 `/api`，不会被它截走，
 * 也不会与它冲突。
 *
 * 错误契约：业务失败返回 `{ ok: false, error: { code, message, details } }` + 语义化
 * HTTP 状态码（400/403/404/409/422/500/502），因此"冻结后修改必须失败"这类
 * 不变量在 API 层是可断言的。
 */

import { capabilityMatrix, ROLES } from '../core/auth.js'
import { CODES, HTTP_STATUS_BY_CODE } from '../core/errors.js'
import { InputError } from '../engine/canonical.js'
import { LANGUAGES, LANGUAGE_LABELS, normalizeLanguage } from '../core/i18n.js'

export const API_PREFIX = '/api/trade-eval'

/** @type {Array<{method: string, pattern: string, handler: Function, description: string}>} */
const ROUTES = []

function route(method, pattern, handler, description) {
  ROUTES.push({ method, pattern, handler, description })
}

function match(pattern, pathname) {
  const patternParts = pattern.split('/').filter((part) => part.length > 0)
  const pathParts = pathname.split('/').filter((part) => part.length > 0)
  if (patternParts.length !== pathParts.length) return null
  const params = {}
  for (let i = 0; i < patternParts.length; i += 1) {
    const expected = patternParts[i]
    const actual = pathParts[i]
    if (expected.startsWith(':')) {
      params[expected.slice(1)] = decodeURIComponent(actual)
      continue
    }
    if (expected !== actual) return null
  }
  return params
}

function sendJson(res, status, body) {
  const text = JSON.stringify(body, null, 2)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(text),
    'cache-control': 'no-store',
  })
  res.end(text)
}

async function readBody(req, limitBytes = 1_000_000) {
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > limitBytes) throw new Error(`request body exceeds ${limitBytes} bytes`)
    chunks.push(chunk)
  }
  if (chunks.length === 0) return {}
  const text = Buffer.concat(chunks).toString('utf8')
  if (text.trim().length === 0) return {}
  try {
    return JSON.parse(text)
  } catch (error) {
    throw Object.assign(new Error(`invalid JSON body: ${error.message}`), { code: CODES.VALIDATION })
  }
}

/**
 * 解析报告语言：`?lang=` 优先，其次 `Accept-Language`。
 * 只影响文案，不影响任何数值或判定；认不出时回落到插件默认语言。
 */
function languageFrom(req, url, body) {
  const explicit = body?.language ?? url.searchParams.get('lang') ?? url.searchParams.get('language')
  if (explicit !== null && explicit !== undefined) return normalizeLanguage(explicit, 'zh')
  const header = req.headers['accept-language']
  if (typeof header === 'string') return normalizeLanguage(header, 'zh')
  return undefined
}

/**
 * 解析调用方身份，优先级：**body.actor → 查询串 → 请求头**。
 *
 * ⚠️ 请求头必须参与解析：前端在查询串里通常只带 `role`，而 ANALYST 的身份需要
 * `actor_id` 才能判定"读自己的策略"。若 GET 路由只看查询串，`actor_id` 会缺失并回落到
 * 默认身份（demo_manager），ANALYST 会因此读到 403 —— 实测踩过。
 */
function actorOf(req, url, body) {
  if (body?.actor !== undefined) return body.actor
  // 合并而不是"查询串胜出"：前端常在查询串里只带 `role`，`actor_id` 走请求头。
  // compact() 保证两侧都没有 undefined 键，因此展开不会互相抹掉字段。
  const merged = { ...(actorFrom(req, url, null) ?? {}), ...(actorFromQuery(url, null) ?? {}) }
  return Object.keys(merged).length === 0 ? undefined : merged
}

/**
 * HTTP 层身份的唯一出口 —— 给身份**打上来源标记** `source: 'request'`。
 *
 * 为什么要在这里统一打标记：`actor` 在这条路由里出现 20 次，
 * 逐个加参数迟早漏掉一处，而漏掉的那一处会让"自述身份"被当成"配置层身份"，
 * 在 `identity.requireVerified` 打开时就是个提权口子。
 * 打标记只有这一个出口，因此不存在漏网：下面所有 `actorOf/actorFrom` 的
 * 业务调用都走 `actorRequest`。
 */
function actorRequest(req, url, body) {
  const actor = actorOf(req, url, body)
  return actor === undefined ? undefined : { ...actor, source: 'request' }
}

/** 从查询串解析调用方身份。 */
function actorFrom(req, url, body) {
  if (body?.actor !== undefined) return body.actor
  const headerRole = req.headers['x-actor-role']
  const headerId = req.headers['x-actor-id']
  return compact({
    role: Array.isArray(headerRole) ? headerRole[0] : headerRole,
    actor_id: Array.isArray(headerId) ? headerId[0] : headerId,
  })
}

function actorFromQuery(url, body) {
  if (body?.actor !== undefined) return body.actor
  const role = url.searchParams.get('role')
  const id = url.searchParams.get('actor_id')
  return compact({ role, actor_id: id })
}

/**
 * 丢掉值为 undefined / null 的键。
 *
 * ⚠️ 这一步是必需的：`{ ...a, ...b }` 会把 `b` 里显式的 `undefined` **覆盖**掉 `a` 的取值。
 * 前端在查询串里通常只带 `role`（`actor_id` 走请求头），若查询串产出
 * `{ role: 'ANALYST', actor_id: undefined }` 再去展开，就会把请求头里的 actor_id 抹掉，
 * 身份回落到默认值并误报 403（实测踩过）。
 */
function compact(input) {
  const out = {}
  for (const [key, value] of Object.entries(input ?? {})) {
    if (value === undefined || value === null) continue
    out[key] = value
  }
  return Object.keys(out).length === 0 ? undefined : out
}

// ─────────────────────────────────────────────────────────── meta / health

route('GET', `${API_PREFIX}/health`, async () => ({ ok: true, service: 'dsh-trade-strategy-evaluator', version: 1 }), '健康检查')

route('GET', `${API_PREFIX}/meta`, async ({ service }) => {
  const stats = (await service.stats())
  return {
    ok: true,
    plugin: 'dsh-trade-strategy-evaluator',
    evaluator: stats.evaluator,
    api_prefix: API_PREFIX,
    storage: { driver: stats.driver, requested: stats.storage?.requestedDriver, fallback_reason: stats.storage?.fallbackReason, counts: stats.storage?.counts },
    rules_version: stats.rules_version,
    rules: stats.rules,
    clock: stats.clock,
    language: stats.language,
    languages: LANGUAGES.map((id) => ({ id, label: LANGUAGE_LABELS[id] })),
    market: stats.market,
    endpoints: ROUTES.map((row) => `${row.method} ${row.pattern} — ${row.description}`),
  }
}, '插件元数据、端点清单、存储与时钟状态')

// ─────────────────────────────────────────────────────────── strategies

route('POST', `${API_PREFIX}/observations/evaluate`, async ({service,req,url,body}) => ({
  ok: true, evaluation: await service.evaluateObservation(body?.request, {actor:actorRequest(req,url,body)})
}), '评价已冻结 Observation；远端只追加结果，不编辑 Alpha 研究决定')

route('POST', `${API_PREFIX}/strategies`, async ({ service, req, url, body }) => {
  // auto_freeze: false 时只创建 DRAFT，之后再显式 freeze（§5.1 的 DRAFT → ACTIVE 路径）。
  const strategy = await service.createStrategy(body, {
    actor: actorRequest(req, url, body),
    sessionId: url.searchParams.get('session_id') ?? undefined,
    autoFreeze: body?.auto_freeze,
  })
  return {
    ok: true,
    strategy_id: strategy.strategy_id,
    status: strategy.status,
    frozen: strategy.frozen,
    frozen_at: strategy.frozen_at,
    market_snapshot: strategy.market_snapshot,
    strategy,
  }
}, '创建策略（默认创建即冻结）')

route('GET', `${API_PREFIX}/strategies`, async ({ service, req, url, body }) => {
  const rows = (await service.listStrategies({
    analyst_id: url.searchParams.get('analyst_id') ?? undefined,
    status: url.searchParams.get('status') ?? undefined,
    ticker: url.searchParams.get('ticker') ?? undefined,
    limit: url.searchParams.has('limit') ? Number(url.searchParams.get('limit')) : undefined,
    actor: actorRequest(req, url, body),
  }))
  return { ok: true, count: rows.length, strategies: rows }
}, '列出策略')

route('GET', `${API_PREFIX}/strategies/:id`, async ({ service, req, url, params, body }) => ({
  ok: true,
  strategy: (await service.getStrategy(params.id, { actor: actorRequest(req, url, body) })),
}), '读取策略')

route('POST', `${API_PREFIX}/strategies/:id/freeze`, async ({ service, req, url, params, body }) => {
  const strategy = (await service.freezeStrategy(params.id, { actor: actorRequest(req, url, body), sessionId: url.searchParams.get('session_id') ?? undefined }))
  return { ok: true, strategy_id: strategy.strategy_id, status: strategy.status, frozen: strategy.frozen, frozen_at: strategy.frozen_at }
}, '冻结策略')

route('PATCH', `${API_PREFIX}/strategies/:id`, async ({ service, req, url, params, body }) => {
  // 冻结后修改核心字段 → 409 FROZEN_STRATEGY_IMMUTABLE（§18 关键测试）
  const strategy = (await service.updateStrategy(params.id, body?.patch ?? body, { actor: actorRequest(req, url, body) }))
  return { ok: true, strategy }
}, '修改策略（冻结后必须失败）')

route('POST', `${API_PREFIX}/strategies/:id/cancel`, async ({ service, req, url, params, body }) => {
  const strategy = (await service.cancelStrategy(params.id, { actor: actorRequest(req, url, body), reason: body?.reason, sessionId: url.searchParams.get('session_id') ?? undefined }))
  return { ok: true, strategy_id: strategy.strategy_id, status: strategy.status }
}, '取消策略')

route('GET', `${API_PREFIX}/strategies/:id/status`, async ({ service, req, url, params, body }) => ({
  ok: true,
  ...(await service.getStatus(params.id, { actor: actorRequest(req, url, body) })),
}), '策略生命周期状态')

route('GET', `${API_PREFIX}/strategies/:id/performance`, async ({ service, req, url, params, body }) => {
  const strategy = (await service.getStrategy(params.id, { actor: actorRequest(req, url, body) }))
  const evaluation = strategy.evaluation ?? null
  return {
    ok: true,
    strategy_id: strategy.strategy_id,
    status: strategy.status,
    live_performance: strategy.performance ?? null,
    evaluated: evaluation !== null,
    evaluation,
  }
}, '查询表现（浮动 + 已完成评价）')

route('POST', `${API_PREFIX}/strategies/:id/evaluate`, async ({ service, req, url, params, body }) => {
  const asOf = body?.as_of ?? url.searchParams.get('as_of') ?? undefined
  const result = await service.evaluateStrategy(params.id, { asOf, actor: actorRequest(req, url, body), sessionId: url.searchParams.get('session_id') ?? undefined })
  return { ok: true, reused: result.reused, identical: result.identical, evaluation: result.evaluation, strategy_status: result.strategy?.status ?? null }
}, '执行确定性评价')

route('GET', `${API_PREFIX}/strategies/:id/replay`, async ({ service, req, url, params, body }) => ({
  ok: true,
  replay: (await service.replayStrategy(params.id, { actor: actorRequest(req, url, body) })),
}), '策略 Replay')

route('GET', `${API_PREFIX}/strategies/:id/replay/verify`, async ({ service, params }) => ({
  ok: true,
  verification: await service.verifyReplay(params.id),
}), 'Replay 一致性校验（重算比对）')

// ─────────────────────────────────────────────────────────── evaluations

route('GET', `${API_PREFIX}/evaluations`, async ({ service, url }) => ({
  ok: true,
  evaluations: (await service.listEvaluations({
    strategyId: url.searchParams.get('strategy_id') ?? undefined,
    analystId: url.searchParams.get('analyst_id') ?? undefined,
    limit: url.searchParams.has('limit') ? Number(url.searchParams.get('limit')) : undefined,
  })),
}), '列出评价记录')

route('GET', `${API_PREFIX}/evaluations/:id`, async ({ service, params }) => ({
  ok: true,
  evaluation: (await service.getEvaluation(params.id)),
}), '读取评价记录')

route('GET', `${API_PREFIX}/rules`, async ({ service }) => ({ ok: true, ...service.getRules() }), '读取评分规则')

route('PUT', `${API_PREFIX}/rules`, async ({ service, req, url, body }) => ({
  ok: true,
  rules: (await service.updateRules(body, { actor: actorRequest(req, url, body) })),
}), '更新评分规则（仅 ADMIN）')

// ─────────────────────────────────────────────────────────── market

route('GET', `${API_PREFIX}/market/universe`, async ({ service }) => ({
  ok: true,
  provider: service.provider.name,
  data_boundary: service.provider.boundary(),
  tickers: service.provider.listTickers(),
  benchmarks: service.provider.listBenchmarks(),
}), '可用标的与数据上界')

route('GET', `${API_PREFIX}/market/quote/:ticker`, async ({ service, params }) => ({
  ok: true,
  quote: await service.getQuote(params.ticker),
}), '读取报价')

route('GET', `${API_PREFIX}/market/history/:ticker`, async ({ service, url, params }) => ({
  ok: true,
  ticker: params.ticker.toUpperCase(),
  bars: await service.getHistory(params.ticker, url.searchParams.get('from') ?? undefined, url.searchParams.get('to') ?? undefined),
}), '读取日线序列')

// ─────────────────────────────────────────────────────────── analysts / teams / dashboard

route('GET', `${API_PREFIX}/analysts`, async ({ service }) => ({ ok: true, analysts: (await service.listAnalysts()) }), '列出分析师')

route('GET', `${API_PREFIX}/capabilities`, async () => ({ ok: true, roles: ROLES, capabilities: capabilityMatrix() }), '角色能力矩阵（§19）')

route('GET', `${API_PREFIX}/analysts/:id/performance`, async ({ service, req, url, params, body }) => {
  const { analyst, aggregate } = (await service.getAnalystPerformance(params.id, { actor: actorRequest(req, url, body) }))
  const { rows, ...metrics } = aggregate
  return { ok: true, analyst, metrics, strategies: rows }
}, '分析师绩效')

route('GET', `${API_PREFIX}/teams`, async ({ service }) => ({ ok: true, teams: (await service.listTeams()) }), '列出团队与成员')

route('GET', `${API_PREFIX}/teams/:team/performance`, async ({ service, req, url, params, body }) => {
  const result = (await service.getTeamPerformance(params.team, { actor: actorRequest(req, url, body) }))
  return {
    ok: true,
    team: result.team,
    analyst_count: result.analyst_count,
    metrics: stripRows(result.aggregate),
    // 与 /analysts/:id/performance 保持同一形状：每组是 { analyst_id, name, metrics, strategies }。
    // ⚠️ metrics 必须**嵌套**：聚合里的 `strategies` 是"策略条数"（数字），
    // 而策略列表也叫 strategies —— 平铺在一起会互相覆盖（实测让前端把数组当数字渲染，
    // 页面出现一串 [object Object]）。
    analysts: result.analysts.map((group) => {
      const { rows, ...metrics } = group
      return { analyst_id: group.analyst_id, name: group.name, team: group.team, metrics, strategies: rows }
    }),
  }
}, '团队明细：团队汇总 + 按分析师分组的策略')

route('GET', `${API_PREFIX}/dashboard`, async ({ service, req, url, body }) => ({
  ok: true,
  dashboard: (await service.getDashboard({ actor: actorRequest(req, url, body) })),
}), 'Manager Dashboard 数据')

// ─────────────────────────────────────────────────────────── reports

route('GET', `${API_PREFIX}/reports/strategies/:id`, async ({ service, req, url, params, body }) => {
  const { report, markdown } = (await service.renderStrategyReport(params.id, {
    actor: actorRequest(req, url, body),
    commentary: url.searchParams.get('commentary') ?? null,
    language: languageFrom(req, url, null),
  }))
  return { ok: true, report, markdown }
}, '策略评价报告')

route('GET', `${API_PREFIX}/reports/analysts/:id`, async ({ service, req, url, params, body }) => {
  const { report, markdown, report_id } = (await service.buildAnalystReportFor(params.id, {
    actor: actorRequest(req, url, body),
    commentary: url.searchParams.get('commentary') ?? null,
    language: languageFrom(req, url, null),
  }))
  return { ok: true, report_id, report, markdown }
}, '分析师绩效报告')

route('GET', `${API_PREFIX}/reports/teams`, async ({ service, req, url, body }) => {
  const { report, markdown, report_id } = (await service.buildTeamReportFor({
    actor: actorRequest(req, url, body),
    commentary: url.searchParams.get('commentary') ?? null,
    language: languageFrom(req, url, null),
  }))
  return { ok: true, report_id, report, markdown }
}, '团队绩效报告')

route('GET', `${API_PREFIX}/reports`, async ({ service, url }) => ({
  ok: true,
  reports: (await service.listReports({ limit: url.searchParams.has('limit') ? Number(url.searchParams.get('limit')) : undefined })),
}), '已生成的报告清单')

// ─────────────────────────────────────────────────────────── portfolios（模拟盘，批次 1）

route('GET', `${API_PREFIX}/portfolios`, async ({ service, req, url, body }) => ({
  ok: true,
  ...(await service.listPortfolios({ asOf: url.searchParams.get('as_of') ?? undefined, actor: actorRequest(req, url, body) })),
}), '全部模拟盘汇总')

route('GET', `${API_PREFIX}/portfolios/:analyst_id`, async ({ service, req, url, params, body }) => {
  const { projection, portfolio, reused } = await service.getPortfolio(params.analyst_id, {
    asOf: url.searchParams.get('as_of') ?? undefined,
    actor: actorRequest(req, url, body),
  })
  // 只出收益率与净值，不出金额（C6/F1）。`projection` 本身就没有金额字段，
  // 这里再显式组装一次，是为了让 API 契约稳定、不随内部结构变化而漂移。
  return {
    ok: true,
    snapshot_id: portfolio.snapshot_id,
    analyst_id: params.analyst_id,
    as_of: portfolio.as_of,
    accounting_version: projection.accounting_version,
    start_nav: projection.start_nav,
    nav: projection.nav,
    total_return: projection.total_return,
    gross_exposure_pct: projection.gross_exposure_pct,
    unallocated_pct: projection.unallocated_pct,
    max_position_pct: projection.max_position_pct,
    eviction_strategy: projection.eviction_strategy,
    counts: projection.counts,
    positions: projection.positions,
    closed: projection.lots.filter((lot) => lot.closed_date !== null),
    evictions: projection.evictions,
    rejections: projection.rejections,
    reused,
  }
}, '单个分析师的模拟盘')

route('GET', `${API_PREFIX}/portfolios/:analyst_id/nav`, async ({ service, req, url, params, body }) => ({
  ok: true,
  ...(await service.getPortfolioNav(params.analyst_id, {
    from: url.searchParams.get('from') ?? undefined,
    to: url.searchParams.get('to') ?? undefined,
    asOf: url.searchParams.get('as_of') ?? undefined,
    actor: actorRequest(req, url, body),
  })),
}), '组合净值曲线')

route('GET', `${API_PREFIX}/portfolios/:analyst_id/verify`, async ({ service, req, url, params, body }) => ({
  ok: true,
  ...(await service.recomputePortfolio(params.analyst_id, {
    asOf: url.searchParams.get('as_of') ?? undefined,
    actor: actorRequest(req, url, body),
  })),
}), '组合重算校验（与落库快照逐字段比对）')

// ─────────────────────────────────────────────────────────── audit / monitor / demo

route('GET', `${API_PREFIX}/events`, async ({ service, url }) => ({
  ok: true,
  events: (await service.listEvents({
    strategyId: url.searchParams.get('strategy_id') ?? undefined,
    limit: url.searchParams.has('limit') ? Number(url.searchParams.get('limit')) : undefined,
  })),
}), '审计事件')

route('POST', `${API_PREFIX}/monitor/run`, async ({ service, req, url, body }) => {
  const summary = await service.monitorAllActiveStrategies({ asOf: body?.as_of, actor: actorRequest(req, url, body), sessionId: url.searchParams.get('session_id') ?? undefined })
  return { ok: true, ...summary }
}, '监控全部 ACTIVE 策略')

route('POST', `${API_PREFIX}/monitor/:id`, async ({ service, req, url, params, body }) => {
  const result = await service.monitorStrategy(params.id, { asOf: body?.as_of, actor: actorRequest(req, url, body) })
  return {
    ok: true,
    strategy_id: params.id,
    status: result.strategy.status,
    changed: result.changed,
    performance: result.performance,
    events: result.events.map((event) => event.type),
  }
}, '监控单条策略')

route('POST', `${API_PREFIX}/demo/advance-clock`, async ({ service, req, url, body }) => ({
  ok: true,
  ...(await service.advanceClock(body?.trading_days ?? 1, { actor: actorRequest(req, url, body) })),
}), '【Demo】推进模拟时钟')

route('POST', `${API_PREFIX}/demo/reset`, async ({ service, req, url, body }) => ({
  ok: true,
  ...(await service.resetDemo({ actor: actorRequest(req, url, body) })),
}), '【Demo】重置并重新灌入 Seed 数据')

/** 去掉聚合里的 rows（列表接口里策略明细单独给）。 */
function stripRows(aggregate) {
  const { rows, ...metrics } = aggregate
  return metrics
}

export function listRoutes() {
  return ROUTES.map((row) => ({ method: row.method, path: row.pattern, description: row.description }))
}

/**
 * 处理一个 API 请求。返回 true 表示已处理。
 * @param {{req: import('node:http').IncomingMessage, res: import('node:http').ServerResponse, service: object}} input
 */
export async function handleApiRequest({ req, res, service }) {
  const url = new URL(req.url ?? '/', 'http://127.0.0.1')
  const pathname = url.pathname.replace(/\/+$/, '') || '/'

  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'access-control-allow-methods': 'GET,POST,PATCH,PUT,OPTIONS', 'access-control-allow-headers': 'content-type,x-actor-role,x-actor-id' })
    res.end()
    return true
  }

  let matched = null
  for (const row of ROUTES) {
    if (row.method !== req.method) continue
    const params = match(row.pattern, pathname)
    if (params !== null) {
      matched = { row, params }
      break
    }
  }

  if (matched === null) {
    return false
  }

  try {
    const body = ['POST', 'PATCH', 'PUT'].includes(req.method) ? await readBody(req) : null
    const payload = await matched.row.handler({ service, req, res, url, params: matched.params, body })
    sendJson(res, 200, payload)
  } catch (error) {
    const code = error?.code ?? CODES.STORAGE
    const inputStatus = error instanceof InputError ? ({scope_denied:403, policy_blocked:403, not_found:404, revision_conflict:409, idempotency_conflict:409, input_limit:413}[code] ?? 422) : undefined
    const status = error.status || inputStatus || HTTP_STATUS_BY_CODE[code] || 500
    sendJson(res, status, {
      ok: false,
      error: { code, message: error.message, ...(error.details === undefined ? {} : { details: error.details }) },
    })
  }
  return true
}
