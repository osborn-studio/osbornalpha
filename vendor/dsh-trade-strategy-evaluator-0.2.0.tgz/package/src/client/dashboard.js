/**
 * dsh-trade-strategy-evaluator —— 浏览器端插件 bundle（Manager Dashboard）。
 *
 * ⚠️ 这不是 ESM 文件，而是 DeepSeek Harness 客户端模块系统要求的**注册式 CJS 工厂**：
 *
 *     window.__ModuleLoader__.load({ id: "<包名>", factory: (require) => module.exports })
 *
 * 三条硬性约束（全部来自 dsh-client-modules 的实现）：
 *   1. `id` 必须**逐字等于** package.json 的 name，否则 bundle 加载后会因为
 *      "loaded without registering <id>" 而失败。
 *   2. 文件会被当作 classic script 执行，所以顶层只能注册工厂；
 *      所有副作用必须留在 factory 闭包内（脚本级副作用会在注册时提前发生）。
 *   3. 只能 require 平台 seed 词表里的模块：react、react/jsx-runtime、react-dom、
 *      react-dom/client、@deepseek-ai/cordis、dsh-client-store、dsh-client-ui-slots、
 *      dsh-client-ui-primitives。这里只用 `react`。
 *
 * 中英文切换（与 GUI 的「设置 → 常规 → 语言」是**同一个**偏好，不是自建开关）：
 *   · 词典用 `ctx.locale.register(NS, { zh, en })` 注册进 shell 的 locale 服务；
 *   · 文案用 `ctx.locale.bind(NS)` 得到的 `t()` 取；
 *   · 标签页文案用 `label: () => t('tab')` 声明成 thunk，
 *     因此 shell 切换语言时标签环会跟着变（conversation 包自己订阅了 locale 变化）；
 *   · 面板顶栏另给一个快捷切换器，它调用同一个 `ctx.locale.setLocale()`，
 *     所以两条路径不会各自为政。
 */

window.__ModuleLoader__.load({
  id: 'dsh-trade-strategy-evaluator',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    const React = require('react')
    const { useState, useEffect, useCallback, useMemo, useRef } = React
    const h = React.createElement

    const API = '/api/trade-eval'
    const PLUGIN_ID = 'dsh-trade-strategy-evaluator'
    const NS = 'tradeEval'

    // ── 文案表 ──────────────────────────────────────────────────────────────
    // 两个语言的键集合必须完全一致（tests/unit/i18n.test.js 会断言）。
    const UI = {
      zh: {
        tab: '策略评估',
        appTitle: '交易策略评估',
        dashboard: 'Manager Dashboard',
        analystLabel: '分析师',
        analystPerformance: '分析师绩效',
        teamPerformance: '团队绩效',
        auditEvents: '审计事件（最近）',
        strategies: '策略数',
        evaluated: '已评价',
        active: '跟踪中',
        winRate: '胜率',
        avgReturn: '平均收益',
        avgAlpha: '平均 Alpha',
        maxDrawdown: '最大回撤',
        portfolio: '模拟盘',
        portfolioNav: '组合净值',
        portfolioReturn: '累计收益率',
        portfolioExposure: '当前敞口',
        portfolioUnallocated: '未分配',
        portfolioOpen: '持仓中',
        portfolioClosed: '已平仓',
        portfolioEvicted: '超限挤出',
        portfolioRejected: '被拒指令',
        portfolioAccounting: '会计口径',
        portfolioLimit: '仓位上限',
        thLot: '手',
        thWeight: '权重',
        thOpened: '开仓日',
        thEntry: '建仓价',
        thExit: '平仓价',
        thClosed: '平仓日',
        thCloseReason: '平仓原因',
        thNavAtOpen: '建仓时净值',
        thRealizedPnl: '净值贡献',
        closeReasonStrategyTerminal: '策略终结',
        closeReasonOpposite: '反向指令',
        closeReasonEvicted: '超限挤出',
        navCurveHint: '净值曲线由确定性账本逐日盯市产出，可由 portfolio_recompute 完全重算。',
        noPortfolio: '该分析师还没有已冻结的策略，因此组合为空。',
        noMoney: '模拟盘为权重/净值式记账：只展示收益率与净值，不展示任何金额。',
        verifyPortfolio: '重算校验',
        verifyOk: '重算一致：净值曲线与持仓与落库结果逐字段相同',
        verifyFail: '重算不一致，需调查',
        avgScore: '平均评分',
        totalPnl: '累计盈亏',
        thAnalyst: '分析师',
        thTeam: '团队',
        thStrategies: '策略数',
        thEvaluated: '已评价',
        thActive: '跟踪中',
        thWinRate: '胜率',
        thAvgReturn: '平均收益',
        thAvgAlpha: '平均 Alpha',
        thMaxDD: '最大回撤',
        thScore: '评分',
        thSeq: '序号',
        thAt: '时间',
        thEvent: '事件',
        thStrategy: '策略',
        thActor: '操作者',
        thTicker: '标的',
        thAction: '方向',
        thStatus: '状态',
        thReturn: '收益',
        thBenchmark: '基准',
        thAlpha: 'Alpha',
        thTarget: '目标价',
        thStop: '止损',
        strategyHistory: '策略历史',
        performance: '表现',
        replay: 'Replay',
        report: '报告',
        strategySection: '策略',
        originalStrategy: '原始策略',
        actualPerformance: '实际表现',
        result: '结果',
        strategyId: '策略 ID',
        submitted: '提交时间',
        frozenAt: '冻结时间',
        benchmark: '对比基准',
        positionBefore: '提交前仓位',
        quantity: '数量',
        entry: '入场价',
        target: '目标价',
        stop: '止损价',
        holdingPeriod: '预期持仓',
        snapshotPrice: '快照价格',
        snapshotVolume: '快照成交量',
        snapshotAt: '快照时间',
        entryExit: '入场 → 退出',
        returnPct: '策略收益',
        alpha: '超额收益',
        pnl: '盈亏金额',
        holdingDays: '持仓交易日',
        exitReason: '退出原因',
        targetOutcome: '目标价',
        stopOutcome: '止损',
        benchmarkOutcome: '对比基准',
        calculation: '评分公式',
        entryPrice: '入场',
        exitPrice: '退出',
        days: '个交易日',
        reached: '已达目标价',
        notReached: '未达到',
        triggered: '已触发',
        notTriggered: '未触发',
        outperformed: '跑赢基准',
        underperformed: '跑输基准',
        inLine: '与基准持平',
        analystReasoning: '分析师原始理由（提交时的原文，永不被改写）',
        priceTimeline: '价格走势',
        lifecycleEvents: '生命周期事件',
        auditAnswers: '审计问答',
        q1: '谁提交的',
        q2: '什么时间提交',
        q3: '当时价格',
        q4: '当时仓位',
        q5: '为什么买/卖',
        q6: '后续价格变化',
        q7: '是否触发目标',
        q8: '是否触发止损',
        q9: '最终收益',
        q10: 'Benchmark 表现',
        q11: '最终评分',
        replayConsistent: 'Replay 一致性',
        monitor: '运行监控',
        runEvaluation: '执行评价',
        advance: '推进 1 天',
        reset: '重置 Demo',
        loading: '加载中…',
        notEvaluated: '尚未评价',
        scoreBreakdown: '评分构成：',
        factsFooter: '所有数值由确定性 Evaluation Engine 计算，可重复验证；策略冻结后核心决策字段不可修改；行情不可越过数据上界。',
        tradesDays: '个交易日',
        monitorResult: '监控完成 @ {asOf}\n监控 {monitored} 条，更新 {changed} 条\n止损 {stopped}，完成 {completed}',
        advanceResult: '模拟时钟 → {now}\n行情上界 → {boundary}',
        resetConfirm: '清空并重新灌入 Demo 数据？',
        resetDone: '已重置：{strategies} 条策略，{evaluations} 条评价',
        language: '语言',
    teamDetail: '团队明细',
    teamSummary: '团队汇总',
    byAnalyst: '按分析师分组',
    allTeams: '全部团队',
    unknownTeam: '未知团队',
    analystCount: '分析师数',
    noStrategiesInTeam: '该团队暂无策略',
    viewTeam: '查看团队明细',
    strategiesOf: '{name} 的策略',
    noStrategiesForMember: '该成员暂无策略',
        identity: '身份',
        actingAs: '当前身份',
        analystSelf: '当前分析师',
        newStrategy: '提交策略',
        editStrategy: '编辑策略',
        myStrategies: '我的策略',
        saveDraft: '存为草稿',
        submitAndFreeze: '提交并冻结',
        freezeStrategy: '冻结',
        cancelStrategy: '取消策略',
        cancelReason: '取消原因',
        confirmCancel: '确认取消这条策略？',
        fieldTicker: '标的',
        fieldAction: '方向',
        fieldEntry: '入场价',
        fieldTarget: '目标价',
        fieldStop: '止损价',
        fieldHolding: '预期持仓（交易日）',
        fieldBenchmark: '对比基准',
        fieldQuantity: '数量',
        fieldPositionBefore: '提交前仓位',
        fieldReason: '策略理由',
        useCurrentPrice: '用当前价',
        currentPrice: '当前价',
        snapshotHint: '提交时会自动抓取当时的市场快照，用于事后审计。',
        invalidBuy: 'BUY 要求：止损 < 入场价 < 目标价',
        invalidSell: 'SELL 要求：目标价 < 入场价 < 止损价',
        requiredFields: '请填写所有必填项',
        draftHint: '草稿可编辑；一旦冻结，核心决策字段永久不可修改。',
        createdFrozen: '已提交并冻结：{id}',
        createdDraft: '已存为草稿：{id}',
        savedDraft: '草稿已保存',
        frozenToast: '已冻结：{id}',
        cancelledToast: '已取消：{id}',
        managerReadOnly: '管理者视角：只读（不能创建或修改策略）',
        analystHint: '分析师视角：只维护自己的策略',
        adminPanel: '评分规则（管理员）',
        rulesWeights: '权重（四者之和必须为 1）',
        rulesVersion: '规则版本',
        saveRules: '保存规则',
        rulesSaved: '规则已保存，版本 {version}（只影响之后的评价）',
        noPermission: '当前身份无权执行此操作',
        backToDashboard: '返回看板',
        cannotCancelTerminal: '已完成/已止损/已过期的策略不能取消',
        cancelOnlyActive: '只有 ACTIVE 策略可以直接取消；草稿请先冻结再取消',
        monitorRun: '监控',
        back: '返回',
        entryLine: '入场价',
        targetLine: '目标价',
        stopLine: '止损价',
        priceLine: '收盘价',
        benchmarkLine: '基准（归一化）',
        volatility: '年化波动率',
        riskReward: '盈亏比',
        theme: '主题',
        filterTicker: '标的 / 策略 ID',
        filterStatus: '状态',
        filterAction: '方向',
        allStatuses: '全部状态',
        allActions: '全部方向',
        clearFilters: '清除筛选',
        showingCount: '显示 {shown} / {total} 条',
        noMatches: '没有符合条件的策略',
        noData: '暂无数据',
        retry: '重试',
        errorTitle: '加载失败',
        riskMetrics: '风险指标',
        exitOn: '退出日',
        plannedHolding: '预期持仓',
        actualHolding: '实际持仓',
        sortHint: '点击表头排序',
        scoreOf: '{score} / 100',
        targetHitAt: '达标点',
        stopHitAt: '止损点',
        emptyStrategies: '该分析师暂无策略',
        sessionLabel: '会话',
        rulesLabel: '评分规则',
        clockLabel: '模拟时钟',
        boundaryLabel: '行情上界',
        storageLabel: '存储',
      },
      en: {
        tab: 'Strategy Evaluation',
        appTitle: 'Trading Strategy Evaluation',
        dashboard: 'Manager Dashboard',
        analystLabel: 'Analyst',
        analystPerformance: 'Analyst Performance',
        teamPerformance: 'Team Performance',
        auditEvents: 'Audit Events (recent)',
        strategies: 'Strategies',
        evaluated: 'Evaluated',
        active: 'Active',
        winRate: 'Win Rate',
        avgReturn: 'Avg Return',
        avgAlpha: 'Avg Alpha',
        maxDrawdown: 'Max Drawdown',
        portfolio: 'Simulated Book',
        portfolioNav: 'Portfolio NAV',
        portfolioReturn: 'Total Return',
        portfolioExposure: 'Exposure',
        portfolioUnallocated: 'Unallocated',
        portfolioOpen: 'Open',
        portfolioClosed: 'Closed',
        portfolioEvicted: 'Evicted',
        portfolioRejected: 'Rejected',
        portfolioAccounting: 'Accounting',
        portfolioLimit: 'Position Limit',
        thLot: 'Lot',
        thWeight: 'Weight',
        thOpened: 'Opened',
        thEntry: 'Entry',
        thExit: 'Exit',
        thClosed: 'Closed',
        thCloseReason: 'Close Reason',
        thNavAtOpen: 'NAV at Open',
        thRealizedPnl: 'NAV Impact',
        closeReasonStrategyTerminal: 'Strategy ended',
        closeReasonOpposite: 'Opposite instruction',
        closeReasonEvicted: 'Evicted (limit)',
        navCurveHint: 'The NAV curve is produced by the deterministic ledger and can be fully recomputed by portfolio_recompute.',
        noPortfolio: 'This analyst has no frozen strategy yet, so the book is empty.',
        noMoney: 'Weight/net-value accounting: returns and NAV only, never any currency amount.',
        verifyPortfolio: 'Recompute',
        verifyOk: 'Recompute matches: NAV curve and positions are field-by-field identical to the stored snapshot',
        verifyFail: 'Recompute mismatch — must be investigated',
        avgScore: 'Avg Score',
        totalPnl: 'Total P&L',
        thAnalyst: 'Analyst',
        thTeam: 'Team',
        thStrategies: 'Strategies',
        thEvaluated: 'Evaluated',
        thActive: 'Active',
        thWinRate: 'Win Rate',
        thAvgReturn: 'Avg Return',
        thAvgAlpha: 'Avg Alpha',
        thMaxDD: 'Max DD',
        thScore: 'Score',
        thSeq: 'Seq',
        thAt: 'At',
        thEvent: 'Event',
        thStrategy: 'Strategy',
        thActor: 'Actor',
        thTicker: 'Ticker',
        thAction: 'Action',
        thStatus: 'Status',
        thReturn: 'Return',
        thBenchmark: 'Benchmark',
        thAlpha: 'Alpha',
        thTarget: 'Target',
        thStop: 'Stop',
        strategyHistory: 'Strategy History',
        performance: 'Performance',
        replay: 'Replay',
        report: 'Report',
        strategySection: 'Strategy',
        originalStrategy: 'Original Strategy',
        actualPerformance: 'Actual Performance',
        result: 'Result',
        strategyId: 'Strategy ID',
        submitted: 'Submitted',
        frozenAt: 'Frozen at',
        benchmark: 'Benchmark',
        positionBefore: 'Position Before',
        quantity: 'Quantity',
        entry: 'Entry',
        target: 'Target',
        stop: 'Stop',
        holdingPeriod: 'Holding Period',
        snapshotPrice: 'Snapshot Price',
        snapshotVolume: 'Snapshot Volume',
        snapshotAt: 'Snapshot At',
        entryExit: 'Entry → Exit',
        returnPct: 'Return',
        alpha: 'Alpha',
        pnl: 'P&L',
        holdingDays: 'Holding Days',
        exitReason: 'Exit Reason',
        targetOutcome: 'Target',
        stopOutcome: 'Stop Loss',
        benchmarkOutcome: 'Benchmark',
        calculation: 'Calculation',
        entryPrice: 'Entry',
        exitPrice: 'Exit',
        days: 'days',
        reached: 'Reached',
        notReached: 'Not Reached',
        triggered: 'Triggered',
        notTriggered: 'Not Triggered',
        outperformed: 'Outperformed',
        underperformed: 'Underperformed',
        inLine: 'In Line',
        analystReasoning: 'Analyst Reasoning (as submitted, never rewritten)',
        priceTimeline: 'Price Timeline',
        lifecycleEvents: 'Lifecycle Events',
        auditAnswers: 'Audit Answers',
        q1: 'Who submitted',
        q2: 'Submitted at',
        q3: 'Price at submission',
        q4: 'Position before',
        q5: 'Rationale',
        q6: 'Price evolution',
        q7: 'Target reached',
        q8: 'Stop loss triggered',
        q9: 'Strategy return',
        q10: 'Benchmark performance',
        q11: 'Final score',
        replayConsistent: 'Replay consistency',
        monitor: 'Run Monitor',
        runEvaluation: 'Run Evaluation',
        advance: 'Advance 1 Day',
        reset: 'Reset Demo',
        loading: 'loading…',
        notEvaluated: 'Not evaluated yet',
        scoreBreakdown: 'Score breakdown:',
        factsFooter: 'All metrics are computed by the deterministic Evaluation Engine and are reproducible; a frozen strategy never changes its core decision fields; market data never crosses the data boundary.',
        tradesDays: 'trading days',
        monitorResult: 'Monitor run @ {asOf}\nmonitored {monitored}, changed {changed}\nstopped {stopped}, completed {completed}',
        advanceResult: 'Clock → {now}\nData boundary → {boundary}',
        resetConfirm: 'Reset and re-seed the demo data?',
        resetDone: 'Reset: {strategies} strategies, {evaluations} evaluations',
        language: 'Language',
    teamDetail: 'Team Detail',
    teamSummary: 'Team Summary',
    byAnalyst: 'Grouped by Analyst',
    allTeams: 'All teams',
    unknownTeam: 'Unknown team',
    analystCount: 'Analysts',
    noStrategiesInTeam: 'This team has no strategies yet',
    viewTeam: 'View team detail',
    strategiesOf: 'Strategies of {name}',
    noStrategiesForMember: 'No strategies for this member yet',
        identity: 'Identity',
        actingAs: 'Acting as',
        analystSelf: 'Analyst',
        newStrategy: 'New Strategy',
        editStrategy: 'Edit Strategy',
        myStrategies: 'My Strategies',
        saveDraft: 'Save as Draft',
        submitAndFreeze: 'Submit & Freeze',
        freezeStrategy: 'Freeze',
        cancelStrategy: 'Cancel Strategy',
        cancelReason: 'Cancel reason',
        confirmCancel: 'Cancel this strategy?',
        fieldTicker: 'Ticker',
        fieldAction: 'Action',
        fieldEntry: 'Entry price',
        fieldTarget: 'Target price',
        fieldStop: 'Stop loss',
        fieldHolding: 'Holding period (trading days)',
        fieldBenchmark: 'Benchmark',
        fieldQuantity: 'Quantity',
        fieldPositionBefore: 'Position before',
        fieldReason: 'Strategy rationale',
        useCurrentPrice: 'Use current price',
        currentPrice: 'Current price',
        snapshotHint: 'A market snapshot is captured at submission and frozen into the strategy for later audit.',
        invalidBuy: 'BUY requires: stop < entry < target',
        invalidSell: 'SELL requires: target < entry < stop',
        requiredFields: 'Please fill in every required field',
        draftHint: 'Drafts stay editable; once frozen, the core decision fields can never change.',
        createdFrozen: 'Submitted and frozen: {id}',
        createdDraft: 'Saved as draft: {id}',
        savedDraft: 'Draft saved',
        frozenToast: 'Frozen: {id}',
        cancelledToast: 'Cancelled: {id}',
        managerReadOnly: 'Manager view: read-only (cannot create or modify strategies)',
        analystHint: 'Analyst view: maintain your own strategies only',
        adminPanel: 'Scoring Rules (admin)',
        rulesWeights: 'Weights (must sum to 1)',
        rulesVersion: 'Rules version',
        saveRules: 'Save rules',
        rulesSaved: 'Rules saved, version {version} (affects future evaluations only)',
        noPermission: 'Your current role cannot perform this action',
        backToDashboard: 'Back to dashboard',
        cannotCancelTerminal: 'Completed / stopped / expired strategies cannot be cancelled',
        cancelOnlyActive: 'Only ACTIVE strategies can be cancelled directly; freeze a draft first',
        monitorRun: 'Monitor',
        back: 'Back',
        entryLine: 'Entry',
        targetLine: 'Target',
        stopLine: 'Stop',
        priceLine: 'Close',
        benchmarkLine: 'Benchmark (normalized)',
        volatility: 'Volatility (annualized)',
        riskReward: 'Risk/Reward',
        theme: 'Theme',
        filterTicker: 'Ticker / Strategy ID',
        filterStatus: 'Status',
        filterAction: 'Action',
        allStatuses: 'All statuses',
        allActions: 'All actions',
        clearFilters: 'Clear filters',
        showingCount: 'Showing {shown} / {total}',
        noMatches: 'No strategies match the filters',
        noData: 'No data',
        retry: 'Retry',
        errorTitle: 'Failed to load',
        riskMetrics: 'Risk Metrics',
        exitOn: 'Exit date',
        plannedHolding: 'Planned holding',
        actualHolding: 'Actual holding',
        sortHint: 'Click a header to sort',
        scoreOf: '{score} / 100',
        targetHitAt: 'Target hit',
        stopHitAt: 'Stop hit',
        emptyStrategies: 'This analyst has no strategies yet',
        sessionLabel: 'Session',
        rulesLabel: 'Rules',
        clockLabel: 'Clock',
        boundaryLabel: 'Boundary',
        storageLabel: 'Storage',
      },
    }

    /** 本地兜底 `t`：locale 服务不可用时也能渲染（键缺失时回退到 key）。 */
    function localT(language) {
      const dict = UI[language] ?? UI.zh
      return (key, params) => {
        const template = dict[key] ?? UI.zh[key] ?? key
        if (!params) return template
        return String(template).replace(/\{(\w+)\}/g, (match, name) => (name in params ? String(params[name]) : match))
      }
    }

    // ── 样式（内联，随 effect 生命期安装/卸载）──────────────────────────────
    const CSS = `
/* ── 设计令牌 ───────────────────────────────────────────────────────────────
   全部使用 shell 的 --dsw-* 别名令牌并带回退值：这样插件面板会**自动跟随**
   GUI 的浅色/深色主题与品牌色，而不是自带一套固定配色。                        */
.tse-root {
  --tse-bg: var(--dsw-alias-bg-base, transparent);
  --tse-panel: var(--dsw-alias-bg-layer-1, #131b26);
  --tse-panel-2: var(--dsw-alias-bg-layer-2, #18222f);
  --tse-hover: var(--dsw-alias-interactive-bg-hover, rgba(127,127,127,.12));
  --tse-line: var(--dsw-alias-border-l1, #24303f);
  --tse-line-2: var(--dsw-alias-border-l2, #33445a);
  --tse-text: var(--dsw-alias-label-primary, #e8eef7);
  --tse-dim: var(--dsw-alias-label-secondary, #9db0c7);
  --tse-faint: var(--dsw-alias-label-tertiary, #6d8299);
  --tse-accent: var(--dsw-alias-brand-primary, #4da3ff);
  --tse-accent-fill: var(--dsw-alias-button-primary-fill, #17406b);
  --tse-accent-hover: var(--dsw-alias-button-primary-hover, #1d4f83);
  --tse-good: var(--dsw-alias-state-success-primary, #35d07f);
  --tse-bad: var(--dsw-alias-state-error-primary, #ff6b6b);
  --tse-warn: var(--dsw-alias-state-warn-primary, #ffc857);
  --tse-skeleton: var(--dsw-alias-bg-skeleton, rgba(127,127,127,.16));
  --tse-shadow: var(--dsw-shadow-lv1, 0 1px 2px rgba(0,0,0,.3));
  --tse-mono: ui-monospace, SFMono-Regular, Menlo, monospace;
  display: flex; flex-direction: column; height: 100%; min-height: 0;
  color: var(--tse-text);
  font-family: var(--dsw-font-family, inherit);
  font-size: var(--dsw-font-xxs-12-font-size, 12px);
  line-height: var(--dsw-font-xxs-12-line-height, 1.5);
}

/* 顶栏 */
.tse-bar { display: flex; align-items: center; gap: 8px; padding: 10px 14px; border-bottom: 1px solid var(--tse-line); flex-wrap: wrap; }
.tse-brand { display: flex; align-items: center; gap: 8px; min-width: 0; }
.tse-mark { width: 24px; height: 24px; border-radius: 7px; flex: none; display: grid; place-items: center;
  background: linear-gradient(140deg, var(--tse-accent), var(--dsw-alias-state-business-primary, #a78bfa));
  color: #fff; font-weight: 700; font-size: var(--dsw-font-xxxs-11-font-size, 11px); box-shadow: var(--tse-shadow); }
.tse-title { font-size: var(--dsw-font-xs-13-font-size, 13px); font-weight: var(--dsw-font-xs-strong-13-font-weight, 600); white-space: nowrap; }
.tse-meta { font-size: var(--dsw-font-xxxs-11-font-size, 11px); color: var(--tse-faint); font-family: var(--tse-mono); }
.tse-grow { flex: 1; }
.tse-btn { background: var(--tse-panel); border: 1px solid var(--tse-line); color: var(--tse-text);
  border-radius: 6px; padding: 4px 10px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); cursor: pointer;
  transition: border-color .12s, background .12s; }
.tse-btn:hover:not(:disabled) { border-color: var(--tse-accent); background: var(--tse-hover); }
/* 主按钮：**不要硬编码 #fff**。
   shell 的 button-primary-fill 在亮色主题是近黑(#0f1115)、暗色主题是近白(#f9fafb)，
   因此白字在暗色主题下只有 1.05:1（几乎不可见，实测）。
   正确做法是用 shell 成对的两端：主文字色做底 + 面板底色做字，两端天然互相反色。 */
.tse-btn.primary {
  background: var(--dsw-alias-label-primary, #e8eef7);
  border-color: var(--dsw-alias-label-primary, #e8eef7);
  color: var(--dsw-alias-bg-layer-1, #131b26);
  font-weight: 600;
}
.tse-btn.primary:hover:not(:disabled) {
  background: var(--dsw-alias-label-primary, #e8eef7);
  border-color: var(--dsw-alias-label-primary, #e8eef7);
  opacity: .88;
}
.tse-btn.primary:disabled { opacity: .45; }
.tse-btn:disabled { opacity: .45; cursor: not-allowed; }
.tse-seg { display: flex; gap: 2px; border: 1px solid var(--tse-line); border-radius: 6px; padding: 1px; }
.tse-seg button { background: none; border: 0; color: var(--tse-dim); padding: 3px 8px; font-size: var(--dsw-font-xxxs-11-font-size, 11px);
  cursor: pointer; border-radius: 4px; }
.tse-seg button:hover { color: var(--tse-text); background: var(--tse-hover); }
.tse-seg button.on { background: var(--tse-hover); color: var(--tse-accent); font-weight: 600; }

/* 工具条 */
.tse-scroll { overflow: auto; padding: 14px; flex: 1; min-height: 0; }
.tse-toolbar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 12px; }
.tse-crumbs { display: flex; align-items: center; gap: 6px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); color: var(--tse-dim); min-width: 0; }
.tse-crumbs a { color: var(--tse-accent); cursor: pointer; text-decoration: none; }
.tse-crumbs a:hover { text-decoration: underline; }
.tse-crumbs .leaf { font-family: var(--tse-mono); color: var(--tse-text); }

/* 卡片 */
.tse-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(118px, 1fr)); gap: 8px; margin-bottom: 16px; }
.tse-card { position: relative; overflow: hidden; border: 1px solid var(--tse-line); border-radius: 10px;
  padding: 9px 11px; background: var(--tse-panel); transition: border-color .12s, transform .12s; }
.tse-card:hover { border-color: var(--tse-line-2); transform: translateY(-1px); }
.tse-card .k { font-size: var(--dsw-font-xxxs-11-font-size, 11px); text-transform: uppercase; letter-spacing: .6px; color: var(--tse-faint); font-weight: 600; }
.tse-card .v { font-size: var(--dsw-font-l-20-font-size, 18px); font-weight: 650; margin-top: 3px; font-family: var(--tse-mono); font-variant-numeric: tabular-nums; letter-spacing: -.3px; }
.tse-card .bar { position: absolute; left: 0; bottom: 0; height: 2px; width: 100%; background: var(--tse-accent); opacity: .85; }
.tse-card.good .bar { background: var(--tse-good); }
.tse-card.bad .bar { background: var(--tse-bad); }

.tse-h2 { display: flex; align-items: center; gap: 6px; font-size: var(--dsw-font-xxxs-11-font-size, 11px);
  text-transform: uppercase; letter-spacing: .7px; color: var(--tse-dim); margin: 18px 0 8px; font-weight: 650; }
.tse-h2 .count { color: var(--tse-faint); font-weight: 500; text-transform: none; letter-spacing: 0; font-family: var(--tse-mono); }

/* 表格 */
.tse-tablewrap { border: 1px solid var(--tse-line); border-radius: 10px; background: var(--tse-panel); overflow: auto; max-height: 62vh; box-shadow: var(--tse-shadow); }
.tse-table { width: 100%; border-collapse: separate; border-spacing: 0; }
.tse-table th, .tse-table td { padding: 7px 10px; text-align: left; white-space: nowrap; border-bottom: 1px solid var(--tse-line); }
.tse-table th { position: sticky; top: 0; z-index: 2; background: var(--tse-panel-2); color: var(--tse-dim);
  font-size: var(--dsw-font-xxxs-11-font-size, 11px); text-transform: uppercase; letter-spacing: .5px; font-weight: 600;
  cursor: pointer; user-select: none; }
.tse-table th.nosort { cursor: default; }
.tse-table th:hover { color: var(--tse-text); }
.tse-table th .arrow { color: var(--tse-accent); margin-left: 3px; font-size: 9px; }
.tse-table tbody tr { cursor: pointer; transition: background .1s; }
.tse-table tbody tr:hover { background: var(--tse-hover); }
.tse-table tbody tr:last-child td { border-bottom: 0; }
.tse-table .num { text-align: right; font-family: var(--tse-mono); font-variant-numeric: tabular-nums; }
.tse-pos { color: var(--tse-good); }
.tse-neg { color: var(--tse-bad); }
.tse-tag { display: inline-block; padding: 1px 7px; border-radius: 20px; font-size: var(--dsw-font-xxxs-11-font-size, 11px);
  border: 1px solid var(--tse-line); background: var(--tse-panel-2); font-family: var(--tse-mono); }
.tse-tag.ACTIVE { border-color: var(--tse-accent); color: var(--tse-accent); }
.tse-tag.COMPLETED { border-color: var(--tse-good); color: var(--tse-good); }
.tse-tag.STOPPED { border-color: var(--tse-bad); color: var(--tse-bad); }
.tse-tag.DRAFT { border-color: var(--tse-warn); color: var(--tse-warn); }
.tse-tag.CANCELLED, .tse-tag.EXPIRED { color: var(--tse-faint); }
.tse-dir { font-family: var(--tse-mono); font-weight: 600; font-size: var(--dsw-font-xxxs-11-font-size, 11px); }
.tse-dir.BUY { color: var(--tse-good); }
.tse-dir.SELL { color: var(--tse-bad); }

.tse-filters { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 10px; }
.tse-filters input, .tse-filters select { background: var(--tse-panel); color: var(--tse-text); border: 1px solid var(--tse-line);
  border-radius: 6px; padding: 4px 8px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); }
.tse-filters input { min-width: 150px; }

/* 详情 */
.tse-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 10px; }
.tse-kv { border: 1px solid var(--tse-line); border-radius: 10px; padding: 10px 12px; background: var(--tse-panel); }
.tse-kv h3 { margin: 0 0 8px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); text-transform: uppercase; letter-spacing: .6px; color: var(--tse-dim); font-weight: 650; }
.tse-kv dl { margin: 0; display: grid; grid-template-columns: auto 1fr; gap: 5px 14px; }
.tse-kv dt { color: var(--tse-dim); font-size: var(--dsw-font-xxxs-11-font-size, 11px); }
.tse-kv dd { margin: 0; text-align: right; font-family: var(--tse-mono); font-variant-numeric: tabular-nums; font-size: var(--dsw-font-xxxs-11-font-size, 11px); }

.tse-tabs { display: flex; gap: 2px; margin: 14px 0 10px; border-bottom: 1px solid var(--tse-line); }
.tse-tabs button { background: none; border: 0; border-bottom: 2px solid transparent; color: var(--tse-dim);
  padding: 7px 10px; cursor: pointer; font-size: var(--dsw-font-xxs-12-font-size, 12px); border-radius: 0; }
.tse-tabs button:hover { color: var(--tse-text); }
.tse-tabs button.on { color: var(--tse-text); border-bottom-color: var(--tse-accent); font-weight: 600; }

.tse-reason { border: 1px solid var(--tse-line); border-left: 3px solid var(--tse-accent); border-radius: 8px; padding: 10px 12px; white-space: pre-wrap; }

/* 图表 */
.tse-chart { border: 1px solid var(--tse-line); border-radius: 10px; padding: 12px; background: var(--tse-panel); }
.tse-chart svg { width: 100%; height: 190px; display: block; overflow: visible; }
.tse-legend { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 10px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); color: var(--tse-dim); }
.tse-legend i { display: inline-block; width: 14px; height: 2px; vertical-align: middle; margin-right: 5px; }

/* 评分环 */
.tse-score { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.tse-score .ring { flex: none; }
.tse-bars { flex: 1; display: grid; gap: 5px; min-width: 170px; }
.tse-bars .row { display: grid; grid-template-columns: 58px 1fr 56px; align-items: center; gap: 8px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); }
.tse-bars .track { height: 6px; background: var(--tse-panel-2); border-radius: 4px; overflow: hidden; }
.tse-bars .fill { height: 100%; background: var(--tse-accent); border-radius: 4px; }
.tse-bars .val { text-align: right; font-family: var(--tse-mono); color: var(--tse-dim); }

/* 生命周期时间线 */
.tse-timeline { list-style: none; padding: 0; margin: 0; }
.tse-timeline li { padding: 5px 0 5px 14px; border-left: 2px solid var(--tse-line); position: relative; }
.tse-timeline li::before { content: ''; position: absolute; left: -4px; top: 10px; width: 6px; height: 6px; border-radius: 50%; background: var(--tse-accent); }
.tse-timeline li.ev-STOP_LOSS_TRIGGERED::before { background: var(--tse-bad); }
.tse-timeline li.ev-TARGET_REACHED::before { background: var(--tse-good); }
.tse-timeline li.ev-STRATEGY_FROZEN::before { background: var(--dsw-alias-state-business-primary, #a78bfa); }
.tse-at { color: var(--tse-faint); font-family: var(--tse-mono); font-size: var(--dsw-font-xxxs-11-font-size, 11px); margin-right: 8px; }
.tse-who { color: var(--tse-faint); font-size: var(--dsw-font-xxxs-11-font-size, 11px); }

/* 报告排版 */
.tse-prose { border: 1px solid var(--tse-line); border-radius: 10px; padding: 14px 18px; background: var(--tse-panel); line-height: 1.7; }
.tse-prose h1 { font-size: var(--dsw-font-l-20-font-size, 18px); margin: 0 0 8px; }
.tse-prose h2 { font-size: var(--dsw-font-xs-13-font-size, 13px); text-transform: none; letter-spacing: 0; color: var(--tse-text);
  margin: 18px 0 6px; border-bottom: 1px solid var(--tse-line); padding-bottom: 4px; }
.tse-prose h3 { font-size: var(--dsw-font-xxs-12-font-size, 12px); margin: 12px 0 6px; color: var(--tse-dim); }
.tse-prose p { margin: 3px 0; font-family: var(--tse-mono); font-variant-numeric: tabular-nums; }
.tse-prose ul { margin: 6px 0; padding-left: 20px; font-family: var(--tse-mono); }
.tse-prose blockquote { margin: 10px 0; padding: 6px 10px; border-left: 3px solid var(--tse-warn); color: var(--tse-warn); font-size: var(--dsw-font-xxxs-11-font-size, 11px); }
.tse-prose hr { border: 0; border-top: 1px solid var(--tse-line); margin: 18px 0 10px; }
.tse-prose em { color: var(--tse-faint); }
.tse-prose table { width: auto; margin: 6px 0; border-collapse: collapse; }
.tse-prose th, .tse-prose td { padding: 4px 9px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); border-bottom: 1px solid var(--tse-line); }

.tse-disclaimer { border: 1px dashed var(--tse-warn); color: var(--tse-warn); border-radius: 6px; padding: 6px 9px;
  font-size: var(--dsw-font-xxxs-11-font-size, 11px); margin-bottom: 8px; }
.tse-note { color: var(--tse-faint); font-size: var(--dsw-font-xxxs-11-font-size, 11px); margin-top: 6px; }
.tse-err { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; border: 1px solid var(--tse-bad);
  border-radius: 8px; padding: 10px 12px; color: var(--tse-bad); }
.tse-err .msg { flex: 1; min-width: 180px; }
.tse-empty { color: var(--tse-faint); padding: 28px; text-align: center; border: 1px dashed var(--tse-line); border-radius: 10px; }

/* 骨架屏 */
.tse-sk { background: var(--tse-skeleton); border-radius: 10px; animation: tse-sk 1.3s ease-in-out infinite;
  background-image: linear-gradient(90deg, transparent 25%, var(--tse-hover) 37%, transparent 63%);
  background-size: 400% 100%; }
@keyframes tse-sk { 0% { background-position: 100% 50%; } 100% { background-position: 0 50%; } }
.tse-sk-row { height: 30px; margin-bottom: 6px; }
.tse-sk-card { height: 62px; margin-bottom: 8px; }
.tse-sk-title { height: 14px; width: 160px; margin: 18px 0 8px; }
@media (prefers-reduced-motion: reduce) { .tse-sk { animation: none; } }

.tse-mono { font-family: var(--tse-mono); font-variant-numeric: tabular-nums; }
/* 表单与身份控件 */
.tse-field { display: flex; align-items: center; gap: 5px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); color: var(--tse-dim); }
.tse-field select { background: var(--tse-panel); color: var(--tse-text); border: 1px solid var(--tse-line);
  border-radius: 6px; padding: 3px 6px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); }
.tse-field2 { display: flex; flex-direction: column; gap: 4px; font-size: var(--dsw-font-xxxs-11-font-size, 11px); color: var(--tse-dim); }
.tse-field2 input, .tse-field2 select, .tse-field2 textarea {
  background: var(--tse-bg); color: var(--tse-text); border: 1px solid var(--tse-line);
  border-radius: 6px; padding: 6px 8px; font: inherit; font-size: var(--dsw-font-xxs-12-font-size, 12px); width: 100%;
}
.tse-field2 textarea { min-height: 84px; resize: vertical; font-family: inherit; }
.tse-form { border: 1px solid var(--tse-line); border-radius: 10px; padding: 12px 14px; background: var(--tse-panel); }
.tse-formrow { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px 14px; }
.tse-hint { color: var(--tse-faint); font-size: var(--dsw-font-xxxs-11-font-size, 11px); }
`

    function installStyles() {
      const existing = document.querySelector(`style[data-plugin="${PLUGIN_ID}"]`)
      if (existing !== null) return () => {}
      const style = document.createElement('style')
      // data-plugin 必须等于模块 id：Harness 的 HMR 用这个属性名精确清理样式。
      style.dataset.plugin = PLUGIN_ID
      style.textContent = CSS
      document.head.append(style)
      return () => style.remove()
    }

    // ── API 客户端（报告语言跟随当前 locale，由服务端渲染对应语言的 Markdown）──
    function createClient(languageRef, actorRef) {
      return async function request(path, { method = 'GET', body, query } = {}) {
        const url = new URL(API + path, window.location.origin)
        for (const [key, value] of Object.entries(query ?? {})) {
          if (value !== undefined && value !== null) url.searchParams.set(key, String(value))
        }
        const actor = actorRef?.() ?? {}
        const response = await fetch(url.toString(), {
          method,
          credentials: 'same-origin',
          headers: {
            'content-type': 'application/json',
            'accept-language': languageRef(),
            // 身份走请求头（服务端会合并查询串与请求头，见 /capabilities 与 README）
            ...(actor.role === undefined ? {} : { 'x-actor-role': actor.role }),
            ...(actor.actor_id === undefined ? {} : { 'x-actor-id': actor.actor_id }),
          },
          body: body === undefined ? undefined : JSON.stringify(body),
        })
        const payload = await response.json().catch(() => null)
        if (!response.ok || payload?.ok === false) {
          const error = new Error(payload?.error?.message ?? `HTTP ${response.status}`)
          error.code = payload?.error?.code ?? `HTTP_${response.status}`
          throw error
        }
        return payload
      }
    }

    /**
     * 当前界面语言 —— 只用于千分位与小数点的本地化（zh-CN / en-US）。
     *
     * 格式化函数在工厂闭包里，拿不到组件里的 locale 快照，所以用这个可变值承接；
     * `createShell` 在 locale 推进时写入，渲染前一定已经是最新值。
     */
    let uiLanguage = 'zh'
    const langTag = () => (uiLanguage === 'en' ? 'en-US' : 'zh-CN')

    // ── 格式化 ──────────────────────────────────────────────────────────────
    //
    // ⚠️ 这四个函数与 src/core/report/format.js 是**同一套语义的客户端副本**，
    // 不是"看起来差不多"的另一个实现：
    //   pct   signed      有方向的量（收益 / Alpha / 基准收益）—— 正数带 `+`
    //   mag   magnitude   幅度量（波动率 / 胜率 / 回撤 / 达成率）—— **不加 `+`**
    //   pts   score       评分 —— 0-100 的普通数，不是百分比、不补零
    //   num   number/money 无量纲数 / 金额 —— 固定小数位 + 千分位
    //
    // 为什么不能在客户端直接 import 报告层那份：本文件是 Harnss 客户端模块系统要求的
    // 注册式 CJS 工厂，只能 require 平台 seed 词表里的模块（见文件头注释），
    // 无法 import 相对路径的 ESM。
    //
    // 因此"两份实现不许漂移"这件事**不靠注释保证，靠测试保证**：
    // tests/integration/metric-format-parity.test.js 会针对每个已声明类型的指标
    // 逐值比对客户端与报告层的输出，一旦分歧 CI 立即失败。
    //
    // 曾经的 bug：客户端只有 `pct`，于是波动率被印成 `+40.7%`、胜率被印成 `+50.0%`
    // —— 幅度量加了方向号，读起来像"正向收益"。这就是"少一个格式化函数"的代价。
    const pct = (v, d = 2) => (typeof v === 'number' && Number.isFinite(v) ? `${v > 0 ? '+' : ''}${(v * 100).toFixed(d)}%` : '—')
    const mag = (v, d = 2) => (typeof v === 'number' && Number.isFinite(v) ? `${(v * 100).toFixed(d)}%` : '—')
    const pts = (v, d = 2) => (typeof v === 'number' && Number.isFinite(v)
      ? v.toLocaleString(langTag(), { minimumFractionDigits: 0, maximumFractionDigits: d })
      : '—')
    const num = (v, d = 2) => (typeof v === 'number' && Number.isFinite(v)
      ? v.toLocaleString(langTag(), { minimumFractionDigits: d, maximumFractionDigits: d })
      : '—')
    const cls = (v) => (typeof v === 'number' && Number.isFinite(v) ? (v > 0 ? 'tse-pos' : v < 0 ? 'tse-neg' : '') : '')
    const dirOf = (action) => (action === 'BUY' ? 'BUY' : 'SELL')

    // ── 基础组件 ────────────────────────────────────────────────────────────
    function Card({ k, v, kind }) {
      return h('div', { className: `tse-card ${kind ?? ''}` },
        h('div', { className: 'k' }, k),
        h('div', { className: 'v' }, v),
        h('div', { className: 'bar' }))
    }

    function Kv({ title, rows }) {
      return h('div', { className: 'tse-kv' },
        title === undefined || title.length === 0 ? null : h('h3', {}, title),
        h('dl', {}, rows.flatMap(([k, v, klass], i) => [
          h('dt', { key: `k${i}` }, k),
          h('dd', { key: `v${i}`, className: klass ?? '' }, v),
        ])))
    }

    function Skeleton() {
      return h('div', { 'aria-busy': 'true', 'aria-live': 'polite' },
        h('div', { className: 'tse-sk tse-sk-title' }),
        h('div', { className: 'tse-sk tse-sk-card' }),
        h('div', { className: 'tse-sk tse-sk-card' }),
        ...[0, 1, 2, 3, 4, 5].map((i) => h('div', { key: i, className: 'tse-sk tse-sk-row' })))
    }

    function ErrorCard({ error, onRetry, t }) {
      return h('div', { className: 'tse-err', role: 'alert' },
        h('div', { className: 'msg' },
          h('strong', {}, `${t('errorTitle')} · ${error.code ?? 'ERROR'}`),
          h('div', {}, error.message)),
        onRetry === undefined ? null : h('button', { className: 'tse-btn primary', onClick: onRetry }, t('retry')))
    }

    function Empty({ text }) {
      return h('div', { className: 'tse-empty' }, text)
    }

    /**
     * 可排序表格：点表头切列与方向，带 aria-sort；行可用键盘打开（Enter / Space）。
     * 排序状态由父组件持有，切换语言或刷新数据后保持。
     */
    function SortableTable({ id, columns, rows, onOpen, emptyText, t, sort, onSort, keyOf }) {
      const active = sort ?? { key: null, dir: 'desc' }
      const sorted = rows.slice()
      if (active.key !== null) {
        const column = columns.find((item) => item.key === active.key)
        if (column !== undefined) {
          sorted.sort((left, right) => {
            const a = column.get(left)
            const b = column.get(right)
            if (a === b) return 0
            if (a === null || a === undefined) return 1
            if (b === null || b === undefined) return -1
            const comparison = typeof a === 'number' && typeof b === 'number' ? a - b : String(a).localeCompare(String(b))
            return active.dir === 'asc' ? comparison : -comparison
          })
        }
      }

      if (rows.length === 0) return h(Empty, { text: emptyText ?? t('noData') })

      return h('div', { className: 'tse-tablewrap' },
        h('table', { className: 'tse-table' },
          h('thead', {}, h('tr', {}, columns.map((column) => {
            const sortable = column.sortable !== false
            const isActive = active.key === column.key
            return h('th', {
              key: column.key,
              className: `${column.numeric === true ? 'num ' : ''}${sortable ? '' : 'nosort'}`,
              title: sortable ? t('sortHint') : undefined,
              'aria-sort': isActive ? (active.dir === 'asc' ? 'ascending' : 'descending') : 'none',
              onClick: sortable ? () => onSort(column.key, isActive && active.dir === 'desc' ? 'asc' : 'desc') : undefined,
            }, column.label, isActive ? h('span', { className: 'arrow' }, active.dir === 'asc' ? '▲' : '▼') : null)
          }))),
          h('tbody', {}, sorted.map((row, index) => {
            const open = onOpen === undefined ? undefined : () => onOpen(row)
            // key 必须唯一：事件表里同一策略会有多条事件，按 strategy_id 取键会重复，
            // React 会明确警告"行为不受支持"并可能漏渲染行 → 因此用显式 rowKey。
            const rowKey = typeof keyOf === 'function' ? keyOf(row) : (row.strategy_id ?? row.analyst_id ?? row.team ?? row.event_id ?? index)
            return h('tr', {
              key: rowKey,
              tabIndex: open === undefined ? undefined : 0,
              onClick: open,
              onKeyDown: open === undefined ? undefined : (event) => {
                if (event.key === 'Enter' || event.key === ' ') {
                  event.preventDefault()
                  open()
                }
              },
            }, columns.map((column) => h('td', { key: column.key, className: column.numeric === true ? 'num' : '' },
              column.render === undefined ? column.get(row) : column.render(row))))
          }))))
    }

    // ── 图表与评分环 ────────────────────────────────────────────────────────
    /** 价格走势：收盘价 + 入场/目标/止损参考线 + 达标/止损触发点 + 基准归一化对照。 */
    function PriceChart({ replay, original, rules, t }) {
      const steps = replay.price_steps
      if (steps.length === 0) return h(Empty, { text: t('noData') })

      const width = 900
      const height = 190
      const pad = { left: 48, right: 14, top: 12, bottom: 22 }
      const prices = steps.map((row) => row.price)
      const bench = replay.benchmark_steps ?? []
      const benchNorm = bench.length === prices.length ? bench.map((row) => (row.price / bench[0].price) * prices[0]) : []
      const all = prices.concat(benchNorm, [original.entry_price, original.target_price, original.stop_loss])
      const min = Math.min(...all)
      const max = Math.max(...all)
      const span = Math.max(max - min, 1e-6)
      const x = (index) => pad.left + (index / Math.max(steps.length - 1, 1)) * (width - pad.left - pad.right)
      const y = (value) => pad.top + (1 - (value - min) / span) * (height - pad.top - pad.bottom)
      const path = (values) => values.map((value, index) => `${index === 0 ? 'M' : 'L'}${x(index).toFixed(1)},${y(value).toFixed(1)}`).join(' ')

      const parts = []
      for (const ratio of [0, 0.25, 0.5, 0.75, 1]) {
        const value = min + span * ratio
        parts.push(h('line', { key: `grid${ratio}`, x1: pad.left, x2: width - pad.right, y1: y(value), y2: y(value), stroke: 'var(--tse-line)', strokeWidth: 1, strokeDasharray: ratio === 0 || ratio === 1 ? undefined : '3 4' }))
        parts.push(h('text', { key: `gl${ratio}`, x: pad.left - 6, y: y(value) + 3, fill: 'var(--tse-faint)', fontSize: 10, textAnchor: 'end', fontFamily: 'var(--tse-mono)' }, value.toFixed(2)))
      }
      for (const ref of [
        { value: original.target_price, color: 'var(--tse-good)', label: t('targetLine') },
        { value: original.entry_price, color: 'var(--tse-accent)', label: t('entryLine') },
        { value: original.stop_loss, color: 'var(--tse-bad)', label: t('stopLine') },
      ]) {
        parts.push(h('line', { key: `ref${ref.label}`, x1: pad.left, x2: width - pad.right, y1: y(ref.value), y2: y(ref.value), stroke: ref.color, strokeWidth: 1, strokeDasharray: '5 4', opacity: 0.8 }))
        parts.push(h('text', { key: `refl${ref.label}`, x: width - pad.right, y: y(ref.value) - 4, fill: ref.color, fontSize: 10, textAnchor: 'end', fontFamily: 'var(--tse-mono)' }, `${ref.label} ${ref.value.toFixed(2)}`))
      }
      if (benchNorm.length === prices.length) {
        parts.push(h('path', { key: 'bench', d: path(benchNorm), fill: 'none', stroke: 'var(--tse-faint)', strokeWidth: 1.4, strokeDasharray: '4 3', opacity: 0.85 }))
      }
      parts.push(h('path', { key: 'price', d: path(prices), fill: 'none', stroke: 'var(--tse-accent)', strokeWidth: 2, strokeLinejoin: 'round' }))

      const marker = (date, kind) => {
        if (typeof date !== 'string') return null
        const index = steps.findIndex((row) => row.date === date)
        if (index < 0) return null
        return h('circle', {
          key: `${kind}${date}`,
          cx: x(index), cy: y(prices[index]), r: 4,
          fill: kind === 'target' ? 'var(--tse-good)' : 'var(--tse-bad)',
          stroke: 'var(--tse-panel)', strokeWidth: 1.5,
        })
      }
      parts.push(marker(rules?.target_reached_on, 'target'))
      parts.push(marker(rules?.stop_loss_triggered_on, 'stop'))
      parts.push(h('text', { key: 'from', x: pad.left, y: height - 6, fill: 'var(--tse-faint)', fontSize: 10, fontFamily: 'var(--tse-mono)' }, steps[0].date))
      parts.push(h('text', { key: 'to', x: width - pad.right, y: height - 6, fill: 'var(--tse-faint)', fontSize: 10, textAnchor: 'end', fontFamily: 'var(--tse-mono)' }, steps[steps.length - 1].date))

      const legend = [
        [t('priceLine'), 'var(--tse-accent)'],
        [t('targetLine'), 'var(--tse-good)'],
        [t('stopLine'), 'var(--tse-bad)'],
        benchNorm.length === prices.length ? [t('benchmarkLine'), 'var(--tse-faint)'] : null,
        rules?.target_reached ? [t('targetHitAt'), 'var(--tse-good)'] : null,
        rules?.stop_loss_triggered ? [t('stopHitAt'), 'var(--tse-bad)'] : null,
      ].filter((row) => row !== null)

      return h('div', { className: 'tse-chart' },
        h('svg', { viewBox: `0 0 ${width} ${height}`, preserveAspectRatio: 'none', role: 'img', 'aria-label': t('priceTimeline') }, parts),
        h('div', { className: 'tse-legend' }, legend.map(([label, color]) => h('span', { key: label },
          h('i', { style: { background: color } }), label))))
    }

    /** 评分环 + 分项条形分解。 */
    function ScorePanel({ score, t }) {
      if (score === null || score === undefined) return h('div', { className: 'tse-note' }, t('notEvaluated'))
      const total = score.total
      const radius = 26
      const circumference = 2 * Math.PI * radius
      const filled = (Math.max(0, Math.min(100, total)) / 100) * circumference
      const color = total >= 70 ? 'var(--tse-good)' : total >= 45 ? 'var(--tse-accent)' : 'var(--tse-bad)'

      return h('div', { className: 'tse-score' },
        h('svg', { className: 'ring', width: 72, height: 72, viewBox: '0 0 72 72', role: 'img', 'aria-label': `${t('thScore')} ${Math.round(total)}` },
          h('circle', { cx: 36, cy: 36, r: radius, fill: 'none', stroke: 'var(--tse-panel-2)', strokeWidth: 7 }),
          h('circle', {
            cx: 36, cy: 36, r: radius, fill: 'none', stroke: color, strokeWidth: 7, strokeLinecap: 'round',
            strokeDasharray: `${filled.toFixed(1)} ${(circumference - filled).toFixed(1)}`,
            transform: 'rotate(-90 36 36)',
          }),
          h('text', { x: 36, y: 41, textAnchor: 'middle', fontSize: 17, fontWeight: 650, fill: 'var(--tse-text)', fontFamily: 'var(--tse-mono)' }, Math.round(total))),
        h('div', { className: 'tse-bars' },
          Object.entries(score.components).map(([key, value]) => h('div', { key, className: 'row' },
            h('span', { className: 'tse-note', style: { margin: 0 } }, key),
            h('div', { className: 'track' }, h('div', { className: 'fill', style: { width: `${Math.max(0, Math.min(100, value)).toFixed(1)}%` } })),
            h('span', { className: 'val' }, `${pts(value, 0)}×${score.weights[key]}`))),
          h('div', { className: 'tse-note' }, `${t('calculation')}: ${score.calculation_version}`)))
    }

    // ── 报告 Markdown → 结构化 HTML ─────────────────────────────────────────
    function escapeHtml(value) {
      return String(value).replace(/[&<>"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[char]))
    }

    function markdownToHtml(markdown) {
      const lines = escapeHtml(markdown).split('\n')
      const out = []
      let inList = false
      let inTable = false
      const closeList = () => { if (inList) { out.push('</ul>'); inList = false } }
      const closeTable = () => { if (inTable) { out.push('</tbody></table>'); inTable = false } }

      for (const line of lines) {
        if (/^\|\s*-{2,}/.test(line)) continue
        if (/^\|/.test(line)) {
          const cells = line.split('|').slice(1, -1).map((cell) => cell.trim())
          if (!inTable) {
            closeList()
            out.push('<table><thead><tr>', cells.map((cell) => `<th>${cell}</th>`).join(''), '</tr></thead><tbody>')
            inTable = true
          } else {
            out.push('<tr>', cells.map((cell) => `<td>${cell}</td>`).join(''), '</tr>')
          }
          continue
        }
        closeTable()
        if (/^###\s/.test(line)) { closeList(); out.push(`<h3>${line.replace(/^###\s/, '')}</h3>`); continue }
        if (/^##\s/.test(line)) { closeList(); out.push(`<h2>${line.replace(/^##\s/, '')}</h2>`); continue }
        if (/^#\s/.test(line)) { closeList(); out.push(`<h1>${line.replace(/^#\s/, '')}</h1>`); continue }
        if (/^-{3,}\s*$/.test(line)) { closeList(); out.push('<hr/>'); continue }
        if (/^&gt;\s?/.test(line)) { closeList(); out.push(`<blockquote>${line.replace(/^&gt;\s?/, '')}</blockquote>`); continue }
        if (/^[-*]\s/.test(line)) {
          if (!inList) { out.push('<ul>'); inList = true }
          out.push(`<li>${line.replace(/^[-*]\s/, '')}</li>`)
          continue
        }
        closeList()
        if (line.trim().length === 0) continue
        out.push(`<p>${line.replace(/_(.+?)_/g, '<em>$1</em>')}</p>`)
      }
      closeList()
      closeTable()
      return out.join('')
    }

    // ── 视图 ────────────────────────────────────────────────────────────────
    function DashboardView({ t, client, can, role, rules, onRulesSaved, onAnalyst, onTeam }) {
      const [data, setData] = useState(null)
      const [error, setError] = useState(null)
      const [sort, setSort] = useState({})

      const load = useCallback(() => {
        let alive = true
        setError(null)
        client('/dashboard').then((p) => alive && setData(p.dashboard)).catch((e) => alive && setError(e))
        return () => { alive = false }
      }, [client])
      useEffect(load, [load])

      if (error !== null) return h(ErrorCard, { error, onRetry: () => load(), t })
      if (data === null) return h(Skeleton)
      const x = data.totals
      const sortProps = (id) => ({
        t,
        sort: sort[id],
        onSort: (key, dir) => setSort((prev) => ({ ...prev, [id]: { key, dir } })),
      })

      return h('div', {},
        // 视角提示：三种角色看到的东西不同，必须让使用者一眼知道自己在哪个视角
        role === 'MANAGER' ? h('div', { className: 'tse-disclaimer' }, t('managerReadOnly')) : null,
        role === 'ANALYST' ? h('div', { className: 'tse-disclaimer' }, t('analystHint')) : null,
        role === 'ADMIN' && rules !== null
          ? h(AdminRulesPanel, { t, client, actor: () => ({ actor_id: 'demo_admin', role: 'ADMIN' }), rules, onSaved: onRulesSaved })
          : null,
        h('div', { className: 'tse-cards' },
          h(Card, { k: t('strategies'), v: x.strategies }),
          h(Card, { k: t('evaluated'), v: x.evaluated }),
          h(Card, { k: t('active'), v: x.active }),
          h(Card, { k: t('winRate'), v: mag(x.win_rate) }),
          h(Card, { k: t('avgReturn'), v: pct(x.average_return), kind: cls(x.average_return) }),
          h(Card, { k: t('avgAlpha'), v: pct(x.average_alpha), kind: cls(x.average_alpha) }),
          h(Card, { k: t('maxDrawdown'), v: mag(x.max_drawdown), kind: 'bad' }),
          h(Card, { k: t('avgScore'), v: pts(x.average_score) })),
        role === 'ANALYST' ? null : h('div', { className: 'tse-h2' }, t('analystPerformance'), h('span', { className: 'count' }, `(${data.analysts.length})`)),
        role === 'ANALYST' ? null : h(SortableTable, {
          id: 'analysts',
          ...sortProps('analysts'),
          rows: data.analysts,
          onOpen: (row) => onAnalyst(row),
          columns: [
            { key: 'name', label: t('thAnalyst'), get: (row) => row.name, render: (row) => h('span', {}, h('strong', {}, row.name), ' ', h('span', { className: 'tse-tag' }, row.analyst_id)) },
            { key: 'team', label: t('thTeam'), get: (row) => row.team },
            { key: 'strategies', label: t('thStrategies'), numeric: true, get: (row) => row.strategies },
            { key: 'evaluated', label: t('thEvaluated'), numeric: true, get: (row) => row.evaluated },
            { key: 'active', label: t('thActive'), numeric: true, get: (row) => row.active },
            { key: 'win_rate', label: t('thWinRate'), numeric: true, get: (row) => row.win_rate, render: (row) => mag(row.win_rate) },
            { key: 'average_return', label: t('thAvgReturn'), numeric: true, get: (row) => row.average_return, render: (row) => h('span', { className: cls(row.average_return) }, pct(row.average_return)) },
            { key: 'average_alpha', label: t('thAvgAlpha'), numeric: true, get: (row) => row.average_alpha, render: (row) => h('span', { className: cls(row.average_alpha) }, pct(row.average_alpha)) },
            { key: 'max_drawdown', label: t('thMaxDD'), numeric: true, get: (row) => row.max_drawdown, render: (row) => h('span', { className: 'tse-neg' }, mag(row.max_drawdown)) },
            { key: 'average_score', label: t('thScore'), numeric: true, get: (row) => row.average_score, render: (row) => pts(row.average_score) },
            { key: 'total_pnl', label: t('totalPnl'), numeric: true, get: (row) => row.total_pnl, render: (row) => num(row.total_pnl) },
          ],
        }),
        role === 'ANALYST' ? null : h('div', { className: 'tse-h2' }, t('teamPerformance'), h('span', { className: 'count' }, `(${data.teams.length})`)),
        role === 'ANALYST' ? null : h(SortableTable, {
          id: 'teams',
          ...sortProps('teams'),
          rows: data.teams,
          onOpen: (row) => onTeam(row),
          columns: [
            { key: 'team', label: t('thTeam'), get: (row) => row.team, render: (row) => h('strong', {}, row.team) },
            { key: 'analyst_count', label: t('thAnalyst'), numeric: true, get: (row) => row.analyst_count },
            { key: 'strategies', label: t('thStrategies'), numeric: true, get: (row) => row.strategies },
            { key: 'win_rate', label: t('thWinRate'), numeric: true, get: (row) => row.win_rate, render: (row) => mag(row.win_rate) },
            { key: 'average_return', label: t('thAvgReturn'), numeric: true, get: (row) => row.average_return, render: (row) => h('span', { className: cls(row.average_return) }, pct(row.average_return)) },
            { key: 'average_alpha', label: t('thAvgAlpha'), numeric: true, get: (row) => row.average_alpha, render: (row) => h('span', { className: cls(row.average_alpha) }, pct(row.average_alpha)) },
            { key: 'max_drawdown', label: t('thMaxDD'), numeric: true, get: (row) => row.max_drawdown, render: (row) => h('span', { className: 'tse-neg' }, mag(row.max_drawdown)) },
            { key: 'average_score', label: t('thScore'), numeric: true, get: (row) => row.average_score, render: (row) => pts(row.average_score) },
          ],
        }),
        h('div', { className: 'tse-h2' }, t('auditEvents'), h('span', { className: 'count' }, `(${data.recent_events.length})`)),
        h(SortableTable, {
          id: 'events',
          keyOf: (row) => row.event_id,
          ...sortProps('events'),
          rows: data.recent_events,
          onOpen: (row) => row.strategy_id && onAnalyst({ analyst_id: row.analyst_id, name: null, __strategy: row.strategy_id }),
          columns: [
            { key: 'event_id', label: t('thSeq'), get: (row) => row.event_id },
            { key: 'at', label: t('thAt'), get: (row) => row.at },
            { key: 'label', label: t('thEvent'), get: (row) => row.label },
            { key: 'strategy_id', label: t('thStrategy'), get: (row) => row.strategy_id ?? '—' },
            { key: 'actor', label: t('thActor'), get: (row) => (row.actor ? `${row.actor.role}:${row.actor.actor_id}` : '—') },
          ],
        }))
    }

    /** 表格列定义：分析师详情与团队分组共用，避免两处口径分叉。 */
    function strategyColumns(t, onOpen) {
      return {
        onOpen,
        columns: [
          { key: 'strategy_id', label: t('thStrategy'), get: (row) => row.strategy_id, render: (row) => h('span', { className: 'tse-tag' }, row.strategy_id) },
          { key: 'ticker', label: t('thTicker'), get: (row) => row.ticker, render: (row) => h('strong', {}, row.ticker) },
          { key: 'action', label: t('thAction'), get: (row) => row.action, render: (row) => h('span', { className: `tse-dir ${dirOf(row.action)}` }, row.action) },
          { key: 'status', label: t('thStatus'), get: (row) => row.status, render: (row) => h('span', { className: `tse-tag ${row.status}` }, row.status) },
          { key: 'entry_price', label: t('entry'), numeric: true, get: (row) => row.entry_price, render: (row) => num(row.entry_price) },
          { key: 'exit_price', label: t('exitPrice'), numeric: true, get: (row) => row.exit_price, render: (row) => num(row.exit_price) },
          { key: 'strategy_return', label: t('thReturn'), numeric: true, get: (row) => row.strategy_return, render: (row) => h('span', { className: cls(row.strategy_return) }, pct(row.strategy_return)) },
          { key: 'benchmark_return', label: t('thBenchmark'), numeric: true, get: (row) => row.benchmark_return, render: (row) => h('span', { className: cls(row.benchmark_return) }, pct(row.benchmark_return)) },
          { key: 'alpha', label: t('thAlpha'), numeric: true, get: (row) => row.alpha, render: (row) => h('span', { className: cls(row.alpha) }, pct(row.alpha)) },
          { key: 'target_reached', label: t('targetOutcome'), sortable: false, get: (row) => row.target_reached, render: (row) => (row.target_reached === null ? '—' : row.target_reached ? h('span', { className: 'tse-pos' }, t('reached')) : h('span', { className: 'tse-note' }, t('notReached'))) },
          { key: 'stop_loss_triggered', label: t('stopOutcome'), sortable: false, get: (row) => row.stop_loss_triggered, render: (row) => (row.stop_loss_triggered === null ? '—' : row.stop_loss_triggered ? h('span', { className: 'tse-neg' }, t('triggered')) : h('span', { className: 'tse-note' }, t('notTriggered'))) },
          { key: 'score', label: t('thScore'), numeric: true, get: (row) => row.score, render: (row) => (row.score ?? '—') },
        ],
      }
    }

    /**
     * 团队明细：团队汇总指标 + **按分析师分组**的策略。
     * 每个成员一块：可点进该分析师，下面是该成员的策略表（可点进策略详情）。
     */
    function TeamView({ t, client, team, onAnalyst, onStrategy }) {
      const [data, setData] = useState(null)
      const [error, setError] = useState(null)
      const [sort, setSort] = useState({})

      const load = useCallback(() => {
        let alive = true
        setError(null)
        client(`/teams/${encodeURIComponent(team)}/performance`)
          .then((p) => alive && setData(p))
          .catch((e) => alive && setError(e))
        return () => { alive = false }
      }, [client, team])
      useEffect(load, [load])

      if (error !== null) return h(ErrorCard, { error, onRetry: () => load(), t })
      if (data === null) return h(Skeleton)

      const m = data.metrics
      return h('div', {},
        h('div', { className: 'tse-h2' }, t('teamSummary'), h('span', { className: 'count' }, data.team)),
        h('div', { className: 'tse-cards' },
          h(Card, { k: t('strategies'), v: m.strategies }),
          h(Card, { k: t('analystCount'), v: data.analyst_count }),
          h(Card, { k: t('evaluated'), v: m.evaluated }),
          h(Card, { k: t('winRate'), v: mag(m.win_rate) }),
          h(Card, { k: t('avgReturn'), v: pct(m.average_return), kind: cls(m.average_return) }),
          h(Card, { k: t('avgAlpha'), v: pct(m.average_alpha), kind: cls(m.average_alpha) }),
          h(Card, { k: t('maxDrawdown'), v: mag(m.max_drawdown), kind: 'bad' }),
          h(Card, { k: t('avgScore'), v: pts(m.average_score) })),
        h('div', { className: 'tse-h2' }, t('byAnalyst'), h('span', { className: 'count' }, `(${data.analysts.length})`)),
        data.analysts.length === 0
          ? h(Empty, { text: t('noStrategiesInTeam') })
          : data.analysts.map((group) => {
            const gm = group.metrics
            const shared = strategyColumns(t, (row) => onStrategy(group, row))
            return h('div', { key: group.analyst_id },
              h('div', { className: 'tse-h2' },
                h('a', {
                  style: { color: 'var(--tse-accent)', cursor: 'pointer' },
                  onClick: () => onAnalyst(group),
                }, `${group.name} (${group.analyst_id})`),
                h('span', { className: 'count' },
                  `${gm.strategies} ${t('thStrategies')} · ${t('thWinRate')} ${mag(gm.win_rate)} · ${t('thAvgReturn')} ${pct(gm.average_return)} · ${t('thAlpha')} ${pct(gm.average_alpha)} · ${t('maxDrawdown')} ${mag(gm.max_drawdown)} · ${t('thScore')} ${pts(gm.average_score)}`)),
              h(SortableTable, {
                id: `team-strategies-${group.analyst_id}`,
                keyOf: (row) => row.strategy_id,
                t,
                sort: sort[group.analyst_id],
                onSort: (key, dir) => setSort((prev) => ({ ...prev, [group.analyst_id]: { key, dir } })),
                rows: group.strategies,
                onOpen: shared.onOpen,
                columns: shared.columns,
                emptyText: t('noStrategiesForMember'),
              }))
          }))
    }

    function AnalystView({ t, client, analyst, onStrategy, onPortfolio }) {
      const [data, setData] = useState(null)
      const [error, setError] = useState(null)
      const [sort, setSort] = useState({})
      const [filters, setFilters] = useState({ text: '', status: '', action: '' })

      const load = useCallback(() => {
        let alive = true
        setError(null)
        client(`/analysts/${encodeURIComponent(analyst.analyst_id)}/performance`)
          .then((p) => alive && setData(p))
          .catch((e) => alive && setError(e))
        return () => { alive = false }
      }, [client, analyst.analyst_id])
      useEffect(load, [load])

      if (error !== null) return h(ErrorCard, { error, onRetry: () => load(), t })
      if (data === null) return h(Skeleton)

      const m = data.metrics
      const filtered = data.strategies.filter((row) => {
        if (filters.text.length > 0) {
          const needle = filters.text.toLowerCase()
          if (!row.ticker.toLowerCase().includes(needle) && !row.strategy_id.toLowerCase().includes(needle)) return false
        }
        if (filters.status.length > 0 && row.status !== filters.status) return false
        if (filters.action.length > 0 && row.action !== filters.action) return false
        return true
      })

      return h('div', {},
        // 「模拟盘」入口：没有可达路径的视图等于没做
        h('div', { className: 'tse-h2' }, t('portfolio'),
          h('button', { className: 'tse-btn', onClick: () => onPortfolio?.() }, t('portfolio')),
          h('span', { className: 'tse-note' }, t('noMoney'))),
        h('div', { className: 'tse-cards' },
          h(Card, { k: t('strategies'), v: m.strategies }),
          h(Card, { k: t('evaluated'), v: m.evaluated }),
          h(Card, { k: t('winRate'), v: mag(m.win_rate) }),
          h(Card, { k: t('avgReturn'), v: pct(m.average_return), kind: cls(m.average_return) }),
          h(Card, { k: t('avgAlpha'), v: pct(m.average_alpha), kind: cls(m.average_alpha) }),
          h(Card, { k: t('maxDrawdown'), v: mag(m.max_drawdown), kind: 'bad' }),
          h(Card, { k: t('avgScore'), v: pts(m.average_score) }),
          h(Card, { k: t('totalPnl'), v: num(m.total_pnl) })),
        h('div', { className: 'tse-h2' }, `${t('strategyHistory')} — ${data.analyst.name}`, h('span', { className: 'count' }, data.analyst.team)),
        h('div', { className: 'tse-filters' },
          h('input', {
            type: 'search',
            placeholder: t('filterTicker'),
            value: filters.text,
            'aria-label': t('filterTicker'),
            onInput: (event) => setFilters((prev) => ({ ...prev, text: event.target.value })),
          }),
          h('select', {
            'aria-label': t('filterStatus'),
            value: filters.status,
            onChange: (event) => setFilters((prev) => ({ ...prev, status: event.target.value })),
          }, [['', t('allStatuses')]].concat(['ACTIVE', 'COMPLETED', 'STOPPED', 'DRAFT', 'CANCELLED', 'EXPIRED'].map((s) => [s, s]))
            .map(([value, label]) => h('option', { key: value, value }, label))),
          h('select', {
            'aria-label': t('filterAction'),
            value: filters.action,
            onChange: (event) => setFilters((prev) => ({ ...prev, action: event.target.value })),
          }, [['', t('allActions')], ['BUY', 'BUY'], ['SELL', 'SELL']].map(([value, label]) => h('option', { key: value, value }, label))),
          h('button', { className: 'tse-btn', onClick: () => setFilters({ text: '', status: '', action: '' }) }, t('clearFilters')),
          h('span', { className: 'tse-note', style: { margin: 0 } }, t('showingCount', { shown: filtered.length, total: data.strategies.length }))),
        h(SortableTable, {
          id: 'strategies',
          t,
          sort: sort.strategies,
          onSort: (key, dir) => setSort((prev) => ({ ...prev, strategies: { key, dir } })),
          rows: filtered,
          keyOf: (row) => row.strategy_id,
          emptyText: data.strategies.length === 0 ? t('emptyStrategies') : t('noMatches'),
          onOpen: strategyColumns(t, onStrategy).onOpen,
          columns: strategyColumns(t, onStrategy).columns,
        }))
    }

    /**
     * 模拟盘组合视图（批次 1）。
     *
     * 与独立 Demo 页的同名视图**同一个后端契约**（`/portfolios/*`），
     * 因此两套 UI 不会各自算出不同的净值 —— 它们都只显示账本给的东西。
     * 页面上刻意不出现任何金额：这是权重/净值式记账（C6/F1）。
     */
    function PortfolioView({ t, client, analyst, onStrategy }) {
      const [data, setData] = useState(null)
      const [nav, setNav] = useState(null)
      const [error, setError] = useState(null)
      const [verdict, setVerdict] = useState(null)
      const [sort, setSort] = useState({ key: null, dir: 'desc' })
      const analystId = analyst?.analyst_id ?? analyst

      useEffect(() => {
        let alive = true
        setData(null); setError(null); setVerdict(null)
        Promise.all([
          client(`/portfolios/${encodeURIComponent(analystId)}`),
          client(`/portfolios/${encodeURIComponent(analystId)}/nav`),
        ])
          .then(([portfolio, navPayload]) => { if (alive) { setData(portfolio); setNav(navPayload) } })
          .catch((caught) => { if (alive) setError(caught) })
        return () => { alive = false }
      }, [client, analystId])

      const onSort = useCallback((key, dir) => setSort({ key, dir }), [])

      if (error !== null) return h(ErrorCard, { t, error, onRetry: () => setSort({ key: null, dir: 'desc' }) })
      if (data === null || nav === null) return h(Skeleton)

      const reasonLabel = (reason) => ({
        STRATEGY_TERMINAL: t('closeReasonStrategyTerminal'),
        OPPOSITE_INSTRUCTION: t('closeReasonOpposite'),
        EVICTED: t('closeReasonEvicted'),
      })[reason] ?? reason
      const link = (strategyId) => h('a', { className: 'tse-link', onClick: () => onStrategy?.(strategyId) }, strategyId)

      const openColumns = [
        { key: 'lot_id', label: t('thLot'), get: (row) => row.lot_id },
        { key: 'ticker', label: t('thTicker'), get: (row) => row.ticker },
        { key: 'action', label: t('thAction'), get: (row) => row.action, render: (row) => h('span', { className: `tse-tag ${row.action}` }, row.action) },
        { key: 'weight_pct', label: t('thWeight'), numeric: true, get: (row) => row.weight_pct, render: (row) => `${row.weight_pct}%` },
        { key: 'opened_date', label: t('thOpened'), get: (row) => row.opened_date },
        { key: 'entry_price', label: t('thEntry'), numeric: true, get: (row) => row.entry_price, render: (row) => num(row.entry_price) },
        { key: 'nav_at_open', label: t('thNavAtOpen'), numeric: true, get: (row) => row.nav_at_open, render: (row) => num(row.nav_at_open) },
        { key: 'strategy_id', label: t('thStrategy'), get: (row) => row.strategy_id, render: (row) => link(row.strategy_id) },
      ]
      const closedColumns = [
        ...openColumns.slice(0, 7),
        { key: 'exit_price', label: t('thExit'), numeric: true, get: (row) => row.exit_price, render: (row) => num(row.exit_price) },
        { key: 'closed_date', label: t('thClosed'), get: (row) => row.closed_date ?? '—' },
        { key: 'close_reason', label: t('thCloseReason'), get: (row) => row.close_reason, render: (row) => h('span', { className: 'tse-note' }, reasonLabel(row.close_reason)) },
        { key: 'realized_return', label: t('thReturn'), numeric: true, get: (row) => row.realized_return, render: (row) => h('span', { className: cls(row.realized_return) }, pct(row.realized_return)) },
        { key: 'realized_pnl_nav', label: t('thRealizedPnl'), numeric: true, get: (row) => row.realized_pnl_nav, render: (row) => h('span', { className: cls(row.realized_pnl_nav) }, num(row.realized_pnl_nav)) },
      ]

      return h('div', {},
        h('div', { className: 'tse-cards' },
          h(Card, { k: t('portfolioNav'), v: num(data.nav) }),
          h(Card, { k: t('portfolioReturn'), v: pct(data.total_return), kind: data.total_return >= 0 ? 'good' : 'bad' }),
          h(Card, { k: t('portfolioExposure'), v: `${mag(data.gross_exposure_pct / 100)} / ${mag(data.max_position_pct / 100)}` }),
          h(Card, { k: t('portfolioUnallocated'), v: mag(data.unallocated_pct / 100) }),
          h(Card, { k: t('portfolioOpen'), v: String(data.counts.lots_open) }),
          h(Card, { k: t('portfolioClosed'), v: String(data.counts.lots_closed) }),
          h(Card, { k: t('portfolioEvicted'), v: String(data.counts.evictions), kind: data.counts.evictions > 0 ? 'bad' : '' }),
          h(Card, { k: t('portfolioRejected'), v: String(data.counts.rejections), kind: data.counts.rejections > 0 ? 'bad' : '' })),

        h('div', { className: 'tse-sec' },
          h('h2', {}, t('portfolioNav'), h('span', { className: 'tse-note' }, `  ${t('portfolioAccounting')} ${data.accounting_version} · as of ${data.as_of}`)),
          h(NavChart, { t, nav }),
          h('div', { className: 'tse-note' }, t('navCurveHint'))),

        h('div', { className: 'tse-sec' },
          h('h2', {}, `${t('portfolioOpen')} (${data.positions.length})`),
          h(SortableTable, { t, columns: openColumns, rows: data.positions, sort, onSort, keyOf: (row) => row.lot_id, emptyText: t('noData') })),

        h('div', { className: 'tse-sec' },
          h('h2', {}, `${t('portfolioClosed')} (${data.closed.length})`),
          h(SortableTable, { t, columns: closedColumns, rows: data.closed, sort, onSort, keyOf: (row) => row.lot_id, emptyText: t('noData') })),

        data.evictions.length === 0 ? null : h('div', { className: 'tse-sec' },
          h('h2', {}, `${t('portfolioEvicted')} (${data.evictions.length})`),
          h(SortableTable, {
            t,
            columns: [
              { key: 'date', label: t('thOpened'), get: (row) => row.date },
              { key: 'ticker', label: t('thTicker'), get: (row) => row.ticker },
              { key: 'strategy_id', label: t('thStrategy'), get: (row) => row.strategy_id, render: (row) => link(row.strategy_id) },
              { key: 'weight_pct', label: t('thWeight'), numeric: true, get: (row) => row.weight_pct, render: (row) => `${row.weight_pct}%` },
              { key: 'evicted_for', label: t('thStrategy'), get: (row) => row.evicted_for, render: (row) => link(row.evicted_for) },
            ],
            rows: data.evictions, sort, onSort, keyOf: (row) => `${row.lot_id}-${row.date}`, emptyText: t('noData'),
          })),

        h('div', { className: 'tse-sec' },
          h('button', {
            className: 'tse-btn',
            onClick: () => {
              setVerdict({ pending: true })
              client(`/portfolios/${encodeURIComponent(analystId)}/verify`)
                .then((result) => setVerdict(result))
                .catch((caught) => setVerdict({ error: caught }))
            },
          }, t('verifyPortfolio')),
          verdict === null
            ? null
            : h('div', { className: verdict.pending === true ? 'tse-note' : (verdict.matches === true ? 'tse-ok' : 'tse-err') },
              verdict.pending === true
                ? '…'
                : (verdict.error !== undefined
                  ? `${verdict.error.code}: ${verdict.error.message}`
                  : (verdict.matches === true
                    ? `${t('verifyOk')}（${verdict.accounting_version}，${verdict.instruction_digest}）`
                    : `${t('verifyFail')}：${(verdict.differences ?? []).join(', ')}`))),
          h('div', { className: 'tse-note' }, t('noMoney'))))
    }

    /** 组合净值曲线：一条净值线 + 起始净值参考线。 */
    function NavChart({ t, nav }) {
      const points = nav.curve ?? []
      if (points.length === 0) return h(Empty, { text: t('noData') })
      const width = 720
      const height = 180
      const pad = { left: 52, right: 12, top: 10, bottom: 20 }
      const values = points.map((point) => point.nav)
      const min = Math.min(...values, nav.start_nav)
      const max = Math.max(...values, nav.start_nav)
      const span = Math.max(max - min, 1e-6)
      const x = (index) => pad.left + (index / Math.max(points.length - 1, 1)) * (width - pad.left - pad.right)
      const y = (value) => pad.top + (1 - (value - min) / span) * (height - pad.top - pad.bottom)
      const path = values.map((value, index) => `${index === 0 ? 'M' : 'L'}${x(index).toFixed(1)},${y(value).toFixed(1)}`).join(' ')
      const grid = [0, 0.5, 1].map((ratio) => {
        const value = min + span * ratio
        return h('g', { key: ratio },
          h('line', { x1: pad.left, x2: width - pad.right, y1: y(value), y2: y(value), stroke: 'var(--dsw-alias-border-l1)', strokeWidth: 1, strokeDasharray: '3 4' }),
          h('text', { x: pad.left - 6, y: y(value) + 4, textAnchor: 'end', fontSize: 10, fill: 'var(--dsw-alias-label-tertiary)' }, value.toFixed(2)))
      })
      return h('div', { className: 'tse-chart' },
        h('svg', { viewBox: `0 0 ${width} ${height}`, role: 'img', 'aria-label': `${t('portfolioNav')} ${nav.start_nav} → ${nav.nav}` },
          grid,
          h('line', { x1: pad.left, x2: width - pad.right, y1: y(nav.start_nav), y2: y(nav.start_nav), stroke: 'var(--dsw-alias-label-tertiary)', strokeWidth: 1, strokeDasharray: '2 3' }),
          h('path', { d: path, fill: 'none', stroke: 'var(--dsw-alias-brand-primary)', strokeWidth: 2 }),
          h('text', { x: pad.left, y: height - 4, fontSize: 10, fill: 'var(--dsw-alias-label-tertiary)' }, points[0].date),
          h('text', { x: width - pad.right, y: height - 4, textAnchor: 'end', fontSize: 10, fill: 'var(--dsw-alias-label-tertiary)' }, points.at(-1).date)))
    }

    function StrategyView({ t, client, can, actor, strategyId, tab, onTab, onEdit }) {
      const [state, setState] = useState({ loading: true })
      const [busy, setBusy] = useState(false)

      const load = useCallback(() => {
        let alive = true
        setState({ loading: true })
        Promise.all([
          client(`/strategies/${encodeURIComponent(strategyId)}/replay`),
          client(`/reports/strategies/${encodeURIComponent(strategyId)}`),
        ]).then(([replay, report]) => {
          if (!alive) return
          setState({ loading: false, replay: replay.replay, report: report.report, markdown: report.markdown })
        }).catch((error) => alive && setState({ loading: false, error }))
        return () => { alive = false }
      }, [client, strategyId])

      // 语言切换后重新拉取：报告 Markdown 由服务端按语言渲染
      useEffect(load, [load, t])

      const act = useCallback(async (path) => {
        setBusy(true)
        try {
          await client(path, { method: 'POST', body: {} })
          load()
        } catch (error) {
          setState((prev) => ({ ...prev, error }))
        } finally {
          setBusy(false)
        }
      }, [client, load])

      // ⚠️ 所有 hook 必须在 early return **之前**：放在 return 之后会让两次渲染的 hook
      // 数量不一致，React 会抛 "Rendered more hooks than during the previous render"
      // 并整棵树卸载（表现为页面空白）。实测踩过。
      const runAction = useCallback(async (path, body) => {
        setBusy(true)
        try {
          await client(path, { method: 'POST', body: body ?? { actor: actor() } })
          load()
        } catch (caught) {
          setState((prev) => ({ ...prev, error: caught }))
        } finally {
          setBusy(false)
        }
      }, [client, actor, load])

      if (state.loading) return h(Skeleton)
      if (state.error !== undefined) return h(ErrorCard, { error: state.error, onRetry: () => load(), t })

      const { report, replay, markdown } = state
      const meta = report.factual.strategy
      const original = report.factual.original_strategy
      const performance = report.factual.actual_performance
      const rules = report.factual.rule_evaluation
      const score = report.factual.score

      const cards = h('div', { className: 'tse-cards' },
        h(Card, { k: t('thTicker'), v: meta.ticker }),
        h(Card, { k: t('thAction'), v: meta.action }),
        h(Card, { k: t('thStatus'), v: meta.status }),
        h(Card, { k: t('returnPct'), v: pct(performance?.strategy_return), kind: cls(performance?.strategy_return) }),
        h(Card, { k: t('thBenchmark'), v: pct(performance?.benchmark_return), kind: cls(performance?.benchmark_return) }),
        h(Card, { k: t('alpha'), v: pct(performance?.alpha), kind: cls(performance?.alpha) }),
        h(Card, { k: t('maxDrawdown'), v: mag(performance?.max_drawdown), kind: 'bad' }),
        h(Card, { k: t('thScore'), v: score ? pts(score.total) : '—' }))

      const isDraft = meta.status === 'DRAFT'
      const terminal = ['COMPLETED', 'STOPPED', 'EXPIRED'].includes(meta.status)

      // 维护入口：草稿可编辑/冻结，ACTIVE 可取消 —— 由能力矩阵与状态共同决定
      const actions = h('div', { className: 'tse-toolbar' },
        isDraft && can('strategy.create')
          ? h('button', { className: 'tse-btn primary', onClick: onEdit }, t('editStrategy'))
          : null,
        isDraft && can('strategy.freeze')
          ? h('button', { className: 'tse-btn', disabled: busy, onClick: () => runAction(`/strategies/${encodeURIComponent(strategyId)}/freeze`) }, t('freezeStrategy'))
          : null,
        meta.status === 'ACTIVE' && can('strategy.cancel')
          ? h('button', {
            className: 'tse-btn',
            disabled: busy,
            onClick: () => {
              const reason = window.prompt(t('cancelReason'))
              if (reason === null) return
              runAction(`/strategies/${encodeURIComponent(strategyId)}/cancel`, { reason, actor: actor() })
            },
          }, t('cancelStrategy'))
          : null,
        terminal ? h('span', { className: 'tse-note', style: { margin: 0 } }, t('cannotCancelTerminal')) : null,
        h('button', { className: 'tse-btn', onClick: () => act(`/monitor/${encodeURIComponent(strategyId)}`), disabled: busy }, t('monitorRun')),
        h('button', { className: 'tse-btn', onClick: () => act(`/strategies/${encodeURIComponent(strategyId)}/evaluate`), disabled: busy }, t('runEvaluation')),
        h('span', { className: 'tse-note', style: { margin: 0 } },
          `${meta.status} · ${t('submitted')} ${meta.submitted} · ${replay.price_steps.length} ${t('tradesDays')}`))

      const tabs = h('div', { className: 'tse-tabs', role: 'tablist' }, [
        ['performance', t('performance')],
        ['replay', t('replay')],
        ['report', t('report')],
      ].map(([key, label]) => h('button', {
        key,
        role: 'tab',
        'aria-selected': tab === key ? 'true' : 'false',
        className: tab === key ? 'on' : '',
        onClick: () => onTab(key),
      }, label)))

      if (tab === 'replay') {
        return h('div', {}, cards, actions, tabs,
          h('div', { className: 'tse-h2' }, t('priceTimeline')),
          h(PriceChart, { replay, original, rules, t }),
          h('div', { className: 'tse-h2' }, t('lifecycleEvents'), h('span', { className: 'count' }, `(${replay.timeline.length})`)),
          h('ul', { className: 'tse-timeline' }, replay.timeline.map((row) => h('li', { key: row.sequence, className: `ev-${row.type}` },
            h('span', { className: 'tse-at' }, row.at), row.label,
            row.actor ? h('span', { className: 'tse-who' }, ` — ${row.actor.role}:${row.actor.actor_id}`) : null))),
          h('div', { className: 'tse-h2' }, t('auditAnswers')),
          h(Kv, { rows: [
            [t('q1'), replay.answers['1_who_submitted']],
            [t('q2'), replay.answers['2_submitted_at']],
            [t('q3'), replay.answers['3_price_at_submission']],
            [t('q4'), replay.answers['4_position_before']],
            [t('q6'), `${replay.price_steps.length} ${t('tradesDays')}`],
            [t('q7'), String(replay.answers['7_target_reached'])],
            [t('q8'), String(replay.answers['8_stop_loss_triggered'])],
            [t('q9'), pct(replay.answers['9_strategy_return'])],
            [t('q10'), replay.answers['10_benchmark'] === null ? '—' : pct(replay.answers['10_benchmark'].benchmark_return)],
            [t('q11'), replay.answers['11_final_score'] === null ? '—' : t('scoreOf', { score: replay.answers['11_final_score'] })],
            [t('replayConsistent'), String(replay.replay_consistent)],
          ] }))
      }

      if (tab === 'report') {
        return h('div', {}, cards, actions, tabs,
          h('div', { className: 'tse-disclaimer' }, report.commentary_disclaimer),
          h('div', { className: 'tse-prose', dangerouslySetInnerHTML: { __html: markdownToHtml(markdown) } }))
      }

      return h('div', {}, cards, actions, tabs,
        h('div', { className: 'tse-grid' },
          h(Kv, { title: t('strategySection'), rows: [
            [t('strategyId'), meta.strategy_id],
            [t('analystLabel'), `${meta.analyst_name} (${meta.analyst_id})`],
            [t('submitted'), meta.submitted],
            [t('frozenAt'), meta.frozen_at ?? '—'],
            [t('benchmark'), original.benchmark],
            [t('positionBefore'), num(original.position_before, 0)],
            [t('quantity'), num(original.quantity, 0)],
          ] }),
          h(Kv, { title: t('originalStrategy'), rows: [
            [t('entry'), num(original.entry_price)],
            [t('target'), num(original.target_price)],
            [t('stop'), num(original.stop_loss)],
            [t('plannedHolding'), `${original.holding_period} ${t('days')}`],
            [t('snapshotPrice'), num(original.market_snapshot?.price)],
            [t('snapshotVolume'), num(original.market_snapshot?.volume, 0)],
            [t('snapshotAt'), original.market_snapshot?.timestamp ?? '—'],
          ] }),
          h(Kv, { title: t('actualPerformance'), rows: performance === null ? [[t('thStatus'), t('notEvaluated')]] : [
            [t('entryExit'), `${num(performance.entry_price)} → ${num(performance.exit_price)}`],
            [t('exitOn'), performance.exit_date ?? '—'],
            [t('returnPct'), pct(performance.strategy_return), cls(performance.strategy_return)],
            [t('thBenchmark'), pct(performance.benchmark_return), cls(performance.benchmark_return)],
            [t('alpha'), pct(performance.alpha), cls(performance.alpha)],
            [t('pnl'), num(performance.pnl)],
            [t('actualHolding'), `${performance.holding_days} ${t('days')}`],
            [t('exitReason'), performance.exit_reason],
          ] }),
          h(Kv, { title: t('riskMetrics'), rows: performance === null ? [[t('thStatus'), t('notEvaluated')]] : [
            [t('maxDrawdown'), mag(performance.max_drawdown)],
            [t('volatility'), mag(performance.volatility)],
            [t('riskReward'), num(performance.risk_reward_ratio, 2)],
            [t('targetOutcome'), rules === null ? '—' : rules.target_reached ? `${t('reached')} ${rules.target_reached_on}` : t('notReached')],
            [t('stopOutcome'), rules === null ? '—' : rules.stop_loss_triggered ? `${t('triggered')} ${rules.stop_loss_triggered_on}` : t('notTriggered')],
            [t('benchmarkOutcome'), rules === null ? '—' : t(rules.benchmark_outcome)],
          ] })),
        h('div', { className: 'tse-h2' }, t('scoreBreakdown')),
        h('div', { className: 'tse-kv' }, h(ScorePanel, { score, t })),
        h('div', { className: 'tse-h2' }, t('priceTimeline')),
        h(PriceChart, { replay, original, rules, t }),
        h('div', { className: 'tse-h2' }, t('analystReasoning')),
        h('div', { className: 'tse-reason' }, original.reason),
        h('div', { className: 'tse-note', style: { marginTop: '16px' } }, t('factsFooter')))
    }

    /** 表单字段：label + 控件（可选提示）。 */
    function Field({ label, children, hint }) {
      return h('label', { className: 'tse-field2' }, label, children, hint === undefined ? null : h('span', { className: 'tse-hint' }, hint))
    }

    /**
     * 提交 / 编辑策略。
     *
     * 校验规则与服务端同源（BUY: stop<entry<target；SELL: target<entry<stop>）——
     * 前端先拦只是为了体验，服务端仍会再拦一次；**前端校验不是安全边界**。
     */
    function StrategyFormView({ t, client, can, actor, analysts, role, actorId, mode, strategyId, onDone, onCancel }) {
      const [universe, setUniverse] = useState(null)
      const [existing, setExisting] = useState(null)
      const [loading, setLoading] = useState(true)
      // 两类错误必须分开：
      //  · loadError  → 加载失败，整页替换成错误卡片（没什么可保留的）
      //  · formError  → 本地校验/提交失败，**就地**显示在表单里，绝不能让表单消失
      //    （否则用户刚填的内容全丢，实测踩过）
      const [loadError, setLoadError] = useState(null)
      const [formError, setFormError] = useState(null)
      const [notice, setNotice] = useState(null)
      const [busy, setBusy] = useState(false)
      const [quote, setQuote] = useState(null)
      const [form, setForm] = useState({
        analyst_id: role === 'ANALYST' ? actorId : (analysts[0]?.analyst_id ?? 'john'),
        ticker: '', action: 'BUY', entry_price: '', target_price: '', stop_loss: '',
        holding_period: 20, quantity: 100, position_before: 0, benchmark: '', reason: '',
      })

      const patch = useCallback((changes) => setForm((prev) => ({ ...prev, ...changes })), [])

      useEffect(() => {
        let alive = true
        setLoading(true)
        const tasks = [client('/market/universe')]
        if (mode === 'edit') tasks.push(client(`/strategies/${encodeURIComponent(strategyId)}`))
        Promise.all(tasks).then(([market, payload]) => {
          if (!alive) return
          setUniverse(market)
          if (payload !== undefined) {
            const record = payload.strategy
            setExisting(record)
            setForm({
              analyst_id: record.analyst_id,
              ticker: record.ticker,
              action: record.action,
              entry_price: record.entry_price,
              target_price: record.target_price,
              stop_loss: record.stop_loss,
              holding_period: record.holding_period,
              quantity: record.quantity ?? 100,
              position_before: record.position_before ?? 0,
              benchmark: record.benchmark,
              reason: record.reason,
            })
          } else {
            setForm((prev) => ({ ...prev, ticker: market.tickers[0], benchmark: market.benchmarks[0] }))
          }
          setLoading(false)
        }).catch((caught) => { if (alive) { setLoadError(caught); setLoading(false) } })
        return () => { alive = false }
      }, [client, mode, strategyId])

      const refreshQuote = useCallback(async (ticker) => {
        try {
          const payload = await client(`/market/quote/${encodeURIComponent(ticker)}`)
          setQuote(payload.quote ?? payload)
        } catch {
          setQuote(null)
        }
      }, [client])

      useEffect(() => { if (form.ticker.length > 0) refreshQuote(form.ticker) }, [form.ticker, refreshQuote])

      if (mode === 'create' && !can('strategy.create')) {
        return h('div', {},
          h('div', { className: 'tse-h2' }, t('newStrategy')),
          h('div', { className: 'tse-disclaimer' }, `${t('noPermission')} — ${t('managerReadOnly')}`),
          h('button', { className: 'tse-btn', onClick: onCancel }, t('backToDashboard')))
      }
      if (mode === 'edit' && existing !== null && existing.frozen === true) {
        return h('div', {},
          h('div', { className: 'tse-h2' }, t('editStrategy')),
          h('div', { className: 'tse-disclaimer' }, `${t('noPermission')} — FROZEN_STRATEGY_IMMUTABLE`),
          h('button', { className: 'tse-btn', onClick: onCancel }, t('back')))
      }
      if (loading) return h(Skeleton)
      if (loadError !== null) return h(ErrorCard, { error: loadError, t })

      const localError = () => {
        const entry = Number(form.entry_price)
        const target = Number(form.target_price)
        const stop = Number(form.stop_loss)
        if ((form.reason ?? '').trim().length === 0) return t('requiredFields')
        if (![entry, target, stop].every((value) => Number.isFinite(value) && value > 0)) return t('requiredFields')
        if (!Number.isInteger(Number(form.holding_period)) || Number(form.holding_period) < 1) return t('requiredFields')
        if (form.action === 'BUY' && !(stop < entry && target > entry)) return t('invalidBuy')
        if (form.action === 'SELL' && !(target < entry && stop > entry)) return t('invalidSell')
        return null
      }

      const submit = async (freeze) => {
        const problem = localError()
        if (problem !== null) { setFormError(new Error(problem)); setNotice(null); return }
        setBusy(true)
        setFormError(null)
        const body = {
          ...form,
          holding_period: Number(form.holding_period),
          quantity: Number(form.quantity),
          position_before: Number(form.position_before),
          actor: actor(),
        }
        try {
          if (mode === 'edit') {
            await client(`/strategies/${encodeURIComponent(strategyId)}`, { method: 'PATCH', body: { patch: body, actor: actor() } })
            if (freeze) {
              await client(`/strategies/${encodeURIComponent(strategyId)}/freeze`, { method: 'POST', body: { actor: actor() } })
              setNotice(t('frozenToast', { id: strategyId }))
            } else {
              setNotice(t('savedDraft'))
            }
            onDone(strategyId)
            return
          }
          const payload = await client('/strategies', { method: 'POST', body: { ...body, auto_freeze: freeze } })
          setNotice(t(freeze ? 'createdFrozen' : 'createdDraft', { id: payload.strategy_id }))
          onDone(payload.strategy_id)
        } catch (caught) {
          setFormError(caught)
        } finally {
          setBusy(false)
        }
      }

      const numberField = (key, label, step = '0.01') => h(Field, { label },
        h('input', {
          type: 'number', step, value: form[key],
          // 用 onInput 而不是 onChange：React 对文本类受控组件把 onChange 实现为
          // "input 事件 + 内部 value tracker 比对"，而在 jsdom 里那个 tracker 不生效，
          // 导致 onChange 永不触发（实测 onChange 0 次、onInput 正常）。onInput 对
          // input/textarea 与 onChange 等价，且真实浏览器同样逐键触发。
          onInput: (event) => patch({ [key]: event.target.value === '' ? '' : Number(event.target.value) }),
        }))

      return h('div', {},
        h('div', { className: 'tse-h2' }, mode === 'create' ? t('newStrategy') : t('editStrategy')),
        h('div', { className: 'tse-disclaimer' }, t('snapshotHint')),
        mode === 'create' ? h('div', { className: 'tse-note' }, t('draftHint')) : null,
        notice === null ? null : h('div', { className: 'tse-note' }, notice),
        h('div', { className: 'tse-form' },
          h('div', { className: 'tse-formrow' },
            h(Field, { label: t('analystSelf') },
              role === 'ANALYST'
                ? h('input', { value: actorId, readOnly: true })
                : h('select', {
                  value: form.analyst_id,
                  onChange: (event) => patch({ analyst_id: event.target.value }),
                }, analysts.map((item) => h('option', { key: item.analyst_id, value: item.analyst_id }, `${item.name} (${item.analyst_id})`)))),
            h(Field, { label: t('fieldTicker') },
              h('select', { value: form.ticker, onChange: (event) => patch({ ticker: event.target.value }) },
                universe.tickers.map((ticker) => h('option', { key: ticker, value: ticker }, ticker)))),
            h(Field, { label: t('fieldAction') },
              h('select', { value: form.action, onChange: (event) => patch({ action: event.target.value }) },
                ['BUY', 'SELL'].map((item) => h('option', { key: item, value: item }, item)))),
            numberField('entry_price', t('fieldEntry')),
            numberField('target_price', t('fieldTarget')),
            numberField('stop_loss', t('fieldStop')),
            numberField('holding_period', t('fieldHolding'), '1'),
            numberField('quantity', t('fieldQuantity'), '1'),
            numberField('position_before', t('fieldPositionBefore'), '1'),
            h(Field, { label: t('fieldBenchmark') },
              h('select', { value: form.benchmark, onChange: (event) => patch({ benchmark: event.target.value }) },
                universe.benchmarks.map((item) => h('option', { key: item, value: item }, item))))),
          h('div', { className: 'tse-toolbar', style: { marginTop: '10px' } },
            h('button', {
              className: 'tse-btn',
              type: 'button',
              onClick: () => {
                const price = Number(quote?.price)
                if (!Number.isFinite(price) || price <= 0) return
                patch({
                  entry_price: price,
                  target_price: Number((form.action === 'BUY' ? price * 1.15 : price * 0.85).toFixed(2)),
                  stop_loss: Number((form.action === 'BUY' ? price * 0.93 : price * 1.07).toFixed(2)),
                })
              },
            }, t('useCurrentPrice')),
            quote === null ? null : h('span', { className: 'tse-note', style: { margin: 0 } }, `${t('currentPrice')} ${quote.price}`)),
          h(Field, { label: t('fieldReason') },
            h('textarea', { value: form.reason, onInput: (event) => patch({ reason: event.target.value }) })),
          formError === null ? null : h('div', { className: 'tse-err', role: 'alert' },
            h('div', { className: 'msg' }, h('strong', {}, formError.code ?? 'ERROR'), h('div', {}, formError.message))),
          h('div', { className: 'tse-toolbar', style: { marginTop: '12px' } },
            h('button', { className: 'tse-btn', type: 'button', onClick: onCancel, disabled: busy }, t('back')),
            can('strategy.create') && mode === 'create'
              ? h('button', { className: 'tse-btn', type: 'button', disabled: busy, onClick: () => submit(false) }, t('saveDraft'))
              : null,
            h('button', { className: 'tse-btn primary', type: 'button', disabled: busy, onClick: () => submit(true) },
              mode === 'create' ? t('submitAndFreeze') : t('freezeStrategy')))))
    }

    /** 管理员：评分规则编辑（只影响之后的评价）。 */
    function AdminRulesPanel({ t, client, actor, rules, onSaved }) {
      const [draft, setDraft] = useState(() => ({ weights: { ...rules.weights }, version: rules.version }))
      const [error, setError] = useState(null)
      const [busy, setBusy] = useState(false)

      const save = async () => {
        setBusy(true)
        setError(null)
        try {
          const payload = await client('/rules', { method: 'PUT', body: { version: draft.version, weights: draft.weights, actor: actor() } })
          onSaved(payload.rules)
        } catch (caught) {
          setError(caught)
        } finally {
          setBusy(false)
        }
      }

      return h('div', {},
        h('div', { className: 'tse-h2' }, t('adminPanel')),
        h('div', { className: 'tse-form' },
          h('div', { className: 'tse-formrow' },
            ...Object.keys(draft.weights).map((key) => h(Field, { key, label: key },
              h('input', {
                type: 'number', step: '0.05', value: draft.weights[key],
                onInput: (event) => setDraft((prev) => ({ ...prev, weights: { ...prev.weights, [key]: Number(event.target.value) } })),
              }))),
            h(Field, { label: t('rulesVersion') },
              h('input', { value: draft.version, onInput: (event) => setDraft((prev) => ({ ...prev, version: event.target.value })) }))),
          h('div', { className: 'tse-note' }, t('rulesWeights')),
          error === null ? null : h('div', { className: 'tse-err', role: 'alert' }, h('div', { className: 'msg' }, h('div', {}, error.message))),
          h('div', { className: 'tse-toolbar', style: { marginTop: '10px' } },
            h('button', { className: 'tse-btn primary', disabled: busy, onClick: save }, t('saveRules')))))
    }

    // ── 顶层组件 ────────────────────────────────────────────────────────────
    function TradeEvaluationDashboard({ t, locale, language }) {
      const [stack, setStack] = useState([])
      const [view, setView] = useState({ name: 'dashboard' })
      const [meta, setMeta] = useState(null)
      const [busy, setBusy] = useState(false)
      // 身份：角色 + 当前分析师（Demo 没有真实登录，显式选择；权限仍全部由服务端强制）
      const [role, setRole] = useState('MANAGER')
      const [actorId, setActorId] = useState('john')
      const [capabilities, setCapabilities] = useState(null)
      const [analysts, setAnalysts] = useState([])
      const [rules, setRules] = useState(null)

      const actorRef = useRef({ role, actor_id: actorId })
      actorRef.current = { role, actor_id: role === 'ANALYST' ? actorId : `demo_${role.toLowerCase()}` }

      // 报告语言跟随当前 locale；身份跟随当前角色/分析师
      const client = useMemo(() => createClient(() => language, () => actorRef.current), [language])
      const can = useCallback((capability) => capabilities?.[capability]?.includes(role) === true, [capabilities, role])
      const actor = useCallback(() => ({ ...actorRef.current }), [])

      useEffect(() => {
        let alive = true
        Promise.all([client('/meta'), client('/capabilities'), client('/analysts'), client('/rules')])
          .then(([metaPayload, caps, analystList, rulePayload]) => {
            if (!alive) return
            setMeta(metaPayload)
            setCapabilities(caps.capabilities)
            setAnalysts(analystList.analysts)
            setRules(rulePayload.rules)
          })
          .catch(() => {})
        return () => { alive = false }
      }, [client, t])

      const navigate = useCallback((next) => {
        setStack((prev) => (next.name === 'dashboard' ? [] : [...prev, view]))
        setView(next)
      }, [view])

      const goBack = useCallback(() => {
        setStack((prev) => {
          const previous = prev[prev.length - 1]
          setView(previous ?? { name: 'dashboard' })
          return prev.slice(0, -1)
        })
      }, [])

      const runGlobal = useCallback(async (path, successKey) => {
        setBusy(true)
        try {
          const result = await client(path, { method: 'POST', body: {} })
          const monitor = successKey === 'advanceResult'
            ? await client('/monitor/run', { method: 'POST', body: {} })
            : {}
          window.alert(t(successKey, {
            asOf: result.as_of ?? '',
            monitored: result.monitored ?? monitor.monitored ?? 0,
            changed: result.changed ?? monitor.changed ?? 0,
            stopped: result.stopped ?? 0,
            completed: result.completed ?? 0,
            now: result.clock?.now ?? '',
            boundary: result.boundary ?? '',
          }))
          setView((prev) => ({ ...prev }))
        } catch (error) {
          window.alert(`${error.code}: ${error.message}`)
        } finally {
          setBusy(false)
        }
      }, [client, t])

      const crumbs = []
      crumbs.push(h('a', { key: 'root', onClick: () => navigate({ name: 'dashboard' }) }, t('dashboard')))
      // 团队层：从团队明细进来时先显示团队，方便"策略 → 团队 → Dashboard"逐层退回
      if (view.team !== undefined && view.name !== 'team') {
        crumbs.push(h('span', { key: 't0' }, '/'))
        crumbs.push(h('a', { key: 'team', onClick: () => navigate({ name: 'team', team: view.team }) }, view.team))
      }
      if (view.name === 'team') {
        crumbs.push(h('span', { key: 's1' }, '/'))
        crumbs.push(h('span', { key: 'teamleaf', className: 'leaf' }, view.team))
      } else if (view.name === 'analyst' || view.name === 'strategy' || view.name === 'portfolio') {
        crumbs.push(h('span', { key: 's1' }, '/'))
        crumbs.push(h('a', {
          key: 'analyst',
          onClick: () => navigate({ name: 'analyst', analyst: view.analyst ?? { analyst_id: view.analyst_id, name: view.analystName }, team: view.team }),
        }, view.analyst?.name ?? view.analystName ?? view.analyst_id ?? t('analystLabel')))
      }
      if (view.name === 'portfolio') {
        crumbs.push(h('span', { key: 's2' }, '/'))
        crumbs.push(h('span', { key: 'pf', className: 'leaf' }, t('portfolio')))
      }
      if (view.name === 'strategy') {
        crumbs.push(h('span', { key: 's2' }, '/'))
        crumbs.push(h('span', { key: 'sid', className: 'leaf' }, view.strategyId))
      }
      if (view.name === 'new') {
        crumbs.push(h('span', { key: 's3' }, '/'))
        crumbs.push(h('span', { key: 'newleaf', className: 'leaf' }, t('newStrategy')))
      }
      if (view.name === 'edit') {
        crumbs.push(h('span', { key: 's4' }, '/'))
        crumbs.push(h('a', { key: 'editstrategy', onClick: () => navigate({ name: 'strategy', strategyId: view.strategyId }) }, view.strategyId))
        crumbs.push(h('span', { key: 's5' }, '/'))
        crumbs.push(h('span', { key: 'editleaf', className: 'leaf' }, t('editStrategy')))
      }

      return h('div', { className: 'tse-root' },
        h('div', { className: 'tse-bar' },
          h('div', { className: 'tse-brand' },
            h('div', { className: 'tse-mark', 'aria-hidden': 'true' }, 'T'),
            h('span', { className: 'tse-title' }, t('appTitle'))),
          h('span', { className: 'tse-meta' }, meta === null
            ? ''
            : `${t('storageLabel')}=${meta.storage.driver} · ${t('rulesLabel')}=${meta.rules_version} · ${t('clockLabel')}=${meta.clock.now} · ${t('boundaryLabel')}=${meta.market.boundary}`),
          h('div', { className: 'tse-grow' }),
          // 身份：角色 + 当前分析师。前端只负责"不显示不该有的入口"，权限全部在服务端。
          h('label', { className: 'tse-field' },
            h('span', {}, t('identity')),
            h('select', {
              value: role,
              'aria-label': t('identity'),
              onChange: (event) => {
                setRole(event.target.value)
                setView({ name: 'dashboard' })
                setStack([])
              },
            }, ['MANAGER', 'ANALYST', 'ADMIN'].map((item) => h('option', { key: item, value: item }, item)))),
          role === 'ANALYST'
            ? h('label', { className: 'tse-field' },
              h('span', {}, t('analystSelf')),
              h('select', {
                value: actorId,
                'aria-label': t('analystSelf'),
                onChange: (event) => setActorId(event.target.value),
              }, analysts.map((item) => h('option', { key: item.analyst_id, value: item.analyst_id }, `${item.name} (${item.analyst_id})`))))
            : null,
          can('strategy.create')
            ? h('button', { className: 'tse-btn primary', onClick: () => navigate({ name: 'new' }) }, t('newStrategy'))
            : null,
          // 语言切换：写的是 shell 的同一个偏好，标签页文案与报告语言会一起变
          h('div', { className: 'tse-seg', title: t('language'), role: 'group', 'aria-label': t('language') },
            (locale?.languages ?? [{ id: 'zh', label: '中文' }, { id: 'en', label: 'English' }])
              .map((entry) => h('button', {
                key: entry.id,
                className: entry.id === language ? 'on' : '',
                onClick: () => locale?.setLocale(entry.id),
              }, entry.label))),
          h('button', { className: 'tse-btn', onClick: () => runGlobal('/monitor/run', 'monitorResult'), disabled: busy }, t('monitor')),
          h('button', { className: 'tse-btn', onClick: () => runGlobal('/demo/advance-clock', 'advanceResult'), disabled: busy }, t('advance')),
          h('button', {
            className: 'tse-btn',
            disabled: busy,
            onClick: () => { if (window.confirm(t('resetConfirm'))) runGlobal('/demo/reset', 'resetDone') },
          }, t('reset'))),
        h('div', { className: 'tse-scroll' },
          h('div', { className: 'tse-toolbar' },
            h('button', {
              className: 'tse-btn',
              disabled: stack.length === 0,
              onClick: goBack,
              title: t('back'),
              'aria-label': t('back'),
            }, '\u2190 ', t('back')),
            h('nav', { className: 'tse-crumbs', 'aria-label': 'breadcrumb' }, crumbs)),
          view.name === 'new' && h(StrategyFormView, {
            t, client, can, actor, analysts, role, actorId,
            mode: 'create',
            onDone: (strategyId) => { setStack([]); setView({ name: 'strategy', strategyId }) },
            onCancel: () => navigate({ name: 'dashboard' }),
          }),
          view.name === 'edit' && h(StrategyFormView, {
            t, client, can, actor, analysts, role, actorId,
            mode: 'edit',
            strategyId: view.strategyId,
            onDone: (strategyId) => setView({ name: 'strategy', strategyId }),
            onCancel: () => navigate({ name: 'strategy', strategyId: view.strategyId }),
          }),
          view.name === 'dashboard' && h(DashboardView, {
            t,
            client,
            can,
            role,
            rules,
            onRulesSaved: (next) => setRules(next),
            onTeam: (row) => navigate({ name: 'team', team: row.team }),
            onAnalyst: (row) => navigate(row.__strategy !== undefined
              ? { name: 'strategy', strategyId: row.__strategy, analystId: row.analyst_id }
              : { name: 'analyst', analyst: row }),
          }),
          view.name === 'team' && h(TeamView, {
            t,
            client,
            team: view.team,
            onAnalyst: (group) => navigate({ name: 'analyst', analyst: { analyst_id: group.analyst_id, name: group.name }, team: view.team }),
            onStrategy: (group, row) => navigate({
              name: 'strategy',
              strategyId: row.strategy_id,
              analystId: group.analyst_id,
              analystName: group.name,
              team: view.team,
            }),
          }),
          view.name === 'analyst' && h(AnalystView, {
            t,
            client,
            analyst: view.analyst,
            onStrategy: (row) => navigate({ name: 'strategy', analyst: view.analyst, strategyId: row.strategy_id }),
            onPortfolio: () => navigate({ name: 'portfolio', analyst: view.analyst }),
          }),
          view.name === 'portfolio' && h(PortfolioView, {
            t,
            client,
            analyst: view.analyst,
            onStrategy: (strategyId) => navigate({ name: 'strategy', analyst: view.analyst, strategyId }),
          }),
          view.name === 'strategy' && h(StrategyView, {
            t,
            client,
            can,
            actor,
            strategyId: view.strategyId,
            tab: view.tab ?? 'performance',
            onTab: (tab) => setView((prev) => ({ ...prev, tab })),
            onEdit: () => navigate({ name: 'edit', strategyId: view.strategyId }),
          })))
    }

    /**
     * 把 locale 服务与 `t` 注入面板组件。
     *
     * 语言切换时 shell 会推进 locale 快照，这里订阅并重渲染，因此**不需要重新挂载插件**、
     * 也不需要刷新页面，面板内文案与报告语言就会一起切换。
     */
    function createShell(locale) {
      const snapshotFallback = { active: 'zh', locales: [{ id: 'zh', label: '中文' }, { id: 'en', label: 'English' }], revision: 0 }
      const initial = (typeof locale?.getSnapshot === 'function' ? locale.getSnapshot() : null) ?? snapshotFallback
      const fallbackT = localT(initial.active)
      const boundT = typeof locale?.bind === 'function' ? locale.bind(NS) : fallbackT

      return function Shell() {
        const [snapshot, setSnapshot] = useState(() => (typeof locale?.getSnapshot === 'function' ? locale.getSnapshot() : null) ?? initial)
        useEffect(() => {
          if (typeof locale?.subscribe !== 'function') return undefined
          return locale.subscribe(() => setSnapshot(locale.getSnapshot()))
        }, [])
        const language = snapshot?.active ?? initial.active
        uiLanguage = language
        const t = useCallback((key, params) => {
          const template = boundT(key, params)
          // locale 服务里没有的键（例如词典尚未注册完成）用本地兜底，避免界面露出裸 key
          return template === key ? fallbackT(key, params) : template
        }, [language])
        return h(TradeEvaluationDashboard, {
          t,
          language,
          locale: {
            languages: snapshot?.locales ?? initial.locales,
            setLocale: (id) => locale?.setLocale?.(id),
          },
        })
      }
    }

    // ── 插件本体 ────────────────────────────────────────────────────────────
    const name = 'trade-strategy-evaluator-client'
    const inject = ['slots', 'locale']

    function apply(ctx, input) {
      const config = typeof input === 'object' && input !== null ? input : {}
      if (config.enabled === false) return
      const order = typeof config.order === 'number' && Number.isFinite(config.order) ? config.order : 40
      const fallbackLabel = typeof config.label === 'string' && config.label.trim().length > 0 ? config.label.trim() : undefined

      const t = ctx.locale.bind(NS)
      ctx.effect(() => ctx.locale.register(NS, { zh: UI.zh, en: UI.en }), 'trade-strategy-evaluator: dictionaries')
      ctx.effect(() => installStyles(), 'trade-strategy-evaluator: styles')

      const Shell = createShell(ctx.locale)
      ctx.slots.inject('conversation.view', () => ctx.slots.register({
        name: 'conversation.view',
        id: PLUGIN_ID,
        order,
        // label 声明成 thunk：shell 切换语言时标签环会自己刷新（conversation 包订阅了 locale）。
        // 显式配置了 label 就优先用它，方便部署方固定文案。
        label: fallbackLabel === undefined ? () => t('tab') : fallbackLabel,
      }, Shell))
    }

    exports.name = name
    exports.inject = inject
    exports.apply = apply
    /** 暴露词典供测试断言两语言键集合一致（Harness 只读 name/inject/apply，多余导出无副作用）。 */
    exports.dictionaries = UI
    /** 测试接缝：让真实 DOM 测试能直接挂载面板组件，而不必复刻 slot 机制。 */
    exports.__test = { TradeEvaluationDashboard, SortableTable, markdownToHtml, createShell, format: { pct, mag, pts, num } }
    return module.exports
  },
})
