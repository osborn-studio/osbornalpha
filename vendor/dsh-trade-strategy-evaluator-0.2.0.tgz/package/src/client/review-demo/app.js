function render() {
  if (!accounts().some((a) => a.id === view.account))
    view.account = accounts()[0]?.id;
  const nav = navigation
    .map(
      ([id, ic, label], i) =>
        `${i === 6 ? '<div class="nav-label" style="margin-top:24px">工作区管理</div>' : ""}<button data-action="navigate" data-page="${id}" class="${view.page === id ? "active" : ""}" ${view.page === id ? 'aria-current="page"' : ""}>${icon(ic)}${label}${id === "inbox" && pending().length ? `<span class="count">${pending().length}</span>` : ""}</button>`,
    )
    .join("");
  $("#app").innerHTML =
    `<div class="app"><aside class="sidebar"><div class="brand"><div class="brandmark">${icon("chart")}</div><div><strong>投研判断台</strong><small>DAO.REVIEW</small></div></div><div class="workspace"><label for="workspace">WORKSPACE</label><select id="workspace"><option value="team" ${view.workspace === "team" ? "selected" : ""}>大道 · 机构工作区</option><option value="personal" ${view.workspace === "personal" ? "selected" : ""}>Osborn · 个人工作区</option></select></div><div class="nav-label">投研工作台</div><nav class="nav" aria-label="主导航">${nav}</nav><div class="sidebar-bottom"><div class="sidebar-note"><div class="row">${icon("play")}<strong style="font-size:12px">从观点，到有据可循</strong></div><p>五分钟走完一条投研记录的完整旅程。</p>${btn("开始演示 " + icon("arrow"), "tour", "link small")}</div><div class="user">${avatar(view.actor.id === "pm" || view.actor.id === "admin" ? "lin" : view.actor.id)}<div><strong style="font-size:12px">${view.actor.role === "manager" ? "投资经理" : view.actor.role === "admin" ? "工作区管理员" : member(view.actor.id).name}</strong><small style="display:block;font-size:10px">${view.actor.role === "analyst" ? "分析师" : "管理视角"} · 演示身份</small></div></div></div></aside><main class="main"><header class="topbar">${btn(icon("menu"), "menu", "ghost mobile-menu", 'aria-label="展开导航"')}<div class="breadcrumb">${view.workspace === "team" ? "大道机构工作区" : "Osborn 个人工作区"} <span style="margin:0 10px">/</span> <strong>${title()}</strong></div><div class="topbar-right"><span class="demo-pill">模拟数据 · 本地演示</span><select id="role" aria-label="切换演示身份">${(view.workspace ===
    "team"
      ? [
          ["pm", "PM · 演示"],
          ["lin", "林知远 · 分析师"],
          ["chen", "陈予安 · 分析师"],
          ["zhou", "周明澈 · 分析师"],
          ["admin", "管理员 · 演示"],
        ]
      : [["osborn", "Osborn · 个人"]]
    )
      .map(
        ([id, n]) =>
          `<option value="${id}" ${view.actor.id === id ? "selected" : ""}>${n}</option>`,
      )
      .join(
        "",
      )}</select>${btn(icon("clock"), "clock-info", "ghost small", 'aria-label="模拟时钟说明"')}</div></header><div class="page"><div class="print-only">模拟数据 · 非真实业绩 · ${M.DAYS[state.day]} · ${M.VERSION}</div>${storageWarning ? `<div class="hint">${esc(storageWarning)}</div>` : ""}${({ overview, inbox, judgments: judgmentView, portfolio, performance: performanceView, reviews, evidence, settings, coverage, hypotheses }[view.page] || overview)()}<footer class="footer"><span>DAO.REVIEW · 模拟数据 / 非真实业绩 · ${M.DAYS[state.day]} · HKD 样例</span><span>${btn("需求覆盖 65 条", "navigate", "link", 'data-page="coverage"')} <span style="margin:0 8px">·</span> 数据仅存当前浏览器</span></footer></div></main></div>`;
}
function detail(id) {
  const j = judgments().find((j) => j.id === id);
  if (!j) return toast("当前演示身份无权查看该记录", true);
  const own = view.actor.id === j.owner && view.actor.role === "analyst";
  const canConfirm = ["pending", "ambiguous", "blocked"].includes(j.status);
  const a = state.accounts.find((a) => a.id === j.accountId),
    trades = a.trades.filter((t) => t.judgmentId === id);
  const history = events().filter((e) => e.ref === id);
  openDialog(
    `${security(j.ticker).name} · 判断详情`,
    `<div class="row spread"><div class="name-cell">${avatar(j.owner)}<div><strong>${member(j.owner).name}</strong><small style="display:block">${j.id} · ${j.accountId}</small></div></div>${statusBadge(j)}</div><blockquote>${esc(j.text)}</blockquote><dl class="definition"><dt>建议来源</dt><dd>${j.origin === "manual" ? "人工原创" : `AI 辅助 / ${esc(j.origin)} · 人工筛选`}</dd><dt>消息产生</dt><dd class="mono">${j.createdAt}</dd><dt>系统接收</dt><dd class="mono">${j.receivedAt}</dd><dt>确认人 / 时间</dt><dd>${j.decisionAuthor ? `${member(j.decisionAuthor).name} · ${j.confirmedAt}` : "尚未确认，不计入资金账本"}</dd><dt>执行规则</dt><dd>${j.policy ? j.policy.version : `rules-${state.settings.ruleVersion}`} · 确认后下一模拟交易日开盘</dd>${j.runId ? `<dt>候选运行 / 版本</dt><dd>${esc(j.runId)} / ${esc(j.sourceVersion)}</dd><dt>输入截止</dt><dd>${esc(j.inputCutoff)}</dd>` : ""}</dl>
 ${j.reason ? `<div class="hint">${esc(j.reason)}</div>` : ""}
 ${canConfirm ? `<form id="confirm-form" data-id="${id}"><h3>检查结构化结果</h3><div class="field-grid"><div><label for="ticker">证券</label><select name="ticker" id="ticker" required><option value="">请选择证券</option>${M.SECURITIES.map((s) => `<option value="${s.ticker}" ${s.ticker === j.ticker ? "selected" : ""}>${s.name} · ${s.ticker}</option>`).join("")}</select></div><div><label for="direction">方向</label><select name="direction" id="direction"><option value="BUY" ${j.direction === "BUY" ? "selected" : ""}>买入（仅做多）</option><option value="SELL" ${j.direction === "SELL" ? "selected" : ""}>卖出（减少持仓）</option></select></div><div><label for="weight">仓位比例（%）</label><input name="weight" id="weight" type="number" min="0" max="100" step=".1" value="${j.weight ?? ""}" required></div><div><label for="mode">仓位语义</label><select name="mode" id="mode" required><option value="">请选择目标或增减</option><option value="target" ${j.mode === "target" ? "selected" : ""}>调整至目标仓位</option><option value="delta" ${j.mode === "delta" ? "selected" : ""}>增加 / 减少相应仓位</option></select></div><div class="full"><label for="reason">确认 / 纠正说明</label><input id="reason" name="reason" placeholder="例如：原文 10 个点指增仓 10%" maxlength="500"></div></div><div class="check-row"><input id="rebalance" name="rebalance" type="checkbox"><label for="rebalance">若超出 ${a.maxPosition}% 总仓位或现金约束，允许按 FIFO 卖出其他旧持仓后再买入（会计入模拟费用）。</label></div><div class="hint green">确认只创建待执行指令。需要推进演示时钟，才会使用未来的模拟开盘价成交。</div><div class="row wrap">${own ? '<button class="primary" type="submit">确认并排队执行</button>' : btn(`切换为${member(j.owner).name}确认`, "switch-owner", "primary", `data-id="${id}"`)}${own ? btn("忽略 / 撤回", "dismiss", "ghost", `data-id="${id}"`) : ""}</div></form>` : `<div class="row wrap">${j.status === "queued" ? `${btn("推进下一交易日", "advance", "primary")}${own ? btn("撤回待执行指令", "dismiss", "", `data-id="${id}"`) : ""}` : ""}${btn("补充观点 / 更正说明", "note", "", `data-id="${id}"`)}</div>`}
 ${trades.length ? `<details open><summary>模拟成交与资金证据</summary>${trades.map((t) => `<dl class="definition"><dt>${security(t.ticker).name}</dt><dd>${t.quantity > 0 ? "买入" : "卖出"} ${fmt(Math.abs(t.quantity), 4)} 份 @ ${fmt(t.price)}</dd><dt>价格形成</dt><dd>${t.priceFormedAt}</dd><dt>行情到达</dt><dd>${t.priceArrivedAt}</dd><dt>费用 / 原因</dt><dd>HKD ${fmt(t.fee)} · ${esc(t.reason)}</dd></dl>`).join("")}</details>` : ""}
 ${view.workspace === "team" ? `<details ${!canConfirm ? "open" : ""}><summary>PM 采纳与决策</summary>${j.pm ? `<div class="hint green">${esc(j.pm.choice)}：${esc(j.pm.reason)}</div>` : '<p class="note" style="margin-top:12px">尚无决定。模拟成交不代表 PM 已采纳。</p>'}${view.actor.role === "manager" ? `<form id="pm-form" data-id="${id}"><div class="field-grid"><div><label for="pm-choice">决定</label><select id="pm-choice" name="choice"><option>观察</option><option>采纳</option><option>未采纳</option></select></div><div class="full"><label for="pm-reason">理由（必填）</label><textarea id="pm-reason" name="reason" required maxlength="2000" placeholder="记录当时的依据和约束…"></textarea></div></div><button type="submit" class="primary">保存 PM 决定</button></form>` : '<p class="note">切换 PM 演示身份可记录决定。</p>'}</details>` : ""}
 <details><summary>观点兑现与后续证据</summary><p class="note" style="margin-top:12px">当前：${esc(j.observation || "尚待观察")}。观点兑现与模拟涨跌分别记录。</p>${own || view.actor.role === "manager" ? `<form id="observation-form" data-id="${id}"><div class="field-grid"><div><label for="observation">验证状态</label><select id="observation" name="observation"><option>持续观察</option><option>兑现</option><option>假设承压</option><option>失效</option><option>无法判断</option></select></div><div class="full"><label for="observation-evidence">证据与日期</label><textarea id="observation-evidence" name="evidence" required maxlength="2000" placeholder="记录可核查的事实、证据日期及局限…"></textarea></div></div><button type="submit" class="primary">保存观点验证</button></form>` : ""}</details>
 <details><summary>解析纠正历史 · ${j.versions.length} 个版本</summary>${j.versions.map((v) => `<div class="hint">${esc(v.at)} · ${esc(v.actor)}<br>原解析：${esc(JSON.stringify(v.before))}<br>确认后：${esc(JSON.stringify(v.after))}<br>${esc(v.reason)}</div>`).join("") || '<p class="note">尚无确认或纠正。</p>'}</details><details open><summary>原文到结果的事件链</summary><div style="margin-top:18px">${timeLine(history.slice().reverse())}</div></details>`,
    { drawer: true },
  );
}
function newMessage(text = "", owner = "") {
  go("inbox");
  $("#ingest-text").value = text;
  if (owner && accounts().some((a) => a.owner === owner))
    $("#ingest-owner").value = owner;
  $("#ingest-text").focus();
}
function tour() {
  openDialog(
    "五分钟，走完一条判断的旅程",
    `<p class="note">全部为模拟行情与虚构成员。港股 / HKD 只是演示样例，不代表客户市场已经确定。</p>${[
      ["记录一句话", "在收件箱输入“@判断台 买入腾讯，目标仓位35%”。"],
      [
        "确认你真正的意思",
        "查看原话，区分目标与增量仓位，以本人演示身份确认。",
      ],
      ["让模拟账本运转", "推进一个交易日，检查现金、持仓、费用及规则。"],
      ["记录 PM 的决定", "切回 PM 视角，在判断详情中记下采纳或未采纳的理由。"],
      ["带着证据去复盘", "打开团队复盘，留下跟踪事项，导出报告或证据包。"],
    ]
      .map(
        ([t, p], i) =>
          `<div class="tour-step"><div class="num">${i + 1}</div><div><h3>${t}</h3><p>${p}</p></div></div>`,
      )
      .join(
        "",
      )}<div class="dialog-actions">${btn("开始体验 " + icon("arrow"), "start-tour", "primary")}</div>`,
  );
}
function exportMeeting() {
  const r = state.reviews[0];
  const text = `# 投研复盘 · 模拟数据（非真实业绩）\n\n${r.title}\n\n${r.period}\n\n${r.summary}\n\n## 行动\n${r.actions.map((a) => `- [${a.done ? "x" : " "}] ${a.text} / ${member(a.owner).name} / ${a.due}`).join("\n")}\n\n## 结论\n${r.conclusion || "待填写"}\n\n## 口径\nMock 行情；${M.VERSION}；${M.DAYS[state.day]}；仅本地演示。\n\n## 判断与决定\n${judgments()
    .filter((j) => j.pm)
    .map((j) => `${j.id} ${j.text}\nPM：${j.pm.choice} — ${j.pm.reason}`)
    .join("\n\n")}`;
  download("团队复盘-模拟数据.md", text, "text/markdown");
}
const actions = {
  navigate: (b) => go(b.dataset.page),
  close: () => $("#dialog").close(),
  menu: () => $(".sidebar").classList.toggle("open"),
  tour,
  "start-tour": () => {
    $("#dialog").close();
    newMessage(
      "@判断台 买入腾讯，目标仓位 35%，观察广告业务增长，观察期三个月。",
    );
  },
  new: () => newMessage(),
  detail: (b) => detail(b.dataset.id),
  "switch-owner": (b) => {
    const j = judgments().find((j) => j.id === b.dataset.id);
    view.actor = { id: j.owner, role: "analyst" };
    render();
    detail(j.id);
    toast(`已切换为${member(j.owner).name}的演示身份`);
  },
  sample: (b) => {
    $("#ingest-text").value = {
      clear: "@判断台 买入腾讯，目标仓位 35%，观察期三个月。",
      ambiguous: "@判断台 买入腾讯 10 个点，继续观察广告业务。",
      noise: "今天下午一起讨论互联网行业？",
      sell: "@判断台 卖出腾讯，目标仓位 15%，控制风险。",
    }[b.dataset.value];
    $("#ingest-text").focus();
  },
  period: (b) => {
    view.period = Number(b.dataset.value);
    render();
  },
  account: (b) => {
    view.account = b.dataset.id;
    render();
  },
  sell: (b) =>
    newMessage(
      `@判断台 卖出${security(b.dataset.ticker).name}，目标仓位 0%，结束本次观察。`,
      b.dataset.owner,
    ),
  advance: () => {
    if (
      mutate(
        () => M.advance(state),
        "模拟时钟已推进，已检查待执行指令并更新净值",
      )
    ) {
      if ($("#dialog").open) $("#dialog").close();
    }
  },
  dismiss: (b) => {
    if (
      mutate(
        () => M.dismiss(state, b.dataset.id, view.actor),
        "已撤回，原文与历史事件仍保留",
      )
    )
      $("#dialog").close();
  },
  note: (b) =>
    openDialog(
      "补充观点 / 更正说明",
      `<p class="note">已成交结果不会被改写。观点变化向未来生效；新增买卖请另行记录。历史核算重述需要正式审阅流程，本 Demo 不伪造已审批状态。</p><form id="note-form" data-id="${b.dataset.id}"><label for="note-text" style="margin-top:20px">补充说明</label><textarea id="note-text" name="text" required maxlength="2000"></textarea><div class="dialog-actions"><button type="submit" class="primary">追加记录</button></div></form>`,
    ),
  verify: () =>
    openDialog(
      "独立核对：从成交重新回算",
      `<p class="note">按初始现金减买入、加卖出、扣费用，重建现金及每个证券份额。不是服务端防篡改认证。</p>${accounts()
        .map((a) => {
          const r = M.verify(a);
          return `<div class="hint ${r.ok ? "green" : ""}"><strong>${member(a.owner).name} · ${r.ok ? "一致" : "存在差异"}</strong><br>重算现金 HKD ${fmt(r.cash)} / ${r.tradeCount} 笔成交 / 累计费用 ${fmt(r.fee)}${r.errors.length ? `<br>${esc(r.errors.join("；"))}` : ""}</div>`;
        })
        .join("")}`,
    ),
  "clock-info": () =>
    openDialog(
      "演示时钟与成交时间",
      `<p>当前模拟日期：<strong>${M.DAYS[state.day]}</strong></p><div class="hint green">确认时间为演示当日 16:10。模拟成交使用之后交易日的 09:30 开盘价；价格到达时间为 09:30:02。</div><p class="note">日历和价格均为固定样例。推进会处理所有演示账户的待执行指令，并更新日终净值，不改变真实时钟。终点为 ${M.DAYS.at(-1)}。</p><div class="dialog-actions">${btn("推进一个交易日", "advance", "primary")}</div>`,
    ),
  "export-report": () =>
    download("投研复盘-模拟数据报告.html", reportHTML(), "text/html"),
  "export-evidence": () =>
    download("模拟证据包.json", JSON.stringify(report(), null, 2)),
  "export-records": () => {
    const cell = (s) =>
      '"' +
      String(s ?? "")
        .replace(/"/g, '""')
        .replace(/^(\s*[=+@-]|[\t\r\n])/, "\u0027$1") +
      '"';
    const rows = [
      [
        "模拟数据-非真实业绩",
        "编号",
        "分析师",
        "原文",
        "状态",
        "来源",
        "确认人",
        "规则版本",
      ],
      ...judgments().map((j) => [
        "本地演示",
        j.id,
        member(j.owner).name,
        j.text,
        statuses[j.status][0],
        j.origin,
        j.decisionAuthor,
        j.policy?.version,
      ]),
    ];
    download(
      "判断记录-模拟数据.csv",
      "\uFEFF" + rows.map((r) => r.map(cell).join(",")).join("\r\n"),
      "text/csv",
    );
  },
  "export-meeting": () => {
    if (view.actor.role !== "manager") return toast("请切换 PM 演示身份", true);
    exportMeeting();
  },
  "add-task": () => {
    if (view.actor.role !== "manager") return toast("请切换 PM 演示身份", true);
    openDialog(
      "添加复盘跟踪事项",
      `<form id="task-form"><label for="task-text">要验证的事项</label><textarea id="task-text" name="text" required maxlength="500"></textarea><div class="field-grid"><div><label for="task-owner">跟踪人</label><select id="task-owner" name="owner">${M.MEMBERS.filter(
        (m) => m.id !== "osborn",
      )
        .map((m) => `<option value="${m.id}">${m.name}</option>`)
        .join(
          "",
        )}</select></div><div><label for="task-due">截止日期</label><input id="task-due" name="due" type="date" required value="2026-09-25"></div></div><div class="dialog-actions"><button type="submit" class="primary">添加事项</button></div></form>`,
    );
  },
  "toggle-task": (b) =>
    mutate(() => {
      if (view.actor.role !== "manager")
        throw new Error("仅 PM 可更新机构复盘事项");
      const a = state.reviews[0].actions.find((a) => a.id === b.dataset.id);
      a.done = !a.done;
      record("复盘行动", `${a.done ? "完成" : "重新打开"}：${a.text}`);
    }, "复盘事项已更新"),
  connector: (b) =>
    openDialog(
      `${esc(b.dataset.name)} · 接入准备`,
      `<p>当前状态：${badge("未连接", "orange")}</p><dl class="definition"><dt>飞书 / Lark</dt><dd>企业应用授权、可信发送者映射、消息去重、编辑 / 撤回事件、群内确认卡。</dd><dt>Ostag</dt><dd>身份治理、judgment_ledger 回执与判断事件。</dd><dt>Supabase</dt><dd>独立模拟账户表、account_id 级持仓主键、事务幂等与机构 RLS。</dd><dt>验收</dt><dd>先在测试环境打通一条完整消息，再做对账和越权验证。</dd></dl><p class="note">此处没有假“连接成功”按钮。离线 HTML 不能证明这些服务已联通。</p>`,
    ),
  reset: () =>
    openDialog(
      "恢复初始演示样例",
      `<p>这会清除当前浏览器中本 Demo 的操作记录，包括机构和个人虚构样例。可以先导出备份。</p><div class="dialog-actions">${btn("取消", "close")}${btn("确认恢复", "reset-confirm", "primary")}</div>`,
    ),
  "reset-confirm": () => {
    storageWarning = "";
    state = M.createState();
    view = {
      page: "overview",
      workspace: "team",
      actor: { id: "pm", role: "manager" },
      period: 0,
      account: "ACC-lin",
      search: "",
      filter: "all",
    };
    persist();
    $("#dialog").close();
    render();
    toast("已恢复初始演示数据");
  },
  backup: () => {
    const aa = accounts();
    download(
      "工作区演示备份.json",
      JSON.stringify(
        {
          format: "review-workspace-backup-v1",
          label: "模拟数据",
          workspace: view.workspace,
          day: state.day,
          accounts: aa,
          judgments: judgments(),
          events: events(),
          reviews:
            view.workspace === "team" && view.actor.role !== "analyst"
              ? state.reviews
              : [],
          hypotheses:
            view.workspace === "team" && view.actor.role !== "analyst"
              ? state.hypotheses
              : [],
        },
        null,
        2,
      ),
    );
  },
  restore: () => {
    openDialog(
      "恢复当前工作区备份",
      `<p class="note">恢复只接受当前模拟日期、完整工作区导出的备份。为防止另一工作区被时间回退影响，跨日期备份不接受。机构恢复需管理员演示身份。</p><form id="restore-form"><label for="backup-file" style="margin-top:18px">选择本 Demo 导出的 JSON</label><input id="backup-file" type="file" accept=".json,application/json" required><div class="dialog-actions"><button type="submit" class="primary">校验并恢复</button></div></form>`,
    );
  },
  "export-coverage": () =>
    download(
      "65条需求-本轮演示覆盖.json",
      JSON.stringify(
        { label: "覆盖映射不是生产验收", requirements: REQUIREMENTS },
        null,
        2,
      ),
    ),
  "add-hypothesis": () => {
    if (view.actor.role !== "manager" && view.actor.role !== "admin")
      return toast("请切换 PM 演示身份", true);
    openDialog(
      "新增一级假设 · 人工样例",
      `<form id="hypothesis-form"><label for="project">虚构项目名称</label><input id="project" name="project" required maxlength="100"><label for="hypothesis" style="margin-top:15px">可以验证的假设</label><textarea id="hypothesis" name="hypothesis" required maxlength="1000"></textarea><div class="field-grid"><div><label for="decision">决定</label><select id="decision" name="decision"><option>继续研究</option><option>投资</option><option>不投资</option></select></div><div><label for="deadline">验证截止</label><input id="deadline" name="deadline" type="date" required value="2026-12-18"></div></div><button type="submit" class="primary">保存人工样例</button></form>`,
    );
  },
  "hypothesis-result": (b) => {
    if (view.actor.role !== "manager" && view.actor.role !== "admin")
      return toast("请切换 PM 演示身份", true);
    openDialog(
      "记录后续事实",
      `<form id="hypothesis-result-form" data-id="${b.dataset.id}"><label for="result">验证结果</label><select name="result" id="result"><option>待验证</option><option>兑现</option><option>失效</option><option>延期</option><option>无法判断</option></select><label for="evidence-text" style="margin-top:15px">证据与日期</label><textarea name="evidence" id="evidence-text" required maxlength="2000" placeholder="记录来源、证据日期与不确定性…"></textarea><button type="submit" class="primary">保存验证记录</button></form>`,
    );
  },
};
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-action]");
  if (!b) return;
  const action = actions[b.dataset.action];
  if (action) {
    try {
      action(b);
    } catch (err) {
      toast(err.message, true);
    }
  }
});
document.addEventListener("change", (e) => {
  if (e.target.id === "workspace") {
    view.workspace = e.target.value;
    view.actor =
      view.workspace === "team"
        ? { id: "pm", role: "manager" }
        : { id: "osborn", role: "analyst" };
    view.account = view.workspace === "team" ? "ACC-lin" : "ACC-osborn";
    go("overview");
  }
  if (e.target.id === "role") {
    view.actor = {
      id: e.target.value,
      role:
        e.target.value === "pm"
          ? "manager"
          : e.target.value === "admin"
            ? "admin"
            : "analyst",
    };
    render();
  }
  if (e.target.id === "filter") {
    view.filter = e.target.value;
    render();
  }
  if (e.target.id === "account-select") {
    view.account = e.target.value;
    render();
  }
  if (e.target.id === "period-select") {
    view.period = Number(e.target.value);
    render();
  }
});
document.addEventListener("input", (e) => {
  if (e.target.id === "search") {
    const pos = e.target.selectionStart;
    view.search = e.target.value;
    render();
    $("#search").focus();
    $("#search").setSelectionRange(pos, pos);
  }
});
document.addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  const data = Object.fromEntries(new FormData(f));
  if (f.id === "ingest-form") {
    let result;
    if (
      mutate(() => {
        result = M.ingest(state, { ...data, workspace: view.workspace });
      }, "")
    ) {
      toast(
        result.duplicate
          ? "重复消息已识别，未新增记录"
          : "候选已记录，尚未入账",
      );
      if (!result.duplicate && result.judgment.status !== "ignored")
        detail(result.judgment.id);
    }
  }
  if (f.id === "confirm-form") {
    if (
      mutate(
        () =>
          M.confirm(
            state,
            f.dataset.id,
            { ...data, rebalance: data.rebalance === "on" },
            view.actor,
          ),
        "已确认，等待下一模拟交易日",
      )
    )
      detail(f.dataset.id);
  }
  if (f.id === "pm-form") {
    if (
      mutate(
        () =>
          M.recordPM(state, f.dataset.id, data.choice, data.reason, view.actor),
        "PM 决定已保存并留下事件",
      )
    )
      detail(f.dataset.id);
  }
  if (f.id === "note-form") {
    if (
      mutate(
        () => M.addNote(state, f.dataset.id, data.text, view.actor),
        "补充说明已追加，原文未改写",
      )
    )
      detail(f.dataset.id);
  }
  if (f.id === "observation-form") {
    if (
      mutate(() => {
        M.addNote(
          state,
          f.dataset.id,
          `观点验证：${data.observation}；证据：${data.evidence}`,
          view.actor,
        );
        state.judgments.find((j) => j.id === f.dataset.id).observation =
          data.observation;
      }, "观点验证已记录，未改写原文与历史业绩")
    )
      detail(f.dataset.id);
  }
  if (f.id === "settings-form")
    mutate(
      () => M.changeSettings(state, data, view.actor),
      "新规则已保存，仅对后续确认生效",
    );
  if (f.id === "conclusion-form")
    mutate(() => {
      if (view.actor.role !== "manager")
        throw new Error("仅 PM 可更新复盘结论");
      if (!data.conclusion.trim()) throw new Error("请填写结论");
      state.reviews[0].conclusion = data.conclusion;
      record("复盘结论", data.conclusion);
    }, "复盘结论已保存");
  if (f.id === "task-form") {
    if (
      mutate(() => {
        if (view.actor.role !== "manager")
          throw new Error("仅 PM 可添加机构事项");
        if (!data.text.trim()) throw new Error("请填写跟踪事项");
        state.reviews[0].actions.push({
          ...data,
          id: `A-${++state.sequence}`,
          done: false,
        });
        record("新增复盘行动", data.text);
      }, "跟踪事项已添加")
    )
      $("#dialog").close();
  }
  if (f.id === "hypothesis-form") {
    if (
      mutate(() => {
        if (!["manager", "admin"].includes(view.actor.role))
          throw new Error("需要管理身份");
        state.hypotheses.push({
          ...data,
          id: `H-${++state.sequence}`,
          result: "待验证",
          evidence: "人工样例，待补充证据",
        });
        record("一级假设样例", data.hypothesis);
      }, "人工样例已保存")
    )
      $("#dialog").close();
  }
  if (f.id === "hypothesis-result-form") {
    if (
      mutate(() => {
        if (!["manager", "admin"].includes(view.actor.role))
          throw new Error("需要管理身份");
        const h = state.hypotheses.find((h) => h.id === f.dataset.id);
        Object.assign(h, data);
        record(
          "假设事实更新",
          `${h.project}：${data.result} / ${data.evidence}`,
        );
      }, "验证记录已保存")
    )
      $("#dialog").close();
  }
  if (f.id === "restore-form") {
    try {
      const file = $("#backup-file").files[0];
      if (!file || file.size > 2e6)
        throw new Error("请选择小于 2 MB 的演示备份");
      const restored = JSON.parse(await file.text());
      if (mutate(() => restoreWorkspace(restored), "当前工作区备份已恢复"))
        $("#dialog").close();
    } catch (err) {
      $("#form-error").textContent = err.message;
    }
  }
});
function restoreWorkspace(b) {
  if (view.workspace === "team" && view.actor.role !== "admin")
    throw new Error("机构恢复需管理员演示身份");
  if (
    b.format !== "review-workspace-backup-v1" ||
    b.workspace !== view.workspace ||
    b.day !== state.day
  )
    throw new Error("备份版本、工作区或模拟日期不匹配");
  const expected = state.accounts
    .filter((a) => a.workspace === view.workspace)
    .map((a) => a.id)
    .sort();
  if (
    !Array.isArray(b.accounts) ||
    JSON.stringify(b.accounts.map((a) => a.id).sort()) !==
      JSON.stringify(expected)
  )
    throw new Error("备份未包含完整工作区账户");
  for (const a of b.accounts) {
    const original = state.accounts.find((x) => x.id === a.id);
    if (
      a.workspace !== view.workspace ||
      a.owner !== original.owner ||
      a.kind !== original.kind ||
      a.initial !== 1000000 ||
      !Number.isFinite(a.cash) ||
      a.cash < 0 ||
      !Array.isArray(a.history) ||
      !Array.isArray(a.trades) ||
      !a.positions
    )
      throw new Error("账户结构无效");
    if (!M.verify(a).ok) throw new Error("备份账本核对失败");
    M.valuation(a, state.day);
  }
  for (const key of ["judgments", "events", "reviews", "hypotheses"])
    if (!Array.isArray(b[key])) throw new Error("备份结构不完整");
  if (
    b.judgments.some(
      (j) =>
        j.workspace !== view.workspace ||
        !expected.includes(j.accountId) ||
        !statuses[j.status] ||
        typeof j.text !== "string" ||
        !Array.isArray(j.versions) ||
        !j.createdAt ||
        !j.receivedAt ||
        j.owner !== b.accounts.find((a) => a.id === j.accountId)?.owner,
    )
  )
    throw new Error("判断记录结构无效");
  if (
    b.events.some(
      (x) => x.workspace !== view.workspace || typeof x.at !== "string",
    )
  )
    throw new Error("事件工作区不匹配");
  if (new Set(b.judgments.map((j) => j.id)).size !== b.judgments.length)
    throw new Error("判断编号重复");
  const otherIds = new Set(
    state.judgments
      .filter((j) => j.workspace !== view.workspace)
      .map((j) => j.id),
  );
  if (b.judgments.some((j) => otherIds.has(j.id)))
    throw new Error("判断编号与其他工作区冲突");
  if (
    view.workspace === "team" &&
    (!b.reviews[0] || !Array.isArray(b.reviews[0].actions))
  )
    throw new Error("复盘结构无效");
  state.accounts = state.accounts
    .filter((a) => a.workspace !== view.workspace)
    .concat(b.accounts);
  state.judgments = state.judgments
    .filter((j) => j.workspace !== view.workspace)
    .concat(b.judgments);
  state.events = state.events
    .filter((e) => e.workspace !== view.workspace)
    .concat(b.events);
  if (view.workspace === "team") {
    state.reviews = b.reviews;
    state.hypotheses = b.hypotheses;
  }
  state.sequence = Math.max(
    state.sequence,
    ...[...state.judgments, ...state.events].map(
      (j) => Number(j.id.split("-").at(-1)) || 0,
    ),
  );
  record("演示备份恢复", "结构与账本已核对，未修改其他工作区");
  M.validateState(state);
}
render();
