const M = ReviewDemo;
const STORAGE = "osanalyst-review-demo-v1";
let storageWarning = "";
let state = (() => {
  try {
    const raw = localStorage.getItem(STORAGE);
    if (raw) return M.validateState(JSON.parse(raw));
  } catch {
    storageWarning = "浏览器存储不可用或数据损坏，本次已加载初始演示样例。";
  }
  return M.createState();
})();
let view = {
  page: "overview",
  workspace: "team",
  actor: { id: "pm", role: "manager" },
  period: 0,
  account: "ACC-lin",
  search: "",
  filter: "all",
};
const $ = (s) => document.querySelector(s);
const esc = (s) =>
  String(s ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const fmt = (n, d = 2) =>
  Number(n).toLocaleString("en-US", {
    minimumFractionDigits: d,
    maximumFractionDigits: d,
  });
const pct = (n) => `${n > 0 ? "+" : ""}${fmt(n * 100)}%`;
const cls = (n) => (n < 0 ? "down" : "up");
const member = (id) =>
  M.MEMBERS.find((m) => m.id === id) || { id, name: id, color: "green" };
const security = (t) =>
  M.SECURITIES.find((s) => s.ticker === t) || {
    ticker: t,
    name: "待识别",
    sector: "待确认",
  };
const statuses = {
  pending: ["待确认", "orange"],
  ambiguous: ["待澄清", "orange"],
  queued: ["待执行", "blue"],
  executed: ["已模拟成交", "green"],
  ignored: ["普通讨论", "gray"],
  withdrawn: ["已撤回", "gray"],
  blocked: ["执行拦截", "red"],
};
const badge = (text, color = "gray") =>
  `<span class="badge ${color}">${esc(text)}</span>`;
const statusBadge = (j) =>
  badge(
    ...(j.status === "queued" && state.settings.missingTicker === j.ticker
      ? ["待行情", "orange"]
      : statuses[j.status] || [j.status, "gray"]),
  );
const avatar = (id) => {
  const m = member(id);
  return `<span class="avatar ${m.color}">${esc(m.name.slice(0, 1))}</span>`;
};
const paths = {
  home: "M3 10 12 3l9 7M5 9v12h5v-7h4v7h5V9",
  inbox: "M4 4h16v16H4zM4 13h5l2 3h2l2-3h5",
  file: "M6 3h9l4 4v14H6zM14 3v5h5M9 12h7M9 16h7",
  wallet: "M3 6h17v15H3zM3 6V3h14v3M15 12h6v5h-6z",
  chart: "M3 3v18h18M6 15l4-5 4 3 6-8",
  review: "M4 4h16v13H9l-5 4zM8 8h8M8 12h5",
  shield: "m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6zM8 11l3 3 5-5",
  settings:
    "M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2",
  plus: "M12 5v14M5 12h14",
  arrow: "M4 12h15M14 6l6 6-6 6",
  down: "M12 3v12M7 10l5 5 5-5M4 17v4h16v-4",
  clock: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18M12 7v5l3 2",
  check: "M5 12l4 4L19 6",
  close: "m6 6 12 12M6 18 18 6",
  search: "M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14M15 15l6 6",
  users:
    "M8 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8M2 21v-3a6 6 0 0 1 12 0v3M16 4a4 4 0 0 1 0 8M18 15a5 5 0 0 1 4 6",
  eye: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6",
  menu: "M4 6h16M4 12h16M4 18h16",
  leaf: "M5 19C2 8 10 3 21 3c0 12-5 19-16 16ZM5 19 16 8",
  bolt: "M13 2 4 14h7l-1 8 10-13h-7z",
  info: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18M12 10v7M12 7v.1",
  play: "m9 5 11 7-11 7z",
  link: "M10 14l4-4M8 16l-2 2a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0M16 8l2-2a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0",
};
const icon = (name) =>
  `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[name] || paths.file}"/></svg>`;
const btn = (text, action, kind = "", data = "") =>
  `<button class="${kind}" data-action="${action}" ${data}>${text}</button>`;
const navigation = [
  ["overview", "home", "复盘总览"],
  ["inbox", "inbox", "观点收件箱"],
  ["judgments", "file", "判断档案"],
  ["portfolio", "wallet", "模拟组合"],
  ["performance", "chart", "表现分析"],
  ["reviews", "review", "团队复盘"],
  ["evidence", "shield", "证据中心"],
  ["settings", "settings", "接入与规则"],
];
const accounts = () => M.visibleAccounts(state, view.workspace, view.actor);
const judgments = () =>
  state.judgments.filter(
    (j) =>
      j.workspace === view.workspace &&
      (view.actor.role !== "analyst" || j.owner === view.actor.id),
  );
const events = () =>
  state.events.filter(
    (e) =>
      e.workspace === view.workspace &&
      (view.actor.role !== "analyst" ||
        e.actor === view.actor.id ||
        (e.ref && judgments().some((j) => j.id === e.ref))),
  );
const pending = () =>
  judgments().filter((j) =>
    ["pending", "ambiguous", "blocked"].includes(j.status),
  );
const selectedAccount = () =>
  accounts().find((a) => a.id === view.account) || accounts()[0];
const title = () =>
  navigation.find((x) => x[0] === view.page)?.[2] ||
  { coverage: "需求覆盖", hypotheses: "一级假设验证" }[view.page];
const total = () => {
  const a = accounts();
  return {
    equity: a.reduce((s, a) => s + M.valuation(a, state.day).equity, 0),
    initial: a.reduce((s, a) => s + a.initial, 0),
    cash: a.reduce((s, a) => s + a.cash, 0),
  };
};
function toast(message, error = false) {
  const el = $("#toast");
  el.textContent = message;
  el.className = `toast ${error ? "error" : ""}`;
  el.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => (el.hidden = true), 4800);
}
function persist() {
  try {
    localStorage.setItem(STORAGE, JSON.stringify(state));
  } catch {
    storageWarning = "本地保存失败，请导出演示备份以保留本次变更。";
    toast(storageWarning, true);
  }
}
function mutate(fn, message) {
  const before = JSON.stringify(state);
  try {
    fn();
    persist();
    render();
    if (message) toast(message);
    return true;
  } catch (e) {
    state = JSON.parse(before);
    const error = $("#form-error");
    if (error) error.textContent = e.message;
    else toast(e.message, true);
    return false;
  }
}
function record(type, detail, ref = null) {
  state.events.push({
    id: `EV-${String(++state.sequence).padStart(4, "0")}`,
    type,
    detail,
    ref,
    workspace: view.workspace,
    actor: view.actor.id,
    at: `${M.DAYS[state.day]}T16:15:00+08:00`,
    version: M.VERSION,
  });
}
function go(page) {
  view.page = page;
  view.search = "";
  view.filter = "all";
  render();
  window.scrollTo({ top: 0, behavior: "instant" });
}
function head(subtitle, actions = "") {
  return `<div class="pagehead"><div><div class="eyebrow">INVESTMENT DECISION REVIEW</div><h1>${esc(title())}</h1><p>${subtitle}</p></div><div class="actions">${actions}</div></div>`;
}
function panel(name, body, action = "", sub = "") {
  return `<section class="panel"><div class="panel-head"><div><h2>${name}</h2>${sub ? `<small>${sub}</small>` : ""}</div>${action}</div>${body}</section>`;
}
function metric(label, value, foot, ic = "chart", color = "") {
  return `<article class="metric"><span class="metric-icon">${icon(ic)}</span><small>${label}</small><div class="number ${color}">${value}</div><div class="foot">${foot}</div></article>`;
}
function empty(
  text = "没有符合条件的记录",
  hint = "试试调整筛选条件，或录入一条新的观点。",
) {
  return `<div class="empty">${icon("inbox")}<h3>${text}</h3><p>${hint}</p></div>`;
}
function filters(includeStatus = true) {
  return `<div class="filters"><input id="search" aria-label="搜索记录" type="search" placeholder="搜索标的、分析师、观点…" value="${esc(view.search)}">${
    includeStatus
      ? `<select id="filter" aria-label="筛选状态"><option value="all">全部状态</option>${Object.entries(
          statuses,
        )
          .map(
            ([k, v]) =>
              `<option value="${k}" ${view.filter === k ? "selected" : ""}>${v[0]}</option>`,
          )
          .join("")}</select>`
      : ""
  }<span class="right note">${M.DAYS[state.day]} · 演示时钟</span></div>`;
}
function filtered(list) {
  return list.filter(
    (j) =>
      (view.filter === "all" || j.status === view.filter) &&
      `${j.text} ${j.ticker} ${member(j.owner).name} ${j.id}`
        .toLowerCase()
        .includes(view.search.toLowerCase()),
  );
}
function judgmentTable(list) {
  return !list.length
    ? empty()
    : `<div class="tablewrap"><table><thead><tr><th>标的 / 判断</th><th>分析师</th><th>方向 · 仓位</th><th>确认状态</th><th>PM 决定</th><th>来源</th><th></th></tr></thead><tbody>${list.map((j) => `<tr><td>${btn(esc(security(j.ticker).name), "detail", "link", `data-id="${j.id}"`)}<small class="mono">${esc(j.ticker || "待识别")} · ${j.day !== undefined ? M.DAYS[j.day].slice(5) : ""}</small></td><td><div class="name-cell">${avatar(j.owner)}${member(j.owner).name}</div></td><td>${j.direction === "SELL" ? badge("卖出", "orange") : badge("买入", "green")} <span class="mono">${j.weight ?? "—"}%</span><small>${j.mode === "target" ? "目标仓位" : j.mode === "delta" ? "增减仓位" : "语义待确认"}</small></td><td>${statusBadge(j)}</td><td>${j.pm ? badge(j.pm.choice, j.pm.choice === "采纳" ? "green" : "gray") : '<span class="muted">待讨论</span>'}</td><td>${j.origin === "manual" ? "人工判断" : badge("AI 辅助", "blue")}</td><td>${btn(icon("arrow"), "detail", "ghost small", `data-id="${j.id}" aria-label="查看 ${j.id}"`)}</td></tr>`).join("")}</tbody></table></div>`;
}
function timeLine(list) {
  return `<div class="timeline">${list.map((e) => `<div class="timeline-item"><small class="mono">${esc(e.at.slice(5, 16).replace("T", " "))} · ${esc(e.actor)}</small><h3>${esc(e.type)}</h3><p>${esc(e.detail)}</p>${e.ref ? btn(esc(e.ref), "detail", "link small", `data-id="${esc(e.ref)}"`) : ""}</div>`).join("")}</div>`;
}
function chart(account, window = 0) {
  const p = M.performance(account, state.day, window),
    hs = p.history;
  const start = hs[0]?.equity || account.initial;
  const series = hs.map((h) => (h.equity / start) * 100),
    base = hs.map(
      (h) => (M.price("02800", h.day) / M.price("02800", hs[0].day)) * 100,
    );
  const lo = Math.min(...series, ...base, 99.5) - 0.3,
    hi = Math.max(...series, ...base, 100.5) + 0.3;
  const x = (i) => 48 + (i / Math.max(1, hs.length - 1)) * 610,
    y = (v) => 175 - ((v - lo) / (hi - lo)) * 145;
  const line = (values) =>
    values
      .map((v, i) => `${i ? "L" : "M"}${x(i).toFixed(2)},${y(v).toFixed(2)}`)
      .join(" ");
  const ticks = [lo, (hi + lo) / 2, hi];
  const end = hs.length - 1;
  return `<svg class="chart" viewBox="0 0 700 210" role="img" aria-label="${member(account.owner).name}模拟净值与盈富基金基准对比"><defs><linearGradient id="chart-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#81b492" stop-opacity=".2"/><stop offset="100%" stop-color="#81b492" stop-opacity="0"/></linearGradient></defs>${ticks.map((v) => `<line x1="48" y1="${y(v)}" x2="658" y2="${y(v)}" stroke="#e8ede7" stroke-dasharray="3 4"/><text x="4" y="${y(v) + 4}">${fmt(v, 1)}</text>`).join("")}<path d="${line(series)} L${x(end)},175 L48,175Z" fill="url(#chart-fill)"/><path d="${line(base)}" fill="none" stroke="#b3bfae" stroke-width="2" stroke-dasharray="5 5"/><path d="${line(series)}" fill="none" stroke="#297857" stroke-width="2.5"/>${hs.map((h, i) => `<circle cx="${x(i)}" cy="${y(series[i])}" r="5" fill="transparent"><title>${M.DAYS[h.day]} 净值 ${fmt(series[i], 3)} · 基准 ${fmt(base[i], 3)}</title></circle>`).join("")}<circle cx="${x(end)}" cy="${y(series[end])}" r="4" fill="#297857" stroke="white" stroke-width="2"/>${[0, Math.floor(end / 2), end].map((i) => `<text x="${x(i)}" y="202" text-anchor="middle">${M.DAYS[hs[i].day].slice(5)}</text>`).join("")}</svg>`;
}
function chartPanel(account) {
  const p = M.performance(account, state.day, view.period);
  return panel(
    "模拟净值表现",
    `<div class="chart-toolbar"><div class="legend"><span><i></i>${member(account.owner).name}的组合</span><span><i class="benchmark"></i>盈富基金</span></div><div class="segmented">${[
      [5, "近一周"],
      [0, "成立以来"],
    ]
      .map(([n, t]) =>
        btn(
          t,
          "period",
          view.period === n ? "active" : "",
          `data-value="${n}"`,
        ),
      )
      .join(
        "",
      )}</div></div>${chart(account, view.period)}<div class="chart-summary"><span>区间收益 <b class="${cls(p.return)}">${pct(p.return)}</b></span><span>基准差异 <b>${pct(p.excess)}</b></span><span>最大回撤 <b>${pct(p.drawdown)}</b></span></div>`,
    badge("模拟数据", "green"),
    "期初归一至 100 · 日终估值 · 费用已计入",
  );
}
function openDialog(name, body, { drawer = false } = {}) {
  const d = $("#dialog");
  if (d.open) d.close();
  d.className = `dialog ${drawer ? "drawer" : ""}`;
  d.innerHTML = `<div class="dialog-head"><div><small class="eyebrow">REVIEW / 模拟数据</small><h2 id="dialog-title">${name}</h2></div>${btn(icon("close"), "close", "ghost", 'aria-label="关闭弹窗"')}</div><div class="dialog-content">${body}<div id="form-error" class="form-error" role="alert"></div></div>`;
  d.showModal();
}
function download(name, body, type = "application/json") {
  const blob = new Blob([body], { type: `${type};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  toast("已生成文件，正在下载");
}
function report() {
  const aa = accounts();
  return {
    label: "模拟数据 · 非真实业绩 · 仅用于产品演示",
    version: M.VERSION,
    asOf: M.DAYS[state.day],
    workspace: view.workspace,
    market: "港股/HKD 样例，客户市场待定",
    marketVersion: "hk-mock-v1",
    reportKind: "USER_PAPER_PORTFOLIO",
    executionPolicy:
      "人工确认后下一模拟交易日开盘；仅做多；分数股；演示费用不代表实际税费",
    storage: "浏览器演示存储，无服务器认证或生产防篡改",
    accounts: aa.map((a) => ({
      id: a.id,
      owner: a.owner,
      accountKind: a.kind,
      initial: a.initial,
      ...M.valuation(a, state.day),
      performance: M.performance(a, state.day, view.period),
      reconciliation: M.verify(a),
      trades: a.trades,
    })),
    judgments: judgments(),
    events: events(),
    reviews:
      view.workspace === "team" && view.actor.role !== "analyst"
        ? state.reviews
        : [],
    limitations: [
      "Mock 行情，不可证明投资能力",
      "未连接飞书/Ostag/Supabase",
      "分红/拆股/退市和实际市场规则未接入",
      "无风险调整 alpha 或人员能力总分",
    ],
  };
}
function reportHTML() {
  const r = report();
  return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>投研复盘样例报告 · 模拟数据</title><style>body{font:14px/1.8 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;max-width:1050px;margin:40px auto;padding:0 24px;color:#17392c}h1{font-size:30px}h2{margin-top:35px}h3{font-size:16px}small{color:#65796d}.label{background:#edf4eb;border:1px solid #cfdccc;padding:16px;border-radius:8px}table{border-collapse:collapse;width:100%;font-size:12px;margin:20px 0}th,td{text-align:left;border-bottom:1px solid #e2e9e0;padding:10px 8px}th{background:#f3f6ef}svg{width:100%;height:240px}svg text{font-size:10px;fill:#69816d}article{break-inside:avoid;border:1px solid #e2e9e0;border-radius:8px;padding:20px;margin-top:20px}.metrics{display:flex;flex-wrap:wrap;gap:25px}.metrics strong{display:block;font-size:24px}.muted{color:#69776e}blockquote{border-left:3px solid #b3ccb6;padding-left:14px;white-space:pre-wrap}.print-note{font-size:12px;color:#6a796f}@media print{body{margin:0}h2{break-before:auto}article{box-shadow:none}}</style><body><small>DAO.REVIEW / 投研判断与复盘</small><h1>${view.workspace === "team" ? "大道机构" : "Osborn 个人"} · 模拟组合表现报告</h1><div class="label"><strong>${r.label}</strong><br>报告日期 ${r.asOf} · ${esc(r.market)} · ${r.version}<br>${esc(r.executionPolicy)}</div><p class="print-note">可通过浏览器打印保存为 PDF。所有图表与表格为导出时快照，不包含实时行情。</p>${accounts()
    .map((a) => {
      const v = M.valuation(a, state.day),
        p = M.performance(a, state.day, view.period),
        check = M.verify(a);
      return `<article><h2>${member(a.owner).name} · ${a.kind === "PERSONAL_PAPER" ? "个人模拟" : "机构模拟"}账户</h2><small>${a.id} · 观察期 ${M.DAYS[p.history[0].day]} 至 ${M.DAYS[state.day]} · ${p.history.length} 个模拟交易日</small><div class="metrics"><p>组合权益<strong>HKD ${fmt(v.equity)}</strong></p><p>区间收益<strong>${pct(p.return)}</strong></p><p>基准差异<strong>${pct(p.excess)}</strong></p><p>最大回撤<strong>${pct(p.drawdown)}</strong></p></div>${chart(a, view.period)}<p>绿色：模拟组合；虚线：盈富基金基准。期初归一至 100，费用已计入。</p><table><thead><tr><th>证券</th><th>份额</th><th>成本</th><th>模拟现价</th><th>市值</th><th>浮动盈亏</th><th>仓位</th></tr></thead><tbody>${v.holdings.map((p) => `<tr><td>${security(p.ticker).name} ${p.ticker}</td><td>${fmt(p.quantity, 4)}</td><td>${fmt(p.cost)}</td><td>${fmt(p.price)}</td><td>${fmt(p.value)}</td><td>${fmt(p.pnl)}</td><td>${fmt(p.weight)}%</td></tr>`).join("")}</tbody></table><p>可用现金 HKD ${fmt(v.cash)} ＋ 持仓市值 HKD ${fmt(v.marketValue)} ＝ 组合权益 HKD ${fmt(v.equity)}<br>累计费用 HKD ${fmt(check.fee)} · ${check.tradeCount} 笔成交 · 账本核对${check.ok ? "一致" : "存在差异"}</p></article>`;
    })
    .join("")}<h2>判断与采纳证据</h2>${judgments()
    .filter((j) => j.status !== "ignored")
    .map(
      (j) =>
        `<article><strong>${esc(j.id)} · ${member(j.owner).name} · ${statuses[j.status][0]}</strong><blockquote>${esc(j.text)}</blockquote><p>建议来源：${esc(j.origin)} / ${esc(j.sourceVersion)}<br>确认：${esc(j.confirmedAt || "未确认")} / ${esc(j.decisionAuthor || "—")}<br>规则：${esc(j.policy?.version || "尚未固定")}<br>观点验证：${esc(j.observation || "尚待观察")}<br>PM：${j.pm ? `${esc(j.pm.choice)} — ${esc(j.pm.reason)}` : "尚无决定"}</p></article>`,
    )
    .join(
      "",
    )}<h2>报告边界</h2><ul>${r.limitations.map((x) => `<li>${esc(x)}</li>`).join("")}</ul><p>${esc(r.storage)}。来源与资金账户分别记录；人工筛选的 AI 建议不等于独立 AI 业绩。</p><small>${r.marketVersion} · ${r.version} · 报告生成于模拟日期 ${r.asOf}</small></body></html>`;
}
