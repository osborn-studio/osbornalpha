function overview() {
  const t = total(),
    a = selectedAccount(),
    p = M.performance(a, state.day),
    js = judgments().filter((j) => j.status !== "ignored");
  const executed = js.filter((j) => j.status === "executed");
  return `${head(view.workspace === "personal" ? "记录我的判断，分清建议来源，持续复盘。" : "把当时的判断，变成今天有依据的讨论。", btn(icon("play") + "五分钟导览", "tour") + btn(icon("plus") + "记录观点", "new", "primary"))}
 <div class="intro">${icon("leaf")}<div><div class="step-label">从一条观点，开始完整的复盘</div><p>原文留存 <span class="muted">／</span> 人工确认 <span class="muted">／</span> 模拟组合 <span class="muted">／</span> 结果与证据</p></div>${btn("体验一条完整记录 " + icon("arrow"), "navigate", "small", 'data-page="inbox"')}</div>
 <div class="metrics">${metric("有效判断记录", js.length, `${executed.length} 条已模拟成交 · 全量保留原文`, "file")}${metric("待确认与澄清", pending().length, "人工确认后才进入模拟执行", "inbox", pending().length ? "" : "")}${metric("组合平均收益", pct(t.equity / t.initial - 1), "等初始资金 · 同日起点 · 含现金与费用", "chart", cls(t.equity - t.initial))}${metric("本周复盘行动", view.workspace === "team" ? state.reviews[0].actions.filter((x) => !x.done).length : "1", view.workspace === "team" ? "记录决定，也记录下一步" : "个人与机构数据分开演示", "review")}</div>
 <div class="grid-main">${chartPanel(a)}${panel("今天，先看这几件事", `<div class="task"><div class="task-marker">${icon("inbox")}</div><div><h3>${pending().length} 条观点等待确认</h3><p>原话里的“10 个点”，是哪种仓位？</p><span class="meta">确认语义，减少复盘争议</span></div>${btn("处理", "navigate", "small", 'data-page="inbox"')}</div><div class="task"><div class="task-marker green">${icon("review")}</div><div><h3>${view.workspace === "team" ? "本周投研复盘" : "我的模拟记录"}</h3><p>把表现与最初的依据放在一起。</p><span class="meta">${M.DAYS[state.day]} · 模拟日期</span></div>${btn("打开", "navigate", "small", `data-page="${view.workspace === "team" ? "reviews" : "judgments"}"`)}</div><div class="task"><div class="task-marker green">${icon("shield")}</div><div><h3>账本可以逐笔核对</h3><p>现金 + 持仓市值 = 组合权益</p><span class="meta">${accounts().length} 个演示账户 · 确定性核算</span></div>${btn("核对", "verify", "small")}</div>`, badge("工作清单", "gray"))}</div>
 ${panel("最近的判断", judgmentTable(js.slice(-5).reverse()), btn("查看全部 " + icon("arrow"), "navigate", "link small", 'data-page="judgments"'), "从原话到结果，每一条都能回溯")}
 <div class="grid-two" style="margin-top:22px">${panel("研究与结果，分开看", `<div class="panel-body"><div class="row spread"><div><h3>不让一个收益数字代替完整判断</h3><p class="note" style="margin-top:8px">模拟结果、观点兑现、记录质量、PM 采纳分别展示。观察期只有 ${state.day + 1} 个模拟交易日，样本不足以评价长期能力。</p></div>${icon("eye")}</div></div>`, badge("评价原则", "green"))}${panel("最近动态", `<div class="panel-body">${timeLine(events().slice(-2).reverse())}</div>`, btn("证据中心", "navigate", "link small", 'data-page="evidence"'))}</div>`;
}
function inbox() {
  const list = filtered(judgments())
    .filter(
      (j) =>
        view.filter !== "all" ||
        ["pending", "ambiguous", "queued", "blocked"].includes(j.status),
    )
    .slice()
    .reverse();
  return `${head("保留原话，确认语义。讨论不会自动变成正式交易指令。", btn(icon("plus") + "手动录入", "new", "primary"))}${filters()}<div class="inbox-layout">${panel("待处理观点", list.length ? list.map((j) => `<article class="message-card">${avatar(j.owner)}<div class="message-body"><div class="row spread"><strong>${member(j.owner).name}</strong>${statusBadge(j)}</div><span class="meta">${j.origin === "manual" ? "大道 · 投研交流（虚构群消息）" : "OsbornAlpha · AI 候选样例"} · ${j.createdAt.slice(5, 16).replace("T", " ")}</span><blockquote>${esc(j.text)}</blockquote>${j.reason ? `<p class="note">${esc(j.reason)}</p>` : ""}<div class="row spread"><small>${j.ticker || "待识别"} · ${j.mode === "target" ? "目标仓位" : j.mode === "delta" ? "增减仓位" : "仓位语义待确认"}</small>${btn(["queued", "executed"].includes(j.status) ? "查看进度" : "检查并确认", "detail", "small", `data-id="${j.id}"`)}</div></div></article>`).join("") : empty("当前没有待处理观点", "可以录入新观点，或筛选已成交、普通讨论等状态。"), badge(`${list.length} 条`))}
 ${panel(
   "试着说出你的判断",
   `<div class="panel-body"><p class="note">模拟飞书输入，不会向任何真实群发送消息。</p><form id="ingest-form"><div class="field-grid"><div><label for="ingest-owner">发言人 · 演示身份</label><select id="ingest-owner" name="owner">${accounts()
     .map((a) => `<option value="${a.owner}">${member(a.owner).name}</option>`)
     .join(
       "",
     )}</select></div><div><label for="origin">建议来源</label><select name="origin" id="origin"><option value="manual">人工原创</option><option value="copilot">AI 辅助 · Copilot</option><option value="signal">AI 信号样例</option></select></div><div class="full"><label for="ingest-text">观点原文</label><textarea id="ingest-text" name="text" required maxlength="4000" placeholder="@判断台 买入腾讯，目标仓位 35%，观察期三个月。"></textarea></div><div class="full"><label for="message-id">消息编号（可选，同编号可测试去重）</label><input id="message-id" name="messageId" placeholder="例如 demo-message-001" maxlength="100"></div></div><button type="submit" class="primary">${icon("bolt")}生成待确认卡片</button></form><div class="hint">仅演示规则解析；歧义需要人工纠正。AI 候选本身不拥有模拟资金账户。</div><h3>一键填入样例</h3><div class="row wrap" style="margin-top:12px">${btn("明确买入", "sample", "small", 'data-value="clear"')}${btn("仓位有歧义", "sample", "small", 'data-value="ambiguous"')}${btn("普通讨论", "sample", "small", 'data-value="noise"')}${btn("模拟卖出", "sample", "small", 'data-value="sell"')}</div></div>`,
   badge("离线沙盒", "green"),
 )}</div>`;
}
function judgmentView() {
  return `${head("原始建议、人工确认、执行结果和 PM 决定，放在同一条记录里。", btn(icon("down") + "导出记录", "export-records") + btn(icon("plus") + "记录观点", "new", "primary"))}${filters()}${panel("全部判断", judgmentTable(filtered(judgments()).slice().reverse()), badge(`${filtered(judgments()).length} 条`), "普通讨论、未采纳和失败记录同样保留，不挑选“好结果”")}`;
}
function portfolio() {
  const a = selectedAccount(),
    v = M.valuation(a, state.day),
    r = M.verify(a),
    p = M.performance(a, state.day);
  const colors = [
    "#4a8763",
    "#82a78b",
    "#a6bfa0",
    "#bbcfae",
    "#71999a",
    "#b5b7a1",
  ];
  return `${head("每个分析师都有独立的模拟现金、持仓与账本。", btn(icon("shield") + "核对账本", "verify") + btn(icon("clock") + "推进一个交易日", "advance", "primary"))}
 <div class="account-grid">${accounts()
   .map((x) => {
     const v = M.valuation(x, state.day);
     return `<button class="account-card ${a.id === x.id ? "selected" : ""}" data-action="account" data-id="${x.id}"><div class="row spread"><div class="name-cell">${avatar(x.owner)}<div><strong>${member(x.owner).name}</strong><div class="note">${x.kind === "PERSONAL_PAPER" ? "个人模拟 · 混合来源" : "机构模拟 · 人工确认"}</div></div></div>${badge("模拟", "green")}</div><div class="value mono">${fmt(v.equity)}</div><div class="row spread"><small>组合权益 · HKD</small><strong class="${cls(v.return)}">${pct(v.return)}</strong></div><div class="progress"><i style="width:${Math.min(100, v.exposure)}%"></i></div><div class="row spread"><small>仓位 ${fmt(v.exposure, 1)}%</small><small>上限 ${x.maxPosition}%</small></div></button>`;
   })
   .join("")}</div>
 <div class="metrics">${metric("可用现金 · HKD", fmt(v.cash), `初始资金 ${fmt(a.initial, 0)} · 无外部入金`, "wallet")}${metric("持仓市值 · HKD", fmt(v.marketValue), `${v.holdings.length} 个标的 · 模拟收盘价估值`, "chart")}${metric("净值", fmt(v.nav, 4), `最大回撤 ${pct(p.drawdown)}`, "chart")}${metric("累计模拟费用 · HKD", fmt(r.fee), `${a.trades.length} 笔成交 · ${r.ok ? "流水核对一致" : "待核查"}`, "shield")}</div>
 <div class="grid-main">${chartPanel(a)}${panel("仓位分布", `<div class="panel-body"><div class="row spread"><span class="muted">总仓位</span><strong class="mono">${fmt(v.exposure, 1)}%</strong></div><div class="alloc-bar">${v.holdings.map((p, i) => `<span style="width:${p.weight}%;background:${colors[i]}"></span>`).join("")}<span style="width:${100 - v.exposure}%;background:#e8ece4"></span></div>${v.holdings.map((p, i) => `<div class="row spread" style="margin:10px 0"><span class="note"><i style="display:inline-block;width:7px;height:7px;background:${colors[i]};margin-right:8px"></i>${security(p.ticker).name}</span><span class="mono note">${fmt(p.weight, 1)}%</span></div>`).join("")}<div class="row spread"><span class="note">现金</span><span class="mono note">${fmt(100 - v.exposure, 1)}%</span></div></div>`, badge("只做多 · 无杠杆"))}</div>
 ${panel("当前持仓", v.holdings.length ? `<div class="tablewrap"><table><thead><tr><th>证券</th><th>份额</th><th>平均成本</th><th>模拟现价</th><th>持仓市值</th><th>浮动盈亏</th><th>仓位</th><th></th></tr></thead><tbody>${v.holdings.map((p) => `<tr><td><strong>${security(p.ticker).name}</strong><small class="mono">${p.ticker}.HK</small></td><td class="mono">${fmt(p.quantity, 4)}</td><td class="mono">${fmt(p.cost)}</td><td class="mono">${fmt(p.price)}</td><td class="mono">${fmt(p.value)}</td><td class="mono ${cls(p.pnl)}">${p.pnl > 0 ? "+" : ""}${fmt(p.pnl)}</td><td>${fmt(p.weight, 1)}%</td><td>${btn("减仓", "sell", "small", `data-ticker="${p.ticker}" data-owner="${a.owner}"`)}</td></tr>`).join("")}</tbody></table></div>` : empty("当前为空仓", "确认买入后，推进演示交易日即可查看持仓。"), badge("分数股 · 演示规则"))}
 <div style="margin-top:22px">${panel("成交流水", tradeTable(a.trades), btn("导出报告", "export-report", "link small"), "确认时点早于价格形成时点；不使用有利历史价格")}</div>`;
}
function tradeTable(trades) {
  return !trades.length
    ? empty("暂无模拟成交")
    : `<div class="tablewrap"><table><thead><tr><th>成交日期</th><th>证券 / 方向</th><th>份额</th><th>开盘价</th><th>金额</th><th>费用</th><th>原因 / 证据</th></tr></thead><tbody>${trades
        .slice()
        .reverse()
        .map(
          (t) =>
            `<tr><td class="mono">${M.DAYS[t.day]}</td><td>${security(t.ticker).name} ${badge(t.quantity > 0 ? "买入" : "卖出", t.quantity > 0 ? "green" : "orange")}</td><td class="mono">${fmt(Math.abs(t.quantity), 4)}</td><td class="mono">${fmt(t.price)}</td><td class="mono">${fmt(Math.abs(t.gross))}</td><td class="mono">${fmt(t.fee)}</td><td>${esc(t.reason)}<small>${btn(t.judgmentId, "detail", "link", `data-id="${t.judgmentId}"`)}</small></td></tr>`,
        )
        .join("")}</tbody></table></div>`;
}
function performanceView() {
  const a = selectedAccount(),
    periodData = M.performance(a, state.day, view.period);
  return `${head("用一致的观察期与口径看表现，也看样本和数据限制。", btn(icon("down") + "导出表现报告", "export-report"))}<div class="filters"><select id="account-select" aria-label="选择模拟账户">${accounts()
    .map(
      (x) =>
        `<option value="${x.id}" ${x.id === a.id ? "selected" : ""}>${member(x.owner).name}</option>`,
    )
    .join(
      "",
    )}</select><select id="period-select" aria-label="表现统计周期"><option value="0" ${view.period === 0 ? "selected" : ""}>成立以来（本月）</option><option value="5" ${view.period === 5 ? "selected" : ""}>最近一周</option><option value="22" ${view.period === 22 ? "selected" : ""}>最近一月</option><option value="252" ${view.period === 252 ? "selected" : ""}>最近一年</option></select><span class="note">实际样本仅 ${state.day + 1} 个交易日；月 / 年视图按已有样本展示，不年化</span></div><div class="grid-main">${chartPanel(a)}${panel("数据与评价口径", `<div class="panel-body"><dl class="definition"><dt>报告类型</dt><dd>用户模拟组合</dd><dt>观察期</dt><dd>${M.DAYS[periodData.history[0].day]} 至 ${M.DAYS[state.day]}</dd><dt>有效交易日</dt><dd>${periodData.history.length} 个模拟交易日</dd><dt>基准</dt><dd>盈富基金 · 同期买入持有</dd><dt>“基准差异”</dt><dd>组合收益 − 基准收益，非风险调整 alpha</dd><dt>估值数据</dt><dd>hk-mock-v1 · ${M.DAYS[state.day]}</dd><dt>费用 / 公司行动</dt><dd>费用计入；分红拆股暂不支持</dd></dl></div>`, badge("固定口径", "green"))}</div>${panel(
    "分析师表现对照",
    `<div class="tablewrap"><table><thead><tr><th>分析师</th><th>区间收益</th><th>基准差异</th><th>最大回撤</th><th>累计成交</th><th>累计确认</th><th>PM 采纳</th></tr></thead><tbody>${accounts()
      .map((x) => {
        const p = M.performance(x, state.day, view.period),
          jj = judgments().filter(
            (j) => j.owner === x.owner && j.status !== "ignored",
          );
        return `<tr><td><div class="name-cell">${avatar(x.owner)}${member(x.owner).name}</div></td><td class="mono ${cls(p.return)}">${pct(p.return)}</td><td class="mono ${cls(p.excess)}">${pct(p.excess)}</td><td class="mono down">${pct(p.drawdown)}</td><td>${p.samples} 笔</td><td>${jj.filter((j) => j.confirmedAt).length} / ${jj.length} 已确认</td><td>${jj.filter((j) => j.pm?.choice === "采纳").length} 条<small>采纳不等于真实交易</small></td></tr>`;
      })
      .join(
        "",
      )}</tbody></table></div><div class="scope-label">按成员固定顺序展示，不按收益排名。不同风险暴露不能直接推导个人能力。</div>`,
    badge("不生成综合总分"),
  )}<div class="hint">全部为虚构样例和模拟行情。样本有限，不能作为真实投资业绩或薪酬依据；个人 AI 辅助记录不代表独立 AI 账户业绩。</div>`;
}
function reviews() {
  if (view.workspace === "personal")
    return `${head("个人工作区独立于机构复盘。")}${panel("我的判断复盘", judgmentTable(judgments()), btn("查看判断", "navigate", "link", 'data-page="judgments"'))}`;
  if (view.actor.role === "analyst")
    return `${head("分析师可查看和补充本人的判断记录。")}${panel("我的复盘材料", judgmentTable(judgments()), badge("本人范围"))}`;
  const r = state.reviews[0];
  return `${head("让复盘会议形成下一次行动，而不止是一份收益报告。", btn(icon("down") + "导出会议材料", "export-meeting") + btn(icon("plus") + "添加跟踪事项", "add-task", "primary"))}<div class="review-hero"><div class="eyebrow">WEEKLY REVIEW · ${esc(r.period)}</div><h2>${esc(r.title)}</h2><p>${esc(r.summary)}</p><div class="row wrap" style="margin-top:17px">${badge("第 3 周 · 演示议程", "green")}${badge(`${judgments().filter((j) => j.status === "executed").length} 条已成交记录`)}${badge(`${r.actions.filter((a) => !a.done).length} 项待跟进`)}</div></div>
 <div class="grid-main">${panel(
   "本周需要讨论的判断",
   judgmentTable(
     judgments()
       .filter((j) => j.status === "executed")
       .slice(0, 4),
   ),
   badge("回到原始证据", "green"),
 )}${panel("行动清单", `<div class="panel-body">${r.actions.map((a) => `<div class="action-item ${a.done ? "done" : ""}">${btn(a.done ? icon("check") : "", "toggle-task", "", `data-id="${a.id}" aria-label="${a.done ? "重新打开" : "完成"} ${esc(a.text)}" aria-pressed="${a.done}"`)}<div><p>${esc(a.text)}</p><small>${member(a.owner).name} · ${esc(a.due)}</small></div></div>`).join("") || empty("暂无行动")}</div>`, badge(`${r.actions.filter((a) => a.done).length}/${r.actions.length}`))}</div>
 ${panel("复盘结论", `<div class="panel-body"><form id="conclusion-form"><label for="conclusion">本周学到了什么？下周验证什么？</label><textarea id="conclusion" name="conclusion" maxlength="4000" required placeholder="记录观点变化、反证和需要继续验证的条件…">${esc(r.conclusion)}</textarea><div class="row spread" style="margin-top:14px"><small>保存会留下新事件，不修改原观点。</small><button class="primary" type="submit">保存复盘结论</button></div></form></div>`, badge("PM 记录"))}`;
}
function evidence() {
  const aa = accounts(),
    checks = aa.map((a) => M.verify(a));
  return `${head("把原始消息、确认、规则与资金变化串成可以核对的历史。", btn(icon("down") + "导出证据包", "export-evidence") + btn(icon("shield") + "重新核对", "verify", "primary"))}<div class="metrics">${metric("证据事件", events().length, "浏览器本地事件 · 非生产防篡改存证", "shield")}${metric("账本对账", `${checks.filter((r) => r.ok).length} / ${aa.length}`, "从初始现金逐笔回算现金与持仓", "check")}${metric("行情版本", "Mock v1", `${M.DAYS[state.day]} · 模拟数据`, "chart")}${metric("规则版本", `v${state.settings.ruleVersion}`, "旧指令保留确认时的规则快照", "file")}</div><div class="grid-main">${panel("事件时间线", `<div class="panel-body">${timeLine(events().slice().reverse().slice(0, 30))}</div>`, badge("保留原始历史", "green"))}${panel("来源与可信边界", `<div class="panel-body"><h3>两类记录，各自承担责任</h3><dl class="definition"><dt>判断事件</dt><dd>计划由 Ostag 接收平台身份、原文、确认及版本。</dd><dt>资金账本</dt><dd>计划由 Supabase 独立模拟账户保存持仓、现金及成交。</dd><dt>关联键</dt><dd class="mono">judgment_id</dd><dt>本次演示</dt><dd>所有状态保存在当前浏览器。未连接以上服务。</dd></dl><div class="hint">“可回算”不等于“不可篡改”。真实审计仍需要可信身份、持久化存储和访问控制。</div><h3>逐账户核对</h3>${aa.map((a) => `<div class="row spread" style="margin-top:14px"><span>${member(a.owner).name}</span>${badge(M.verify(a).ok ? "账实一致" : "存在差异", M.verify(a).ok ? "green" : "red")}</div>`).join("")}</div>`, badge("透明披露"))}</div>`;
}
function settings() {
  return `${head("配置演示规则，查看真实接入前还需要完成的事项。", btn("恢复初始样例", "reset", "danger"))}<div class="grid-two">${panel(
    "工作流连接",
    `<div class="panel-body">${[
      ["飞", "飞书 / Lark", "群消息、身份与确认卡片"],
      ["O", "Ostag", "判断事件与审批治理"],
      ["S", "Supabase", "独立模拟账户与资金账本"],
      ["α", "OsbornAlpha", "个人研究与 AI 候选来源"],
    ]
      .map(
        ([mark, n, d]) =>
          `<div class="connector"><div class="connector-logo">${mark}</div><div class="connector-body"><h3>${n}</h3><p>${d}</p></div>${btn("未连接", "connector", "small", `data-name="${n}"`)}</div>`,
      )
      .join(
        "",
      )}<p class="note">真实接入需要企业应用配置及测试环境。此页面不会保存密钥、连接真实群或发送消息。</p></div>`,
    badge("离线演示", "orange"),
  )}${panel(
    "模拟执行规则",
    `<div class="panel-body"><form id="settings-form"><div class="field-grid"><div><label for="fee">交易费率（bps）</label><input id="fee" name="feeBps" type="number" min="0" max="100" step=".1" value="${state.settings.feeBps}" required></div><div><label for="maxPosition">最大总仓位（%）</label><input id="maxPosition" name="maxPosition" type="number" min="10" max="100" value="${state.accounts[0].maxPosition}" required></div><div><label for="scope-account">应用账户</label><select id="scope-account" name="accountId"><option value="">所有机构模拟账户</option>${state.accounts
      .filter((a) => a.workspace === "team")
      .map((a) => `<option value="${a.id}">${member(a.owner).name}</option>`)
      .join(
        "",
      )}</select></div><div><label for="trigger">本地解析触发方式</label><select id="trigger" name="trigger">${[
      ["mention", "@判断台 / @机器人"],
      ["prefix", "固定前缀 /记录"],
      ["all", "全部文本（本地样例）"],
    ]
      .map(
        ([v, t]) =>
          `<option value="${v}" ${state.settings.trigger === v ? "selected" : ""}>${t}</option>`,
      )
      .join(
        "",
      )}</select></div><div class="full"><label for="missingTicker">异常演示：暂停指定证券的新成交行情</label><select id="missingTicker" name="missingTicker"><option value="">无异常</option>${M.SECURITIES.map((s) => `<option value="${s.ticker}" ${state.settings.missingTicker === s.ticker ? "selected" : ""}>${s.name} · ${s.ticker}</option>`).join("")}</select></div></div><div class="hint">规则变更仅影响后续确认。已排队指令保留原规则；暂停行情仅模拟缺失新成交价格，历史估值样例保持可用。</div><button class="primary" type="submit" ${view.actor.role !== "admin" ? "disabled" : ""}>保存新规则版本</button>${view.actor.role !== "admin" ? '<p class="note" style="margin-top:8px">在右上角切换“管理员 · 演示”后可配置。</p>' : ""}</form></div>`,
    badge(`rules-${state.settings.ruleVersion}`),
  )}</div>
 ${panel(
   "成员与访问范围（体验预览）",
   `<div class="tablewrap"><table><thead><tr><th>成员</th><th>研究范围</th><th>模拟账户</th><th>访问范围</th><th>身份来源</th></tr></thead><tbody>${M.MEMBERS.filter(
     (m) => accounts().some((a) => a.owner === m.id),
   )
     .map(
       (m) =>
         `<tr><td><div class="name-cell">${avatar(m.id)}${m.name}</div></td><td>${m.sector}</td><td class="mono">ACC-${m.id}</td><td>本人记录与模拟组合</td><td>${badge("未核验 · 演示身份", "orange")}</td></tr>`,
     )
     .join(
       "",
     )}</tbody></table></div><div class="scope-label">右上角角色切换只演示体验；HTML 包含全部虚构数据，不提供真实租户隔离或服务端授权。</div>`,
 )}<div class="grid-two" style="margin-top:22px">${panel("演示数据与备份", `<div class="panel-body"><p class="note">浏览器会保留你的演示操作。导出 JSON 可保存完整演示进度，恢复前会校验结构与账本。</p><div class="row wrap" style="margin-top:15px">${btn("导出演示备份", "backup")}${btn("恢复演示备份", "restore")}</div></div>`)}${panel("一级市场方向", `<div class="panel-body"><p class="note">先用人工样例验证“投前假设 → 投委会决定 → 后续事实”，不计入二级业绩，不承诺一级完整系统。</p><div style="margin-top:15px">${btn("打开假设验证样例 " + icon("arrow"), "navigate", "link", 'data-page="hypotheses"')}</div></div>`, badge("访谈验证阶段", "orange"))}</div>`;
}
function hypotheses() {
  if (view.workspace !== "team" || view.actor.role === "analyst")
    return `${head("一级方向仅在机构管理视角提供人工验证样例。")}${empty("请切换机构 PM 演示身份", "个人模拟记录与机构项目数据分开展示。")}`;
  return `${head("人工样例用于访谈；项目事实和二级市场模拟净值分别管理。", btn(icon("plus") + "新增假设样例", "add-hypothesis", "primary"))}<div class="hint">一级方向仅提供人工记录体验。不计算估值收益、IRR、个人总分，也未接入真实项目数据。</div>${panel("投资假设与后续事实", `<div class="tablewrap"><table><thead><tr><th>项目</th><th>原始假设</th><th>投委会决定</th><th>事实验证</th><th>到期日</th><th></th></tr></thead><tbody>${state.hypotheses.map((h) => `<tr><td><strong>${esc(h.project)}</strong><small>虚构项目</small></td><td style="white-space:normal;min-width:240px">${esc(h.hypothesis)}<small>${esc(h.evidence)}</small></td><td>${badge(h.decision)}</td><td>${badge(h.result, h.result === "兑现" ? "green" : h.result === "失效" ? "red" : "orange")}</td><td>${esc(h.deadline)}</td><td>${btn("更新事实", "hypothesis-result", "small", `data-id="${h.id}"`)}</td></tr>`).join("")}</tbody></table></div>`, badge("人工样例"))}`;
}
function coverage() {
  return `${head("65 条原始需求保留编号；演示覆盖与真实接入验收分开记录。", btn("下载需求映射", "export-coverage"))}<div class="hint green">本轮交付可点击的产品闭环。原需求历史“已实现”状态保持原文，不用它宣称此次生产验收通过。</div>${panel("原始需求映射", `<div class="tablewrap"><table class="coverage-table"><thead><tr><th>编号</th><th>原需求</th><th>优先级</th><th>本轮对应</th><th>交付边界</th></tr></thead><tbody>${REQUIREMENTS.map((r) => `<tr><td class="mono">${esc(r.id)}</td><td>${esc(r.description.replace(/\*\*/g, ""))}</td><td>${esc(r.priority)}</td><td>${btn(r.pageLabel, "navigate", "link", `data-page="${r.page}"`)}</td><td>${badge(r.scope, r.scope === "交互演示" ? "green" : "orange")}</td></tr>`).join("")}</tbody></table></div>`, badge("65 / 65 已映射"))}`;
}
