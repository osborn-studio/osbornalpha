/**
 * 独立 Demo Dashboard（无框架、无构建、无 CDN）。
 *
 * 与 DSH GUI 里的 `conversation.view` 客户端插件消费**同一套 REST API**，
 * 因此两边看到的事实数字永远一致。
 *
 * 前端能力：
 *   · 主题：跟随系统 / 深色 / 浅色，切换只换 CSS 变量（index.html 里的设计令牌）
 *   · 导航：hash 路由（可深链、可刷新、浏览器前进后退可用）+ 返回按钮 + 面包屑
 *   · 表格：点表头排序、固定表头、按标的/状态/方向过滤、整行键盘可达
 *   · 图表：价格走势 + 入场/目标/止损参考线 + 达标/止损触发点 + Benchmark 归一化对照
 *   · 状态：骨架屏、错误卡片（带重试）、空状态；报告 Markdown 渲染成可读排版
 *   · 中英文：顶栏切换，选择存 localStorage，并作为 Accept-Language 发给服务端
 *     （报告 Markdown 因此也是所选语言）
 */

const API = '/api/trade-eval'
const app = document.getElementById('app')
const LANG_KEY = 'trade-eval-language'
const THEME_KEY = 'trade-eval-theme'

/** 文案表（键名与 src/client/dashboard.js 的 UI 词典保持一致，测试会断言两边对齐）。 */
export const DICT = {
  zh: {
    tab: '策略评估',
    appTitle: '交易策略评估',
    dashboard: 'Manager Dashboard',
    role: '角色',
    language: '语言',
    theme: '主题',
    themeAuto: '跟随系统',
    themeLight: '浅色',
    themeDark: '深色',
    teamDetail: '团队明细',
    teamSummary: '团队汇总',
    byAnalyst: '按分析师分组',
    allTeams: '全部团队',
    unknownTeam: '未知团队',
    analystCount: '分析师数',
    noStrategiesInTeam: '该团队暂无策略',
    viewTeam: '查看团队明细',
    strategiesOf: '{name} 的策略',
    noStrategiesForMember: '该成员暂无策略',
    identity: '身份',
    actingAs: '当前身份',
    analystSelf: '当前分析师',
    newStrategy: '提交策略',
    editStrategy: '编辑策略',
    myStrategies: '我的策略',
    saveDraft: '存为草稿',
    submitAndFreeze: '提交并冻结',
    freezeStrategy: '冻结',
    cancelStrategy: '取消策略',
    cancelReason: '取消原因',
    confirmCancel: '确认取消这条策略？',
    fieldTicker: '标的',
    fieldAction: '方向',
    fieldEntry: '入场价',
    fieldTarget: '目标价',
    fieldStop: '止损价',
    fieldHolding: '预期持仓（交易日）',
    fieldBenchmark: '对比基准',
    fieldQuantity: '数量',
    fieldPositionBefore: '提交前仓位',
    fieldReason: '策略理由',
    useCurrentPrice: '用当前价',
    currentPrice: '当前价',
    snapshotHint: '提交时会自动抓取当时的市场快照，用于事后审计。',
    invalidBuy: 'BUY 要求：止损 < 入场价 < 目标价',
    invalidSell: 'SELL 要求：目标价 < 入场价 < 止损价',
    requiredFields: '请填写所有必填项',
    draftHint: '草稿可编辑；一旦冻结，核心决策字段永久不可修改。',
    createdFrozen: '已提交并冻结：{id}',
    createdDraft: '已存为草稿：{id}',
    savedDraft: '草稿已保存',
    frozenToast: '已冻结：{id}',
    cancelledToast: '已取消：{id}',
    managerReadOnly: '管理者视角：只读（不能创建或修改策略）',
    analystHint: '分析师视角：只维护自己的策略',
    adminPanel: '评分规则（管理员）',
    rulesWeights: '权重（四者之和必须为 1）',
    rulesVersion: '规则版本',
    saveRules: '保存规则',
    rulesSaved: '规则已保存，版本 {version}（只影响之后的评价）',
    noPermission: '当前身份无权执行此操作',
    backToDashboard: '返回看板',
    cannotCancelTerminal: '已完成/已止损/已过期的策略不能取消',
    cancelOnlyActive: '只有 ACTIVE 策略可以直接取消；草稿请先冻结再取消',
    monitorRun: '监控',
    back: '返回',
    entryLine: '入场价',
    targetLine: '目标价',
    stopLine: '止损价',
    priceLine: '收盘价',
    benchmarkLine: '基准（归一化）',
    volatility: '年化波动率',
    riskReward: '盈亏比',
    analystLabel: '分析师',
    analystPerformance: '分析师绩效',
    teamPerformance: '团队绩效',
    auditEvents: '审计事件',
    strategies: '策略数',
    evaluated: '已评价',
    active: '跟踪中',
    winRate: '胜率',
    avgReturn: '平均收益',
    avgAlpha: '平均 Alpha',
    maxDrawdown: '最大回撤',
    avgScore: '平均评分',
    totalPnl: '累计盈亏',
    thAnalyst: '分析师',
    thTeam: '团队',
    thStrategies: '策略数',
    thEvaluated: '已评价',
    thActive: '跟踪中',
    thWinRate: '胜率',
    thAvgReturn: '平均收益',
    thAvgAlpha: '平均 Alpha',
    thMaxDD: '最大回撤',
    thScore: '评分',
    portfolio: '模拟盘',
    portfolioNav: '组合净值',
    portfolioReturn: '累计收益率',
    portfolioExposure: '当前敞口',
    portfolioLimit: '仓位上限',
    portfolioUnallocated: '未分配',
    portfolioOpen: '持仓中',
    portfolioClosed: '已平仓',
    portfolioEvicted: '被挤出',
    portfolioRejected: '被拒指令',
    portfolioAccounting: '会计口径',
    thLot: '手',
    thWeight: '权重',
    thOpened: '开仓日',
    thEntry: '建仓价',
    thExit: '平仓价',
    thClosed: '平仓日',
    thCloseReason: '平仓原因',
    thNavAtOpen: '建仓时净值',
    thRealizedPnl: '净值贡献',
    closeReasonStrategyTerminal: '策略终结',
    closeReasonOpposite: '反向指令',
    closeReasonEvicted: '超限挤出',
    navCurveHint: '净值曲线由确定性账本逐日盯市产出，可由 portfolio_recompute 完全重算。',
    noPortfolio: '该分析师还没有已冻结的策略，因此组合为空。',
    noMoney: '模拟盘为权重/净值式记账：只展示收益率与净值，不展示任何金额。',
    verifyPortfolio: '重算校验',
    verifyOk: '重算一致：净值曲线与持仓与落库结果逐字段相同',
    verifyFail: '重算不一致，需调查',
    thSeq: '序号',
    thAt: '时间',
    thEvent: '事件',
    thStrategy: '策略',
    thActor: '操作者',
    thTicker: '标的',
    thAction: '方向',
    thStatus: '状态',
    thReturn: '收益',
    thBenchmark: '基准',
    thAlpha: 'Alpha',
    thTarget: '目标价',
    thStop: '止损',
    strategyHistory: '策略历史',
    performance: '表现',
    replay: 'Replay',
    report: '报告',
    strategySection: '策略',
    originalStrategy: '原始策略',
    actualPerformance: '实际表现',
    result: '结果',
    riskMetrics: '风险指标',
    strategyId: '策略 ID',
    submitted: '提交时间',
    frozenAt: '冻结时间',
    benchmark: '对比基准',
    positionBefore: '提交前仓位',
    quantity: '数量',
    entry: '入场价',
    target: '目标价',
    stop: '止损价',
    holdingPeriod: '预期持仓',
    snapshotPrice: '快照价格',
    snapshotVolume: '快照成交量',
    snapshotAt: '快照时间',
    entryExit: '入场 → 退出',
    returnPct: '策略收益',
    alpha: '超额收益',
    pnl: '盈亏金额',
    holdingDays: '持仓交易日',
    exitReason: '退出原因',
    targetOutcome: '目标价',
    stopOutcome: '止损',
    benchmarkOutcome: '对比基准',
    calculation: '评分公式',
    entryPrice: '入场',
    exitPrice: '退出',
    days: '个交易日',
    reached: '已达目标价',
    notReached: '未达到',
    triggered: '已触发',
    notTriggered: '未触发',
    outperformed: '跑赢基准',
    underperformed: '跑输基准',
    inLine: '与基准持平',
    analystReasoning: '分析师原始理由（提交时的原文，永不被改写）',
    priceTimeline: '价格走势',
    lifecycleEvents: '生命周期事件',
    auditAnswers: '审计问答',
    q1: '谁提交的',
    q2: '什么时间提交',
    q3: '当时价格',
    q4: '当时仓位',
    q5: '为什么买/卖',
    q6: '后续价格变化',
    q7: '是否触发目标',
    q8: '是否触发止损',
    q9: '最终收益',
    q10: 'Benchmark 表现',
    q11: '最终评分',
    replayConsistent: 'Replay 一致性',
    monitor: '运行监控',
    runEvaluation: '执行评价',
    advance: '推进 1 天',
    reset: '重置 Demo',
    loading: '加载中…',
    notEvaluated: '尚未评价',
    scoreBreakdown: '评分构成',
    factsFooter: '所有数值由确定性 Evaluation Engine 计算，可重复验证；策略冻结后核心决策字段不可修改；行情不可越过数据上界。',
    tradesDays: '个交易日',
    monitorResult: '监控完成 @ {asOf}\n监控 {monitored} 条，更新 {changed} 条\n止损 {stopped}，完成 {completed}',
    advanceResult: '模拟时钟 → {now}\n行情上界 → {boundary}\n监控 {monitored} 条，更新 {changed} 条',
    resetConfirm: '清空并重新灌入 Demo 数据？',
    resetDone: '已重置：{strategies} 条策略，{evaluations} 条评价',
    rulesLabel: '评分规则',
    clockLabel: '模拟时钟',
    boundaryLabel: '行情上界',
    storageLabel: '存储',
    filterTicker: '标的 / 策略 ID',
    filterStatus: '状态',
    filterAction: '方向',
    allStatuses: '全部状态',
    allActions: '全部方向',
    clearFilters: '清除筛选',
    showingCount: '显示 {shown} / {total} 条',
    noMatches: '没有符合条件的策略',
    noData: '暂无数据',
    retry: '重试',
    errorTitle: '加载失败',
    entryLine: '入场价',
    targetLine: '目标价',
    stopLine: '止损价',
    priceLine: '收盘价',
    benchmarkLine: '基准（归一化）',
    targetHitAt: '达标点',
    stopHitAt: '止损点',
    sortHint: '点击表头排序',
    keyMetrics: '关键指标',
    exitOn: '退出日',
    plannedHolding: '预期持仓',
    actualHolding: '实际持仓',
    scoreOf: '{score} / 100',
    weight: '权重',
    emptyStrategies: '该分析师暂无策略',
    sessionLabel: '会话',
  },
  en: {
    tab: 'Strategy Evaluation',
    appTitle: 'Trading Strategy Evaluation',
    dashboard: 'Manager Dashboard',
    role: 'Role',
    language: 'Language',
    theme: 'Theme',
    themeAuto: 'Auto',
    themeLight: 'Light',
    themeDark: 'Dark',
    teamDetail: 'Team Detail',
    teamSummary: 'Team Summary',
    byAnalyst: 'Grouped by Analyst',
    allTeams: 'All teams',
    unknownTeam: 'Unknown team',
    analystCount: 'Analysts',
    noStrategiesInTeam: 'This team has no strategies yet',
    viewTeam: 'View team detail',
    strategiesOf: 'Strategies of {name}',
    noStrategiesForMember: 'No strategies for this member yet',
    identity: 'Identity',
    actingAs: 'Acting as',
    analystSelf: 'Analyst',
    newStrategy: 'New Strategy',
    editStrategy: 'Edit Strategy',
    myStrategies: 'My Strategies',
    saveDraft: 'Save as Draft',
    submitAndFreeze: 'Submit & Freeze',
    freezeStrategy: 'Freeze',
    cancelStrategy: 'Cancel Strategy',
    cancelReason: 'Cancel reason',
    confirmCancel: 'Cancel this strategy?',
    fieldTicker: 'Ticker',
    fieldAction: 'Action',
    fieldEntry: 'Entry price',
    fieldTarget: 'Target price',
    fieldStop: 'Stop loss',
    fieldHolding: 'Holding period (trading days)',
    fieldBenchmark: 'Benchmark',
    fieldQuantity: 'Quantity',
    fieldPositionBefore: 'Position before',
    fieldReason: 'Strategy rationale',
    useCurrentPrice: 'Use current price',
    currentPrice: 'Current price',
    snapshotHint: 'A market snapshot is captured at submission and frozen into the strategy for later audit.',
    invalidBuy: 'BUY requires: stop < entry < target',
    invalidSell: 'SELL requires: target < entry < stop',
    requiredFields: 'Please fill in every required field',
    draftHint: 'Drafts stay editable; once frozen, the core decision fields can never change.',
    createdFrozen: 'Submitted and frozen: {id}',
    createdDraft: 'Saved as draft: {id}',
    savedDraft: 'Draft saved',
    frozenToast: 'Frozen: {id}',
    cancelledToast: 'Cancelled: {id}',
    managerReadOnly: 'Manager view: read-only (cannot create or modify strategies)',
    analystHint: 'Analyst view: maintain your own strategies only',
    adminPanel: 'Scoring Rules (admin)',
    rulesWeights: 'Weights (must sum to 1)',
    rulesVersion: 'Rules version',
    saveRules: 'Save rules',
    rulesSaved: 'Rules saved, version {version} (affects future evaluations only)',
    noPermission: 'Your current role cannot perform this action',
    backToDashboard: 'Back to dashboard',
    cannotCancelTerminal: 'Completed / stopped / expired strategies cannot be cancelled',
    cancelOnlyActive: 'Only ACTIVE strategies can be cancelled directly; freeze a draft first',
    monitorRun: 'Monitor',
    back: 'Back',
    entryLine: 'Entry',
    targetLine: 'Target',
    stopLine: 'Stop',
    priceLine: 'Close',
    benchmarkLine: 'Benchmark (normalized)',
    volatility: 'Volatility (annualized)',
    riskReward: 'Risk/Reward',
    analystLabel: 'Analyst',
    analystPerformance: 'Analyst Performance',
    teamPerformance: 'Team Performance',
    auditEvents: 'Audit Events',
    strategies: 'Strategies',
    evaluated: 'Evaluated',
    active: 'Active',
    winRate: 'Win Rate',
    avgReturn: 'Avg Return',
    avgAlpha: 'Avg Alpha',
    maxDrawdown: 'Max Drawdown',
    avgScore: 'Avg Score',
    totalPnl: 'Total P&L',
    thAnalyst: 'Analyst',
    thTeam: 'Team',
    thStrategies: 'Strategies',
    thEvaluated: 'Evaluated',
    thActive: 'Active',
    thWinRate: 'Win Rate',
    thAvgReturn: 'Avg Return',
    thAvgAlpha: 'Avg Alpha',
    thMaxDD: 'Max DD',
    thScore: 'Score',
    portfolio: 'Simulated Book',
    portfolioNav: 'Portfolio NAV',
    portfolioReturn: 'Total Return',
    portfolioExposure: 'Exposure',
    portfolioLimit: 'Position Limit',
    portfolioUnallocated: 'Unallocated',
    portfolioOpen: 'Open',
    portfolioClosed: 'Closed',
    portfolioEvicted: 'Evicted',
    portfolioRejected: 'Rejected',
    portfolioAccounting: 'Accounting',
    thLot: 'Lot',
    thWeight: 'Weight',
    thOpened: 'Opened',
    thEntry: 'Entry',
    thExit: 'Exit',
    thClosed: 'Closed',
    thCloseReason: 'Close Reason',
    thNavAtOpen: 'NAV at Open',
    thRealizedPnl: 'NAV Impact',
    closeReasonStrategyTerminal: 'Strategy ended',
    closeReasonOpposite: 'Opposite instruction',
    closeReasonEvicted: 'Evicted (limit)',
    navCurveHint: 'The NAV curve is produced by the deterministic ledger and can be fully recomputed by portfolio_recompute.',
    noPortfolio: 'This analyst has no frozen strategy yet, so the book is empty.',
    noMoney: 'Weight/net-value accounting: returns and NAV only, never any currency amount.',
    verifyPortfolio: 'Recompute',
    verifyOk: 'Recompute matches: NAV curve and positions are field-by-field identical to the stored snapshot',
    verifyFail: 'Recompute mismatch — must be investigated',
    thSeq: 'Seq',
    thAt: 'At',
    thEvent: 'Event',
    thStrategy: 'Strategy',
    thActor: 'Actor',
    thTicker: 'Ticker',
    thAction: 'Action',
    thStatus: 'Status',
    thReturn: 'Return',
    thBenchmark: 'Benchmark',
    thAlpha: 'Alpha',
    thTarget: 'Target',
    thStop: 'Stop',
    strategyHistory: 'Strategy History',
    performance: 'Performance',
    replay: 'Replay',
    report: 'Report',
    strategySection: 'Strategy',
    originalStrategy: 'Original Strategy',
    actualPerformance: 'Actual Performance',
    result: 'Result',
    riskMetrics: 'Risk Metrics',
    strategyId: 'Strategy ID',
    submitted: 'Submitted',
    frozenAt: 'Frozen at',
    benchmark: 'Benchmark',
    positionBefore: 'Position Before',
    quantity: 'Quantity',
    entry: 'Entry',
    target: 'Target',
    stop: 'Stop',
    holdingPeriod: 'Holding Period',
    snapshotPrice: 'Snapshot Price',
    snapshotVolume: 'Snapshot Volume',
    snapshotAt: 'Snapshot At',
    entryExit: 'Entry → Exit',
    returnPct: 'Return',
    alpha: 'Alpha',
    pnl: 'P&L',
    holdingDays: 'Holding Days',
    exitReason: 'Exit Reason',
    targetOutcome: 'Target',
    stopOutcome: 'Stop Loss',
    benchmarkOutcome: 'Benchmark',
    calculation: 'Calculation',
    entryPrice: 'Entry',
    exitPrice: 'Exit',
    days: 'days',
    reached: 'Reached',
    notReached: 'Not Reached',
    triggered: 'Triggered',
    notTriggered: 'Not Triggered',
    outperformed: 'Outperformed',
    underperformed: 'Underperformed',
    inLine: 'In Line',
    analystReasoning: 'Analyst Reasoning (as submitted, never rewritten)',
    priceTimeline: 'Price Timeline',
    lifecycleEvents: 'Lifecycle Events',
    auditAnswers: 'Audit Answers',
    q1: 'Who submitted',
    q2: 'Submitted at',
    q3: 'Price at submission',
    q4: 'Position before',
    q5: 'Rationale',
    q6: 'Price evolution',
    q7: 'Target reached',
    q8: 'Stop loss triggered',
    q9: 'Strategy return',
    q10: 'Benchmark performance',
    q11: 'Final score',
    replayConsistent: 'Replay consistency',
    monitor: 'Run Monitor',
    runEvaluation: 'Run Evaluation',
    advance: 'Advance 1 Day',
    reset: 'Reset Demo',
    loading: 'loading…',
    notEvaluated: 'Not evaluated yet',
    scoreBreakdown: 'Score breakdown',
    factsFooter: 'All metrics are computed by the deterministic Evaluation Engine and are reproducible; a frozen strategy never changes its core decision fields; market data never crosses the data boundary.',
    tradesDays: 'trading days',
    monitorResult: 'Monitor run @ {asOf}\nmonitored {monitored}, changed {changed}\nstopped {stopped}, completed {completed}',
    advanceResult: 'Clock → {now}\nData boundary → {boundary}\nmonitored {monitored}, changed {changed}',
    resetConfirm: 'Reset and re-seed the demo data?',
    resetDone: 'Reset: {strategies} strategies, {evaluations} evaluations',
    rulesLabel: 'Rules',
    clockLabel: 'Clock',
    boundaryLabel: 'Boundary',
    storageLabel: 'Storage',
    filterTicker: 'Ticker / Strategy ID',
    filterStatus: 'Status',
    filterAction: 'Action',
    allStatuses: 'All statuses',
    allActions: 'All actions',
    clearFilters: 'Clear filters',
    showingCount: 'Showing {shown} / {total}',
    noMatches: 'No strategies match the filters',
    noData: 'No data',
    retry: 'Retry',
    errorTitle: 'Failed to load',
    entryLine: 'Entry',
    targetLine: 'Target',
    stopLine: 'Stop',
    priceLine: 'Close',
    benchmarkLine: 'Benchmark (normalized)',
    targetHitAt: 'Target hit',
    stopHitAt: 'Stop hit',
    sortHint: 'Click a header to sort',
    keyMetrics: 'Key metrics',
    exitOn: 'Exit date',
    plannedHolding: 'Planned holding',
    actualHolding: 'Actual holding',
    scoreOf: '{score} / 100',
    weight: 'Weight',
    emptyStrategies: 'This analyst has no strategies yet',
    sessionLabel: 'Session',
  },
}

const LANGUAGES = [{ id: 'zh', label: '中文' }, { id: 'en', label: 'English' }]
const THEMES = ['auto', 'light', 'dark']

const IDENTITY_KEY = 'trade-eval-identity'

const state = {
  view: { name: 'dashboard' },
  stack: [],
  role: 'MANAGER',
  // 当前"身份"：ANALYST 需要指明是哪个分析师（Demo 没有真实登录，所以显式选择；
  // 权限仍然全部在服务端强制，前端只负责不显示不该有的入口）
  actorId: 'john',
  analysts: [],
  universe: null,
  capabilities: null,
  rules: null,
  language: readStored(LANG_KEY, () => ((navigator.language ?? '').toLowerCase().startsWith('en') ? 'en' : 'zh')),
  theme: readStored(THEME_KEY, () => 'auto'),
  sort: {},
  filters: {},
  meta: null,
}

/** 当前身份持久化（角色 + 分析师），刷新后保持。 */
function loadIdentity() {
  try {
    const raw = JSON.parse(globalThis.localStorage?.getItem(IDENTITY_KEY) ?? 'null')
    if (raw !== null && typeof raw === 'object') {
      if (['ANALYST', 'MANAGER', 'ADMIN'].includes(raw.role)) state.role = raw.role
      if (typeof raw.actorId === 'string' && raw.actorId.length > 0) state.actorId = raw.actorId
    }
  } catch {
    /* 存储损坏时用默认身份 */
  }
}

function saveIdentity() {
  globalThis.localStorage?.setItem(IDENTITY_KEY, JSON.stringify({ role: state.role, actorId: state.actorId }))
}

/** 能力判定：由服务端的能力矩阵驱动，前端不硬编码角色名。 */
function can(capability) {
  return state.capabilities?.[capability]?.includes(state.role) === true
}

function readStored(key, fallback) {
  const stored = globalThis.localStorage?.getItem(key)
  if (typeof stored === 'string' && stored.length > 0) return stored
  return fallback()
}

// ── 文案与主题 ────────────────────────────────────────────────────────────
function t(key, params) {
  const template = DICT[state.language]?.[key] ?? DICT.zh[key] ?? key
  if (!params) return template
  return String(template).replace(/\{(\w+)\}/g, (match, name) => (name in params ? String(params[name]) : match))
}

function resolveTheme(mode) {
  if (mode !== 'auto') return mode
  // ⚠️ 必须写成 `matchMedia?.(...)?.matches`：原写法 `matchMedia?.(...).matches`
  // 在 matchMedia 不存在时（旧浏览器 / jsdom）会因为可选链只保护了函数调用、
  // 却继续读取 undefined 的属性而抛 TypeError。主题解析不该让整页崩掉。
  return globalThis.matchMedia?.('(prefers-color-scheme: light)')?.matches === true ? 'light' : 'dark'
}

const THEME_LABEL_KEY = { auto: 'themeAuto', light: 'themeLight', dark: 'themeDark' }

function applyTheme() {
  document.documentElement.dataset.theme = resolveTheme(state.theme)
  for (const button of document.querySelectorAll('#theme button')) {
    button.classList.toggle('on', button.dataset.theme === state.theme)
    button.textContent = t(THEME_LABEL_KEY[button.dataset.theme])
  }
}

function setTheme(mode) {
  state.theme = mode
  globalThis.localStorage?.setItem(THEME_KEY, mode)
  applyTheme()
}

/** 顶栏与静态文案随语言刷新。 */
function refreshStaticText() {
  document.documentElement.lang = state.language === 'en' ? 'en' : 'zh-CN'
  document.title = state.language === 'en'
    ? 'Trading Strategy Evaluation — Manager Dashboard'
    : '交易策略评估 — Manager Dashboard'
  document.getElementById('app-title').textContent = t('appTitle')
  document.getElementById('identity-label').textContent = t('identity')
  document.getElementById('analyst-label').textContent = t('analystSelf')
  const newButton = document.getElementById('new-strategy')
  newButton.textContent = t('newStrategy')
  newButton.hidden = !can('strategy.create')
  newButton.disabled = !can('strategy.create')
  const picker = document.getElementById('analyst-picker')
  picker.hidden = state.role !== 'ANALYST'
  if (state.role === 'ANALYST') {
    const select = document.getElementById('analyst')
    if (select.options.length !== state.analysts.length) {
      select.replaceChildren(...state.analysts.map((a) => el('option', { value: a.analyst_id }, `${a.name} (${a.analyst_id})`)))
    }
    select.value = state.actorId
  }
  document.getElementById('monitor').textContent = t('monitor')
  document.getElementById('advance').textContent = t('advance')
  document.getElementById('reset').textContent = t('reset')
  document.getElementById('lang').setAttribute('aria-label', t('language'))
  document.getElementById('theme').setAttribute('aria-label', t('theme'))
  for (const button of document.querySelectorAll('#lang button')) {
    button.classList.toggle('on', button.dataset.lang === state.language)
  }
  document.getElementById('clock').textContent = state.meta === null ? t('loading') : clockText()
}

/** 角色/身份变化后刷新顶栏按钮的显隐与文案。 */
function refreshIdentityUi() {
  refreshStaticText()
}

function setLanguage(id) {
  state.language = id
  globalThis.localStorage?.setItem(LANG_KEY, id)
  applyTheme()
  refreshStaticText()
  render()
}

function clockText() {
  const meta = state.meta
  return `${t('storageLabel')}=${meta.storage.driver} · ${t('rulesLabel')}=${meta.rules_version} · ${t('clockLabel')}=${meta.clock.now} · ${t('boundaryLabel')}=${meta.market.boundary} · ${meta.market.provider}`
}

// ── 路由（hash：可深链 / 可刷新 / 前进后退可用）───────────────────────────
function toHash(view) {
  if (view.name === 'new') return '#/new'
  if (view.name === 'edit') return `#/strategy/${encodeURIComponent(view.strategyId)}/edit`
  if (view.name === 'team') return `#/team/${encodeURIComponent(view.team)}`
  if (view.name === 'analyst') return `#/analyst/${encodeURIComponent(view.id)}`
  if (view.name === 'portfolio') return `#/portfolio/${encodeURIComponent(view.id)}`
  if (view.name === 'strategy') return `#/strategy/${encodeURIComponent(view.strategyId)}/${view.tab ?? 'performance'}`
  return '#/'
}

function parseHash() {
  const parts = location.hash.replace(/^#\/?/, '').split('/').filter((part) => part.length > 0)
  if (parts[0] === 'new') return { name: 'new' }
  if (parts[0] === 'team' && parts[1] !== undefined) return { name: 'team', team: decodeURIComponent(parts[1]) }
  if (parts[0] === 'strategy' && parts[1] !== undefined && parts[2] === 'edit') {
    return { name: 'edit', strategyId: decodeURIComponent(parts[1]) }
  }
  if (parts[0] === 'analyst' && parts[1] !== undefined) return { name: 'analyst', id: decodeURIComponent(parts[1]) }
  if (parts[0] === 'portfolio' && parts[1] !== undefined) return { name: 'portfolio', id: decodeURIComponent(parts[1]) }
  if (parts[0] === 'strategy' && parts[1] !== undefined) {
    return { name: 'strategy', strategyId: decodeURIComponent(parts[1]), tab: parts[2] ?? 'performance' }
  }
  return { name: 'dashboard' }
}

function go(view, { push = true } = {}) {
  if (push && toHash(state.view) !== toHash(view)) state.stack.push({ ...state.view })
  state.view = view
  if (location.hash !== toHash(view)) location.hash = toHash(view)
  render()
}

function goBack() {
  const previous = state.stack.pop()
  go(previous ?? { name: 'dashboard' }, { push: false })
}

function canGoBack() {
  return state.stack.length > 0
}

globalThis.addEventListener('hashchange', () => {
  const next = parseHash()
  if (toHash(next) !== toHash(state.view)) {
    state.view = next
    render()
  }
})

globalThis.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && canGoBack()) {
    event.preventDefault()
    goBack()
  }
})

// ── API ───────────────────────────────────────────────────────────────────
function actor() {
  return { actor_id: state.role === 'ANALYST' ? state.actorId : `demo_${state.role.toLowerCase()}`, role: state.role }
}

async function api(path, options = {}) {
  const url = new URL(`${API}${path}`, location.origin)
  for (const [key, value] of Object.entries(options.query ?? {})) {
    if (value !== undefined && value !== null) url.searchParams.set(key, String(value))
  }
  const response = await fetch(url, {
    method: options.method ?? 'GET',
    headers: {
      'content-type': 'application/json',
      // 报告由服务端按语言渲染，这里把语言点发过去
      'accept-language': state.language,
      'x-actor-role': state.role,
      'x-actor-id': actor().actor_id,
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  })
  const payload = await response.json().catch(() => null)
  if (!response.ok || payload?.ok === false) {
    const error = new Error(payload?.error?.message ?? `HTTP ${response.status}`)
    error.code = payload?.error?.code ?? `HTTP_${response.status}`
    error.details = payload?.error?.details
    throw error
  }
  return payload
}

// ── 格式化 ────────────────────────────────────────────────────────────────
//
// 这四个函数与 src/core/report/format.js 是**同一套语义的页面副本**：
//   pct  signed      有方向的量（收益 / Alpha / 基准收益）—— 正数带 `+`
//   mag  magnitude   幅度量（波动率 / 胜率 / 回撤 / 达成率）—— **不加 `+`**
//   pts  score       评分 —— 0-100 的普通数，不是百分比、不补零
//   num  number/money 无量纲数 / 金额 —— 固定小数位 + 千分位
//
// 曾经只有 `pct`，于是波动率被印成 `+40.7%`、胜率被印成 `+50.0%`
// —— 幅度量带上方向号，读起来像"正向收益"。
// 「两份实现不许漂移」由 tests/integration/metric-format-parity.test.js 逐值比对保证。
const langTag = () => (state.language === 'en' ? 'en-US' : 'zh-CN')
const pct = (value, decimals = 2) => (typeof value === 'number' && Number.isFinite(value)
  ? `${value > 0 ? '+' : ''}${(value * 100).toFixed(decimals)}%`
  : '—')
const mag = (value, decimals = 2) => (typeof value === 'number' && Number.isFinite(value)
  ? `${(value * 100).toFixed(decimals)}%`
  : '—')
const pts = (value, decimals = 2) => (typeof value === 'number' && Number.isFinite(value)
  ? value.toLocaleString(langTag(), { minimumFractionDigits: 0, maximumFractionDigits: decimals })
  : '—')
const num = (value, decimals = 2) => (typeof value === 'number' && Number.isFinite(value)
  ? value.toLocaleString(langTag(), { minimumFractionDigits: decimals, maximumFractionDigits: decimals })
  : '—')
const cls = (value) => (typeof value === 'number' && Number.isFinite(value) ? (value > 0 ? 'pos' : value < 0 ? 'neg' : '') : '')
const dirClass = (action) => (action === 'BUY' ? 'BUY' : 'SELL')

// ── DOM 工具 ──────────────────────────────────────────────────────────────
function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag)
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue
    if (key === 'html') node.innerHTML = value
    else if (key === 'class') node.className = value
    else if (key === 'text') node.textContent = value
    else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value)
    else if (value === true) node.setAttribute(key, '')
    else node.setAttribute(key, String(value))
  }
  for (const child of children.flat()) {
    if (child === undefined || child === null || child === false) continue
    node.append(child instanceof Node ? child : document.createTextNode(String(child)))
  }
  return node
}

function card(key, value, klass = '') {
  return el('div', { class: `card ${klass}` },
    el('div', { class: 'k' }, key),
    el('div', { class: 'v' }, value),
    el('div', { class: 'bar' }))
}

function kv(title, rows) {
  return el('div', { class: 'kv' },
    title.length === 0 ? null : el('h3', {}, title),
    el('dl', {}, rows.flatMap(([key, value, klass]) => [
      el('dt', {}, key),
      el('dd', { class: klass ?? '' }, value),
    ])))
}

function skeleton() {
  const wrap = el('div', { 'aria-busy': 'true', 'aria-live': 'polite' })
  wrap.append(el('div', { class: 'sk sk-title' }),
    ...[0, 1].map(() => el('div', { class: 'sk sk-card' })),
    ...[0, 1, 2, 3, 4, 5].map(() => el('div', { class: 'sk sk-row' })))
  return wrap
}

function errorCard(error, retry) {
  return el('div', { class: 'err', role: 'alert' },
    el('div', { class: 'msg' },
      el('strong', {}, `${t('errorTitle')} · ${error.code ?? 'ERROR'}`),
      el('div', {}, error.message)),
    retry === undefined ? null : el('button', { class: 'primary', onClick: retry }, t('retry')))
}

function emptyBox(message) {
  return el('div', { class: 'empty' }, message)
}

/**
 * 排序表。表头可点、带方向箭头；行可用键盘打开（Enter / Space）。
 * @param {{id: string, columns: Array<object>, rows: Array<object>, onOpen?: Function, emptyText?: string}} spec
 */
function sortableTable(spec) {
  const sort = state.sort[spec.id] ?? { key: null, dir: 'desc' }
  const sorted = [...spec.rows]
  if (sort.key !== null) {
    const column = spec.columns.find((item) => item.key === sort.key)
    if (column !== undefined) {
      sorted.sort((left, right) => {
        const a = column.get(left)
        const b = column.get(right)
        if (a === b) return 0
        if (a === null || a === undefined) return 1
        if (b === null || b === undefined) return -1
        const comparison = typeof a === 'number' && typeof b === 'number' ? a - b : String(a).localeCompare(String(b))
        return sort.dir === 'asc' ? comparison : -comparison
      })
    }
  }

  const header = el('tr', {}, spec.columns.map((column) => {
    const sortable = column.sortable !== false
    const active = sort.key === column.key
    return el('th', {
      class: `${column.numeric === true ? 'num ' : ''}${sortable ? '' : 'nosort'}`,
      title: sortable ? t('sortHint') : undefined,
      'aria-sort': active ? (sort.dir === 'asc' ? 'ascending' : 'descending') : 'none',
      onClick: sortable
        ? () => {
          state.sort[spec.id] = { key: column.key, dir: active && sort.dir === 'desc' ? 'asc' : 'desc' }
          render()
        }
        : undefined,
    }, column.label, active ? el('span', { class: 'arrow' }, sort.dir === 'asc' ? '▲' : '▼') : null)
  }))

  const body = sorted.map((row) => {
    const open = spec.onOpen === undefined ? undefined : () => spec.onOpen(row)
    return el('tr', {
      tabindex: open === undefined ? undefined : '0',
      onClick: open,
      onKeydown: open === undefined ? undefined : (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault()
          open()
        }
      },
    }, spec.columns.map((column) => el('td', { class: column.numeric === true ? 'num' : '' },
      column.render === undefined ? column.get(row) : column.render(row))))
  })

  if (body.length === 0) return emptyBox(spec.emptyText ?? t('noData'))
  return el('div', { class: 'tablewrap' },
    el('table', {}, el('thead', {}, header), el('tbody', {}, body)))
}

// ── 图表与评分环 ──────────────────────────────────────────────────────────
/**
 * 价格走势 SVG：收盘价折线 + 入场/目标/止损参考线 + 达标/止损触发点 + 基准归一化对照。
 * 纯手写 SVG，不引入任何图表库。
 */
function priceChart(replay, original, rules) {
  const steps = replay.price_steps
  if (steps.length === 0) return emptyBox(t('noData'))

  const width = 900
  const height = 200
  const pad = { left: 48, right: 14, top: 12, bottom: 22 }
  const prices = steps.map((row) => row.price)
  const bench = replay.benchmark_steps ?? []
  // 基准以同一入场价为基准归一化，才能与价格画在同一坐标系里比较
  const benchNorm = bench.length === prices.length ? bench.map((row) => (row.price / bench[0].price) * prices[0]) : []
  const all = [...prices, ...benchNorm, original.entry_price, original.target_price, original.stop_loss]
  const min = Math.min(...all)
  const max = Math.max(...all)
  const span = Math.max(max - min, 1e-6)
  const x = (index) => pad.left + (index / Math.max(steps.length - 1, 1)) * (width - pad.left - pad.right)
  const y = (value) => pad.top + (1 - (value - min) / span) * (height - pad.top - pad.bottom)
  const path = (values) => values.map((value, index) => `${index === 0 ? 'M' : 'L'}${x(index).toFixed(1)},${y(value).toFixed(1)}`).join(' ')

  const svg = []
  for (const ratio of [0, 0.25, 0.5, 0.75, 1]) {
    const value = min + span * ratio
    svg.push(`<line x1="${pad.left}" x2="${width - pad.right}" y1="${y(value).toFixed(1)}" y2="${y(value).toFixed(1)}" stroke="var(--line)" stroke-width="1" stroke-dasharray="${ratio === 0 || ratio === 1 ? '0' : '3 4'}"/>`)
    svg.push(`<text x="${pad.left - 6}" y="${(y(value) + 3).toFixed(1)}" fill="var(--text-faint)" font-size="10" text-anchor="end" font-family="var(--mono)">${value.toFixed(2)}</text>`)
  }

  for (const ref of [
    { value: original.target_price, color: 'var(--good)', label: t('targetLine') },
    { value: original.entry_price, color: 'var(--accent)', label: t('entryLine') },
    { value: original.stop_loss, color: 'var(--bad)', label: t('stopLine') },
  ]) {
    svg.push(`<line x1="${pad.left}" x2="${width - pad.right}" y1="${y(ref.value).toFixed(1)}" y2="${y(ref.value).toFixed(1)}" stroke="${ref.color}" stroke-width="1" stroke-dasharray="5 4" opacity=".8"/>`)
    svg.push(`<text x="${width - pad.right}" y="${(y(ref.value) - 4).toFixed(1)}" fill="${ref.color}" font-size="10" text-anchor="end" font-family="var(--mono)">${ref.label} ${ref.value.toFixed(2)}</text>`)
  }

  if (benchNorm.length === prices.length) {
    svg.push(`<path d="${path(benchNorm)}" fill="none" stroke="var(--text-faint)" stroke-width="1.4" stroke-dasharray="4 3" opacity=".85"/>`)
  }
  svg.push(`<path d="${path(prices)}" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linejoin="round"/>`)

  const marker = (date, kind) => {
    if (typeof date !== 'string') return ''
    const index = steps.findIndex((row) => row.date === date)
    if (index < 0) return ''
    const color = kind === 'target' ? 'var(--good)' : 'var(--bad)'
    return `<circle cx="${x(index).toFixed(1)}" cy="${y(prices[index]).toFixed(1)}" r="4" fill="${color}" stroke="var(--panel)" stroke-width="1.5"/>`
  }
  svg.push(marker(rules?.target_reached_on, 'target'))
  svg.push(marker(rules?.stop_loss_triggered_on, 'stop'))
  svg.push(`<text x="${pad.left}" y="${height - 6}" fill="var(--text-faint)" font-size="10" font-family="var(--mono)">${steps[0].date}</text>`)
  svg.push(`<text x="${width - pad.right}" y="${height - 6}" fill="var(--text-faint)" font-size="10" text-anchor="end" font-family="var(--mono)">${steps.at(-1).date}</text>`)

  const legend = [
    [t('priceLine'), 'var(--accent)'],
    [t('entryLine'), 'var(--accent)'],
    [t('targetLine'), 'var(--good)'],
    [t('stopLine'), 'var(--bad)'],
    benchNorm.length === prices.length ? [t('benchmarkLine'), 'var(--text-faint)'] : null,
    rules?.target_reached ? [t('targetHitAt'), 'var(--good)'] : null,
    rules?.stop_loss_triggered ? [t('stopHitAt'), 'var(--bad)'] : null,
  ].filter((row) => row !== null)

  return el('div', { class: 'chart' },
    el('div', { html: `<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" role="img" aria-label="${t('priceTimeline')}">${svg.join('')}</svg>` }),
    el('div', { class: 'legend' }, legend.map(([label, color]) => el('span', {}, el('i', { style: `background:${color}` }), label))))
}

/** 评分环 + 分项条形分解。 */
function scorePanel(score) {
  if (score === null || score === undefined) return el('div', { class: 'note' }, t('notEvaluated'))
  const total = score.total
  const radius = 26
  const circumference = 2 * Math.PI * radius
  const filled = (Math.max(0, Math.min(100, total)) / 100) * circumference
  const color = total >= 70 ? 'var(--good)' : total >= 45 ? 'var(--accent)' : 'var(--bad)'
  const ring = `<svg class="ring" width="72" height="72" viewBox="0 0 72 72" role="img" aria-label="${t('thScore')} ${Math.round(total)}">
      <circle cx="36" cy="36" r="${radius}" fill="none" stroke="var(--panel-2)" stroke-width="7"/>
      <circle cx="36" cy="36" r="${radius}" fill="none" stroke="${color}" stroke-width="7" stroke-linecap="round"
        stroke-dasharray="${filled.toFixed(1)} ${(circumference - filled).toFixed(1)}" transform="rotate(-90 36 36)"/>
      <text x="36" y="41" text-anchor="middle" font-size="17" font-weight="650" fill="var(--text)" font-family="var(--mono)">${Math.round(total)}</text>
    </svg>`

  return el('div', { class: 'scorewrap' },
    el('div', { html: ring }),
    el('div', { class: 'bars' },
      Object.entries(score.components).map(([key, value]) => el('div', { class: 'row' },
        el('span', { class: 'muted' }, key),
        el('div', { class: 'track' }, el('div', { class: 'fill', style: `width:${Math.max(0, Math.min(100, value)).toFixed(1)}%` })),
        el('span', { class: 'val' }, `${pts(value, 0)}×${score.weights[key]}`))),
      el('div', { class: 'note' }, `${t('calculation')}: ${score.calculation_version}`)))
}

// ── Markdown → 可读排版（服务端输出受信任，但仍先转义再解析）──────────────
function escapeHtml(text) {
  return String(text).replace(/[&<>"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[char]))
}

function renderMarkdown(markdown) {
  const lines = escapeHtml(markdown).split('\n')
  const out = []
  let inList = false
  let inTable = false
  const closeList = () => { if (inList) { out.push('</ul>'); inList = false } }
  const closeTable = () => { if (inTable) { out.push('</tbody></table>'); inTable = false } }

  for (const line of lines) {
    if (/^\|\s*-{2,}/.test(line)) continue                              // 表格分隔行
    if (/^\|/.test(line)) {
      const cells = line.split('|').slice(1, -1).map((cell) => cell.trim())
      if (!inTable) {
        closeList()
        out.push('<table><thead><tr>', cells.map((cell) => `<th>${cell}</th>`).join(''), '</tr></thead><tbody>')
        inTable = true
      } else {
        out.push('<tr>', cells.map((cell) => `<td>${cell}</td>`).join(''), '</tr>')
      }
      continue
    }
    closeTable()
    if (/^###\s/.test(line)) { closeList(); out.push(`<h3>${line.replace(/^###\s/, '')}</h3>`); continue }
    if (/^##\s/.test(line)) { closeList(); out.push(`<h2>${line.replace(/^##\s/, '')}</h2>`); continue }
    if (/^#\s/.test(line)) { closeList(); out.push(`<h1>${line.replace(/^#\s/, '')}</h1>`); continue }
    if (/^-{3,}\s*$/.test(line)) { closeList(); out.push('<hr/>'); continue }
    if (/^&gt;\s?/.test(line)) { closeList(); out.push(`<blockquote>${line.replace(/^&gt;\s?/, '')}</blockquote>`); continue }
    if (/^[-*]\s/.test(line)) {
      if (!inList) { out.push('<ul>'); inList = true }
      out.push(`<li>${line.replace(/^[-*]\s/, '')}</li>`)
      continue
    }
    closeList()
    if (line.trim().length === 0) continue
    out.push(`<p>${line.replace(/_(.+?)_/g, '<em>$1</em>')}</p>`)
  }
  closeList()
  closeTable()
  return out.join('')
}

// ── 渲染 ──────────────────────────────────────────────────────────────────
function toolbar() {
  return el('div', { class: 'toolbar' },
    el('button', {
      class: 'icon-btn ghost',
      disabled: !canGoBack(),
      onClick: goBack,
      title: `${t('back')} (Esc)`,
      'aria-label': t('back'),
    }, '← ', t('back')),
    crumbs())
}

function crumbs() {
  const parts = [el('a', { onClick: () => go({ name: 'dashboard' }) }, t('dashboard'))]
  if (state.view.name === 'team' || state.view.teamLabel !== undefined) {
    parts.push(el('span', { class: 'sep' }, '/'))
    parts.push(el('a', { onClick: () => go({ name: 'team', team: state.view.team }) }, state.view.team))
  }
  if (state.view.name === 'analyst' && state.view.teamLabel !== undefined) {
    parts.push(el('span', { class: 'sep' }, '/'))
    parts.push(el('a', { onClick: () => go({ name: 'team', team: state.view.teamLabel }) }, state.view.teamLabel))
  }
  if (state.view.name !== 'dashboard' && state.view.name !== 'team') {
    const id = state.view.name === 'analyst' ? state.view.id : state.view.analystId
    if (id !== undefined) {
      const name = state.view.analystName ?? id
      parts.push(el('span', { class: 'sep' }, '/'))
      parts.push(el('a', { onClick: () => go({ name: 'analyst', id, analystName: state.view.analystName }) }, name))
    }
  }
  if (state.view.name === 'strategy') {
    parts.push(el('span', { class: 'sep' }, '/'))
    parts.push(el('span', { class: 'leaf' }, state.view.strategyId))
  }
  if (state.view.name === 'new') {
    parts.push(el('span', { class: 'sep' }, '/'))
    parts.push(el('span', { class: 'leaf' }, t('newStrategy')))
  }
  if (state.view.name === 'edit') {
    parts.push(el('span', { class: 'sep' }, '/'))
    parts.push(el('a', { onClick: () => go({ name: 'strategy', strategyId: state.view.strategyId }) }, state.view.strategyId))
    parts.push(el('span', { class: 'sep' }, '/'))
    parts.push(el('span', { class: 'leaf' }, t('editStrategy')))
  }
  return el('nav', { class: 'crumbs', 'aria-label': 'breadcrumb' }, parts)
}

async function render() {
  const main = document.getElementById('app')
  main.replaceChildren(toolbar(), skeleton())
  try {
    main.replaceChildren(toolbar(), await view())
  } catch (error) {
    main.replaceChildren(toolbar(), errorCard(error, () => render()))
  }
  main.focus?.({ preventScroll: true })
}

async function view() {
  if (state.view.name === 'new') return renderStrategyForm({ mode: 'create' })
  if (state.view.name === 'edit') return renderStrategyForm({ mode: 'edit', strategyId: state.view.strategyId })
  if (state.view.name === 'team') return renderTeam()
  if (state.view.name === 'analyst') return renderAnalyst()
  if (state.view.name === 'portfolio') return renderPortfolio()
  if (state.view.name === 'strategy') return renderStrategy()
  return renderDashboard()
}

async function renderDashboard() {
  const { dashboard } = await api('/dashboard', { query: { role: state.role } })
  const totals = dashboard.totals
  const wrap = el('div', {})

  // 视角提示：三种角色看到的东西不同，必须让用户一眼知道自己在哪个视角
  if (state.role === 'MANAGER') wrap.append(el('div', { class: 'banner readonly' }, t('managerReadOnly')))
  if (state.role === 'ANALYST') wrap.append(el('div', { class: 'banner readonly' }, t('analystHint')))
  if (state.role === 'ADMIN') wrap.append(adminRulesPanel())

  wrap.append(el('div', { class: 'cards' },
    card(t('strategies'), totals.strategies),
    card(t('evaluated'), totals.evaluated),
    card(t('active'), totals.active),
    card(t('winRate'), mag(totals.win_rate)),
    card(t('avgReturn'), pct(totals.average_return), cls(totals.average_return)),
    card(t('avgAlpha'), pct(totals.average_alpha), cls(totals.average_alpha)),
    card(t('maxDrawdown'), mag(totals.max_drawdown), 'bad'),
    card(t('avgScore'), pts(totals.average_score))))

  if (state.role !== 'ANALYST') {
  wrap.append(el('h2', {}, t('analystPerformance'), el('span', { class: 'count' }, `(${dashboard.analysts.length})`)))
  wrap.append(sortableTable({
    id: 'analysts',
    rows: dashboard.analysts,
    onOpen: (row) => go({ name: 'analyst', id: row.analyst_id, analystName: row.name }),
    columns: [
      { key: 'name', label: t('thAnalyst'), get: (row) => row.name, render: (row) => el('span', {}, el('strong', {}, row.name), ' ', el('span', { class: 'tag' }, row.analyst_id)) },
      { key: 'team', label: t('thTeam'), get: (row) => row.team },
      { key: 'strategies', label: t('thStrategies'), numeric: true, get: (row) => row.strategies },
      { key: 'evaluated', label: t('thEvaluated'), numeric: true, get: (row) => row.evaluated },
      { key: 'active', label: t('thActive'), numeric: true, get: (row) => row.active },
      { key: 'win_rate', label: t('thWinRate'), numeric: true, get: (row) => row.win_rate, render: (row) => mag(row.win_rate) },
      { key: 'average_return', label: t('thAvgReturn'), numeric: true, get: (row) => row.average_return, render: (row) => el('span', { class: cls(row.average_return) }, pct(row.average_return)) },
      { key: 'average_alpha', label: t('thAvgAlpha'), numeric: true, get: (row) => row.average_alpha, render: (row) => el('span', { class: cls(row.average_alpha) }, pct(row.average_alpha)) },
      { key: 'max_drawdown', label: t('thMaxDD'), numeric: true, get: (row) => row.max_drawdown, render: (row) => el('span', { class: 'neg' }, mag(row.max_drawdown)) },
      { key: 'average_score', label: t('thScore'), numeric: true, get: (row) => row.average_score, render: (row) => pts(row.average_score) },
      { key: 'total_pnl', label: t('totalPnl'), numeric: true, get: (row) => row.total_pnl, render: (row) => num(row.total_pnl) },
    ],
  }))

  }

  if (state.role !== 'ANALYST') {
  wrap.append(el('h2', {}, t('teamPerformance'), el('span', { class: 'count' }, `(${dashboard.teams.length})`)))
  wrap.append(sortableTable({
    id: 'teams',
    rows: dashboard.teams,
    onOpen: (row) => go({ name: 'team', team: row.team }),
    columns: [
      { key: 'team', label: t('thTeam'), get: (row) => row.team, render: (row) => el('strong', {}, row.team) },
      { key: 'analyst_count', label: t('thAnalyst'), numeric: true, get: (row) => row.analyst_count },
      { key: 'strategies', label: t('thStrategies'), numeric: true, get: (row) => row.strategies },
      { key: 'win_rate', label: t('thWinRate'), numeric: true, get: (row) => row.win_rate, render: (row) => mag(row.win_rate) },
      { key: 'average_return', label: t('thAvgReturn'), numeric: true, get: (row) => row.average_return, render: (row) => el('span', { class: cls(row.average_return) }, pct(row.average_return)) },
      { key: 'average_alpha', label: t('thAvgAlpha'), numeric: true, get: (row) => row.average_alpha, render: (row) => el('span', { class: cls(row.average_alpha) }, pct(row.average_alpha)) },
      { key: 'max_drawdown', label: t('thMaxDD'), numeric: true, get: (row) => row.max_drawdown, render: (row) => el('span', { class: 'neg' }, mag(row.max_drawdown)) },
      { key: 'average_score', label: t('thScore'), numeric: true, get: (row) => row.average_score, render: (row) => pts(row.average_score) },
    ],
  }))

  }

  wrap.append(el('h2', {}, t('auditEvents'), el('span', { class: 'count' }, `(${dashboard.recent_events.length})`)))
  wrap.append(sortableTable({
    id: 'events',
    rows: dashboard.recent_events,
    onOpen: (row) => row.strategy_id && go({ name: 'strategy', strategyId: row.strategy_id, analystId: row.analyst_id }),
    columns: [
      { key: 'event_id', label: t('thSeq'), get: (row) => row.event_id },
      { key: 'at', label: t('thAt'), get: (row) => row.at },
      { key: 'label', label: t('thEvent'), get: (row) => row.label },
      { key: 'strategy_id', label: t('thStrategy'), get: (row) => row.strategy_id ?? '—' },
      { key: 'actor', label: t('thActor'), get: (row) => (row.actor ? `${row.actor.role}:${row.actor.actor_id}` : '—') },
    ],
  }))
  return wrap
}

/**
 * 提交 / 编辑策略表单。
 *
 * 校验规则与服务端**同源**（BUY: stop<entry<target；SELL: target<entry<stop），
 * 前端先拦是为了体验，服务端仍会再拦一次 —— 前端校验绝不是安全边界。
 */
async function renderStrategyForm({ mode, strategyId }) {
  // 界面不提供"必然失败"的入口：MANAGER 直接深链到 #/new 时也只看到说明。
  // 真正的边界仍在服务端（strategy.create 只给 ANALYST/ADMIN）。
  if (mode === 'create' && !can('strategy.create')) {
    return el('div', {},
      el('h2', {}, t('newStrategy')),
      el('div', { class: 'banner readonly' }, t('noPermission'), ' — ', t('managerReadOnly')),
      el('div', { class: 'actions' }, el('button', { class: 'ghost', onClick: () => go({ name: 'dashboard' }) }, t('backToDashboard'))))
  }
  if (state.universe === null) state.universe = await api('/market/universe')

  let existing = null
  if (mode === 'edit') {
    const payload = await api(`/strategies/${encodeURIComponent(strategyId)}`)
    existing = payload.strategy
    if (existing.frozen === true) {
      return el('div', { class: 'banner readonly' }, t('noPermission'), ' — ', existing.strategy_id, ' ', el('span', { class: 'tag' }, 'FROZEN'))
    }
  }

  const form = {
    analyst_id: existing?.analyst_id ?? (state.role === 'ANALYST' ? state.actorId : state.analysts[0]?.analyst_id ?? 'john'),
    ticker: existing?.ticker ?? state.universe.tickers[0],
    action: existing?.action ?? 'BUY',
    entry_price: existing?.entry_price ?? '',
    target_price: existing?.target_price ?? '',
    stop_loss: existing?.stop_loss ?? '',
    holding_period: existing?.holding_period ?? 20,
    quantity: existing?.quantity ?? 100,
    position_before: existing?.position_before ?? 0,
    benchmark: existing?.benchmark ?? state.universe.benchmarks[0],
    reason: existing?.reason ?? '',
  }

  const errors = el('div', {})
  const wrap = el('div', {})
  wrap.append(el('h2', {}, mode === 'create' ? t('newStrategy') : t('editStrategy')))
  wrap.append(el('div', { class: 'banner hint' }, t('snapshotHint')))
  if (mode === 'create') wrap.append(el('div', { class: 'banner hint' }, t('draftHint')))

  const field = (label, node, hint) => el('label', {}, label, node, hint === undefined ? null : el('span', { class: 'hint' }, hint))
  const numberInput = (key, step = '0.01') => el('input', {
    type: 'number', step, value: form[key],
    onInput: (event) => { form[key] = event.target.value === '' ? '' : Number(event.target.value) },
  })
  const priceTag = el('span', { class: 'pricetag' }, '')

  const refreshPrice = async () => {
    try {
      const quote = await api(`/market/quote/${encodeURIComponent(form.ticker)}`)
      priceTag.textContent = `${t('currentPrice')} ${quote.price}`
      priceTag.dataset.price = String(quote.price)
    } catch {
      priceTag.textContent = ''
    }
  }

  const row = el('div', { class: 'row' },
    state.role === 'ANALYST'
      ? field(t('analystSelf'), el('input', { value: state.actorId, readonly: true }))
      : field(t('analystSelf'), el('select', {
        onChange: (event) => { form.analyst_id = event.target.value },
      }, state.analysts.map((a) => el('option', { value: a.analyst_id, selected: a.analyst_id === form.analyst_id }, `${a.name} (${a.analyst_id})`)))),
    field(t('fieldTicker'), el('select', {
      onChange: (event) => { form.ticker = event.target.value; refreshPrice() },
    }, state.universe.tickers.map((ticker) => el('option', { value: ticker, selected: ticker === form.ticker }, ticker))), null),
    field(t('fieldAction'), el('select', {
      onChange: (event) => { form.action = event.target.value },
    }, ['BUY', 'SELL'].map((action) => el('option', { value: action, selected: action === form.action }, action)))),
    field(t('fieldEntry'), numberInput('entry_price')),
    field(t('fieldTarget'), numberInput('target_price')),
    field(t('fieldStop'), numberInput('stop_loss')),
    field(t('fieldHolding'), numberInput('holding_period', '1')),
    field(t('fieldQuantity'), numberInput('quantity', '1')),
    field(t('fieldPositionBefore'), numberInput('position_before', '1')),
    field(t('fieldBenchmark'), el('select', {
      onChange: (event) => { form.benchmark = event.target.value },
    }, state.universe.benchmarks.map((b) => el('option', { value: b, selected: b === form.benchmark }, b)))),
  )
  wrap.append(el('div', { class: 'form' },
    row,
    el('div', { class: 'inline-note', style: 'margin-top:12px' },
      el('button', {
        class: 'ghost', type: 'button',
        onClick: async () => {
          const price = Number(priceTag.dataset.price)
          if (Number.isFinite(price) && price > 0) form.entry_price = price
          const amount = Number(priceTag.dataset.price)
          if (Number.isFinite(amount) && amount > 0) {
            form.entry_price = amount
            form.target_price = form.action === 'BUY' ? Number((amount * 1.15).toFixed(2)) : Number((amount * 0.85).toFixed(2))
            form.stop_loss = form.action === 'BUY' ? Number((amount * 0.93).toFixed(2)) : Number((amount * 1.07).toFixed(2))
          }
          await load()
        },
      }, t('useCurrentPrice')),
      priceTag),
    field(t('fieldReason'), el('textarea', {
      value: form.reason,
      placeholder: t('fieldReason'),
      onInput: (event) => { form.reason = event.target.value },
    }), null),
    errors,
    el('div', { class: 'actions' },
      el('button', { class: 'ghost', type: 'button', onClick: () => goBack() }, t('back')),
      can('strategy.create') && mode === 'create'
        ? el('button', { class: 'ghost', type: 'button', onClick: () => submit(false) }, t('saveDraft'))
        : null,
      el('button', { class: 'primary', type: 'button', onClick: () => submit(true) }, mode === 'create' ? t('submitAndFreeze') : t('freezeStrategy')))))

  async function load() {
    // 只重绘价格标签，不重建表单（保留用户已填内容）
    await refreshPrice()
  }

  function localError() {
    const entry = Number(form.entry_price)
    const target = Number(form.target_price)
    const stop = Number(form.stop_loss)
    if (!(form.reason ?? '').trim()) return t('requiredFields')
    if (![entry, target, stop].every((value) => Number.isFinite(value) && value > 0)) return t('requiredFields')
    if (!Number.isInteger(Number(form.holding_period)) || Number(form.holding_period) < 1) return t('requiredFields')
    if (form.action === 'BUY' && !(stop < entry && target > entry)) return t('invalidBuy')
    if (form.action === 'SELL' && !(target < entry && stop > entry)) return t('invalidSell')
    return null
  }

  async function submit(freeze) {
    const problem = localError()
    if (problem !== null) {
      errors.replaceChildren(el('div', { class: 'err', role: 'alert' }, el('div', { class: 'msg' }, problem)))
      return
    }
    const body = {
      ...form,
      holding_period: Number(form.holding_period),
      quantity: Number(form.quantity),
      position_before: Number(form.position_before),
      actor: actor(),
    }
    try {
      if (mode === 'edit') {
        await api(`/strategies/${encodeURIComponent(strategyId)}`, { method: 'PATCH', body: { patch: body, actor: actor() } })
        if (freeze) {
          await api(`/strategies/${encodeURIComponent(strategyId)}/freeze`, { method: 'POST', body: { actor: actor() } })
          alert(t('frozenToast', { id: strategyId }))
        } else {
          alert(t('savedDraft'))
        }
        go({ name: 'strategy', strategyId })
        return
      }
      const payload = await api('/strategies', { method: 'POST', body: { ...body, auto_freeze: freeze } })
      alert(t(freeze ? 'createdFrozen' : 'createdDraft', { id: payload.strategy_id }))
      state.stack = []
      go({ name: 'strategy', strategyId: payload.strategy_id }, { push: false })
    } catch (error) {
      errors.replaceChildren(el('div', { class: 'err', role: 'alert' },
        el('div', { class: 'msg' }, el('strong', {}, error.code ?? 'ERROR'), el('div', {}, error.message))))
    }
  }

  await refreshPrice()
  return wrap
}

/** 管理员视角：评分规则编辑（只影响之后的评价；历史评价保留自己的 calculation_version）。 */
function adminRulesPanel() {
  const rules = state.rules
  if (rules === null) return el('div', {})
  const draft = { weights: { ...rules.weights }, version: rules.version }
  const wrap = el('div', { class: 'form', style: 'margin-bottom:16px' })
  const errors = el('div', {})

  wrap.append(el('h2', { style: 'margin-top:0' }, t('adminPanel')))
  wrap.append(el('div', { class: 'row' },
    ...Object.keys(draft.weights).map((key) => el('label', {}, key,
      el('input', {
        type: 'number', step: '0.05', value: draft.weights[key],
        onInput: (event) => { draft.weights[key] = Number(event.target.value) },
      }))),
    el('label', {}, t('rulesVersion'),
      el('input', { value: draft.version, onInput: (event) => { draft.version = event.target.value } }))))
  wrap.append(el('div', { class: 'hint', style: 'margin-top:8px' }, t('rulesWeights')))
  wrap.append(errors)
  wrap.append(el('div', { class: 'actions' },
    el('button', {
      class: 'primary', type: 'button',
      onClick: async () => {
        try {
          const payload = await api('/rules', { method: 'PUT', body: { version: draft.version, weights: draft.weights, actor: actor() } })
          state.rules = payload.rules
          alert(t('rulesSaved', { version: payload.rules.version }))
          render()
        } catch (error) {
          errors.replaceChildren(el('div', { class: 'err', role: 'alert' },
            el('div', { class: 'msg' }, el('strong', {}, error.code ?? 'ERROR'), el('div', {}, error.message))))
        }
      },
    }, t('saveRules'))))
  return wrap
}

/** 策略表的列定义：分析师详情与团队明细共用，避免两处口径分叉。 */
function strategyColumns(onOpenFor) {
  return {
    onOpen: onOpenFor,
    columns: [
      { key: 'strategy_id', label: t('thStrategy'), get: (row) => row.strategy_id, render: (row) => el('span', { class: 'tag' }, row.strategy_id) },
      { key: 'ticker', label: t('thTicker'), get: (row) => row.ticker, render: (row) => el('strong', {}, row.ticker) },
      { key: 'action', label: t('thAction'), get: (row) => row.action, render: (row) => el('span', { class: `dir ${dirClass(row.action)}` }, row.action) },
      { key: 'status', label: t('thStatus'), get: (row) => row.status, render: (row) => el('span', { class: `tag ${row.status}` }, row.status) },
      { key: 'entry_price', label: t('entry'), numeric: true, get: (row) => row.entry_price, render: (row) => num(row.entry_price) },
      { key: 'exit_price', label: t('exitPrice'), numeric: true, get: (row) => row.exit_price, render: (row) => num(row.exit_price) },
      { key: 'strategy_return', label: t('thReturn'), numeric: true, get: (row) => row.strategy_return, render: (row) => el('span', { class: cls(row.strategy_return) }, pct(row.strategy_return)) },
      { key: 'benchmark_return', label: t('thBenchmark'), numeric: true, get: (row) => row.benchmark_return, render: (row) => el('span', { class: cls(row.benchmark_return) }, pct(row.benchmark_return)) },
      { key: 'alpha', label: t('thAlpha'), numeric: true, get: (row) => row.alpha, render: (row) => el('span', { class: cls(row.alpha) }, pct(row.alpha)) },
      { key: 'target_reached', label: t('targetOutcome'), sortable: false, get: (row) => row.target_reached, render: (row) => (row.target_reached === null ? '—' : row.target_reached ? el('span', { class: 'pos' }, t('reached')) : el('span', { class: 'muted' }, t('notReached'))) },
      { key: 'stop_loss_triggered', label: t('stopOutcome'), sortable: false, get: (row) => row.stop_loss_triggered, render: (row) => (row.stop_loss_triggered === null ? '—' : row.stop_loss_triggered ? el('span', { class: 'neg' }, t('triggered')) : el('span', { class: 'muted' }, t('notTriggered'))) },
      { key: 'score', label: t('thScore'), numeric: true, get: (row) => row.score, render: (row) => (row.score ?? '—') },
    ],
  }
}

/**
 * 团队明细：团队汇总指标 + **按分析师分组**的策略。
 * 每个成员一块：名字 + 该成员的关键指标 + 该成员的策略表（可点进策略详情）。
 */
/**
 * 模拟盘组合视图（批次 1 · C1/C2/C3/C5/C8/D3）。
 *
 * 刻意**只展示净值与收益率**：这是权重/净值式记账，页面上不出现任何金额。
 * 净值曲线与持仓都由确定性账本产出，并可点「重算校验」当场证明可复现。
 */
async function renderPortfolio() {
  const analystId = state.view.id
  const [data, perf] = await Promise.all([
    api(`/portfolios/${encodeURIComponent(analystId)}`),
    api(`/analysts/${encodeURIComponent(analystId)}/performance`).catch(() => null),
  ])
  const reasonLabel = (reason) => ({
    STRATEGY_TERMINAL: t('closeReasonStrategyTerminal'),
    OPPOSITE_INSTRUCTION: t('closeReasonOpposite'),
    EVICTED: t('closeReasonEvicted'),
  })[reason] ?? reason

  const name = perf?.analyst?.name ?? analystId
  const empty = data.counts.lots_opened === 0

  const header = el('div', { class: 'head' },
    el('div', {},
      el('h1', { text: `${t('portfolio')} · ${name}` }),
      el('div', { class: 'sub', text: `${analystId} · ${t('portfolioAccounting')} ${data.accounting_version} · as of ${data.as_of}` })),
    el('button', { class: 'btn', onclick: () => go({ name: 'analyst', id: analystId }) }, t('byAnalyst')))

  if (empty) {
    return el('div', {}, header, el('div', { class: 'note' }, t('noPortfolio')))
  }

  const cards = el('div', { class: 'cards' },
    card(t('portfolioNav'), num(data.nav), ''),
    card(t('portfolioReturn'), pct(data.total_return), data.total_return >= 0 ? 'good' : 'bad'),
    card(t('portfolioExposure'), `${mag(data.gross_exposure_pct / 100)} / ${mag(data.max_position_pct / 100)}`, ''),
    card(t('portfolioUnallocated'), mag(data.unallocated_pct / 100), ''),
    card(t('portfolioOpen'), num(data.counts.lots_open, 0), ''),
    card(t('portfolioClosed'), num(data.counts.lots_closed, 0), ''),
    card(t('portfolioEvicted'), num(data.counts.evictions, 0), data.counts.evictions > 0 ? 'bad' : ''),
    card(t('portfolioRejected'), num(data.counts.rejections, 0), data.counts.rejections > 0 ? 'bad' : ''))

  const openColumns = [
    { key: 'lot_id', label: t('thLot'), get: (row) => row.lot_id },
    { key: 'ticker', label: t('thTicker'), get: (row) => el('a', { href: `#/strategy/${row.strategy_id}/performance`, class: 'link' }, row.ticker) },
    { key: 'action', label: t('thAction'), get: (row) => el('span', { class: `tag ${dirClass(row.action)}` }, row.action) },
    { key: 'weight_pct', label: t('thWeight'), numeric: true, get: (row) => row.weight_pct, render: (row) => `${row.weight_pct}%` },
    { key: 'opened_date', label: t('thOpened'), get: (row) => row.opened_date },
    { key: 'entry_price', label: t('thEntry'), numeric: true, get: (row) => row.entry_price, render: (row) => num(row.entry_price) },
    { key: 'nav_at_open', label: t('thNavAtOpen'), numeric: true, get: (row) => row.nav_at_open, render: (row) => num(row.nav_at_open) },
  ]
  const closedColumns = [
    ...openColumns.slice(0, 1),
    ...openColumns.slice(1, 6),
    { key: 'exit_price', label: t('thExit'), numeric: true, get: (row) => row.exit_price, render: (row) => num(row.exit_price) },
    { key: 'closed_date', label: t('thClosed'), get: (row) => row.closed_date ?? '—' },
    { key: 'close_reason', label: t('thCloseReason'), get: (row) => row.close_reason, render: (row) => el('span', { class: 'note' }, reasonLabel(row.close_reason)) },
    { key: 'realized_return', label: t('thReturn'), numeric: true, get: (row) => row.realized_return, render: (row) => el('span', { class: cls(row.realized_return) }, pct(row.realized_return)) },
    { key: 'realized_pnl_nav', label: t('thRealizedPnl'), numeric: true, get: (row) => row.realized_pnl_nav, render: (row) => el('span', { class: cls(row.realized_pnl_nav) }, num(row.realized_pnl_nav)) },
  ]

  const nav = await api(`/portfolios/${encodeURIComponent(analystId)}/nav`)

  const verifyButton = el('button', {
    class: 'btn',
    onclick: async (event) => {
      const button = event.currentTarget
      button.setAttribute('disabled', '')
      try {
        const result = await api(`/portfolios/${encodeURIComponent(analystId)}/verify`)
        button.replaceWith(el('div', { class: result.matches ? 'ok' : 'err' },
          result.matches
            ? `${t('verifyOk')}（${result.accounting_version}，指纹 ${result.instruction_digest}）`
            : `${t('verifyFail')}：${result.differences.join(', ')}`))
      } catch (error) {
        button.replaceWith(el('div', { class: 'err' }, error.message))
      }
    },
  }, t('verifyPortfolio'))

  return el('div', {},
    header,
    cards,
    el('div', { class: 'section' },
      el('h2', { text: t('portfolioNav') }),
      navChart(nav),
      el('div', { class: 'note' }, t('navCurveHint'))),
    el('div', { class: 'section' },
      el('h2', { text: `${t('portfolioOpen')} (${data.positions.length})` }),
      data.positions.length === 0 ? emptyBox(t('noData')) : sortableTable({ columns: openColumns, rows: data.positions, initialKey: 'opened_date' })),
    el('div', { class: 'section' },
      el('h2', { text: `${t('portfolioClosed')} (${data.closed.length})` }),
      data.closed.length === 0 ? emptyBox(t('noData')) : sortableTable({ columns: closedColumns, rows: data.closed, initialKey: 'closed_date' })),
    data.evictions.length === 0 ? el('div', {}) : el('div', { class: 'section' },
      el('h2', { text: `${t('portfolioEvicted')} (${data.evictions.length})` }),
      sortableTable({
        columns: [
          { key: 'date', label: t('thDate'), get: (row) => row.date },
          { key: 'ticker', label: t('thTicker'), get: (row) => row.ticker },
          { key: 'strategy_id', label: t('thStrategy'), get: (row) => el('a', { href: `#/strategy/${row.strategy_id}/performance`, class: 'link' }, row.strategy_id) },
          { key: 'weight_pct', label: t('thWeight'), numeric: true, get: (row) => row.weight_pct, render: (row) => `${row.weight_pct}%` },
          { key: 'evicted_for', label: t('thStrategy'), get: (row) => el('a', { href: `#/strategy/${row.evicted_for}/performance`, class: 'link' }, row.evicted_for) },
        ],
        rows: data.evictions,
        initialKey: 'date',
      })),
    el('div', { class: 'section' },
      el('div', {}, verifyButton),
      el('div', { class: 'note' }, t('noMoney'))))
}

/** 组合净值曲线：只用净值一条线，起点对齐 start_nav。 */
function navChart(nav) {
  const points = nav.curve
  if (points.length === 0) return emptyBox(t('noData'))
  const width = 900
  const height = 200
  const pad = { left: 56, right: 14, top: 12, bottom: 22 }
  const values = points.map((point) => point.nav)
  const min = Math.min(...values, nav.start_nav)
  const max = Math.max(...values, nav.start_nav)
  const span = Math.max(max - min, 1e-6)
  const x = (index) => pad.left + (index / Math.max(points.length - 1, 1)) * (width - pad.left - pad.right)
  const y = (value) => pad.top + (1 - (value - min) / span) * (height - pad.top - pad.bottom)
  const path = values.map((value, index) => `${index === 0 ? 'M' : 'L'}${x(index).toFixed(1)},${y(value).toFixed(1)}`).join(' ')

  const svg = []
  for (const ratio of [0, 0.5, 1]) {
    const value = min + span * ratio
    svg.push(`<line x1="${pad.left}" x2="${width - pad.right}" y1="${y(value).toFixed(1)}" y2="${y(value).toFixed(1)}" stroke="var(--line)" stroke-width="1" stroke-dasharray="3 4"/>`,
      `<text x="${pad.left - 6}" y="${(y(value) + 4).toFixed(1)}" text-anchor="end" font-size="11" fill="var(--muted)">${value.toFixed(2)}</text>`)
  }
  // 起始净值参考线：一眼看出"现在赚了还是亏了"
  svg.push(`<line x1="${pad.left}" x2="${width - pad.right}" y1="${y(nav.start_nav).toFixed(1)}" y2="${y(nav.start_nav).toFixed(1)}" stroke="var(--muted)" stroke-width="1" stroke-dasharray="2 3"/>`)
  svg.push(`<path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2"/>`)
  svg.push(`<text x="${pad.left}" y="${height - 6}" font-size="11" fill="var(--muted)">${points[0].date}</text>`)
  svg.push(`<text x="${width - pad.right}" y="${height - 6}" text-anchor="end" font-size="11" fill="var(--muted)">${points.at(-1).date}</text>`)
  return el('div', { class: 'chart', html: `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${t('portfolioNav')}">${svg.join('')}</svg>` })
}

async function renderTeam() {
  const team = state.view.team
  const payload = await api(`/teams/${encodeURIComponent(team)}/performance`, { query: { role: state.role } })
  const m = payload.metrics

  const wrap = el('div', {})
  wrap.append(el('h2', {}, t('teamSummary'), el('span', { class: 'count' }, team)))
  wrap.append(el('div', { class: 'cards' },
    card(t('strategies'), m.strategies),
    card(t('analystCount'), payload.analyst_count),
    card(t('evaluated'), m.evaluated),
    card(t('winRate'), mag(m.win_rate)),
    card(t('avgReturn'), pct(m.average_return), cls(m.average_return)),
    card(t('avgAlpha'), pct(m.average_alpha), cls(m.average_alpha)),
    card(t('maxDrawdown'), mag(m.max_drawdown), 'bad'),
    card(t('avgScore'), pts(m.average_score))))

  wrap.append(el('h2', {}, t('byAnalyst'), el('span', { class: 'count' }, `(${payload.analysts.length})`)))

  if (payload.analysts.length === 0) {
    wrap.append(emptyBox(t('noStrategiesInTeam')))
    return wrap
  }

  for (const group of payload.analysts) {
    wrap.append(el('h2', { style: 'margin-top:20px' },
      el('a', {
        style: 'color:var(--accent);cursor:pointer',
        onClick: () => go({ name: 'analyst', id: group.analyst_id, analystName: group.name, teamLabel: team }),
      }, `${group.name} (${group.analyst_id})`),
      el('span', { class: 'count' },
        `${group.metrics.strategies} ${t('thStrategies')} · ${t('thWinRate')} ${mag(group.metrics.win_rate)} · ${t('thAvgReturn')} ${pct(group.metrics.average_return)} · ${t('thAlpha')} ${pct(group.metrics.average_alpha)} · ${t('maxDrawdown')} ${mag(group.metrics.max_drawdown)} · ${t('thScore')} ${pts(group.metrics.average_score)}`)))

    const shared = strategyColumns((row) => go({
      name: 'strategy',
      strategyId: row.strategy_id,
      analystId: group.analyst_id,
      analystName: group.name,
      teamLabel: team,
    }))
    wrap.append(sortableTable({
      id: `team-strategies-${group.analyst_id}`,
      rows: group.strategies,
      onOpen: shared.onOpen,
      columns: shared.columns,
      emptyText: t('noStrategiesForMember'),
    }))
  }
  return wrap
}

async function renderAnalyst() {
  const id = state.view.id
  const { analyst, metrics, strategies } = await api(`/analysts/${encodeURIComponent(id)}/performance`, { query: { role: state.role } })
  state.view.analystId = id
  state.view.analystName = analyst.name

  const filters = state.filters[id] ?? { text: '', status: '', action: '' }
  state.filters[id] = filters
  const filtered = strategies.filter((row) => {
    if (filters.text.length > 0) {
      const needle = filters.text.toLowerCase()
      if (!row.ticker.toLowerCase().includes(needle) && !row.strategy_id.toLowerCase().includes(needle)) return false
    }
    if (filters.status.length > 0 && row.status !== filters.status) return false
    if (filters.action.length > 0 && row.action !== filters.action) return false
    return true
  })

  const wrap = el('div', {})
  // 「模拟盘」入口：没有可达路径的视图等于没做。
  // 用 `.head` 这个已有布局类（右侧按钮位），不新增 CSS。
  wrap.append(el('div', { class: 'head' },
    el('div', { class: 'sub', text: t('noMoney') }),
    el('button', { class: 'btn', onclick: () => go({ name: 'portfolio', id }) }, `📈 ${t('portfolio')}`)))
  wrap.append(el('div', { class: 'cards' },
    card(t('strategies'), metrics.strategies),
    card(t('evaluated'), metrics.evaluated),
    card(t('winRate'), mag(metrics.win_rate)),
    card(t('avgReturn'), pct(metrics.average_return), cls(metrics.average_return)),
    card(t('avgAlpha'), pct(metrics.average_alpha), cls(metrics.average_alpha)),
    card(t('maxDrawdown'), mag(metrics.max_drawdown), 'bad'),
    card(t('avgScore'), pts(metrics.average_score)),
    card(t('totalPnl'), num(metrics.total_pnl))))

  wrap.append(el('h2', {}, `${t('strategyHistory')} — ${analyst.name}`, el('span', { class: 'count' }, analyst.team)))

  wrap.append(el('div', { class: 'filters', style: 'margin-bottom:12px' },
    el('input', {
      type: 'search',
      placeholder: t('filterTicker'),
      value: filters.text,
      'aria-label': t('filterTicker'),
      onInput: (event) => { filters.text = event.target.value; render() },
    }),
    el('select', {
      'aria-label': t('filterStatus'),
      onChange: (event) => { filters.status = event.target.value; render() },
    }, [['', t('allStatuses')], ...['ACTIVE', 'COMPLETED', 'STOPPED', 'DRAFT', 'CANCELLED', 'EXPIRED'].map((status) => [status, status])]
      .map(([value, label]) => el('option', { value, selected: filters.status === value }, label))),
    el('select', {
      'aria-label': t('filterAction'),
      onChange: (event) => { filters.action = event.target.value; render() },
    }, [['', t('allActions')], ['BUY', 'BUY'], ['SELL', 'SELL']]
      .map(([value, label]) => el('option', { value, selected: filters.action === value }, label))),
    el('button', { class: 'ghost', onClick: () => { state.filters[id] = { text: '', status: '', action: '' }; render() } }, t('clearFilters')),
    el('span', { class: 'note', style: 'margin:0' }, t('showingCount', { shown: filtered.length, total: strategies.length }))))

  const shared = strategyColumns((row) => go({
    name: 'strategy',
    strategyId: row.strategy_id,
    analystId: id,
    analystName: analyst.name,
    teamLabel: state.view.teamLabel,
  }))
  wrap.append(sortableTable({
    id: `strategies-${id}`,
    rows: filtered,
    emptyText: strategies.length === 0 ? t('emptyStrategies') : t('noMatches'),
    onOpen: shared.onOpen,
    columns: shared.columns,
  }))
  return wrap
}

async function renderStrategy() {
  const id = state.view.strategyId
  const tab = state.view.tab ?? 'performance'
  const [replayPayload, reportPayload] = await Promise.all([
    api(`/strategies/${encodeURIComponent(id)}/replay`, { query: { role: state.role } }),
    api(`/reports/strategies/${encodeURIComponent(id)}`, { query: { role: state.role } }),
  ])
  const replay = replayPayload.replay
  const report = reportPayload.report
  const markdown = reportPayload.markdown
  const original = report.factual.original_strategy
  const meta = report.factual.strategy
  const performance = report.factual.actual_performance
  const rules = report.factual.rule_evaluation
  const score = report.factual.score

  const wrap = el('div', {})
  wrap.append(el('div', { class: 'cards' },
    card(t('thTicker'), meta.ticker),
    card(t('thAction'), meta.action),
    card(t('thStatus'), meta.status),
    card(t('returnPct'), pct(performance?.strategy_return), cls(performance?.strategy_return)),
    card(t('thBenchmark'), pct(performance?.benchmark_return), cls(performance?.benchmark_return)),
    card(t('alpha'), pct(performance?.alpha), cls(performance?.alpha)),
    card(t('maxDrawdown'), mag(performance?.max_drawdown), 'bad'),
    card(t('thScore'), score ? pts(score.total) : '—')))

  const isDraft = meta.status === 'DRAFT'
  const terminal = ['COMPLETED', 'STOPPED', 'EXPIRED'].includes(meta.status)

  wrap.append(el('div', { class: 'toolbar' },
    // 维护入口：草稿可编辑 / 冻结，ACTIVE 可取消 —— 都按能力矩阵与状态决定
    isDraft && can('strategy.create')
      ? el('button', { class: 'primary', onClick: () => go({ name: 'edit', strategyId: id }) }, t('editStrategy'))
      : null,
    isDraft && can('strategy.freeze')
      ? el('button', { class: 'ghost', onClick: async () => {
        try {
          await api(`/strategies/${encodeURIComponent(id)}/freeze`, { method: 'POST', body: { actor: actor() } })
          alert(t('frozenToast', { id }))
          render()
        } catch (error) { alert(`${error.code}: ${error.message}`) }
      } }, t('freezeStrategy'))
      : null,
    meta.status === 'ACTIVE' && can('strategy.cancel')
      ? el('button', { class: 'ghost', onClick: async () => {
        const reason = prompt(t('cancelReason'))
        if (reason === null) return
        try {
          await api(`/strategies/${encodeURIComponent(id)}/cancel`, { method: 'POST', body: { reason, actor: actor() } })
          alert(t('cancelledToast', { id }))
          render()
        } catch (error) { alert(`${error.code}: ${error.message}`) }
      } }, t('cancelStrategy'))
      : null,
    terminal ? el('span', { class: 'note', style: 'margin:0' }, t('cannotCancelTerminal')) : null,
    meta.status === 'DRAFT' && isDraft ? el('span', { class: 'note', style: 'margin:0' }, t('draftHint')) : null,
    el('button', { class: 'ghost', onClick: async () => { await api(`/monitor/${encodeURIComponent(id)}`, { method: 'POST', body: {} }); render() } }, t('monitorRun')),
    el('button', { class: 'ghost', onClick: async () => { await api(`/strategies/${encodeURIComponent(id)}/evaluate`, { method: 'POST', body: {} }); render() } }, t('runEvaluation')),
    el('span', { class: 'note', style: 'margin:0' }, `${meta.status} · ${t('submitted')} ${meta.submitted} · ${replay.price_steps.length} ${t('tradesDays')}`)))

  wrap.append(el('div', { class: 'tabs', role: 'tablist' }, [
    ['performance', t('performance')],
    ['replay', t('replay')],
    ['report', t('report')],
  ].map(([key, label]) => el('button', {
    role: 'tab',
    'aria-selected': tab === key ? 'true' : 'false',
    class: tab === key ? 'on' : '',
    onClick: () => go({ ...state.view, tab: key }),
  }, label))))

  if (tab === 'replay') {
    wrap.append(el('h2', {}, t('priceTimeline')))
    wrap.append(priceChart(replay, original, rules))
    wrap.append(el('h2', {}, t('lifecycleEvents'), el('span', { class: 'count' }, `(${replay.timeline.length})`)))
    wrap.append(el('ul', { class: 'timeline' }, replay.timeline.map((row) => el('li', { class: `ev-${row.type}` },
      el('span', { class: 'at' }, row.at),
      row.label,
      row.actor ? el('span', { class: 'who' }, ` — ${row.actor.role}:${row.actor.actor_id}`) : null))))
    wrap.append(el('h2', {}, t('auditAnswers')))
    wrap.append(kv('', [
      [t('q1'), replay.answers['1_who_submitted']],
      [t('q2'), replay.answers['2_submitted_at']],
      [t('q3'), replay.answers['3_price_at_submission']],
      [t('q4'), replay.answers['4_position_before']],
      [t('q6'), `${replay.price_steps.length} ${t('tradesDays')}`],
      [t('q7'), String(replay.answers['7_target_reached'])],
      [t('q8'), String(replay.answers['8_stop_loss_triggered'])],
      [t('q9'), pct(replay.answers['9_strategy_return'])],
      [t('q10'), replay.answers['10_benchmark'] === null ? '—' : pct(replay.answers['10_benchmark'].benchmark_return)],
      [t('q11'), replay.answers['11_final_score'] === null ? '—' : t('scoreOf', { score: replay.answers['11_final_score'] })],
      [t('replayConsistent'), String(replay.replay_consistent)],
    ]))
    return wrap
  }

  if (tab === 'report') {
    wrap.append(el('div', { class: 'disclaimer' }, report.commentary_disclaimer))
    wrap.append(el('div', { class: 'prose', html: renderMarkdown(markdown) }))
    return wrap
  }

  const grid = el('div', { class: 'grid2' })
  grid.append(kv(t('strategySection'), [
    [t('strategyId'), meta.strategy_id],
    [t('analystLabel'), `${meta.analyst_name} (${meta.analyst_id})`],
    [t('submitted'), meta.submitted],
    [t('frozenAt'), meta.frozen_at ?? '—'],
    [t('benchmark'), original.benchmark],
    [t('positionBefore'), num(original.position_before, 0)],
    [t('quantity'), num(original.quantity, 0)],
  ]))
  grid.append(kv(t('originalStrategy'), [
    [t('entry'), num(original.entry_price)],
    [t('target'), num(original.target_price)],
    [t('stop'), num(original.stop_loss)],
    [t('plannedHolding'), `${original.holding_period} ${t('days')}`],
    [t('snapshotPrice'), num(original.market_snapshot?.price)],
    [t('snapshotVolume'), num(original.market_snapshot?.volume, 0)],
    [t('snapshotAt'), original.market_snapshot?.timestamp ?? '—'],
  ]))
  grid.append(kv(t('actualPerformance'), performance === null ? [[t('thStatus'), t('notEvaluated')]] : [
    [t('entryExit'), `${num(performance.entry_price)} → ${num(performance.exit_price)}`],
    [t('exitOn'), performance.exit_date ?? '—'],
    [t('returnPct'), pct(performance.strategy_return), cls(performance.strategy_return)],
    [t('thBenchmark'), pct(performance.benchmark_return), cls(performance.benchmark_return)],
    [t('alpha'), pct(performance.alpha), cls(performance.alpha)],
    [t('pnl'), num(performance.pnl)],
    [t('actualHolding'), `${performance.holding_days} ${t('days')}`],
    [t('exitReason'), performance.exit_reason],
  ]))
  grid.append(kv(t('riskMetrics'), performance === null ? [[t('thStatus'), t('notEvaluated')]] : [
    [t('maxDrawdown'), mag(performance.max_drawdown)],
    [t('volatility'), mag(performance.volatility)],
    [t('riskReward'), num(performance.risk_reward_ratio, 2)],
    [t('targetOutcome'), rules === null ? '—' : rules.target_reached ? `${t('reached')} ${rules.target_reached_on}` : t('notReached')],
    [t('stopOutcome'), rules === null ? '—' : rules.stop_loss_triggered ? `${t('triggered')} ${rules.stop_loss_triggered_on}` : t('notTriggered')],
    [t('benchmarkOutcome'), rules === null ? '—' : t(rules.benchmark_outcome)],
  ]))
  wrap.append(grid)

  wrap.append(el('h2', {}, t('scoreBreakdown')))
  wrap.append(el('div', { class: 'kv' }, scorePanel(score)))

  wrap.append(el('h2', {}, t('priceTimeline')))
  wrap.append(priceChart(replay, original, rules))

  wrap.append(el('h2', {}, t('analystReasoning')))
  wrap.append(el('div', { class: 'reason' }, original.reason))

  wrap.append(el('footer', {}, t('factsFooter')))
  return wrap
}

// ── 顶栏动作 ──────────────────────────────────────────────────────────────
for (const language of LANGUAGES) {
  document.getElementById('lang').append(
    el('button', { type: 'button', 'data-lang': language.id, onClick: () => setLanguage(language.id) }, language.label))
}
for (const theme of THEMES) {
  document.getElementById('theme').append(
    el('button', { type: 'button', 'data-theme': theme, onClick: () => setTheme(theme) }))
}

document.getElementById('role').addEventListener('change', (event) => {
  state.role = event.target.value
  saveIdentity()
  refreshStaticText()
  render()
})

document.getElementById('analyst').addEventListener('change', (event) => {
  state.actorId = event.target.value
  saveIdentity()
  render()
})

document.getElementById('new-strategy').addEventListener('click', () => {
  if (!can('strategy.create')) {
    alert(t('noPermission'))
    return
  }
  go({ name: 'new' })
})

document.getElementById('monitor').addEventListener('click', async () => {
  try {
    alert(t('monitorResult', await api('/monitor/run', { method: 'POST', body: { actor: actor() } })))
    render()
  } catch (error) {
    alert(`${error.code ?? 'ERROR'}: ${error.message}`)
  }
})

document.getElementById('advance').addEventListener('click', async () => {
  try {
    const advanced = await api('/demo/advance-clock', { method: 'POST', body: { trading_days: 1, actor: actor() } })
    const monitor = await api('/monitor/run', { method: 'POST', body: { actor: actor() } })
    alert(t('advanceResult', { ...advanced, ...monitor }))
    render()
  } catch (error) {
    alert(`${error.code ?? 'ERROR'}: ${error.message}`)
  }
})

document.getElementById('reset').addEventListener('click', async () => {
  if (!confirm(t('resetConfirm'))) return
  try {
    const result = await api('/demo/reset', { method: 'POST', body: { actor: { actor_id: 'demo_admin', role: 'ADMIN' } } })
    alert(t('resetDone', { strategies: result.strategies.length, evaluations: result.evaluations.length }))
    state.stack = []
    go({ name: 'dashboard' }, { push: false })
  } catch (error) {
    alert(`${error.code ?? 'ERROR'}: ${error.message}`)
  }
})

globalThis.matchMedia?.('(prefers-color-scheme: light)')?.addEventListener?.('change', () => {
  if (state.theme === 'auto') applyTheme()
})

async function boot() {
  loadIdentity()
  applyTheme()
  refreshStaticText()
  try {
    const [meta, capabilities, analysts, rules] = await Promise.all([
      api('/meta'),
      api('/capabilities'),
      api('/analysts'),
      api('/rules'),
    ])
    state.meta = meta
    state.capabilities = capabilities.capabilities
    state.analysts = analysts.analysts
    state.rules = rules.rules
    if (state.role === 'ANALYST' && !state.analysts.some((a) => a.analyst_id === state.actorId)) {
      state.actorId = state.analysts[0]?.analyst_id ?? 'john'
    }
  } catch (error) {
    app.replaceChildren(errorCard(error, () => boot()))
    return
  }
  state.view = parseHash()
  refreshStaticText()
  render()
}

boot()

// 供测试比对：与 src/core/report/format.js 的逐值一致性由 metric-format-parity.test.js 保证。
export const FORMAT = { pct, mag, pts, num }
