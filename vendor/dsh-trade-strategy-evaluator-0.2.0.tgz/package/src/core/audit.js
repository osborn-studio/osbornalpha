/**
 * 审计事件（实施方案 §20 / §11）。
 *
 * 任何**影响评价结果**的变化都必须产生 Event。Replay 就是这些事件的
 * 时间线重建：谁、什么时间、当时价格多少、当时仓位多少、为什么、后续如何变化、
 * 是否触发目标/止损、最终收益与评分。
 *
 * 事件同时记录 `session_id`（若调用来自 Harness 会话），这样 Harness 的
 * Session Event Log 与业务 Event Log 可以双向对照，满足"所有重要操作必须能够 Replay"。
 */

export const EVENT_TYPES = {
  STRATEGY_CREATED: 'Strategy Created',
  MARKET_SNAPSHOT_CAPTURED: 'Market Snapshot',
  STRATEGY_FROZEN: 'Strategy Frozen',
  PERFORMANCE_UPDATED: 'Performance Updated',
  TARGET_REACHED: 'Target Reached',
  STOP_LOSS_TRIGGERED: 'Stop Loss Triggered',
  STRATEGY_COMPLETED: 'Strategy Completed',
  STRATEGY_EXPIRED: 'Strategy Expired',
  STRATEGY_STOPPED: 'Strategy Stopped',
  STRATEGY_CANCELLED: 'Strategy Cancelled',
  EVALUATION_COMPLETED: 'Evaluation Completed',
  REPORT_GENERATED: 'Report Generated',
  MONITOR_RUN: 'Monitor Run',
  CLOCK_ADVANCED: 'Clock Advanced',
  RULES_UPDATED: 'Evaluation Rules Updated',
  // ── 模拟盘组合层（批次 1）────────────────────────────────────────────────
  // 组合层会**改变测评结果**（净值曲线就是考评依据），所以它的每个动作都必须留痕：
  // 建仓（含权重）、挤出（谁被挤掉、为谁腾位置）、净值刷新、以及被拒绝的越限指令。
  POSITION_OPENED: 'Portfolio Position Opened',
  POSITION_CLOSED: 'Portfolio Position Closed',
  POSITION_EVICTED: 'Portfolio Position Evicted',
  NAV_UPDATED: 'Portfolio NAV Updated',
  INSTRUCTION_REJECTED: 'Portfolio Instruction Rejected',
}

export const EVENT_TYPE_KEYS = Object.keys(EVENT_TYPES)

/**
 * 追加一条审计事件。`event_id` 全局单调递增，保证事件全序（Replay 依赖它）。
 * @param {import('../storage/repository.js').Repository} repository
 * @param {object} event
 */
export async function appendEvent(repository, event) {
  const record = {
    at: event.at,
    type: event.type,
    label: EVENT_TYPES[event.type] ?? event.type,
    strategy_id: event.strategy_id ?? null,
    evaluation_id: event.evaluation_id ?? null,
    analyst_id: event.analyst_id ?? null,
    actor: event.actor ?? null,
    session_id: event.session_id ?? null,
    payload: event.payload ?? {},
  }
  return repository.appendEvent(record)
}

/** 读取某个策略的完整事件时间线（按事件全序）。 */
export async function strategyTimeline(repository, strategyId) {
  return (await repository
    .list('events'))
    .filter((event) => event.strategy_id === strategyId)
    .sort((a, b) => a.sequence - b.sequence)
}

/** 全部事件（供 Dashboard 的审计视图）。 */
export async function allEvents(repository, { limit = 200 } = {}) {
  return (await repository
    .list('events'))
    .sort((a, b) => b.sequence - a.sequence)
    .slice(0, limit)
}
