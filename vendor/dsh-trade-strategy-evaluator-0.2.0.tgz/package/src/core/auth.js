/**
 * 权限（实施方案 §19）。
 *
 * POC 实现三个角色，且**在服务层强制**，不依赖 UI：
 *
 *  ANALYST  可以创建策略 / 查看自己的策略 / 不能修改 Frozen Strategy / 不能修改 Evaluation
 *  MANAGER  可以查看团队策略 / 查看分析师绩效 / 查看 Replay / 查看报告
 *  ADMIN    可以配置 Evaluation Rules / 配置 Market Data Provider / 管理 Analyst
 *
 * 默认角色由调用方声明（API 头 `x-actor-role` 或 body.actor）；缺省为 MANAGER，
 * 保证 Demo 打开即可读全部数据，同时写操作仍受角色约束。
 *
 * ⚠️ 关于"身份可信度"必须说清楚（这是一个**部署级**约束，不是代码 bug）：
 * DeepSeek Harness 目前**不提供用户身份** —— session/agent 上下文里没有 userId，
 * 唯一能拿到的是 `session.header` 里的 seedLength / cwd。
 * 所以本插件里的 `actor` 一律是**自述身份**：谁调用就声明自己是谁。
 * 因此：
 *   · `actor_source` 会记进审计事件，事后能区分"配置层给的"还是"调用方自述的"；
 *   · `identity.requireVerified` 开关一旦打开（`auth.js` 的 `resolveActor`），
 *     来源不是配置层的高权角色（MANAGER/ADMIN）会被直接拒绝；
 *   · 真正的认证必须接客户 SSO —— 代码层面能做的到此为止，
 *     再往前推只能靠"信任边界"（浏览器鉴权围栏 / 共享令牌），不能靠这里加判断。
 */

import { unauthorized, validation } from './errors.js'

export const ROLES = ['ANALYST', 'MANAGER', 'ADMIN']

/** 高权角色：`identity.requireVerified` 打开后，这两个角色不允许由调用方自述。 */
export const ELEVATED_ROLES = Object.freeze(['MANAGER', 'ADMIN'])

/**
 * 身份的**来源**（会写进审计事件的 `actor_source`）。
 *   config  来自插件配置 `identity.actor` —— 部署者设定的默认身份，可信
 *   tool    来自 Agent 工具调用参数 —— 自述
 *   request 来自 HTTP 头 / 查询串 / body —— 自述
 */
export const ACTOR_SOURCES = Object.freeze(['config', 'tool', 'request'])

export const DEFAULT_ACTOR = Object.freeze({ actor_id: 'demo_manager', role: 'MANAGER', name: 'Demo Manager' })

/** 能力 → 允许的角色。'*' 表示任意已认证角色（所有权另行判定）。 */
const CAPABILITIES = {
  'strategy.create': ['ANALYST', 'ADMIN'],
  'strategy.read.any': ['MANAGER', 'ADMIN'],
  'strategy.read.own': ['ANALYST'],
  'strategy.freeze': ['ANALYST', 'ADMIN'],
  'strategy.cancel': ['ANALYST', 'MANAGER', 'ADMIN'],
  'evaluation.run': ['ANALYST', 'MANAGER', 'ADMIN'],
  'evaluation.write': [],
  'report.read': ['ANALYST', 'MANAGER', 'ADMIN'],
  'replay.read': ['ANALYST', 'MANAGER', 'ADMIN'],
  'rules.write': ['ADMIN'],
  'analyst.manage': ['ADMIN'],
  'market.configure': ['ADMIN'],
  'monitor.run': ['MANAGER', 'ADMIN'],
}

/**
 * 归一化调用方身份。
 *
 * 会**保留**一个合法的 `source`（config/tool/request）：审计需要区分
 * "配置层设定的身份"与"调用方自述的身份"，而 HTTP 层有 20 个调用点，
 * 把来源随身份一起传下去比在每个调用点额外传一个参数更不容易漏。
 */
export function normalizeActor(input) {
  if (input === undefined || input === null) return { ...DEFAULT_ACTOR }
  if (typeof input !== 'object') throw validation('actor must be an object')
  const role = String(input.role ?? DEFAULT_ACTOR.role).toUpperCase()
  if (!ROLES.includes(role)) throw validation(`unknown role "${input.role}"`, { knownRoles: ROLES })
  const actor_id = typeof input.actor_id === 'string' && input.actor_id.length > 0 ? input.actor_id : DEFAULT_ACTOR.actor_id
  const source = input.source === undefined ? undefined : String(input.source)
  if (source !== undefined && !ACTOR_SOURCES.includes(source)) {
    throw validation(`unknown actor source "${input.source}"`, { knownSources: ACTOR_SOURCES })
  }
  return {
    actor_id,
    role,
    ...(typeof input.name === 'string' ? { name: input.name } : {}),
    ...(source === undefined ? {} : { source }),
  }
}

/**
 * 校验并归一化身份策略（来自 `config.identity`）。
 *
 * 为什么要单独一个函数：策略是**部署配置**，必须可校验、可缺省、可解释，
 * 不能让 `requireVerified` 这种开关散落在调用点各写一遍。
 */
export function normalizeIdentityPolicy(input, label = 'config.identity') {
  const raw = typeof input === 'object' && input !== null ? input : {}
  const elevatedRaw = Array.isArray(raw.elevatedRoles) && raw.elevatedRoles.length > 0 ? raw.elevatedRoles : ELEVATED_ROLES
  const elevatedRoles = elevatedRaw.map((role) => String(role).toUpperCase())
  for (const role of elevatedRoles) {
    if (!ROLES.includes(role)) throw validation(`${label}.elevatedRoles contains unknown role "${role}"`, { knownRoles: ROLES })
  }
  return {
    actor: raw.actor === undefined || raw.actor === null ? null : normalizeActor(raw.actor),
    requireVerified: raw.requireVerified === true,
    elevatedRoles,
  }
}

/**
 * 解析出本次调用的身份 —— **所有 actor 的唯一入口**。
 *
 * 三件事在这一处做完，调用点不再各自拼装：
 *  1. 优先级：调用方自述 > 配置层默认（`identity.actor`）> 内置 DEFAULT_ACTOR；
 *  2. 记录来源（config / tool / request），供审计区分可信与自述；
 *  3. `requireVerified` 打开时，拒绝"自述的高权角色"。
 *
 * @param {{ actor?: unknown, fallback?: unknown, policy?: object, source?: string }} input
 */
export function resolveActor({ actor, fallback, policy, source } = {}) {
  // 来源的优先级：显式参数 > 身份对象自带 > 默认。
  // "来自 fallback（配置层）" 默认就是 `config` —— 这正是可信与自述的分界线，
  // 所以它不该由调用点各自声明，否则迟早有人漏写。
  const fromFallback = actor === undefined || actor === null
  const declaredSource = fromFallback ? undefined : actor.source
  const effectiveSource = source ?? declaredSource ?? (fromFallback ? 'config' : 'tool')
  if (!ACTOR_SOURCES.includes(effectiveSource)) {
    throw validation(`unknown actor source "${effectiveSource}"`, { knownSources: ACTOR_SOURCES })
  }
  const resolved = { ...normalizeActor(actor ?? fallback ?? DEFAULT_ACTOR), source: effectiveSource }

  const elevatedRoles = policy?.elevatedRoles ?? ELEVATED_ROLES
  const elevated = elevatedRoles.includes(resolved.role)
  if (policy?.requireVerified === true && elevated && effectiveSource !== 'config') {
    throw unauthorized(
      `identity.requireVerified is enabled: role ${resolved.role} may not be self-declared (actor_source="${source}")`,
      {
        role: resolved.role,
        actor_source: effectiveSource,
        requiredSource: 'config',
        howToFix: 'set identity.actor in the plugin config (cordis.patch.yml), or authenticate through the deployment SSO and pass source="config"',
        note: 'DeepSeek Harness exposes no user identity; a self-declared MANAGER/ADMIN cannot be trusted.',
      },
    )
  }
  return resolved
}

/** 断言角色具备能力，否则抛 UNAUTHORIZED。 */
export function assertCapability(actor, capability, context = {}) {
  const allowed = CAPABILITIES[capability]
  if (allowed === undefined) throw validation(`unknown capability "${capability}"`)
  if (allowed.length === 0) {
    throw unauthorized(`capability "${capability}" is reserved for the deterministic Evaluation Engine and cannot be invoked`, {
      capability,
      actorRole: actor.role,
    })
  }
  if (!allowed.includes(actor.role)) {
    // 报错要**可直接照做**：给出一个能立刻重试的 actor 对象。
    // 只写 "unauthorized" 会让 Agent/调用方反复用同一个身份重试，浪费一轮往返。
    // 默认建议"换角色、沿用同一个 actor_id"；但有些能力光换角色还不够
    // （例如 strategy.create 的 actor_id 必须是一个**真实存在的分析师**），
    // 这时由调用方通过 `context.suggestedActor` 给出一个真能用的身份。
    const suggestedActor = context.suggestedActor ?? { actor_id: actor.actor_id, role: allowed[0] }
    throw unauthorized(context.message ?? `role ${actor.role} may not perform "${capability}"`, {
      capability,
      actorRole: actor.role,
      allowed,
      suggestedActor,
      hint: context.hint ?? `retry with actor=${JSON.stringify(suggestedActor)}`,
      howToFix: context.howToFix ?? `capability "${capability}" is allowed for: ${allowed.join(', ')}`,
      ...(actor.source === undefined ? {} : { actor_source: actor.source }),
    })
  }
  return true
}

/**
 * 读权限：ANALYST 只能读自己的策略，MANAGER/ADMIN 可读全部。
 * @param {object} actor
 * @param {object} strategy
 */
export function assertCanReadStrategy(actor, strategy) {
  if (actor.role === 'ANALYST' && strategy.analyst_id !== actor.actor_id) {
    throw unauthorized(`analyst ${actor.actor_id} may not read strategy ${strategy.strategy_id} owned by ${strategy.analyst_id}`, {
      strategyId: strategy.strategy_id,
      owner: strategy.analyst_id,
    })
  }
  return true
}

/** 写权限：ANALYST 只能操作自己的策略。 */
export function assertCanMutateStrategy(actor, strategy) {
  if (actor.role === 'ANALYST' && strategy.analyst_id !== actor.actor_id) {
    throw unauthorized(`analyst ${actor.actor_id} may not modify strategy ${strategy.strategy_id} owned by ${strategy.analyst_id}`, {
      strategyId: strategy.strategy_id,
      owner: strategy.analyst_id,
    })
  }
  return true
}

/** 角色能力矩阵（供 UI 与文档展示）。 */
export function capabilityMatrix() {
  return Object.fromEntries(Object.entries(CAPABILITIES).map(([capability, roles]) => [capability, [...roles]]))
}
