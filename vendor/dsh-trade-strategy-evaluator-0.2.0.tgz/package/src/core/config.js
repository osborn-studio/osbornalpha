/**
 * 配置装载与校验。
 *
 * 评分规则**必须**可配置（实施方案 §9），绝不硬编码进 Agent Prompt：
 * 规则来自 `config/evaluation-rules.json`，权重之和必须为 1，且 `version`
 * 会写进每条 Evaluation 的 `calculation_version`，保证历史结果将来仍可解释。
 */

import { readFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { DEFAULT_ACTOR, normalizeIdentityPolicy } from './auth.js'
import { normalizePortfolioConfig } from './portfolio/ledger.js'
import { validation } from './errors.js'
import { DEFAULT_LANGUAGE, LANGUAGES, normalizeLanguage } from './i18n.js'

export const PACKAGE_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..')
export const DEFAULT_RULES_PATH = join(PACKAGE_ROOT, 'config', 'evaluation-rules.json')
export const DEFAULT_DEMO_PATH = join(PACKAGE_ROOT, 'config', 'demo-config.json')
export const DEFAULT_UNIVERSE_PATH = join(PACKAGE_ROOT, 'config', 'market-universe.json')

function readJson(path, label) {
  let text
  try {
    text = readFileSync(path, 'utf8')
  } catch (error) {
    throw validation(`cannot read ${label} at ${path}: ${error.message}`)
  }
  try {
    return JSON.parse(text)
  } catch (error) {
    throw validation(`${label} at ${path} is not valid JSON: ${error.message}`)
  }
}

const WEIGHT_KEYS = ['return', 'alpha', 'risk', 'target']

function assertNumber(value, label) {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw validation(`${label} must be a finite number`)
  return value
}

/** 校验并归一化评分规则。 */
export function parseEvaluationRules(raw, source = 'evaluation-rules.json') {
  if (typeof raw !== 'object' || raw === null) throw validation(`${source} must be a JSON object`)

  const weights = raw.weights
  if (typeof weights !== 'object' || weights === null) throw validation(`${source}.weights is required`)
  for (const key of WEIGHT_KEYS) assertNumber(weights[key], `${source}.weights.${key}`)
  const sum = WEIGHT_KEYS.reduce((acc, key) => acc + weights[key], 0)
  if (Math.abs(sum - 1) > 1e-9) throw validation(`${source}.weights must sum to 1, received ${sum}`)

  const scale = (section, fields) => {
    const value = raw[section]
    if (typeof value !== 'object' || value === null) throw validation(`${source}.${section} is required`)
    for (const field of fields) assertNumber(value[field], `${source}.${section}.${field}`)
    return Object.fromEntries(fields.map((field) => [field, value[field]]))
  }

  const returnScale = scale('return_scale', ['zero_score_return', 'full_score_return'])
  if (returnScale.full_score_return <= returnScale.zero_score_return) {
    throw validation(`${source}.return_scale.full_score_return must exceed zero_score_return`)
  }
  const alphaScale = scale('alpha_scale', ['zero_score_alpha', 'full_score_alpha'])
  if (alphaScale.full_score_alpha <= alphaScale.zero_score_alpha) {
    throw validation(`${source}.alpha_scale.full_score_alpha must exceed zero_score_alpha`)
  }
  const riskScale = scale('risk_scale', ['max_drawdown_tolerance', 'stop_loss_penalty_points'])
  if (riskScale.max_drawdown_tolerance <= 0) throw validation(`${source}.risk_scale.max_drawdown_tolerance must be positive`)
  const targetScale = scale('target_scale', ['target_reached', 'holding_ended_without_target', 'stop_loss_triggered'])

  const rounding = raw.rounding ?? {}
  const scoreDecimals = rounding.score_decimals ?? 0
  const ratioDecimals = rounding.ratio_decimals ?? 6

  return Object.freeze({
    version: typeof raw.version === 'string' && raw.version.length > 0 ? raw.version : 'v1',
    weights: Object.freeze({ ...weights }),
    returnScale: Object.freeze(returnScale),
    alphaScale: Object.freeze(alphaScale),
    riskScale: Object.freeze(riskScale),
    targetScale: Object.freeze(targetScale),
    rounding: Object.freeze({ scoreDecimals, ratioDecimals }),
  })
}

export function loadEvaluationRules(path = DEFAULT_RULES_PATH) {
  return parseEvaluationRules(readJson(path, 'evaluation rules'), path)
}

export function loadDemoConfig(path = DEFAULT_DEMO_PATH) {
  const raw = readJson(path, 'demo-config.json')
  if (!Array.isArray(raw.analysts) || raw.analysts.length === 0) throw validation('demo-config.json.analysts must be a non-empty array')
  for (const analyst of raw.analysts) {
    if (typeof analyst.analyst_id !== 'string' || analyst.analyst_id.length === 0) throw validation('each analyst needs a non-empty analyst_id')
    if (typeof analyst.name !== 'string' || analyst.name.length === 0) throw validation(`analyst ${analyst.analyst_id} needs a name`)
  }
  return raw
}

export function loadMarketUniverse(path = DEFAULT_UNIVERSE_PATH) {
  const raw = readJson(path, 'market-universe.json')
  if (typeof raw.tickers !== 'object' || raw.tickers === null || Object.keys(raw.tickers).length === 0) {
    throw validation('market-universe.json.tickers must be a non-empty object')
  }
  return raw
}

/** 插件/服务配置默认值（可由 cordis.patch.yml 的 config 覆盖）。 */
export const DEFAULT_PLUGIN_CONFIG = Object.freeze({
  enabled: true,
  label: '策略评估',
  order: 40,
  dataDir: undefined,
  storage: 'auto',
  monitor: true,
  monitorIntervalMs: 60000,
  seedOnStart: true,
  rulesPath: DEFAULT_RULES_PATH,
  demoPath: DEFAULT_DEMO_PATH,
  universePath: DEFAULT_UNIVERSE_PATH,
  language: DEFAULT_LANGUAGE,
  /**
   * 身份策略。DeepSeek Harness 不提供用户身份，所以：
   *   · `actor` 是部署者设定的默认身份（工具/HTTP 未显式传 actor 时使用）；
   *   · `requireVerified: true` 表示"高权角色不许自述"，
   *     此时 MANAGER/ADMIN 只能来自这一层配置，调用方传的一律拒绝。
   */
  identity: Object.freeze({
    actor: DEFAULT_ACTOR,
    requireVerified: false,
    elevatedRoles: Object.freeze(['MANAGER', 'ADMIN']),
  }),
  /**
   * 模拟盘组合层（批次 1）。口径一旦落库就靠 `accounting_version`（`w1`）锁定，
   * 改这些值会改变后续的净值曲线，因此它们与评分规则同级：**属部署配置，不属代码**。
   */
  portfolio: Object.freeze({
    startNav: 100,
    defaultWeightPct: 10,
    defaultMaxPositionPct: 100,
    evictionStrategy: 'fifo',
  }),
})

export function normalizePluginConfig(input) {
  const raw = typeof input === 'object' && input !== null ? input : {}
  const config = { ...DEFAULT_PLUGIN_CONFIG }
  if (raw.evaluator !== undefined) {
    if (!['local', 'alpha-connected'].includes(raw.evaluator?.mode)) throw validation('invalid evaluator mode')
    config.evaluator = { mode: raw.evaluator.mode, remote: raw.evaluator.remote }
  }
  if (typeof raw.enabled === 'boolean') config.enabled = raw.enabled
  if (typeof raw.label === 'string' && raw.label.trim().length > 0) config.label = raw.label.trim()
  if (typeof raw.order === 'number' && Number.isFinite(raw.order)) config.order = raw.order
  if (typeof raw.dataDir === 'string' && raw.dataDir.length > 0) config.dataDir = raw.dataDir
  if (['auto', 'sqlite', 'json'].includes(raw.storage)) config.storage = raw.storage
  if (typeof raw.monitor === 'boolean') config.monitor = raw.monitor
  if (typeof raw.monitorIntervalMs === 'number' && raw.monitorIntervalMs >= 1000) config.monitorIntervalMs = raw.monitorIntervalMs
  if (typeof raw.seedOnStart === 'boolean') config.seedOnStart = raw.seedOnStart
  if (typeof raw.rulesPath === 'string' && raw.rulesPath.length > 0) config.rulesPath = raw.rulesPath
  if (typeof raw.demoPath === 'string' && raw.demoPath.length > 0) config.demoPath = raw.demoPath
  if (typeof raw.universePath === 'string' && raw.universePath.length > 0) config.universePath = raw.universePath
  if (typeof raw.language === 'string' && raw.language.length > 0) {
    const normalized = normalizeLanguage(raw.language, '')
    if (LANGUAGES.includes(normalized)) config.language = normalized
  }
  if (raw.portfolio !== undefined) {
    config.portfolio = { ...normalizePortfolioConfig(raw.portfolio) }
  }
  if (raw.identity !== undefined) {
    // 校验在 auth.js 里（策略与角色知识都在那边），这里只负责接线
    const identity = normalizeIdentityPolicy(raw.identity)
    config.identity = {
      actor: identity.actor ?? DEFAULT_ACTOR,
      requireVerified: identity.requireVerified,
      elevatedRoles: identity.elevatedRoles,
    }
  }
  return config
}
