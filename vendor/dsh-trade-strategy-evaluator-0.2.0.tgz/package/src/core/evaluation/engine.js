/** Local host I/O adapter; calculation lives in the independently consumable engine. */
import { digest } from '../../engine/canonical.js'
import { evaluateStrategyBars } from '../../engine/strategy.js'
import { validation, lookahead } from '../errors.js'
export { deriveStatusFromPerformance } from '../../engine/strategy.js'
export async function evaluateFrozenStrategy({ strategy, provider, rules, asOf, quantity = 1 }) {
  if (strategy?.frozen !== true) throw validation('strategy must be frozen before evaluation')
  if (typeof asOf !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(asOf)) throw validation('as_of must be a YYYY-MM-DD date')
  const from = new Date(strategy.frozen_at).toISOString().slice(0, 10)
  if (asOf < from) throw lookahead('evaluation precedes freeze')
  const bars = await provider.getHistory(strategy.ticker, from, asOf)
  const benchmarkBars = await provider.getBenchmark(strategy.benchmark, from, asOf)
  const replay_input = structuredClone({ strategy, bars, benchmarkBars, rules, asOf, quantity })
  // Only calculation fields of strategy enter the snapshot, not changing host projections.
  delete replay_input.strategy.performance
  delete replay_input.strategy.evaluation_id
  delete replay_input.strategy.updated_at
  delete replay_input.strategy.status
  delete replay_input.strategy.status_reason
  return { ...evaluateStrategyBars(replay_input), replay_input, replay_sha256: digest(replay_input) }
}
