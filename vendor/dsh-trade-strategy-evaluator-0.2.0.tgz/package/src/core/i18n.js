/**
 * 中英文语言支持（i18n）。
 *
 * 作用范围（刻意划清，避免"半个 i18n"）：
 *  - **切换**：报告模板（策略/分析师/团队）与所有面向人的文字，随 `language` 变化；
 *  - **不切换**：错误码与错误 `message`。它们是诊断信息，保持单一英文表述，
 *    这样日志、测试与排错反馈永远可搜可对；UI 负责把它翻译成人话。
 *  - **不切换**：`AGENT.md` / `SKILL.md`（模型指令，不是 UI）。
 *
 * 语言取值归一化后只有 `zh`（简体中文）与 `en`（English）。默认 `zh`，
 * 可由插件配置 `language`、API 的 `?lang=` / `Accept-Language`、或工具参数 `language` 覆盖。
 */

export const LANGUAGES = Object.freeze(['zh', 'en'])
export const DEFAULT_LANGUAGE = 'zh'

/**
 * 归一化语言标识：接受 `zh`、`zh-CN`、`zh-Hans-CN`、`en`、`en-US`、`Accept-Language` 串等。
 * 认不出时返回 `fallback`（默认 `zh`），而不是抛错 —— 语言偏好不该让业务失败。
 * @param {unknown} input
 * @param {string} [fallback]
 */
export function normalizeLanguage(input, fallback = DEFAULT_LANGUAGE) {
  if (typeof input === 'string' && input.trim().length > 0) {
    // `Accept-Language: zh-CN,zh;q=0.9,en;q=0.8` → 取第一个标签
    const first = input.split(',')[0]?.trim() ?? ''
    const tag = first.split(';')[0]?.trim().toLowerCase() ?? ''
    if (tag.startsWith('zh')) return 'zh'
    if (tag.startsWith('en')) return 'en'
  }
  return LANGUAGES.includes(fallback) ? fallback : DEFAULT_LANGUAGE
}

/** 语言的中文/英文自名（用于语言切换器显示）。 */
export const LANGUAGE_LABELS = Object.freeze({ zh: '中文', en: 'English' })

/**
 * 报告文案表。所有报告里出现的自然语言都从这里取，
 * 因此"加一种语言"= 加一张表，而不是散落各处改字符串。
 */
export const REPORT_TEXT = Object.freeze({
  zh: Object.freeze({
    strategyTitle: '# 交易策略评估报告',
    strategy: '策略',
    originalStrategy: '原始策略',
    marketSnapshot: '提交时的市场快照',
    actualPerformance: '实际表现',
    ruleEvaluation: '规则判定',
    analystCommentary: '模型分析（非事实数据）',
    finalScore: '最终评分',
    notEvaluatedYet: '尚未评价：持仓期还没有走完。',

    strategyId: '策略 ID',
    analyst: '分析师',
    ticker: '标的',
    action: '方向',
    submitted: '提交时间',
    status: '状态',
    frozenAt: '冻结时间',
    entry: '入场价',
    target: '目标价',
    stop: '止损价',
    holdingPeriod: '预期持仓',
    benchmark: '对比基准',
    positionBefore: '提交前仓位',
    price: '价格',
    timestamp: '时间戳',
    volume: '成交量',
    exit: '退出价',
    exitDate: '退出日',
    returnPct: '策略收益',
    benchmarkReturn: '基准收益',
    alpha: '超额收益 Alpha',
    maxDrawdown: '最大回撤',
    volatility: '年化波动率',
    pnl: '盈亏金额',
    holdingDays: '持仓交易日',
    exitReason: '退出原因',
    riskReward: '盈亏比',

    targetReachedOn: '已于 {date} 达到',
    targetNotReached: '未达到',
    stopTriggeredOn: '已于 {date} 触发',
    stopNotTriggered: '未触发',
    outperformed: '跑赢基准',
    underperformed: '跑输基准',
    inLine: '与基准持平',

    scoreBreakdown: '评分构成（各分项 0-100，按权重加权）：',
    scoreVersion: '评分公式版本',
    days: '个交易日',
    factsFooter: '以上事实数据全部由确定性 Evaluation Engine 计算，可重复验证。',
    sessionLabel: '会话',

    commentaryNoContent: '（本区由模型生成；未提供评论时保持为空，事实数据在上方。）',
  }),

  en: Object.freeze({
    strategyTitle: '# Trading Strategy Evaluation Report',
    strategy: 'Strategy',
    originalStrategy: 'Original Strategy',
    marketSnapshot: 'Market Snapshot At Submission',
    actualPerformance: 'Actual Performance',
    ruleEvaluation: 'Rule Evaluation',
    analystCommentary: 'Analyst Commentary',
    finalScore: 'Final Score',
    notEvaluatedYet: 'Not evaluated yet: the holding period has not completed.',

    strategyId: 'Strategy ID',
    analyst: 'Analyst',
    ticker: 'Ticker',
    action: 'Action',
    submitted: 'Submitted',
    status: 'Status',
    frozenAt: 'Frozen at',
    entry: 'Entry',
    target: 'Target',
    stop: 'Stop',
    holdingPeriod: 'Holding Period',
    benchmark: 'Benchmark',
    positionBefore: 'Position Before',
    price: 'Price',
    timestamp: 'Timestamp',
    volume: 'Volume',
    exit: 'Exit',
    exitDate: 'Exit Date',
    returnPct: 'Return',
    benchmarkReturn: 'Benchmark',
    alpha: 'Alpha',
    maxDrawdown: 'Max Drawdown',
    volatility: 'Volatility (annualized)',
    pnl: 'P&L',
    holdingDays: 'Holding Days',
    exitReason: 'Exit Reason',
    riskReward: 'Risk/Reward',

    targetReachedOn: 'Reached on {date}',
    targetNotReached: 'Not Reached',
    stopTriggeredOn: 'Triggered on {date}',
    stopNotTriggered: 'Not Triggered',
    outperformed: 'Outperformed',
    underperformed: 'Underperformed',
    inLine: 'In Line',

    scoreBreakdown: 'Score breakdown (weighted, 0-100 each):',
    scoreVersion: 'Score calculation version',
    days: 'days',
    factsFooter: 'All factual metrics above are computed by the deterministic Evaluation Engine and are reproducible.',
    sessionLabel: 'Session',

    commentaryNoContent: '_(This section is model-generated; it stays empty when no commentary is supplied. The factual data is above.)_',
  }),
})

/** 分析师绩效报告文案。 */
export const PERFORMANCE_TEXT = Object.freeze({
  zh: Object.freeze({
    analystTitle: '# 分析师绩效报告 — {name}',
    teamTitle: '# 团队绩效报告',
    factual: '## 事实数据',
    commentary: '## 模型评论',
    strategyHistory: '## 策略历史',
    metric: '指标',
    value: '数值',
    headers: ['策略', '标的', '方向', '收益', '基准', 'Alpha', '评分', '状态'],
    teamHeaders: ['团队', '分析师数', '策略数', '胜率', '平均收益', '平均 Alpha', '最大回撤', '平均评分'],
    noCommentary: '_（未提供评论。）_',
    metrics: {
      analyst_count: '分析师数',
      strategies: '策略总数', evaluated: '已完成评价', pending_evaluation: '待评价', active: '跟踪中',
      completed: '已完成', stopped: '已止损', expired: '已过期', cancelled: '已取消',
      wins: '盈利笔数', losses: '亏损笔数', win_rate: '胜率', average_return: '平均收益',
      median_return: '收益中位数', best_return: '最佳单笔', worst_return: '最差单笔',
      average_alpha: '平均 Alpha', positive_alpha_count: '跑赢基准数', negative_alpha_count: '跑输基准数',
      hit_rate_vs_benchmark: '跑赢基准比例', max_drawdown: '最大回撤', average_drawdown: '平均回撤',
      average_score: '平均评分', target_achievement_rate: '目标达成率', stop_loss_rate: '止损触发率',
      total_pnl: '累计盈亏',
    },
  }),

  en: Object.freeze({
    analystTitle: '# Analyst Performance Report — {name}',
    teamTitle: '# Team Performance Report',
    factual: '## FACTUAL METRICS',
    commentary: '## LLM COMMENTARY',
    strategyHistory: '## Strategy History',
    metric: 'Metric',
    value: 'Value',
    headers: ['Strategy', 'Ticker', 'Action', 'Return', 'Benchmark', 'Alpha', 'Score', 'Status'],
    teamHeaders: ['Team', 'Analysts', 'Strategies', 'Win Rate', 'Avg Return', 'Avg Alpha', 'Max Drawdown', 'Avg Score'],
    noCommentary: '_(No commentary supplied.)_',
    metrics: {
      analyst_count: 'Analysts',
      strategies: 'Strategies', evaluated: 'Evaluated', pending_evaluation: 'Pending evaluation', active: 'Active',
      completed: 'Completed', stopped: 'Stopped out', expired: 'Expired', cancelled: 'Cancelled',
      wins: 'Winning trades', losses: 'Losing trades', win_rate: 'Win rate', average_return: 'Average return',
      median_return: 'Median return', best_return: 'Best trade', worst_return: 'Worst trade',
      average_alpha: 'Average alpha', positive_alpha_count: 'Outperformed count', negative_alpha_count: 'Underperformed count',
      hit_rate_vs_benchmark: 'Benchmark hit rate', max_drawdown: 'Max drawdown', average_drawdown: 'Average drawdown',
      average_score: 'Average score', target_achievement_rate: 'Target achievement rate', stop_loss_rate: 'Stop-loss rate',
      total_pnl: 'Total P&L',
    },
  }),
})

/** 取报告文案表。 */
export function reportText(language) {
  return REPORT_TEXT[normalizeLanguage(language)]
}

/** 取绩效报告文案表。 */
export function performanceText(language) {
  return PERFORMANCE_TEXT[normalizeLanguage(language)]
}

/** 评论免责声明（每种语言一句，随报告语言变化）。 */
export function commentaryDisclaimer(language) {
  return normalizeLanguage(language) === 'en'
    ? 'The following is model-generated analytical commentary and is not part of the original factual data.'
    : '以下内容为模型生成的分析性解释，不属于原始事实数据。'
}

/** `{name}` 占位替换。 */
export function fillTemplate(template, params) {
  return String(template).replace(/\{(\w+)\}/g, (match, key) => (key in params ? String(params[key]) : match))
}
