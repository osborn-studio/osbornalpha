/**
 * 业务 ID 生成。
 *
 * 格式（与实施方案 §7 / §8 一致）：
 *   strategy:   STR-YYYYMMDD-NNN
 *   evaluation: EVAL-YYYYMMDD-NNN
 *   report:     RPT-YYYYMMDD-NNN
 *
 * 序号由 Repository 持久化分配，保证同一进程重启后不重号。
 * 每个 Strategy 必有 Strategy ID，每次 Evaluation 必有 Evaluation ID（§6 规则 10/11）。
 */

import { formatDate } from './time.js'
import { validation } from './errors.js'

const PATTERNS = {
  strategy: 'STR',
  evaluation: 'EVAL',
  report: 'RPT',
}

export function formatBusinessId(kind, date, sequence) {
  const prefix = PATTERNS[kind]
  if (prefix === undefined) throw validation(`unknown id kind "${kind}"`)
  if (!Number.isInteger(sequence) || sequence < 1) throw validation(`sequence must be a positive integer, received ${sequence}`)
  return `${prefix}-${formatDate(date).replaceAll('-', '')}-${String(sequence).padStart(3, '0')}`
}

export function isBusinessId(kind, value) {
  const prefix = PATTERNS[kind]
  if (prefix === undefined) return false
  return new RegExp(`^${prefix}-\\d{8}-\\d{3}$`).test(String(value))
}

/**
 * @param {{ nextSequence: (kind: string, dayKey: string) => number }} counters 由 Repository 提供
 */
export function createIdFactory(counters) {
  return {
    /** @param {Date} at 生成时刻（决定日期段） */
    async strategy(at) {
      const dayKey = formatDate(at)
      return formatBusinessId('strategy', at, (await counters.nextSequence('strategy', dayKey)))
    },
    async evaluation(at) {
      const dayKey = formatDate(at)
      return formatBusinessId('evaluation', at, (await counters.nextSequence('evaluation', dayKey)))
    },
    async report(at) {
      const dayKey = formatDate(at)
      return formatBusinessId('report', at, (await counters.nextSequence('report', dayKey)))
    },
  }
}
