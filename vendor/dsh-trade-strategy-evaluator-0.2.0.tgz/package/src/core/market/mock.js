/**
 * MockMarketDataProvider —— 确定性模拟行情（实施方案 §16）。
 *
 * 价格模型（纯函数，可对任意日期区间直接求值）：
 *
 *   log P(i) = log(base_price)
 *            + drift · i                                   // 趋势
 *            + cycle_amp · sin(2π (i + phase) / period)     // 周期，制造上涨/下跌阶段
 *            + sigma · Σ_{k=1..i} gauss(seed, k)            // 可复现随机游走
 *
 * 其中 `i` 是自 `history_epoch` 起的第 i 个交易日。同一 (ticker, i) 永远得到同一价格，
 * 因此策略的历史表现、Replay 与重复评价结果完全一致。
 *
 * 提供 5 个 Demo 标的（AAPL/NVDA/MSFT/TSLA/AMZN）与 2 个 Benchmark（QQQ/SPY），
 * 且通过"不同 ticker 的 drift / cycle_phase 差异 + 入场点落在周期的不同相位"
 * 稳定构造出上涨、下跌、触发止损、达到目标、跑赢/跑输 Benchmark 六类结果。
 */

import { MarketDataProvider } from './provider.js'
import { gaussian, uniform } from './random.js'
import { addDays, formatDate, parseDate, TradingCalendar } from '../time.js'
import { lookahead, validation } from '../errors.js'

const INTRADAY_CLOSE_HOUR_UTC = 20

/**
 * 每交易日一个 bar 的确定性生成器。
 *
 * 刻意保持**无状态纯函数**语义：`indexOf` / `logPriceAt` / `bar` 都只依赖
 * (ticker spec, 日期)，不依赖调用顺序，因此可以随机访问任意日期区间，
 * Replay 与重算永远不会因为"先查了哪一天"而改变结果。
 */
class SeriesGenerator {
  constructor(ticker, spec, calendar, epoch) {
    this.ticker = ticker
    this.spec = spec
    this.calendar = calendar
    this.epoch = parseDate(epoch)
    /** @type {Map<string, number>} 日期 → 交易日序号 */
    this.indexCache = new Map([[formatDate(this.epoch), 0]])
    /** @type {Map<number, number>} 序号 → 累计噪声 */
    this.noiseCache = new Map([[0, 0]])
  }

  /** 交易日序号：epoch 当天为 0。非交易日归到其前一个交易日。 */
  indexOf(date) {
    const target = this.calendar.previousTradingDay(date)
    const key = formatDate(target)
    const cached = this.indexCache.get(key)
    if (cached !== undefined) return cached

    let index = 0
    let cursor = this.epoch
    let guard = 0
    while (cursor.getTime() < target.getTime()) {
      guard += 1
      if (guard > 5000) throw validation(`series walk exceeded 5000 steps for ${this.ticker}`)
      cursor = addDays(cursor, 1)
      if (!this.calendar.isTradingDay(cursor)) continue
      index += 1
      this.indexCache.set(formatDate(cursor), index)
    }
    return index
  }

  /** 累计随机游走噪声 Σ_{k=1..index} gauss(seed, k)，带前缀缓存。 */
  noiseAt(index) {
    const cached = this.noiseCache.get(index)
    if (cached !== undefined) return cached
    // 向前找到最近的已缓存前缀，然后单向前进补齐。
    let start = index - 1
    while (start > 0 && !this.noiseCache.has(start)) start -= 1
    let running = this.noiseCache.get(start) ?? 0
    for (let k = start + 1; k <= index; k += 1) {
      running += gaussian(this.spec.seed, k)
      this.noiseCache.set(k, running)
    }
    return running
  }

  logPriceAt(index) {
    const { base_price: base, drift, cycle_amp: amp, cycle_period: period, cycle_phase: phase, sigma } = this.spec
    return (
      Math.log(base)
      + drift * index
      + amp * Math.sin((2 * Math.PI * (index + phase)) / period)
      + sigma * this.noiseAt(index)
    )
  }

  /** 生成某交易日的完整 bar。 */
  bar(date) {
    const day = this.calendar.previousTradingDay(date)
    const index = this.indexOf(day)
    const close = Math.exp(this.logPriceAt(index))
    const prevIndex = Math.max(0, index - 1)
    const prevClose = Math.exp(this.logPriceAt(prevIndex))
    const open = prevIndex === index ? close : prevClose * (1 + 0.0025 * gaussian(this.spec.seed, 'open', index))
    const swing = 0.004 + 0.010 * uniform(this.spec.seed, 'swing', index)
    const high = Math.max(open, close) * (1 + swing)
    const low = Math.min(open, close) * (1 - swing)
    const volume = Math.round(this.spec.base_volume * (0.7 + 0.6 * uniform(this.spec.seed, 'volume', index)))
    const date10 = formatDate(day)
    return {
      ticker: this.ticker,
      date: date10,
      timestamp: `${date10}T${String(INTRADAY_CLOSE_HOUR_UTC).padStart(2, '0')}:00:00Z`,
      open: round(open),
      high: round(high),
      low: round(low),
      close: round(close),
      volume,
    }
  }
}

function round(value) {
  return Math.round(value * 10000) / 10000
}

export class MockMarketDataProvider extends MarketDataProvider {
  /**
   * @param {object} options
   * @param {object} options.universe market-universe.json
   * @param {() => Date} options.now 当前"结算交易日"提供者（来自 Clock，保证与冻结时间同轴）
   */
  constructor({ universe, now }) {
    super()
    if (typeof universe !== 'object' || universe === null) throw validation('mock market data requires a universe config')
    if (typeof now !== 'function') throw validation('mock market data requires a now() provider')
    this.universe = universe
    this.now = now
    this.calendar = new TradingCalendar({ holidays: universe.holidays ?? [] })
    this.epoch = universe.history_epoch ?? '2026-01-02'
    this.series = new Map()
    for (const [ticker, spec] of Object.entries(universe.tickers)) {
      this.series.set(ticker.toUpperCase(), new SeriesGenerator(ticker.toUpperCase(), spec, this.calendar, this.epoch))
    }
  }

  get name() {
    return 'mock'
  }

  /** 数据边界 = 当前交易日的收盘 bar。 */
  boundary() {
    return formatDate(this.calendar.previousTradingDay(this.now()))
  }

  listTickers() {
    return [...this.series.keys()].sort()
  }

  listBenchmarks() {
    return [...this.series.entries()].filter(([, gen]) => gen.spec.is_benchmark === true).map(([ticker]) => ticker).sort()
  }

  #generator(ticker) {
    const key = String(ticker ?? '').toUpperCase()
    const generator = this.series.get(key)
    if (generator === undefined) {
      throw validation(`unknown ticker "${ticker}"`, { knownTickers: this.listTickers() })
    }
    return generator
  }

  async getHistory(ticker, from, to) {
    const generator = this.#generator(ticker)
    const start = from === undefined ? this.epoch : formatDate(parseDate(from))
    const end = to === undefined ? this.boundary() : formatDate(parseDate(to))
    this.assertWithinBoundary(generator.ticker, end)
    if (start > end) throw validation(`history range ${start}..${end} is inverted`)

    const bars = []
    for (const day of this.calendar.tradingDaysBetween(parseDate(start), parseDate(end))) {
      bars.push(generator.bar(day))
    }
    return bars
  }

  async getBenchmark(ticker, from, to) {
    const generator = this.#generator(ticker)
    if (generator.spec.is_benchmark !== true) {
      throw validation(`"${ticker}" is not configured as a benchmark`, { benchmarks: this.listBenchmarks() })
    }
    return this.getHistory(ticker, from, to)
  }

  async getQuote(ticker, at) {
    const generator = this.#generator(ticker)
    const requested = at === undefined ? this.boundary() : formatDate(parseDate(at))
    const day = this.calendar.previousTradingDay(requested)
    const dayKey = formatDate(day)
    this.assertWithinBoundary(generator.ticker, dayKey)
    const bar = generator.bar(day)
    return { ticker: generator.ticker, price: bar.close, timestamp: bar.timestamp, volume: bar.volume }
  }

  async getSnapshot(ticker, at) {
    const quote = await this.getQuote(ticker, at)
    // 快照必须固化"提交当时的市场状态"，因此带上边界日期，便于审计核对。
    return { ...quote, as_of: this.boundary(), source: this.name }
  }

  /** 便捷方法：单日 bar（不存在则抛错，而不是返回未来数据）。 */
  async getBar(ticker, date) {
    const bars = await this.getHistory(ticker, date, date)
    if (bars.length === 0) {
      throw lookahead(`no trading bar for ${ticker} on ${date}`)
    }
    return bars[0]
  }
}
