/**
 * MarketDataProvider —— 统一行情接口（实施方案 §5.2）。
 *
 * 业务层只依赖本抽象，绝不依赖具体行情供应商。POC 使用 MockMarketDataProvider；
 * 未来替换 Polygon / Alpha Vantage / Yahoo Finance / Bloomberg / 内部行情服务时，
 * 只要实现同样 4 个方法即可，业务代码零改动。
 *
 * 契约（所有实现必须遵守）：
 *  - `getQuote(ticker)`            → { ticker, price, timestamp, volume }
 *  - `getHistory(ticker, from, to)`→ Bar[]（按时间升序，闭区间）
 *  - `getBenchmark(ticker, f, to)` → Bar[]（与 getHistory 同源，单独命名以表达语义）
 *  - `getSnapshot(ticker)`         → { ticker, price, timestamp, volume, source }
 *
 * 硬约束：任何实现都**不得**返回晚于 `boundary()` 的数据。这是"禁止使用未来信息"
 * 的结构性保证（§2 / §6 规则 5 / §21），违反时抛 `LOOKAHEAD_VIOLATION`。
 */

import { lookahead } from '../errors.js'

/** @typedef {{ ticker: string, date: string, timestamp: string, open: number, high: number, low: number, close: number, volume: number }} Bar */

export class MarketDataProvider {
  /** 提供商标识，写进 Snapshot 的 `source` 字段用于审计。 */
  get name() {
    return 'abstract'
  }

  /** 数据可用上界（含）。行情与快照一律不得越过该交易日。 */
  boundary() {
    throw new Error('MarketDataProvider.boundary() must be implemented')
  }

  /** @returns {Promise<Bar[]>} */
  async getHistory() {
    throw new Error('MarketDataProvider.getHistory() must be implemented')
  }

  /** @returns {Promise<Bar[]>} */
  async getBenchmark(ticker, from, to) {
    return this.getHistory(ticker, from, to)
  }

  /** @returns {Promise<{ticker: string, price: number, timestamp: string, volume: number, source: string}>} */
  async getQuote() {
    throw new Error('MarketDataProvider.getQuote() must be implemented')
  }

  async getSnapshot(ticker, at) {
    const quote = await this.getQuote(ticker, at)
    return { ...quote, source: this.name }
  }

  /** 已知标的列表（用于校验与 UI 下拉）。 */
  listTickers() {
    return []
  }

  /**
   * 断言请求区间不越过边界。所有实现都应在读取前调用。
   * @param {string} ticker
   * @param {string} to 请求上界（YYYY-MM-DD）
   */
  assertWithinBoundary(ticker, to) {
    const limit = this.boundary()
    if (to > limit) {
      throw lookahead(
        `refusing to read ${ticker} up to ${to}: market data beyond ${limit} is not available yet`,
        { ticker, requestedTo: to, boundary: limit },
      )
    }
  }
}
