/**
 * 确定性伪随机工具。
 *
 * Mock 行情必须是"同一 (ticker, 日期) 永远得到同一价格"的纯函数，否则
 * Replay 与重复评价就无法得到一致结果（实施方案 §5.3 / §26）。因此这里不用
 * `Math.random()`，而是用整数哈希 + 固定种子的 PRNG。
 */

/** 32 位整数哈希（FNV-1a 变体）。 */
export function hash32(...parts) {
  let h = 0x811c9dc5
  for (const part of parts) {
    let value = typeof part === 'number' ? Math.trunc(part) >>> 0 : String(part)
    if (typeof value === 'string') {
      for (let i = 0; i < value.length; i += 1) {
        h ^= value.charCodeAt(i)
        h = Math.imul(h, 0x01000193) >>> 0
      }
      continue
    }
    for (let i = 0; i < 4; i += 1) {
      h ^= (value >>> (i * 8)) & 0xff
      h = Math.imul(h, 0x01000193) >>> 0
    }
  }
  return h >>> 0
}

/** mulberry32：小而稳定的 PRNG。 */
export function mulberry32(seed) {
  let state = seed >>> 0
  return function next() {
    state = (state + 0x6d2b79f5) >>> 0
    let t = state
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/** 由任意组件派生一个 [0,1) 均匀随机数。 */
export function uniform(...parts) {
  return mulberry32(hash32(...parts))()
}

/** 由任意组件派生标准正态随机数（Box–Muller，用同一哈希派生两个均匀量）。 */
export function gaussian(...parts) {
  const next = mulberry32(hash32(...parts))
  const u1 = Math.max(next(), Number.EPSILON)
  const u2 = next()
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2)
}
