/**
 * 不可篡改性守卫（实施方案 §5.1 / §18 / §21）。
 *
 * `CORE_FIELDS` 是**影响评价结果**的字段集合。策略一旦 FREEZE：
 *   - 任何改写核心字段的尝试都会抛 `FROZEN_STRATEGY_IMMUTABLE`；
 *   - 监控与评价只能写 `status` / `performance` / `updated_at` 等非决策字段。
 *
 * 这里刻意用"字段级白名单 + 深比较"实现，而不是信任调用方自觉，
 * 因此即使未来有人新写了绕过 Service 的代码，也会在写库前失败。
 */

import { frozenImmutable, validation } from '../errors.js'

/** 冻结后不可修改的字段。 */
export const CORE_FIELDS = Object.freeze([
  'strategy_id',
  'analyst_id',
  'ticker',
  'action',
  'position_before',
  'entry_price',
  'target_price',
  'stop_loss',
  'holding_period',
  'benchmark',
  'reason',
  'quantity',
  // 组合层的建仓规模：改它等于改模拟盘的测评结果，因此和 entry_price 同级受保护
  'weight_pct',
  'market_snapshot',
  'created_at',
  'created_by',
  'frozen_at',
  'frozen_by',
])

/** 冻结后仍允许变更的字段（监控/评价/生命周期推进）。 */
export const MUTABLE_AFTER_FREEZE = Object.freeze([
  'status',
  'status_reason',
  'performance',
  'updated_at',
  'evaluation_id',
  'cancelled_at',
  'cancelled_by',
  'cancel_reason',
])

function stable(value) {
  return JSON.stringify(value ?? null)
}

/**
 * 断言 `next` 相对 `previous` 没有改动任何核心字段。
 * @param {object} previous 已冻结的原始记录
 * @param {object} next 待写入的记录
 */
export function assertCoreImmutable(previous, next) {
  // 只保护**已经冻结**的记录。
  //
  // 原条件还额外接受"frozen_at 已存在"的情形，但 DRAFT 记录带着 `frozen_at: null`，
  // 于是 DRAFT → 冻结这一步（它必然要写 frozen_at / frozen_by）会被守卫拦住 ——
  // 守卫把"合法的一次性状态跃迁"误判成"篡改"。而 `frozen: true` 已经足以表达
  // "这条记录已经进过冻结态"，不需要再加一个容易误伤的条件。
  if (previous?.frozen !== true) return true
  const changed = CORE_FIELDS.filter((field) => stable(previous[field]) !== stable(next[field]))
  if (changed.length > 0) {
    throw frozenImmutable(
      `frozen strategy ${previous.strategy_id} cannot be modified: attempted change to ${changed.join(', ')}`,
      { strategyId: previous.strategy_id, fields: changed },
    )
  }
  return true
}

/**
 * 校验并挑出允许写入的字段（未知字段直接拒绝，避免"顺手加字段"污染审计）。
 */
export function pickMutableFields(patch) {
  if (typeof patch !== 'object' || patch === null) throw validation('patch must be an object')
  const unknown = Object.keys(patch).filter((key) => !MUTABLE_AFTER_FREEZE.includes(key))
  if (unknown.length > 0) {
    throw frozenImmutable(`fields ${unknown.join(', ')} are not mutable after freeze`, { fields: unknown })
  }
  return Object.fromEntries(Object.entries(patch).filter(([, value]) => value !== undefined))
}

/** 事件的 payload 统一形状，便于 Replay 直接渲染。 */
export function auditEventPayload(data) {
  return Object.fromEntries(Object.entries(data ?? {}).filter(([, value]) => value !== undefined))
}
