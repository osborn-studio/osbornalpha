/**
 * Strategy Monitor（实施方案 §5.4）。
 *
 * 流程：Scheduler → 取 ACTIVE 策略 → 取最新行情 → 更新 Strategy Performance
 *       → 检查 Target → 检查 Stop Loss → 检查 Expiration → 更新状态。
 *
 * 关键约束：监控只允许改写 `status` 与 `performance`（非决策数据），
 * **绝不触碰任何影响评价结果的核心字段**。核心字段的守卫在 trade-strategy 插件里。
 */

import { computeReturn, detectStopLoss, detectTarget, roundTo } from '../evaluation/metrics.js'
import { auditEventPayload, assertCoreImmutable } from './immutability.js'
import { formatDate, formatTimestamp } from '../time.js'
/**
 * 计算一只策略在给定交易日的浮动表现。
 * @returns {Promise<object|null>} 无法取到行情时返回 null（例如上市日之前）
 */
export async function computeLivePerformance({ strategy, provider, calendar, asOf }) {
  const frozenDate = formatDate(new Date(strategy.frozen_at))
  if (asOf < frozenDate) return null

  let bars
  try {
    bars = await provider.getHistory(strategy.ticker, frozenDate, asOf)
  } catch {
    return null
  }
  if (bars.length === 0) return null

  const action = strategy.action
  const closes = bars.map((bar) => bar.close)
  const last = closes.at(-1)
  const extremes = action === 'SELL' ? bars.map((bar) => bar.high) : bars.map((bar) => bar.low)
  const targetExtremes = action === 'SELL' ? bars.map((bar) => bar.low) : bars.map((bar) => bar.high)

  const stop = detectStopLoss({ action, prices: extremes, stopLoss: strategy.stop_loss })
  const target = detectTarget({ action, prices: targetExtremes, targetPrice: strategy.target_price })
  const benchmarkBars = await provider.getBenchmark(strategy.benchmark, frozenDate, asOf).catch(() => [])

  const unrealized = computeReturn({ action, entryPrice: strategy.entry_price, exitPrice: last })
  const benchmarkUnrealized = benchmarkBars.length === 0
    ? null
    : roundTo((benchmarkBars.at(-1).close - benchmarkBars[0].close) / benchmarkBars[0].close, 6)

  return {
    as_of: asOf,
    price: last,
    unrealized_return: unrealized,
    unrealized_alpha: benchmarkUnrealized === null ? null : roundTo(unrealized - benchmarkUnrealized, 6),
    holding_days: bars.length,
    peak_price: Math.max(...closes),
    trough_price: Math.min(...closes),
    target_reached: target.reached,
    target_reached_on: target.reachedAt === null ? null : bars[target.reachedAt].date,
    stop_loss_triggered: stop.triggered,
    stop_loss_triggered_on: stop.triggeredAt === null ? null : bars[stop.triggeredAt].date,
    last_bar_timestamp: bars.at(-1).timestamp,
    updated_at: formatTimestamp(new Date()),
  }
}

/**
 * 依据浮动表现推导新的状态。
 * ACTIVE → STOPPED（止损）/ COMPLETED（持有期满）/ EXPIRED（超过计划期仍未结束）
 */
export function deriveStatus({ strategy, performance }) {
  if (performance.stop_loss_triggered) return { status: 'STOPPED', reason: 'STOP_LOSS' }
  if (performance.holding_days >= strategy.holding_period) return { status: 'COMPLETED', reason: 'HOLDING_PERIOD_END' }
  // 允许一个宽限期（计划期 + 50%），超过仍未评价则视为 EXPIRED，避免僵尸策略。
  if (performance.holding_days >= Math.ceil(strategy.holding_period * 1.5)) return { status: 'EXPIRED', reason: 'HOLDING_PERIOD_EXCEEDED' }
  return { status: 'ACTIVE', reason: null }
}

/**
 * 监控单只策略：返回新的 strategy 记录与应产生的事件（不落库，由 Service 落库）。
 *
 * @param {object} input
 * @param {object} input.strategy
 * @param {object} input.provider
 * @param {import('../time.js').TradingCalendar} input.calendar
 * @param {string} input.asOf
 * @param {object} [input.actor]
 */
export async function monitorStrategy({ strategy, provider, calendar, asOf, actor = null }) {
  const performance = await computeLivePerformance({ strategy, provider, calendar, asOf })
  if (performance === null) {
    return { changed: false, strategy, events: [], reason: 'NO_MARKET_DATA' }
  }

  const previous = strategy.performance ?? null
  const derived = deriveStatus({ strategy, performance })
  const events = []

  if (previous === null || previous.target_reached !== performance.target_reached) {
    if (performance.target_reached) {
      events.push({
        type: 'TARGET_REACHED',
        payload: auditEventPayload({ price: performance.price, target_price: strategy.target_price, on: performance.target_reached_on }),
      })
    }
  }
  if (previous === null || previous.stop_loss_triggered !== performance.stop_loss_triggered) {
    if (performance.stop_loss_triggered) {
      events.push({
        type: 'STOP_LOSS_TRIGGERED',
        payload: auditEventPayload({ price: performance.price, stop_loss: strategy.stop_loss, on: performance.stop_loss_triggered_on }),
      })
    }
  }
  if (derived.status !== strategy.status) {
    if (derived.status === 'STOPPED') events.push({ type: 'STRATEGY_STOPPED', payload: auditEventPayload({ reason: derived.reason }) })
    if (derived.status === 'COMPLETED') events.push({ type: 'STRATEGY_COMPLETED', payload: auditEventPayload({ holding_days: performance.holding_days }) })
    if (derived.status === 'EXPIRED') events.push({ type: 'STRATEGY_EXPIRED', payload: auditEventPayload({ holding_days: performance.holding_days }) })
  }

  const next = {
    ...strategy,
    // 只允许改这两个东西：状态与非决策性的 performance。核心决策字段原样保留。
    status: derived.status,
    performance,
    status_reason: derived.reason,
    updated_at: performance.updated_at,
  }

  // 结构性守卫：万一未来有人在这里改了核心字段，立即失败。
  assertCoreImmutable(strategy, next)

  const changed = JSON.stringify(previous) !== JSON.stringify(performance) || derived.status !== strategy.status
  return {
    changed,
    strategy: next,
    performance,
    events: changed || previous === null
      ? [{ type: 'PERFORMANCE_UPDATED', payload: auditEventPayload({ unrealized_return: performance.unrealized_return, price: performance.price, as_of: asOf, actor }) }, ...events]
      : events,
    reason: 'OK',
  }
}
