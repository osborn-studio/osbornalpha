/**
 * 模拟盘组合账本 —— **权重 / 净值式**，纯函数，完全可复算（批次 1，需求 C1/C2/C3/C5/D3）。
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * 为什么是"权重 / 净值式"而不是金额式
 * ─────────────────────────────────────────────────────────────────────────────
 * 需求原文（会议纪要 05:22）：「他其实只给了一个 text 和百分比对吧？像净值一样」。
 * 因此：
 *   · 起始净值 `NAV = startNav`（默认 100），**永不出现金额**；
 *   · 一条指令 = 一个"手"（lot），占当时净值的 `weight_pct`；
 *   · 对外只展示**收益率与净值曲线**。
 * 金额记账才需要现金流水、手续费、税费、换汇 —— 这里全都不需要，这是刻意的简化。
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * 三条会决定测评结果的口径（必须一次定死，否则历史净值失去可比性）
 * ─────────────────────────────────────────────────────────────────────────────
 * 1. **建仓价用策略记录的 `entry_price`，不用行情重算。**
 *    这样"这一手的收益率 == 该策略的评价收益率"**逐字段相等**，
 *    组合层与逐笔层可以对账（`nav_final − nav_start` 必须等于各手贡献之和）。
 *    若改用指令日收盘价另算一遍，两层永远对不上，审计链白建。
 * 2. **一手只在一处平仓**，三个来源，按优先级：
 *    ① 策略生命周期终结（COMPLETED / STOPPED / EXPIRED）→ 用评价的 `exit_price`；
 *    ② 反向指令（C5：买与卖都在模拟盘内闭环）→ 平掉该标的**最早**的同向手（FIFO）；
 *    ③ 超限挤出（C4）→ 按配置策略选受害者。
 * 3. **撤销（CANCELLED）的手按建仓价平仓，收益率记 0。**
 *    撤销意味着指令从未真正生效；我们**不编造**一个它本该成交的价格
 *    （那会违反"绝不编造行情"）。DRAFT 策略不进组合 —— 它从未被冻结，不构成指令。
 *
 * ─────────────────────────────────────────────────────────────────────────────
 * 为什么这个模块是纯函数
 * ─────────────────────────────────────────────────────────────────────────────
 * `portfolio_recompute` 必须能"重新算一遍并逐字段比对"（对标 `strategy_verify_replay`）。
 * 只要投影是 `(指令流, 交易日序列, 价格查询, 配置) => 结果` 的纯函数，
 * 可复算就是结构性成立的，而不是靠小心。**禁止读系统时间、禁止读随机数、禁止 I/O。**
 */

import { roundTo } from '../evaluation/metrics.js'
import { validation } from '../errors.js'

/** 会计口径版本。与 `calculation_version` 同理：写进快照，将来改口径也能解释历史。 */
export const ACCOUNTING_VERSION = 'w1'

/** 小数位：内部比率 6 位（与 Engine 的 `ratio_decimals` 一致），净值 6 位。 */
const DECIMALS = 6

/**
 * 份额（units）用**更高精度**：`units = 名义净值 / 价格`，价格量级在 10²~10³，
 * 若只留 6 位小数，单手的份额误差可达 5e-7，乘以 200 上下的价格就是 1e-4 的净值误差 ——
 * 7 手累积后对账差额会到 1e-3 量级，看起来像"账算错了"。
 * 份额是内部量，不是对外数字，因此给它 10 位，让对账恒等式保持可信。
 */
const UNIT_DECIMALS = 10

/** 平仓来源。写进 lot 记录，供 UI 与审计区分"为什么平掉了这一手"。 */
export const CLOSE_REASON = Object.freeze({
  STRATEGY_TERMINAL: 'STRATEGY_TERMINAL',
  OPPOSITE_INSTRUCTION: 'OPPOSITE_INSTRUCTION',
  EVICTED: 'EVICTED',
})

/** 可按分析师配置的挤出策略（C3/C4 的可配部分）。 */
export const EVICTION_STRATEGIES = Object.freeze(['fifo', 'largest_weight', 'worst_performer'])

function requireFinite(value, label) {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw validation(`${label} must be a finite number, received ${JSON.stringify(value)}`)
  }
  return value
}

function requirePositive(value, label) {
  requireFinite(value, label)
  if (value <= 0) throw validation(`${label} must be positive, received ${value}`)
  return value
}

/**
 * 组合配置归一化。`maxPositionPct` 已由调用方按"分析师覆盖 → 全局默认"解析完毕。
 */
export function normalizePortfolioConfig(input = {}) {
  const raw = typeof input === 'object' && input !== null ? input : {}
  const startNav = raw.startNav === undefined ? 100 : requirePositive(raw.startNav, 'portfolio.startNav')
  const defaultWeightPct = raw.defaultWeightPct === undefined ? 10 : requirePositive(raw.defaultWeightPct, 'portfolio.defaultWeightPct')
  const defaultMaxPositionPct = raw.defaultMaxPositionPct === undefined ? 100 : requirePositive(raw.defaultMaxPositionPct, 'portfolio.defaultMaxPositionPct')
  const evictionStrategy = raw.evictionStrategy ?? 'fifo'
  if (!EVICTION_STRATEGIES.includes(evictionStrategy)) {
    throw validation(`unknown eviction strategy "${evictionStrategy}"`, { known: [...EVICTION_STRATEGIES] })
  }
  return { startNav, defaultWeightPct, defaultMaxPositionPct, evictionStrategy }
}

/**
 * 从策略流推导出"手"的指令事件流（**纯函数**）。
 *
 * 每个策略最多产生两条事件：OPEN（冻结时）与 CLOSE（终结时）。
 *
 * @param {{ strategies: object[], evaluationsById: Map<string, object> }} input
 */
export function deriveInstructions({ strategies, evaluationsById = new Map() }) {
  const instructions = []
  for (const strategy of strategies) {
    // DRAFT 从未冻结 ⇒ 不构成指令（需求：指令 = 已固化决策）
    if (strategy.frozen !== true) continue
    const weightPct = strategy.weight_pct
    const openAt = strategy.frozen_at
    const openDate = String(openAt).slice(0, 10)
    instructions.push({
      kind: 'OPEN',
      at: openAt,
      date: openDate,
      strategy_id: strategy.strategy_id,
      ticker: strategy.ticker,
      action: strategy.action,
      weight_pct: typeof weightPct === 'number' && Number.isFinite(weightPct) ? weightPct : null, // null ⇒ 用配置默认值
      price: requirePositive(strategy.entry_price, `${strategy.strategy_id}.entry_price`),
    })

    const evaluation = evaluationsById.get(strategy.strategy_id)
    if (strategy.status === 'CANCELLED') {
      // 撤销：按建仓价平仓，收益率 0（不编造行情）
      instructions.push({
        kind: 'CLOSE',
        at: strategy.updated_at ?? openAt,
        date: String(strategy.updated_at ?? openAt).slice(0, 10),
        strategy_id: strategy.strategy_id,
        ticker: strategy.ticker,
        action: strategy.action,
        price: requirePositive(strategy.entry_price, `${strategy.strategy_id}.entry_price`),
        close_reason: CLOSE_REASON.STRATEGY_TERMINAL,
        terminal_status: 'CANCELLED',
      })
      continue
    }
    if (strategy.status === 'COMPLETED' || strategy.status === 'STOPPED' || strategy.status === 'EXPIRED') {
      // 用评价的窗口终点与出场价 —— 与逐笔评价同源，保证两层可对账
      const exitDate = evaluation?.window?.to ?? null
      const exitPrice = evaluation?.exit_price ?? null
      if (exitDate !== null && typeof exitPrice === 'number' && exitPrice > 0) {
        instructions.push({
          kind: 'CLOSE',
          at: `${exitDate}T20:30:00Z`,
          date: exitDate,
          strategy_id: strategy.strategy_id,
          ticker: strategy.ticker,
          action: strategy.action,
          price: exitPrice,
          close_reason: CLOSE_REASON.STRATEGY_TERMINAL,
          terminal_status: strategy.status,
        })
      }
      // 没有评价（理论上不该发生）⇒ 留作未平仓，宁可不平也不要猜价格
    }
  }

  // 稳定的全序：先按日期，再按策略 ID。**必须稳定**，否则复算结果会漂。
  return instructions.sort((a, b) => {
    if (a.date !== b.date) return a.date < b.date ? -1 : 1
    if (a.at !== b.at) return a.at < b.at ? -1 : 1
    if (a.strategy_id !== b.strategy_id) return a.strategy_id < b.strategy_id ? -1 : 1
    return a.kind === b.kind ? 0 : a.kind === 'CLOSE' ? -1 : 1 // 同策略同日先平后开
  })
}

/** 一手的浮动收益率（BUY 做多、SELL 做空，与 Engine 同一口径）。 */
export function lotReturn(lot, price) {
  const raw = lot.action === 'SELL' ? (lot.entry_price - price) / lot.entry_price : (price - lot.entry_price) / lot.entry_price
  return roundTo(raw, DECIMALS)
}

/**
 * 按配置策略挑出挤出受害者。**返回有序数组**（可能挤出不止一手）。
 * @param {{ lots: object[], requiredPct: number, maxPositionPct: number, strategy: string, priceAt: Function }} input
 */
export function selectEvictionVictims({ lots, requiredPct, maxPositionPct, strategy, priceAt, date }) {
  const ordered = [...lots]
  if (strategy === 'largest_weight') {
    ordered.sort((a, b) => (b.weight_pct - a.weight_pct) || (a.opened_at < b.opened_at ? -1 : 1) || (a.lot_id < b.lot_id ? -1 : 1))
  } else if (strategy === 'worst_performer') {
    // 表现最差者先出局；收益率相同则先开者先出（保证确定性）。
    // ⚠️ 必须按**当前日**盯市：用 `opened_date` 当估值日的话，任何一手的收益率都恒为 0，
    // 于是"表现最差"退化成"最早开仓"，与 fifo 完全一样 —— 一个静默失效的策略。
    if (typeof date !== 'string') throw validation('worst_performer eviction requires the current trading date')
    ordered.sort((a, b) => {
      const ra = lotReturn(a, priceAt(a.ticker, date))
      const rb = lotReturn(b, priceAt(b.ticker, date))
      return (ra - rb) || (a.opened_at < b.opened_at ? -1 : 1) || (a.lot_id < b.lot_id ? -1 : 1)
    })
  } else {
    // fifo：最早开仓者先出局
    ordered.sort((a, b) => (a.opened_at < b.opened_at ? -1 : a.opened_at > b.opened_at ? 1 : 0) || (a.lot_id < b.lot_id ? -1 : 1))
  }

  const victims = []
  let gross = requiredPct
  for (const lot of ordered) {
    if (gross <= maxPositionPct) break
    victims.push(lot)
    gross = roundTo(gross - lot.weight_pct, DECIMALS)
  }
  return victims
}

/**
 * 投影出一个分析师的完整组合状态与净值曲线（**纯函数**）。
 *
 * @param {object} input
 * @param {object[]} input.instructions       `deriveInstructions()` 的输出
 * @param {string[]} input.tradingDays        交易日序列（升序），曲线的 x 轴
 * @param {(ticker: string, date: string) => number} input.priceAt 收盘价查询（纯，来自预取的确定性行情）
 * @param {object} input.config               `normalizePortfolioConfig()` 的输出
 * @param {number} [input.maxPositionPct]     该分析师的仓位上限（已解析，覆盖 config 默认）
 */
export function projectPortfolio({ instructions = [], tradingDays = [], priceAt, config, maxPositionPct }) {
  const resolved = config ?? normalizePortfolioConfig()
  if (typeof priceAt !== 'function') throw validation('priceAt must be a function')
  const limit = maxPositionPct === undefined ? resolved.defaultMaxPositionPct : requirePositive(maxPositionPct, 'maxPositionPct')

  let nav = resolved.startNav
  let cash = resolved.startNav
  /** @type {object[]} 全部手（含已平仓），供 UI 与审计追溯 */
  const lots = []
  const evictions = []
  const rejections = []
  const applied = []
  let lotSequence = 0

  const openLots = () => lots.filter((lot) => lot.closed_at === null)
  const grossExposure = () => roundTo(openLots().reduce((sum, lot) => sum + lot.weight_pct, 0), DECIMALS)

  const closeLot = (lot, { at, date, price, reason }) => {
    const exitPrice = requirePositive(price, 'close price')
    const units = lot.units
    // 平仓：把手里的份额按平仓价卖回现金（做空则买回）
    const proceeds = units * exitPrice
    // ⚠️ 已实现盈亏取**账面实际变动**（proceeds − 建仓时的名义额），
    // 而不是再用 `权重 × 建仓净值 × 收益率` 平行算一遍。
    // 两条路算同一个数，迟早会因为舍入而给出两个答案；用账面变动就天然相等。
    const realizedPnl = proceeds - lot.signed_notional
    cash = roundTo(cash + proceeds, DECIMALS)
    const realized = lotReturn(lot, exitPrice)
    lot.closed_at = at
    lot.closed_date = date
    lot.exit_price = exitPrice
    lot.close_reason = reason
    lot.realized_return = realized
    lot.realized_pnl_nav = roundTo(realizedPnl, DECIMALS)
    nav = roundTo(cash + openLots().reduce((sum, open) => sum + open.units * priceAt(open.ticker, date), 0), DECIMALS)
    lot.nav_at_close = nav
    return lot
  }

  // 逐日推进：先把当日**应生效**的事件按序应用，再按当日收盘价标记全仓 → 得到当日净值。
  //
  // ⚠️ 这里用游标推进而不是"按日期精确匹配"：指令日未必落在交易日序列里
  // （周末提交、节假日提交），精确匹配会让那条指令**永远不被应用且无人察觉** ——
  // 组合会静默少一手。游标把 `date <= 当日` 的待处理指令全部应用（顺延到下一交易日生效）。
  const curve = []
  let cursor = 0
  for (const date of tradingDays) {
    const due = []
    while (cursor < instructions.length && instructions[cursor].date <= date) {
      due.push(instructions[cursor])
      cursor += 1
    }
    for (const instruction of due) {
      if (instruction.kind === 'CLOSE') {
        const lot = lots.find((row) => row.strategy_id === instruction.strategy_id && row.closed_at === null)
        if (lot === undefined) continue
        closeLot(lot, { at: instruction.at, date, price: instruction.price, reason: instruction.close_reason ?? CLOSE_REASON.STRATEGY_TERMINAL })
        applied.push({ date, kind: 'CLOSE', strategy_id: instruction.strategy_id, lot_id: lot.lot_id, close_reason: lot.close_reason, realized_return: lot.realized_return })
        continue
      }

      // ── OPEN ──────────────────────────────────────────────────────────────
      const weightPct = instruction.weight_pct === null ? resolved.defaultWeightPct : requirePositive(instruction.weight_pct, 'weight_pct')
      if (weightPct > limit) {
        // 单条指令就超上限：**拒绝而不是悄悄夹紧**。夹紧会让"分析师到底要求了多少"变得不可考。
        rejections.push({ at: instruction.at, date, strategy_id: instruction.strategy_id, ticker: instruction.ticker, weight_pct: weightPct, reason: 'WEIGHT_EXCEEDS_MAX_POSITION', max_position_pct: limit })
        continue
      }

      // 1) 反向指令先平掉该标的**最早**的同向手（C5：买卖在模拟盘内闭环）
      const opposite = instruction.action === 'BUY' ? 'SELL' : 'BUY'
      const facing = openLots().filter((lot) => lot.ticker === instruction.ticker && lot.action === opposite).sort((a, b) => (a.opened_at < b.opened_at ? -1 : 1))
      if (facing.length > 0) {
        closeLot(facing[0], { at: instruction.at, date, price: instruction.price, reason: CLOSE_REASON.OPPOSITE_INSTRUCTION })
        applied.push({ date, kind: 'CLOSE', strategy_id: facing[0].strategy_id, lot_id: facing[0].lot_id, close_reason: CLOSE_REASON.OPPOSITE_INSTRUCTION, realized_return: facing[0].realized_return })
      }

      // 2) 超限则按配置策略挤出（C4）
      if (roundTo(grossExposure() + weightPct, DECIMALS) > limit) {
        const victims = selectEvictionVictims({ lots: openLots(), requiredPct: roundTo(grossExposure() + weightPct, DECIMALS), maxPositionPct: limit, strategy: resolved.evictionStrategy, priceAt, date })
        for (const victim of victims) {
          // 挤出 = "卖掉旧持仓"（需求原文 05:22），因此按**当时市价**平仓。
          // 按建仓价平仓会把这一手已经发生的真实盈亏抹掉，那是篡改结果，不是调仓。
          // "这是系统做的决定"这件事由 `POSITION_EVICTED` 事件与 `close_reason` 记录，
          // 不靠扭曲价格来表达。
          const victimPrice = requirePositive(priceAt(victim.ticker, date), `priceAt(${victim.ticker}, ${date})`)
          closeLot(victim, { at: instruction.at, date, price: victimPrice, reason: CLOSE_REASON.EVICTED })
          evictions.push({ at: instruction.at, date, lot_id: victim.lot_id, strategy_id: victim.strategy_id, ticker: victim.ticker, action: victim.action, weight_pct: victim.weight_pct, evicted_for: instruction.strategy_id, reason: CLOSE_REASON.EVICTED })
          applied.push({ date, kind: 'CLOSE', strategy_id: victim.strategy_id, lot_id: victim.lot_id, close_reason: CLOSE_REASON.EVICTED, realized_return: victim.realized_return })
        }
      }

      // 3) 建仓。notional 按**当时净值**折算 ⇒ 权重是"占当时净值的比例"，与提案口径一致
      const notional = roundTo((weightPct / 100) * nav, DECIMALS)
      const signedNotional = instruction.action === 'SELL' ? -notional : notional
      lotSequence += 1
      const lot = {
        lot_id: `LOT-${String(lotSequence).padStart(4, '0')}`,
        strategy_id: instruction.strategy_id,
        ticker: instruction.ticker,
        action: instruction.action,
        weight_pct: weightPct,
        opened_at: instruction.at,
        opened_date: date,
        entry_price: instruction.price,
        nav_at_open: nav,
        notional_nav: notional,
        signed_notional: signedNotional,
        units: roundTo(signedNotional / instruction.price, UNIT_DECIMALS),
        closed_at: null,
        closed_date: null,
        exit_price: null,
        close_reason: null,
        realized_return: null,
        realized_pnl_nav: null,
        nav_at_close: null,
      }
      cash = roundTo(cash - signedNotional, DECIMALS)
      lots.push(lot)
      applied.push({ date, kind: 'OPEN', strategy_id: instruction.strategy_id, lot_id: lot.lot_id, weight_pct: weightPct, notional_nav: notional })
    }

    // 当日收盘标记全仓 ⇒ 当日净值
    const open = openLots()
    const markedValue = open.reduce((sum, lot) => sum + lot.units * priceAt(lot.ticker, date), 0)
    nav = roundTo(cash + markedValue, DECIMALS)
    curve.push({
      date,
      nav,
      gross_exposure_pct: roundTo(open.reduce((sum, lot) => sum + lot.weight_pct, 0), DECIMALS),
      open_lots: open.length,
      unrealized_pnl_nav: roundTo(markedValue - open.reduce((sum, lot) => sum + lot.notional_nav * (lot.action === 'SELL' ? -1 : 1), 0), DECIMALS),
    })
  }

  const last = curve.at(-1)
  const open = openLots()
  return {
    accounting_version: ACCOUNTING_VERSION,
    start_nav: resolved.startNav,
    max_position_pct: limit,
    eviction_strategy: resolved.evictionStrategy,
    default_weight_pct: resolved.defaultWeightPct,
    nav: last === undefined ? resolved.startNav : last.nav,
    total_return: last === undefined ? 0 : roundTo((last.nav - resolved.startNav) / resolved.startNav, DECIMALS),
    cash,
    unallocated_pct: roundTo(100 - grossExposure(), DECIMALS),
    gross_exposure_pct: grossExposure(),
    curve,
    lots,
    positions: open,
    evictions,
    rejections,
    applied,
    counts: {
      instructions: instructions.length,
      lots_opened: lots.length,
      lots_closed: lots.filter((lot) => lot.closed_at !== null).length,
      lots_open: open.length,
      evictions: evictions.length,
      rejections: rejections.length,
    },
  }
}

/**
 * 指令流的**指纹**。用于证明"两次复算吃的是同一份输入"。
 *
 * 这是 `strategy_verify_replay` 那套"可复算"在组合层的对应物：
 * 只有输入用了同一个指纹，净值一致才有意义。
 */
export function instructionDigest({ instructions, tradingDays, maxPositionPct, config }) {
  const payload = JSON.stringify({
    accounting_version: ACCOUNTING_VERSION,
    instructions: instructions.map((row) => [row.kind, row.date, row.strategy_id, row.ticker, row.action, row.weight_pct, row.price]),
    trading_days: tradingDays,
    max_position_pct: maxPositionPct,
    eviction_strategy: config.evictionStrategy,
    start_nav: config.startNav,
    default_weight_pct: config.defaultWeightPct,
  })
  // 非加密哈希即可：这里要的是"同一输入得到同一指纹"，不是抗碰撞
  let hash = 2166136261
  for (let i = 0; i < payload.length; i += 1) {
    hash ^= payload.charCodeAt(i)
    hash = Math.imul(hash, 16777619)
  }
  return `d${(hash >>> 0).toString(16).padStart(8, '0')}`
}
