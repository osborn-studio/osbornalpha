/**
 * 组合层的装配与比对工具（批次 1）。
 *
 * 分工：`ledger.js` 是**纯会计**（不含 I/O），本模块负责把库里的数据装配成
 * `ledger` 需要的输入，以及把两次投影结果做**逐字段比对**（`portfolio_recompute` 的核心）。
 * 真正读库/写给库的编排在 `service.js`（它是唯一的组合点）。
 */

import { roundTo } from '../evaluation/metrics.js'
import { validation } from '../errors.js'
import { ACCOUNTING_VERSION } from './ledger.js'

/**
 * 解析某个分析师的仓位上限：**分析师覆盖 → 全局默认**（需求 C3：可按分析师单独配置）。
 * @param {{ analyst?: object, config: object }} input
 */
export function resolveMaxPositionPct({ analyst, config }) {
  const override = analyst?.max_position_pct
  if (override !== undefined && override !== null) {
    if (typeof override !== 'number' || !Number.isFinite(override) || override <= 0) {
      throw validation(`analyst ${analyst?.analyst_id ?? '(unknown)'} has invalid max_position_pct ${JSON.stringify(override)}`)
    }
    return override
  }
  return config.defaultMaxPositionPct
}

/**
 * 用预取的行情构造一个**纯价格查询函数**。
 *
 * 取"date 当天或之前最近一根 K 线的收盘价"（标准的逐日盯市口径），
 * 因此对停牌/尚未上市的日期也能给出确定结果。
 * 但**一只标的在该区间内完全没有 K 线时必须抛错** ——
 * 静默返回 0 或建仓价会让净值凭空失真，而失真的净值比报错更危险。
 *
 * @param {{ barsByTicker: Map<string, {date: string, close: number}[]>, label?: string }} input
 */
export function buildPriceLookup({ barsByTicker, label = 'portfolio' }) {
  for (const [ticker, bars] of barsByTicker) {
    if (!Array.isArray(bars) || bars.length === 0) throw validation(`${label}: no price bars for ${ticker}`)
  }
  return function priceAt(ticker, date) {
    const bars = barsByTicker.get(ticker)
    if (bars === undefined) throw validation(`${label}: no price history for ${ticker} (requested ${date})`)
    // 二分找"date 当天或之前最近的一根"
    let low = 0
    let high = bars.length - 1
    let found = -1
    while (low <= high) {
      const mid = (low + high) >> 1
      if (bars[mid].date <= date) {
        found = mid
        low = mid + 1
      } else {
        high = mid - 1
      }
    }
    if (found === -1) {
      throw validation(`${label}: no price for ${ticker} on or before ${date} (earliest bar ${bars[0].date})`)
    }
    const close = bars[found].close
    if (typeof close !== 'number' || !Number.isFinite(close) || close <= 0) {
      throw validation(`${label}: invalid close price for ${ticker} on ${bars[found].date}`)
    }
    return close
  }
}

/**
 * 投影结果中**参与落库与比对**的部分。
 *
 * 刻意排除 `computed_at` 之类的运行时刻字段：它们每次不同，
 * 放进比对里会让"可复算"永远失败。这与 `strategy_verify_replay` 里
 * `stripIdentity()` 的做法是同一个理由。
 */
export function canonicalSnapshot(projection) {
  return {
    accounting_version: projection.accounting_version,
    start_nav: projection.start_nav,
    max_position_pct: projection.max_position_pct,
    eviction_strategy: projection.eviction_strategy,
    default_weight_pct: projection.default_weight_pct,
    nav: projection.nav,
    total_return: projection.total_return,
    cash: projection.cash,
    gross_exposure_pct: projection.gross_exposure_pct,
    unallocated_pct: projection.unallocated_pct,
    curve: projection.curve.map((point) => ({ date: point.date, nav: point.nav, gross_exposure_pct: point.gross_exposure_pct, open_lots: point.open_lots })),
    lots: projection.lots.map((lot) => ({
      lot_id: lot.lot_id,
      strategy_id: lot.strategy_id,
      ticker: lot.ticker,
      action: lot.action,
      weight_pct: lot.weight_pct,
      opened_date: lot.opened_date,
      entry_price: lot.entry_price,
      nav_at_open: lot.nav_at_open,
      units: lot.units,
      closed_date: lot.closed_date,
      exit_price: lot.exit_price,
      close_reason: lot.close_reason,
      realized_return: lot.realized_return,
      realized_pnl_nav: lot.realized_pnl_nav,
    })),
    evictions: projection.evictions.map((row) => ({ date: row.date, lot_id: row.lot_id, strategy_id: row.strategy_id, ticker: row.ticker, weight_pct: row.weight_pct, evicted_for: row.evicted_for })),
    rejections: projection.rejections.map((row) => ({ date: row.date, strategy_id: row.strategy_id, ticker: row.ticker, weight_pct: row.weight_pct, reason: row.reason })),
    counts: projection.counts,
  }
}

/** 逐字段比对两份快照，返回人类可读的差异列表（空数组 = 完全一致）。 */
export function compareSnapshots(stored, recomputed) {
  const differences = []
  const walk = (a, b, path) => {
    if (Array.isArray(a) || Array.isArray(b)) {
      const left = Array.isArray(a) ? a : []
      const right = Array.isArray(b) ? b : []
      if (left.length !== right.length) {
        differences.push(`${path}: length ${left.length} !== ${right.length}`)
        return
      }
      for (let i = 0; i < left.length; i += 1) walk(left[i], right[i], `${path}[${i}]`)
      return
    }
    if (a !== null && b !== null && typeof a === 'object' && typeof b === 'object') {
      const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])].sort()
      for (const key of keys) walk(a[key], b[key], path === '' ? key : `${path}.${key}`)
      return
    }
    if (a !== b) differences.push(`${path}: ${JSON.stringify(a)} !== ${JSON.stringify(b)}`)
  }
  walk(stored, recomputed, '')
  return differences
}

/**
 * 组合的**对账恒等式**（自检，也用于测试）。
 *
 * 组合层与逐笔层必须能对上：`Σ(各手实际盈亏) == 已实现净值的变动`。
 * 这是一条比"数字看起来对不对"强得多的检查 —— 它证明两层没有各算各的。
 */
export function reconcile(projection) {
  const realized = roundTo(
    projection.lots.filter((lot) => lot.closed_date !== null).reduce((sum, lot) => sum + (lot.realized_pnl_nav ?? 0), 0),
    6,
  )
  const unrealized = roundTo(projection.curve.at(-1)?.unrealized_pnl_nav ?? 0, 6)
  const navDelta = roundTo(projection.nav - projection.start_nav, 6)
  // 允许的误差只来自**落库字段的 6 位小数四舍五入**，而不是"两个算法各算各的"。
  // 已实现盈亏取自账面实际变动（见 ledger 的 closeLot），因此恒等式在构造上成立；
  // 8 手累积舍入最多 4e-6，取 1e-5 作为阈值，比真实错误（量级 1e-2）严格三个数量级。
  const gap = roundTo(navDelta - realized - unrealized, 6)
  return {
    realized_pnl_nav: realized,
    unrealized_pnl_nav: unrealized,
    nav_delta: navDelta,
    gap,
    balanced: Math.abs(gap) < 1e-5,
  }
}

/** 给工具/UI 用的紧凑视图：不含曲线全量，只含持仓与关键统计。 */
export function summarizePortfolio(projection) {
  return {
    accounting_version: projection.accounting_version,
    start_nav: projection.start_nav,
    nav: projection.nav,
    total_return: projection.total_return,
    max_position_pct: projection.max_position_pct,
    eviction_strategy: projection.eviction_strategy,
    gross_exposure_pct: projection.gross_exposure_pct,
    unallocated_pct: projection.unallocated_pct,
    counts: projection.counts,
    positions: projection.positions.map((lot) => ({
      lot_id: lot.lot_id,
      strategy_id: lot.strategy_id,
      ticker: lot.ticker,
      action: lot.action,
      weight_pct: lot.weight_pct,
      opened_date: lot.opened_date,
      entry_price: lot.entry_price,
      nav_at_open: lot.nav_at_open,
    })),
    closed: projection.lots
      .filter((lot) => lot.closed_date !== null)
      .map((lot) => ({
        lot_id: lot.lot_id,
        strategy_id: lot.strategy_id,
        ticker: lot.ticker,
        action: lot.action,
        weight_pct: lot.weight_pct,
        opened_date: lot.opened_date,
        closed_date: lot.closed_date,
        close_reason: lot.close_reason,
        realized_return: lot.realized_return,
        realized_pnl_nav: lot.realized_pnl_nav,
      })),
    evictions: projection.evictions,
    rejections: projection.rejections,
  }
}

export { ACCOUNTING_VERSION }
