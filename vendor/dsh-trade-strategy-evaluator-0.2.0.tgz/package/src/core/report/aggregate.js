/**
 * 绩效聚合（实施方案 §12）。
 *
 * 所有数字同样由代码计算，LLM 只负责解释。聚合只使用**已完成评价**的策略，
 * 未评价的策略单独计数，避免把"还没结束"混进收益均值。
 */

function mean(values) {
  if (values.length === 0) return 0
  return values.reduce((a, b) => a + b, 0) / values.length
}

function round(value, decimals = 4) {
  return Math.round((value + Number.EPSILON) * 10 ** decimals) / 10 ** decimals
}

/**
 * 单策略表现摘要（Dashboard 列表行使用）。
 * @param {object} strategy
 * @param {object|null} evaluation
 */
export function summarizeStrategy(strategy, evaluation) {
  return {
    strategy_id: strategy.strategy_id,
    analyst_id: strategy.analyst_id,
    ticker: strategy.ticker,
    action: strategy.action,
    status: strategy.status,
    frozen: strategy.frozen,
    created_at: strategy.created_at,
    frozen_at: strategy.frozen_at,
    holding_period: strategy.holding_period,
    entry_price: strategy.entry_price,
    target_price: strategy.target_price,
    stop_loss: strategy.stop_loss,
    benchmark: strategy.benchmark,
    reason: strategy.reason,
    evaluated: evaluation !== null,
    evaluation_id: evaluation?.evaluation_id ?? null,
    exit_price: evaluation?.exit_price ?? null,
    strategy_return: evaluation?.strategy_return ?? null,
    benchmark_return: evaluation?.benchmark_return ?? null,
    alpha: evaluation?.alpha ?? null,
    max_drawdown: evaluation?.max_drawdown ?? null,
    pnl: evaluation?.pnl ?? null,
    target_reached: evaluation?.target_reached ?? null,
    stop_loss_triggered: evaluation?.stop_loss_triggered ?? null,
    holding_days: evaluation?.holding_days ?? null,
    score: evaluation?.score ?? null,
    exit_reason: evaluation?.exit_reason ?? null,
    calculation_version: evaluation?.calculation_version ?? null,
  }
}

/**
 * 聚合一组策略 + 评价为绩效指标。
 * @param {{strategies: object[], evaluationsById: Map<string, object>}} input
 */
export function aggregatePerformance({ strategies, evaluationsById }) {
  const rows = strategies.map((strategy) => summarizeStrategy(strategy, evaluationsById.get(strategy.strategy_id) ?? null))
  const evaluated = rows.filter((row) => row.evaluated)

  const returns = evaluated.map((row) => row.strategy_return)
  const alphas = evaluated.map((row) => row.alpha)
  const drawdowns = evaluated.map((row) => row.max_drawdown)
  const scores = evaluated.map((row) => row.score)
  const wins = evaluated.filter((row) => row.strategy_return > 0)
  const losses = evaluated.filter((row) => row.strategy_return < 0)
  const outperform = evaluated.filter((row) => row.alpha > 0)
  const underperform = evaluated.filter((row) => row.alpha < 0)

  return {
    strategies: rows.length,
    evaluated: evaluated.length,
    pending_evaluation: rows.length - evaluated.length,
    active: rows.filter((row) => row.status === 'ACTIVE').length,
    completed: rows.filter((row) => row.status === 'COMPLETED').length,
    stopped: rows.filter((row) => row.status === 'STOPPED').length,
    expired: rows.filter((row) => row.status === 'EXPIRED').length,
    cancelled: rows.filter((row) => row.status === 'CANCELLED').length,
    wins: wins.length,
    losses: losses.length,
    win_rate: evaluated.length === 0 ? 0 : round(wins.length / evaluated.length, 4),
    average_return: round(mean(returns), 6),
    median_return: round(median(returns), 6),
    best_return: evaluated.length === 0 ? 0 : round(Math.max(...returns), 6),
    worst_return: evaluated.length === 0 ? 0 : round(Math.min(...returns), 6),
    average_alpha: round(mean(alphas), 6),
    positive_alpha_count: outperform.length,
    negative_alpha_count: underperform.length,
    hit_rate_vs_benchmark: evaluated.length === 0 ? 0 : round(outperform.length / evaluated.length, 4),
    max_drawdown: drawdowns.length === 0 ? 0 : round(Math.min(...drawdowns), 6),
    average_drawdown: round(mean(drawdowns), 6),
    average_score: round(mean(scores), 1),
    target_achievement_rate: evaluated.length === 0 ? 0 : round(evaluated.filter((row) => row.target_reached).length / evaluated.length, 4),
    stop_loss_rate: evaluated.length === 0 ? 0 : round(evaluated.filter((row) => row.stop_loss_triggered).length / evaluated.length, 4),
    total_pnl: round(evaluated.reduce((acc, row) => acc + (row.pnl ?? 0), 0), 2),
    rows,
  }
}

function median(values) {
  if (values.length === 0) return 0
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid]
}

/** 按分析师分组聚合。 */
export function aggregateByAnalyst({ strategies, evaluationsById, analysts }) {
  const groups = new Map()
  for (const analyst of analysts) groups.set(analyst.analyst_id, { analyst, strategies: [] })
  for (const strategy of strategies) {
    if (!groups.has(strategy.analyst_id)) {
      groups.set(strategy.analyst_id, {
        analyst: { analyst_id: strategy.analyst_id, name: strategy.analyst_id, team: 'unassigned' },
        strategies: [],
      })
    }
    groups.get(strategy.analyst_id).strategies.push(strategy)
  }
  return [...groups.values()].map(({ analyst, strategies: owned }) => ({
    analyst_id: analyst.analyst_id,
    name: analyst.name,
    team: analyst.team,
    ...aggregatePerformance({ strategies: owned, evaluationsById }),
  }))
}

/** 按团队分组聚合。 */
export function aggregateByTeam({ strategies, evaluationsById, analysts }) {
  const teamOf = new Map(analysts.map((analyst) => [analyst.analyst_id, analyst.team ?? 'unassigned']))
  const byTeam = new Map()
  for (const strategy of strategies) {
    const team = teamOf.get(strategy.analyst_id) ?? 'unassigned'
    if (!byTeam.has(team)) byTeam.set(team, [])
    byTeam.get(team).push(strategy)
  }
  return [...byTeam.entries()]
    .map(([team, rows]) => ({
      team,
      analyst_count: new Set(rows.map((row) => row.analyst_id)).size,
      ...aggregatePerformance({ strategies: rows, evaluationsById }),
    }))
    .sort((a, b) => b.average_alpha - a.average_alpha)
}
