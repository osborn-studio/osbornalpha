/**
 * 报告构建（实施方案 §5.5 / §22）。
 *
 * 结构上强制区分两件事：
 *   `factual`    —— 全部数值来自 Evaluation Engine，只读、可核对、带 calculation_version
 *   `commentary` —— 留给 LLM 的解释/摘要/归因，**永远**带免责声明
 *
 * 本模块只生产事实与模板。它不会、也无法读取或改写 Evaluation。
 *
 * 语言：所有自然语言都从 `src/core/i18n.js` 的文案表按 `language` 取，
 * 因此报告支持中英文切换，而**数字与判定结果不受语言影响**。
 */

import { commentaryDisclaimer, fillTemplate, normalizeLanguage, performanceText, reportText } from '../i18n.js'
import { formatMetricValue, magnitudePct, signedPct } from './format.js'

/** 有方向的量（收益 / Alpha）：正数带 `+`。 */
function pct(value, decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return signedPct(value, decimals)
}

/**
 * 幅度量（波动率 / 回撤）：**不加 `+`**。
 * 波动率非负 → `40.7%`；回撤本身是负数 → `-20.31%`。
 */
function magPct(value, decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return magnitudePct(value, decimals)
}

function num(value, decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return value.toFixed(decimals)
}

/**
 * 策略评价报告：事实区（§22 的 Strategy / Original Strategy / Actual Performance /
 * Rule Evaluation / Final Score）。
 *
 * @param {object} input
 * @param {string} [input.language] 'zh' | 'en'（默认 zh）
 */
export function buildStrategyReport({ strategy, evaluation, analyst, timeline = [], sessionId = null, language = 'zh' }) {
  const lang = normalizeLanguage(language)
  const facts = {
    language: lang,
    strategy: {
      strategy_id: strategy.strategy_id,
      analyst_id: strategy.analyst_id,
      analyst_name: analyst?.name ?? strategy.analyst_id,
      ticker: strategy.ticker,
      action: strategy.action,
      status: strategy.status,
      submitted: strategy.created_at,
      frozen_at: strategy.frozen_at,
      created_by: strategy.created_by,
    },
    original_strategy: {
      entry_price: strategy.entry_price,
      target_price: strategy.target_price,
      stop_loss: strategy.stop_loss,
      holding_period: strategy.holding_period,
      benchmark: strategy.benchmark,
      position_before: strategy.position_before,
      quantity: strategy.quantity,
      market_snapshot: strategy.market_snapshot,
      reason: strategy.reason,
    },
    actual_performance: evaluation === null ? null : {
      entry_price: evaluation.entry_price,
      exit_price: evaluation.exit_price,
      exit_date: evaluation.exit_date,
      strategy_return: evaluation.strategy_return,
      benchmark_return: evaluation.benchmark_return,
      benchmark_entry_price: evaluation.benchmark_entry_price,
      benchmark_exit_price: evaluation.benchmark_exit_price,
      alpha: evaluation.alpha,
      max_drawdown: evaluation.max_drawdown,
      volatility: evaluation.volatility,
      pnl: evaluation.pnl,
      risk_reward_ratio: evaluation.risk_reward_ratio,
      holding_days: evaluation.holding_days,
      exit_reason: evaluation.exit_reason,
    },
    rule_evaluation: evaluation === null ? null : {
      target_price: evaluation.target_price,
      target_reached: evaluation.target_reached,
      target_reached_on: evaluation.target_reached_on,
      stop_loss: evaluation.stop_loss,
      stop_loss_triggered: evaluation.stop_loss_triggered,
      stop_loss_triggered_on: evaluation.stop_loss_triggered_on,
      benchmark_outcome: evaluation.alpha > 0 ? 'outperformed' : evaluation.alpha < 0 ? 'underperformed' : 'inLine',
    },
    score: evaluation === null ? null : {
      total: evaluation.score,
      components: evaluation.score_components,
      weights: evaluation.score_weights,
      calculation_version: evaluation.calculation_version,
    },
    evaluation_meta: evaluation === null ? null : {
      evaluation_id: evaluation.evaluation_id,
      evaluation_time: evaluation.evaluation_time,
      data_window: evaluation.window,
      calculation_version: evaluation.calculation_version,
    },
    audit_trail: timeline.map((event) => ({ sequence: event.sequence, at: event.at, label: event.label, actor: event.actor })),
    session_id: sessionId,
  }

  return {
    report_type: 'strategy',
    language: lang,
    generated_at: new Date().toISOString(),
    factual: facts,
    commentary: null,
    commentary_disclaimer: commentaryDisclaimer(lang),
  }
}

/** 把策略报告渲染成 §22 的 Markdown 模板（按语言取文案）。 */
export function renderStrategyReportMarkdown(report, commentary = null, language = undefined) {
  const lang = normalizeLanguage(language ?? report.language ?? report.factual?.language)
  const T = reportText(lang)
  const f = report.factual
  const lines = []

  lines.push(T.strategyTitle, '')
  lines.push(`## ${T.strategy}`, '')
  lines.push(`${T.strategyId}: ${f.strategy.strategy_id}`)
  lines.push(`${T.analyst}: ${f.strategy.analyst_name} (${f.strategy.analyst_id})`)
  lines.push(`${T.ticker}: ${f.strategy.ticker}`)
  lines.push(`${T.action}: ${f.strategy.action}`)
  lines.push(`${T.submitted}: ${f.strategy.submitted}`)
  lines.push(`${T.status}: ${f.strategy.status}${f.strategy.frozen_at === null ? '' : ` (${T.frozenAt} ${f.strategy.frozen_at})`}`)
  lines.push('')
  lines.push(`## ${T.originalStrategy}`, '')
  lines.push(`${T.entry}: ${num(f.original_strategy.entry_price)}`)
  lines.push(`${T.target}: ${num(f.original_strategy.target_price)}`)
  lines.push(`${T.stop}: ${num(f.original_strategy.stop_loss)}`)
  lines.push(`${T.holdingPeriod}: ${f.original_strategy.holding_period} ${T.days}`)
  lines.push(`${T.benchmark}: ${f.original_strategy.benchmark}`)
  lines.push(`${T.positionBefore}: ${f.original_strategy.position_before}`)
  lines.push('')
  lines.push(`### ${T.marketSnapshot}`, '')
  lines.push(`${T.price}: ${num(f.original_strategy.market_snapshot?.price)}`)
  lines.push(`${T.timestamp}: ${f.original_strategy.market_snapshot?.timestamp ?? 'n/a'}`)
  lines.push(`${T.volume}: ${f.original_strategy.market_snapshot?.volume ?? 'n/a'}`)
  lines.push('')

  if (f.actual_performance === null) {
    lines.push(`## ${T.actualPerformance}`, '', `_${T.notEvaluatedYet}_`, '')
  } else {
    const p = f.actual_performance
    lines.push(`## ${T.actualPerformance}`, '')
    lines.push(`${T.entry}: ${num(p.entry_price)}`)
    lines.push(`${T.exit}: ${num(p.exit_price)}`)
    lines.push(`${T.returnPct}: ${pct(p.strategy_return)}`)
    lines.push(`${T.benchmarkReturn}: ${pct(p.benchmark_return)}`)
    lines.push(`${T.alpha}: ${pct(p.alpha)}`)
    // 回撤与波动率都是"幅度量"：不加正号；回撤的负号由数值自带。
    // 精度与其它比例统一为两位小数（原先 1 位，导致文本 -20.3% 与 JSON -0.203062 对不上）。
    lines.push(`${T.maxDrawdown}: ${magPct(p.max_drawdown, 2)}`)
    lines.push(`${T.volatility}: ${magPct(p.volatility, 2)}`)
    lines.push(`${T.pnl}: ${num(p.pnl)}`)
    lines.push(`${T.holdingDays}: ${p.holding_days}`)
    lines.push(`${T.exitReason}: ${p.exit_reason}`)
    lines.push('')
    lines.push(`## ${T.ruleEvaluation}`, '')
    lines.push(`${T.target}: ${f.rule_evaluation.target_reached ? fillTemplate(T.targetReachedOn, { date: f.rule_evaluation.target_reached_on }) : T.targetNotReached}`)
    lines.push(`${T.stop}: ${f.rule_evaluation.stop_loss_triggered ? fillTemplate(T.stopTriggeredOn, { date: f.rule_evaluation.stop_loss_triggered_on }) : T.stopNotTriggered}`)
    lines.push(`${T.benchmark}: ${T[f.rule_evaluation.benchmark_outcome]}`)
    lines.push('')
  }

  lines.push(`## ${T.analystCommentary}`, '')
  lines.push(`> ${report.commentary_disclaimer ?? commentaryDisclaimer(lang)}`, '')
  lines.push(typeof commentary === 'string' && commentary.trim().length > 0 ? commentary.trim() : T.commentaryNoContent)
  lines.push('')

  if (f.score !== null) {
    lines.push(`## ${T.finalScore}`, '')
    lines.push(`${num(f.score.total, 0)} / 100`)
    lines.push('')
    lines.push(T.scoreBreakdown)
    for (const [key, value] of Object.entries(f.score.components)) {
      lines.push(`- ${key}: ${num(value, 1)} × ${f.score.weights[key]}`)
    }
    lines.push(`${T.scoreVersion}: ${f.score.calculation_version}`)
    lines.push('')
  }

  lines.push('---', '')
  lines.push(`_${T.factsFooter}_`)
  // 会话号在 factual 里（report.session_id 是不存在的层级，读它会渲染出 "Session: undefined"）。
  if (typeof f.session_id === 'string' && f.session_id.length > 0) {
    lines.push(`_${T.sessionLabel}: ${f.session_id}_`)
  }
  return lines.join('\n')
}

/** 分析师绩效报告。 */
export function buildAnalystReport({ analyst, aggregate, generatedAt, language = 'zh' }) {
  const lang = normalizeLanguage(language)
  return {
    report_type: 'analyst',
    language: lang,
    generated_at: generatedAt,
    factual: {
      language: lang,
      analyst: { analyst_id: analyst.analyst_id, name: analyst.name, team: analyst.team },
      metrics: stripRows(aggregate),
      strategies: aggregate.rows,
    },
    commentary: null,
    commentary_disclaimer: commentaryDisclaimer(lang),
  }
}

/** 团队绩效报告。 */
export function buildTeamReport({ teams, generatedAt, language = 'zh' }) {
  const lang = normalizeLanguage(language)
  return {
    report_type: 'team',
    language: lang,
    generated_at: generatedAt,
    factual: {
      language: lang,
      teams: teams.map((team) => ({ team: team.team, analyst_count: team.analyst_count, ...stripRows(team) })),
    },
    commentary: null,
    commentary_disclaimer: commentaryDisclaimer(lang),
  }
}

function stripRows(aggregate) {
  const { rows, ...metrics } = aggregate
  return metrics
}

/** 渲染分析师/团队报告为 Markdown（同样区分事实与评论，同样支持语言切换）。 */
export function renderPerformanceReportMarkdown(report, commentary = null, language = undefined) {
  const lang = normalizeLanguage(language ?? report.language ?? report.factual?.language)
  const T = performanceText(lang)
  const lines = []

  if (report.report_type === 'analyst') {
    const f = report.factual
    lines.push(fillTemplate(T.analystTitle, { name: f.analyst.name }), '')
    lines.push(T.factual, '')
    lines.push(`| ${T.metric} | ${T.value} |`, '| --- | --- |')
    for (const [key, value] of Object.entries(f.metrics)) {
      if (key === 'language') continue
      // 类型来自显式声明（src/core/report/format.js），不再由字段名子串推断
      lines.push(`| ${T.metrics[key] ?? key} | ${formatMetricValue(key, value, { language: lang })} |`)
    }
    lines.push('')
    lines.push(T.strategyHistory, '')
    lines.push(`| ${T.headers.join(' | ')} |`, `| ${T.headers.map(() => '---').join(' | ')} |`)
    for (const row of f.strategies) {
      lines.push(`| ${row.strategy_id} | ${row.ticker} | ${row.action} | ${pct(row.strategy_return)} | ${pct(row.benchmark_return)} | ${pct(row.alpha)} | ${row.score ?? 'n/a'} | ${row.status} |`)
    }
    lines.push('')
  } else {
    lines.push(T.teamTitle, '')
    lines.push(T.factual, '')
    lines.push(`| ${T.teamHeaders.join(' | ')} |`, `| ${T.teamHeaders.map(() => '---').join(' | ')} |`)
    for (const team of report.factual.teams) {
      const cell = (key, value, decimals) => formatMetricValue(key, value, { language: lang, ...(decimals === undefined ? {} : { decimals }) })
      lines.push(`| ${team.team} | ${cell('analyst_count', team.analyst_count)} | ${cell('strategies', team.strategies)} | ${cell('win_rate', team.win_rate, 1)} | ${cell('average_return', team.average_return)} | ${cell('average_alpha', team.average_alpha)} | ${cell('max_drawdown', team.max_drawdown)} | ${cell('average_score', team.average_score)} |`)
    }
    lines.push('')
  }

  lines.push(T.commentary, '')
  lines.push(`> ${report.commentary_disclaimer ?? commentaryDisclaimer(lang)}`, '')
  lines.push(typeof commentary === 'string' && commentary.trim().length > 0 ? commentary.trim() : T.noCommentary)
  lines.push('')
  return lines.join('\n')
}

// 说明：原先这里有一个 `formatMetric(key, value)`，用 `/(rate|return|alpha|drawdown)/`
// 对字段名做**子串匹配**来猜类型，导致 `strategies`（含 "rate"）被渲染成 `+800.00%`、
// 计数被渲染成 `6.00`。现已删除，改由 format.js 的显式类型表决定（见该文件顶部注释）。
