/**
 * 报告数值格式化 —— **显式类型表**，不做字段名猜测。
 *
 * 为什么要有这个模块（一次真实事故）：
 * 报告层曾用 `/(rate|return|alpha|drawdown)/.test(key)` 猜数值类型，
 * 而正则做的是**子串匹配**，于是：
 *   · `strategies`（st-**rate**-gies）被当成比例 → 输出 `+800.00%`（真值 8）
 *   · `positive_alpha_count`（含 **alpha**）→ 输出 `+400.00%`（真值 4）
 *   · `negative_alpha_count` → `+200.00%`（真值 2）
 *   · 同时计数被强制加两位小数 → `已完成评价 = 6.00`
 * 即报告里出现了**错误数字**，而单元测试全绿（因为测试只断言了表头与分节）。
 *
 * 结论：**接受"字段名能表达类型"这个假设本身就是 bug**。
 * 因此这里把"字段 → 类型"写成一张显式表，并配一条**穷尽性测试**：
 * 聚合器新增任何指标而没在表里声明类型，测试立即失败。
 *
 * 五种类型：
 *   signed     有方向的量（收益 / Alpha / 基准收益）—— 正数带 `+`
 *   magnitude  幅度量（波动率 / 回撤 / 达成率）—— **不加 `+`**，负号由数值自带
 *   score      评分 —— 0-100 的**普通数**，不是百分比（35 分不能写成 `35.00%`）
 *   number     无量纲的普通数（盈亏比 1.00）—— 同样不是百分比
 *   count      计数 —— 整数，无小数
 *   money      金额 —— 两位小数 + 千分位
 *
 * 为什么单独有 `score` / `number`：`magnitude` 会乘 100 并加 `%`。
 * 评分 35 与盈亏比 1.0 都不是比例，一旦被当成 `magnitude` 就变成
 * `3500.0%` / `100.00%` —— 与最初那个子串正则事故是**同一类错误的另一个入口**：
 * 只要"类型"是猜出来的，换一个字段名就会再犯一次。
 */

import { normalizeLanguage } from '../i18n.js'

/** 类型常量，供调用方与测试引用（避免拼错字符串）。 */
export const METRIC_TYPE = Object.freeze({
  SIGNED: 'signed',
  MAGNITUDE: 'magnitude',
  SCORE: 'score',
  NUMBER: 'number',
  COUNT: 'count',
  MONEY: 'money',
})

/**
 * 字段 → 类型。**新增指标必须在这里声明**（否则 `tests/unit/report-format.test.js` 会失败）。
 *
 * 这张表同时是文档：读它就知道每个数字该怎么展示。
 */
export const METRIC_TYPES = Object.freeze({
  // ── 计数 ────────────────────────────────────────────────────────────────
  analyst_count: METRIC_TYPE.COUNT,
  strategies: METRIC_TYPE.COUNT,
  evaluated: METRIC_TYPE.COUNT,
  pending_evaluation: METRIC_TYPE.COUNT,
  active: METRIC_TYPE.COUNT,
  completed: METRIC_TYPE.COUNT,
  stopped: METRIC_TYPE.COUNT,
  expired: METRIC_TYPE.COUNT,
  cancelled: METRIC_TYPE.COUNT,
  wins: METRIC_TYPE.COUNT,
  losses: METRIC_TYPE.COUNT,
  positive_alpha_count: METRIC_TYPE.COUNT,
  negative_alpha_count: METRIC_TYPE.COUNT,
  holding_days: METRIC_TYPE.COUNT,
  holding_period_planned: METRIC_TYPE.COUNT,
  quantity: METRIC_TYPE.COUNT,
  position_before: METRIC_TYPE.COUNT,

  // ── 有方向的量（正数带 +）────────────────────────────────────────────────
  average_return: METRIC_TYPE.SIGNED,
  median_return: METRIC_TYPE.SIGNED,
  best_return: METRIC_TYPE.SIGNED,
  worst_return: METRIC_TYPE.SIGNED,
  average_alpha: METRIC_TYPE.SIGNED,
  strategy_return: METRIC_TYPE.SIGNED,
  benchmark_return: METRIC_TYPE.SIGNED,
  alpha: METRIC_TYPE.SIGNED,
  unrealized_return: METRIC_TYPE.SIGNED,
  unrealized_alpha: METRIC_TYPE.SIGNED,

  // ── 幅度量（不加 +）────────────────────────────────────────────────────
  win_rate: METRIC_TYPE.MAGNITUDE,
  hit_rate_vs_benchmark: METRIC_TYPE.MAGNITUDE,
  target_achievement_rate: METRIC_TYPE.MAGNITUDE,
  stop_loss_rate: METRIC_TYPE.MAGNITUDE,
  max_drawdown: METRIC_TYPE.MAGNITUDE,
  average_drawdown: METRIC_TYPE.MAGNITUDE,
  volatility: METRIC_TYPE.MAGNITUDE,
  // ── 评分：0-100 的普通数，**不是百分比** ────────────────────────────────
  average_score: METRIC_TYPE.SCORE,
  median_score: METRIC_TYPE.SCORE,
  best_score: METRIC_TYPE.SCORE,
  worst_score: METRIC_TYPE.SCORE,
  score: METRIC_TYPE.SCORE,

  // ── 无量纲的普通数（盈亏比 1.00，不是 100%）────────────────────────────
  risk_reward_ratio: METRIC_TYPE.NUMBER,

  // ── 金额 ────────────────────────────────────────────────────────────────
  total_pnl: METRIC_TYPE.MONEY,
  pnl: METRIC_TYPE.MONEY,

})

/**
 * 取某个字段的类型。
 *
 * 未声明的字段**抛错**而不是猜：报告里出现一个来源不明的数字，
 * 比报告生成失败更糟（前者会被当真，后者会被人发现）。
 */
export function metricType(key) {
  const type = METRIC_TYPES[key]
  if (type === undefined) {
    throw new Error(
      `report metric "${key}" has no declared type — add it to METRIC_TYPES in src/core/report/format.js `
      + '(计数用 COUNT、金额用 MONEY、有方向的量用 SIGNED、幅度量用 MAGNITUDE)',
    )
  }
  return type
}

/** 有方向的百分比：正数带 `+`（收益 / Alpha / 基准收益）。 */
export function signedPct(value, decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return `${value > 0 ? '+' : ''}${(value * 100).toFixed(decimals)}%`
}

/**
 * 幅度百分比：**不加 `+`**。
 * 负号由数值自带（回撤本来就是负的，照常显示 `-20.31%`；
 * 波动率非负，显示 `40.7%` 而不是 `+40.7%`）。
 */
export function magnitudePct(value, decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return `${(value * 100).toFixed(decimals)}%`
}

/** 计数：整数 + 千分位，**绝不出现小数**。 */
export function formatCount(value, language = 'zh') {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return Math.round(value).toLocaleString(normalizeLanguage(language) === 'en' ? 'en-US' : 'zh-CN')
}

/** 金额：两位小数 + 千分位。 */
export function formatMoney(value, language = 'zh', decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return value.toLocaleString(normalizeLanguage(language) === 'en' ? 'en-US' : 'zh-CN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

/** 数值（无单位）：固定小数位 + 千分位，用于盈亏比等。 */
export function formatNumber(value, language = 'zh', decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return value.toLocaleString(normalizeLanguage(language) === 'en' ? 'en-US' : 'zh-CN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })
}

/**
 * 评分：普通数，**不加 `%`**，且不补零。
 *
 * 引擎的 `score_decimals` 是 0，所以原始分是整数（`35`）；
 * 而分析师/团队聚合出来的平均值可能是 `46.5`。
 * 用"最多两位、不补零"同时满足两者：`35` 不会变成 `35.0`，`46.5` 也不会被截成 `47`。
 */
export function formatScore(value, language = 'zh', decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return value.toLocaleString(normalizeLanguage(language) === 'en' ? 'en-US' : 'zh-CN', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  })
}

/**
 * 按声明类型格式化一个聚合指标（报告的"事实区"表格用这个）。
 * @param {string} key 指标名
 * @param {unknown} value 指标值
 * @param {{ language?: string, decimals?: number }} [options]
 */
export function formatMetricValue(key, value, options = {}) {
  const language = normalizeLanguage(options.language)
  // 默认小数位：按**类型**给，不按字段名给
  // （旧的 `key.includes('score')` 又是在用字段名猜格式化行为）
  const decimals = options.decimals ?? (metricType(key) === METRIC_TYPE.COUNT ? 0 : 2)
  switch (metricType(key)) {
    case METRIC_TYPE.SIGNED: return signedPct(value, decimals)
    case METRIC_TYPE.MAGNITUDE: return magnitudePct(value, decimals)
    case METRIC_TYPE.SCORE: return formatScore(value, language, decimals)
    case METRIC_TYPE.NUMBER: return formatNumber(value, language, decimals)
    case METRIC_TYPE.COUNT: return formatCount(value, language)
    case METRIC_TYPE.MONEY: return formatMoney(value, language)
    default: throw new Error(`unhandled metric type for "${key}"`)
  }
}
