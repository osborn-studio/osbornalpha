import { computeMaxDrawdown } from "../evaluation/metrics.js";

// Offline demonstration domain. Never a production identity, market, or storage adapter.
export const VERSION = "review-demo-v1";
export const DAYS = [
  "2026-09-01",
  "2026-09-02",
  "2026-09-03",
  "2026-09-04",
  "2026-09-07",
  "2026-09-08",
  "2026-09-09",
  "2026-09-10",
  "2026-09-11",
  "2026-09-14",
  "2026-09-15",
  "2026-09-16",
  "2026-09-17",
  "2026-09-18",
  "2026-09-21",
  "2026-09-22",
  "2026-09-23",
  "2026-09-24",
  "2026-09-25",
];
export const SECURITIES = [
  {
    ticker: "00700",
    name: "腾讯控股",
    sector: "互联网",
    base: 510,
    changes: [
      0, 1.2, 2.1, 1.4, 3, 4.1, 3.7, 5.3, 4.8, 6, 7.2, 6.5, 8, 7.7, 9, 8, 10,
      9.1, 11,
    ],
  },
  {
    ticker: "09988",
    name: "阿里巴巴",
    sector: "互联网",
    base: 128,
    changes: [
      0, 0.6, 1.2, -1, -0.8, 1, 2.1, 1.7, 3, 4, 3.5, 4.2, 5.1, 4.8, 3.9, 5, 6,
      5.2, 7,
    ],
  },
  {
    ticker: "03690",
    name: "美团",
    sector: "消费服务",
    base: 116,
    changes: [
      0, -1, -2, -0.5, -3, -2.5, -4, -3, -5, -4.8, -4, -5.2, -3.5, -4, -3, -2,
      -4, -3, -2,
    ],
  },
  {
    ticker: "01810",
    name: "小米集团",
    sector: "智能硬件",
    base: 52,
    changes: [
      0, 2, 1.4, 3, 2.5, 4, 5.1, 4.3, 6, 7, 5.8, 6.5, 8, 7.1, 9, 8, 10, 11, 9,
    ],
  },
  {
    ticker: "00981",
    name: "中芯国际",
    sector: "半导体",
    base: 62,
    changes: [0, 1, -1, -2, 1, 3, 2, 4, 3, 5, 4, 3, 5, 6, 4, 5, 6, 7, 8],
  },
  {
    ticker: "02800",
    name: "盈富基金",
    sector: "宽基 ETF",
    base: 26,
    changes: [
      0, 0.4, 0.7, 0.2, 1, 1.5, 1.2, 2, 1.7, 2.4, 2.7, 2.2, 3, 2.8, 3.3, 3.1,
      3.7, 3.6, 4,
    ],
  },
];
export const MEMBERS = [
  { id: "lin", name: "林知远", sector: "互联网 / 消费", color: "green" },
  { id: "chen", name: "陈予安", sector: "科技 / 半导体", color: "blue" },
  { id: "zhou", name: "周明澈", sector: "消费 / ETF", color: "orange" },
  {
    id: "osborn",
    name: "Osborn",
    sector: "个人研究 · 混合来源",
    color: "purple",
  },
];
const clone = (x) => JSON.parse(JSON.stringify(x));
const money = (x) => Math.round((x + Number.EPSILON) * 100) / 100;
const stamp = (day) => `${DAYS[day]}T16:10:00+08:00`;
const assert = (condition, message) => {
  if (!condition) throw new Error(message);
};
export const price = (ticker, day, kind = "close") => {
  const s = SECURITIES.find((x) => x.ticker === ticker);
  assert(
    s && Number.isInteger(day) && day >= 0 && day < DAYS.length,
    "没有可用的模拟行情",
  );
  return money(
    s.base * (1 + s.changes[day] / 100) * (kind === "open" ? 0.998 : 1),
  );
};
export function visibleAccounts(
  state,
  workspace = "team",
  actor = { role: "manager" },
) {
  return state.accounts.filter(
    (a) =>
      a.workspace === workspace &&
      (actor.role !== "analyst" || a.owner === actor.id),
  );
}
export function valuation(account, day) {
  const holdings = Object.entries(account.positions)
    .filter(([, p]) => p.quantity > 1e-8)
    .map(([ticker, p]) => ({
      ticker,
      ...p,
      price: price(ticker, day),
      value: money(p.quantity * price(ticker, day)),
      pnl: money(p.quantity * (price(ticker, day) - p.cost)),
    }));
  const marketValue = money(holdings.reduce((a, p) => a + p.value, 0));
  const equity = money(account.cash + marketValue);
  return {
    cash: account.cash,
    marketValue,
    equity,
    nav: equity / account.initial,
    return: equity / account.initial - 1,
    exposure: (marketValue / equity) * 100,
    holdings: holdings.map((p) => ({ ...p, weight: (p.value / equity) * 100 })),
  };
}
export function performance(account, day, window = 0) {
  const history = account.history
    .filter((h) => h.day <= day)
    .slice(window ? -window : 0);
  const first = history[0] || { equity: account.initial, day: 0 };
  const last = history.at(-1) || first;
  const ret = last.equity / first.equity - 1;
  const benchmark = price("02800", last.day) / price("02800", first.day) - 1;
  return {
    history,
    return: ret,
    benchmark,
    excess: ret - benchmark,
    drawdown: computeMaxDrawdown({
      prices: history.length ? history.map((h) => h.equity) : [account.initial],
    }),
    samples: account.trades.length,
  };
}
function event(
  state,
  type,
  detail,
  ref = null,
  actor = "system",
  workspace = "team",
) {
  const e = {
    id: `EV-${String(++state.sequence).padStart(4, "0")}`,
    type,
    detail,
    ref,
    actor,
    workspace,
    at: stamp(state.day),
    version: VERSION,
  };
  state.events.push(e);
  return e;
}
export function parseMessage(text, trigger = "mention") {
  const active =
    trigger === "all" ||
    (trigger === "prefix"
      ? text.trim().startsWith("/记录")
      : /@(?:判断台|机器人)/.test(text));
  if (
    !active ||
    !/(买|卖|建仓|加仓|减仓|清仓|仓位)/.test(text) ||
    /(不买|不卖|不减仓|不加仓|不要买|不要卖|别买|别卖|如果|要不要|能不能|怎么样|[?？])/.test(
      text,
    )
  )
    return {
      status: "ignored",
      reason: "未满足显式指令条件，仅保留为普通讨论",
    };
  const aliases = {
    "00700": ["腾讯"],
    "09988": ["阿里巴巴", "阿里"],
    "03690": ["美团"],
    "01810": ["小米"],
    "00981": ["中芯"],
    "02800": ["盈富"],
  };
  const found = SECURITIES.filter(
    (s) =>
      text.includes(s.ticker) ||
      aliases[s.ticker].some((name) => text.includes(name)),
  );
  const direction = /(卖|减仓|清仓)/.test(text) ? "SELL" : "BUY";
  const weight = /(-?\d+(?:\.\d+)?)\s*(?:%|％|个点)/.exec(text);
  const mode = /目标仓位|仓位至|仓位到/.test(text)
    ? "target"
    : /增加|增量|加仓|减仓/.test(text)
      ? "delta"
      : null;
  const issues = [];
  if (weight && (Number(weight[1]) < 0 || Number(weight[1]) > 100))
    issues.push("仓位超出 0–100% 范围");
  if (/买|建仓|加仓/.test(text) && /卖|减仓|清仓/.test(text))
    issues.push("包含多个买卖动作，请拆分记录");
  if (found.length !== 1)
    issues.push(
      found.length ? "包含多个标的，请拆分记录" : "标的未识别，请人工选择",
    );
  if (!weight && !/清仓/.test(text)) issues.push("缺少仓位比例");
  if (!mode && !/清仓/.test(text)) issues.push("请确认目标仓位还是增减仓位");
  return {
    ticker: found.length === 1 ? found[0].ticker : null,
    direction,
    weight: /清仓/.test(text) ? 0 : weight ? Number(weight[1]) : null,
    mode: /清仓/.test(text) ? "target" : mode,
    status: issues.length ? "ambiguous" : "pending",
    reason: issues.join("；"),
  };
}
export function ingest(
  state,
  { text, owner = "lin", workspace = "team", messageId, origin = "manual" },
) {
  assert(
    typeof text === "string" && text.trim() && text.length <= 4000,
    "请输入 1–4000 字的观点原文",
  );
  const known = state.judgments.find(
    (j) => j.messageId === messageId && j.workspace === workspace,
  );
  if (messageId && known) return { judgment: known, duplicate: true };
  const account = state.accounts.find(
    (a) => a.owner === owner && a.workspace === workspace,
  );
  assert(account, "未知成员：请先完成身份映射");
  const parsed = parseMessage(text, state.settings.trigger);
  const j = {
    id: `J-${String(++state.sequence).padStart(4, "0")}`,
    messageId: messageId || `local-${state.sequence}`,
    workspace,
    owner,
    accountId: account.id,
    text,
    origin,
    sourceVersion: origin === "manual" ? "manual-v1" : "alpha-candidate-v1",
    runId: origin === "manual" ? null : `demo-run-${state.sequence}`,
    inputCutoff: stamp(state.day),
    ...parsed,
    createdAt: stamp(state.day),
    receivedAt: stamp(state.day),
    day: state.day,
    versions: [],
    pm: null,
    observation: "尚待观察",
  };
  state.judgments.push(j);
  event(
    state,
    "观点接收",
    parsed.reason || "生成待确认候选，未入账",
    j.id,
    owner,
    workspace,
  );
  return { judgment: j, duplicate: false };
}
function own(state, id, actor) {
  const j = state.judgments.find((x) => x.id === id);
  assert(j, "记录不存在");
  assert(
    actor.id === j.owner && actor.role === "analyst",
    "仅观点所属分析师可确认或变更；请切换对应演示身份",
  );
  return j;
}
export function confirm(state, id, fields, actor) {
  const j = own(state, id, actor);
  assert(
    ["pending", "ambiguous", "blocked"].includes(j.status),
    "该记录已处理，不能重复确认",
  );
  const account = state.accounts.find((a) => a.id === j.accountId);
  const { ticker, direction, mode } = fields;
  const weight = Number(fields.weight);
  assert(
    SECURITIES.some((s) => s.ticker === ticker),
    "请选择有效证券",
  );
  assert(
    ["BUY", "SELL"].includes(direction) && ["target", "delta"].includes(mode),
    "请选择方向与仓位语义",
  );
  assert(
    Number.isFinite(weight) &&
      weight >= 0 &&
      weight <= 100 &&
      (weight > 0 || (direction === "SELL" && mode === "target")),
    "仓位必须为 0–100%，仅清仓可填 0",
  );
  assert(state.day < DAYS.length - 1, "已到演示行情终点，请重置后演示");
  const values = valuation(account, state.day);
  const existing =
    values.holdings.find((p) => p.ticker === ticker)?.weight || 0;
  const target =
    mode === "target"
      ? weight
      : existing + (direction === "BUY" ? weight : -weight);
  assert(target >= -1e-7, "减仓不能超过已有仓位");
  assert(
    direction === "BUY" ? target > existing : target < existing,
    "方向与目标仓位不一致，或没有可卖持仓",
  );
  assert(
    direction === "SELL" || target <= account.maxPosition,
    "单一目标仓位超过账户总仓位上限",
  );
  const projected = values.exposure - existing + target;
  assert(
    direction === "SELL" ||
      projected <= account.maxPosition + 1e-7 ||
      fields.rebalance === true,
    "超出总仓位上限，请降低仓位或明确确认 FIFO 调仓",
  );
  j.versions.push({
    at: stamp(state.day),
    actor: actor.id,
    before: {
      ticker: j.ticker,
      direction: j.direction,
      weight: j.weight,
      mode: j.mode,
    },
    after: { ticker, direction, weight, mode },
    reason: fields.reason || "确认解析结果",
  });
  Object.assign(j, {
    ticker,
    direction,
    weight,
    mode,
    status: "queued",
    confirmedAt: stamp(state.day),
    confirmedDay: state.day,
    decisionAuthor: actor.id,
    executionDay: state.day + 1,
    policy: {
      feeBps: state.settings.feeBps,
      maxPosition: account.maxPosition,
      rebalance: !!fields.rebalance,
      version: `rules-${state.settings.ruleVersion}`,
    },
    reason: "",
  });
  event(
    state,
    "人工确认",
    "待下一模拟交易日开盘执行；当前现金未变",
    id,
    actor.id,
    j.workspace,
  );
  return j;
}
export function dismiss(state, id, actor, reason = "不构成正式建议") {
  const j = own(state, id, actor);
  assert(
    ["pending", "ambiguous", "queued", "blocked"].includes(j.status),
    "已成交记录不能撤回；请新增卖出或更正事件",
  );
  j.status = "withdrawn";
  event(state, "撤回候选", reason, id, actor.id, j.workspace);
}
function fill(account, j, day, ticker, quantity, feeBps, reason) {
  const px = price(ticker, day, "open");
  const gross = money(quantity * px);
  const fee = money((Math.abs(gross) * feeBps) / 10000);
  const p = account.positions[ticker] || {
    quantity: 0,
    cost: 0,
    openedDay: day,
  };
  const nextQuantity = p.quantity + quantity;
  assert(nextQuantity >= -1e-7, "卖出超过可用持仓");
  const nextCash = money(account.cash - gross - fee);
  assert(nextCash >= -0.01, "现金不足（含费用），请减少目标仓位");
  account.positions[ticker] = {
    quantity: Math.max(0, nextQuantity),
    cost: quantity > 0 ? (p.cost * p.quantity + gross) / nextQuantity : p.cost,
    openedDay: p.quantity ? p.openedDay : day,
  };
  account.cash = Math.max(0, nextCash);
  account.trades.push({
    id: `T-${j.id}-${account.trades.length + 1}`,
    judgmentId: j.id,
    ticker,
    quantity,
    price: px,
    gross,
    fee,
    feeBps,
    day,
    reason,
    priceFormedAt: `${DAYS[day]}T09:30:00+08:00`,
    priceArrivedAt: `${DAYS[day]}T09:30:02+08:00`,
    executedAt: `${DAYS[day]}T09:30:02+08:00`,
    confirmedAt: j.confirmedAt,
    ruleVersion: j.policy.version,
    marketVersion: "hk-mock-v1",
  });
}
function execute(state, j) {
  const account = state.accounts.find((a) => a.id === j.accountId);
  const draft = clone(account);
  const day = state.day;
  const marked = Object.entries(draft.positions).map(([ticker, p]) => ({
    ...p,
    ticker,
    value: p.quantity * price(ticker, day, "open"),
  }));
  const equity = draft.cash + marked.reduce((n, p) => n + p.value, 0);
  const current = marked.find((p) => p.ticker === j.ticker)?.value || 0;
  const target =
    j.mode === "target"
      ? (equity * j.weight) / 100
      : current + ((j.direction === "BUY" ? 1 : -1) * equity * j.weight) / 100;
  assert(target >= -0.01, "成交日可用仓位不足，未执行");
  const delta = target - current;
  assert(
    j.direction === "BUY" ? delta > 0 : delta < 0,
    "成交日价格变动使方向与目标不一致，未执行",
  );
  if (delta > 0) {
    const grossHeld = marked.reduce((n, p) => n + p.value, 0);
    const expectedFee = (delta * j.policy.feeBps) / 10000;
    let required = Math.max(
      0,
      grossHeld + delta - ((equity - expectedFee) * j.policy.maxPosition) / 100,
      delta + expectedFee - draft.cash,
    );
    assert(
      required < 0.01 || j.policy.rebalance,
      "成交日仓位或现金超限，未执行；请重新确认调仓",
    );
    if (required > 0.01) {
      for (const victim of marked
        .filter((p) => p.ticker !== j.ticker && p.quantity > 0)
        .sort(
          (a, b) =>
            a.openedDay - b.openedDay || a.ticker.localeCompare(b.ticker),
        )) {
        assert(
          state.settings.missingTicker !== victim.ticker,
          "调仓标的缺少有效开盘价，整笔指令未执行",
        );
        fill(
          draft,
          j,
          day,
          victim.ticker,
          -victim.quantity,
          j.policy.feeBps,
          "经确认的 FIFO 调仓",
        );
        const held = Object.entries(draft.positions).reduce(
          (n, [t, p]) => n + p.quantity * price(t, day, "open"),
          0,
        );
        const afterEquity = draft.cash + held - expectedFee;
        required = Math.max(
          0,
          held + delta - (afterEquity * j.policy.maxPosition) / 100,
          delta + expectedFee - draft.cash,
        );
        if (required < 0.01) break;
      }
      assert(required < 0.01, "调仓后仍无法满足现金和仓位约束，未执行");
    }
  }
  fill(
    draft,
    j,
    day,
    j.ticker,
    target === 0
      ? -(draft.positions[j.ticker]?.quantity || 0)
      : delta / price(j.ticker, day, "open"),
    j.policy.feeBps,
    "确认后的模拟成交",
  );
  Object.assign(account, draft);
  j.status = "executed";
  j.executedDay = day;
  event(
    state,
    "模拟成交",
    `${j.direction === "BUY" ? "买入" : "卖出"} ${j.ticker}，现金与持仓已更新`,
    j.id,
    j.decisionAuthor,
    j.workspace,
  ).at = account.trades.at(-1).executedAt;
}
export function advance(state) {
  assert(state.day < DAYS.length - 1, "已到演示行情终点，请重置演示数据");
  state.day++;
  for (const j of state.judgments.filter(
    (j) => j.status === "queued" && j.executionDay <= state.day,
  )) {
    if (state.settings.missingTicker === j.ticker) {
      event(
        state,
        "行情缺口",
        "缺少有效开盘价，保持待执行，不编造成交",
        j.id,
        "system",
        j.workspace,
      );
      continue;
    }
    try {
      execute(state, j);
    } catch (e) {
      j.status = "blocked";
      j.reason = e.message;
      event(state, "执行拦截", e.message, j.id, "system", j.workspace);
    }
  }
  for (const a of state.accounts) {
    const v = valuation(a, state.day);
    a.history.push({ day: state.day, equity: v.equity, nav: v.nav });
    event(
      state,
      "日终估值",
      "模拟时钟推进；净值由现金与持仓复算",
      null,
      a.owner,
      a.workspace,
    );
  }
}
export function verify(account) {
  let cash = account.initial;
  const positions = {},
    costs = {};
  const errors = [];
  const ids = new Set();
  const finite = (x, label) => {
    if (typeof x !== "number" || !Number.isFinite(x))
      errors.push(`${label} 不是有效数字`);
  };
  finite(account.initial, "初始资金");
  finite(account.cash, "现金");
  for (const t of account.trades) {
    for (const k of ["quantity", "price", "gross", "fee", "feeBps"])
      finite(t[k], `${t.id} ${k}`);
    if (ids.has(t.id)) errors.push("成交编号重复");
    ids.add(t.id);
    if (
      !Number.isInteger(t.day) ||
      t.day < 0 ||
      t.day >= DAYS.length ||
      !SECURITIES.some((s) => s.ticker === t.ticker)
    ) {
      errors.push("成交日期或证券无效");
      continue;
    }
    if (
      t.price !== price(t.ticker, t.day, "open") ||
      Math.abs(t.gross - money(t.quantity * t.price)) > 0.01
    )
      errors.push(`${t.id} 成交金额或行情不一致`);
    if (
      t.feeBps < 0 ||
      t.feeBps > 100 ||
      t.fee !== money((Math.abs(t.gross) * t.feeBps) / 10000)
    )
      errors.push(`${t.id} 费用不一致`);
    const confirmed = Date.parse(t.confirmedAt),
      formed = Date.parse(t.priceFormedAt),
      arrived = Date.parse(t.priceArrivedAt),
      executed = Date.parse(t.executedAt);
    if (
      ![confirmed, formed, arrived, executed].every(Number.isFinite) ||
      formed <= confirmed ||
      arrived < formed ||
      executed < arrived ||
      !t.priceFormedAt.startsWith(DAYS[t.day])
    )
      errors.push(`${t.id} 价格与确认时间不合法`);
    const old = positions[t.ticker] || 0;
    const next = old + t.quantity;
    if (t.quantity > 0)
      costs[t.ticker] = ((costs[t.ticker] || 0) * old + t.gross) / next;
    positions[t.ticker] = Math.max(0, next);
    cash = money(cash - t.gross - t.fee);
    if (next < -1e-7 || cash < -0.01) errors.push(`${t.id} 现金或持仓为负`);
  }
  if (Math.abs(cash - account.cash) > 0.02) errors.push("现金流水不平");
  for (const ticker of new Set([
    ...Object.keys(positions),
    ...Object.keys(account.positions),
  ])) {
    const p = account.positions[ticker];
    if (p) {
      finite(p.quantity, `${ticker} 份额`);
      finite(p.cost, `${ticker} 成本`);
    }
    if (Math.abs((positions[ticker] || 0) - (p?.quantity || 0)) > 1e-7)
      errors.push(`${ticker} 持仓不平`);
    if (p && Math.abs((costs[ticker] || 0) - p.cost) > 1e-5)
      errors.push(`${ticker} 成本不一致`);
  }
  for (const h of account.history) {
    finite(h.equity, "历史权益");
    finite(h.nav, "历史净值");
    if (!Number.isInteger(h.day) || h.day < 0 || h.day >= DAYS.length) {
      errors.push("历史日期无效");
      continue;
    }
    let hc = account.initial;
    const hp = {};
    for (const t of account.trades.filter((t) => t.day <= h.day)) {
      hc = money(hc - t.gross - t.fee);
      hp[t.ticker] = (hp[t.ticker] || 0) + t.quantity;
    }
    try {
      const eq = money(
        hc +
          Object.entries(hp).reduce(
            (n, [ticker, q]) =>
              n + money(Math.max(0, q) * price(ticker, h.day)),
            0,
          ),
      );
      if (
        Math.abs(eq - h.equity) > 0.02 ||
        Math.abs(eq / account.initial - h.nav) > 1e-7
      )
        errors.push(`历史 ${DAYS[h.day]} 净值不一致`);
    } catch {
      errors.push("历史行情无效");
    }
  }
  return {
    ok: !errors.length,
    errors,
    cash,
    tradeCount: account.trades.length,
    fee: money(account.trades.reduce((n, t) => n + t.fee, 0)),
  };
}
export function validateState(s) {
  const iso = (x) =>
    typeof x === "string" &&
    /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+08:00$/.test(x) &&
    Number.isFinite(Date.parse(x));
  const text = (x) => typeof x === "string" && x.length <= 10000;
  const id = (x, prefix) =>
    typeof x === "string" && new RegExp(`^${prefix}-[0-9]+$`).test(x);
  assert(
    s &&
      s.version === VERSION &&
      Number.isInteger(s.day) &&
      s.day >= 0 &&
      s.day < DAYS.length &&
      Number.isSafeInteger(s.sequence) &&
      s.sequence >= 0,
    "演示状态版本或日期无效",
  );
  for (const key of [
    "accounts",
    "judgments",
    "events",
    "reviews",
    "hypotheses",
  ])
    assert(Array.isArray(s[key]), "演示状态结构不完整");
  assert(
    s.accounts.length === 4 && new Set(s.accounts.map((a) => a.id)).size === 4,
    "模拟账户不完整",
  );
  for (const a of s.accounts) {
    assert(
      MEMBERS.some((m) => m.id === a.owner) &&
        a.id === `ACC-${a.owner}` &&
        a.workspace === (a.owner === "osborn" ? "personal" : "team") &&
        a.kind ===
          (a.owner === "osborn" ? "PERSONAL_PAPER" : "INSTITUTION_PAPER"),
      "账户归属无效",
    );
    assert(
      a.initial === 1000000 &&
        Number.isFinite(a.cash) &&
        a.cash >= 0 &&
        Number.isFinite(a.maxPosition) &&
        a.maxPosition >= 10 &&
        a.maxPosition <= 100 &&
        a.positions &&
        typeof a.positions === "object" &&
        !Array.isArray(a.positions) &&
        Array.isArray(a.trades) &&
        Array.isArray(a.history),
      "账户结构无效",
    );
    assert(
      a.history.length === s.day + 1 && a.history.every((h, i) => h.day === i),
      "历史观察期不完整",
    );
    for (const [ticker, p] of Object.entries(a.positions))
      assert(
        SECURITIES.some((x) => x.ticker === ticker) &&
          p &&
          Number.isFinite(p.quantity) &&
          p.quantity >= 0 &&
          Number.isFinite(p.cost) &&
          p.cost >= 0 &&
          Number.isInteger(p.openedDay) &&
          p.openedDay >= 0 &&
          p.openedDay <= s.day,
        "持仓结构无效",
      );
    for (const t of a.trades)
      assert(
        /^T-J-\d+-\d+$/.test(t.id) &&
          id(t.judgmentId, "J") &&
          iso(t.confirmedAt) &&
          iso(t.priceFormedAt) &&
          iso(t.priceArrivedAt) &&
          iso(t.executedAt) &&
          /^rules-\d+$/.test(t.ruleVersion) &&
          text(t.reason) &&
          t.day <= s.day,
        "成交结构无效",
      );
    assert(verify(a).ok, "演示账本或历史核对失败");
  }
  assert(
    new Set(s.judgments.map((j) => j.id)).size === s.judgments.length,
    "判断编号重复",
  );
  for (const j of s.judgments) {
    const a = s.accounts.find((a) => a.id === j.accountId);
    assert(
      id(j.id, "J") &&
        a &&
        a.owner === j.owner &&
        a.workspace === j.workspace &&
        text(j.text) &&
        text(j.messageId) &&
        iso(j.createdAt) &&
        iso(j.receivedAt) &&
        Number.isInteger(j.day) &&
        j.day >= 0 &&
        j.day <= s.day,
      "判断结构无效",
    );
    assert(
      (j.ticker == null || SECURITIES.some((x) => x.ticker === j.ticker)) &&
        (j.weight == null || Number.isFinite(j.weight)) &&
        (j.direction == null || ["BUY", "SELL"].includes(j.direction)) &&
        (j.mode == null || ["target", "delta"].includes(j.mode)),
      "解析候选结构无效",
    );
    assert(
      ["manual", "copilot", "signal"].includes(j.origin) &&
        [
          "pending",
          "ambiguous",
          "queued",
          "executed",
          "ignored",
          "withdrawn",
          "blocked",
        ].includes(j.status) &&
        Array.isArray(j.versions) &&
        j.versions.every((v) => iso(v.at) && text(v.actor) && text(v.reason)),
      "判断版本或状态无效",
    );
    if (j.confirmedAt)
      assert(
        iso(j.confirmedAt) &&
          j.decisionAuthor === j.owner &&
          j.policy &&
          /^rules-\d+$/.test(j.policy.version) &&
          Number.isFinite(j.policy.feeBps) &&
          j.policy.feeBps >= 0 &&
          j.policy.feeBps <= 100 &&
          Number.isFinite(j.policy.maxPosition) &&
          j.policy.maxPosition >= 10 &&
          j.policy.maxPosition <= 100 &&
          typeof j.policy.rebalance === "boolean",
        "确认或规则无效",
      );
    if (["queued", "executed", "blocked"].includes(j.status))
      assert(
        j.confirmedAt &&
          SECURITIES.some((x) => x.ticker === j.ticker) &&
          ["BUY", "SELL"].includes(j.direction) &&
          ["target", "delta"].includes(j.mode) &&
          Number.isFinite(j.weight) &&
          j.weight >= 0 &&
          j.weight <= 100 &&
          Number.isInteger(j.executionDay) &&
          j.executionDay > j.confirmedDay,
        "指令结构无效",
      );
    if (j.pm)
      assert(
        ["采纳", "观察", "未采纳"].includes(j.pm.choice) &&
          text(j.pm.reason) &&
          iso(j.pm.at),
        "PM 决定无效",
      );
  }
  for (const a of s.accounts)
    for (const t of a.trades)
      assert(
        s.judgments.some(
          (j) =>
            j.id === t.judgmentId &&
            j.accountId === a.id &&
            j.status === "executed",
        ),
        "成交与判断关联无效",
      );
  assert(
    new Set(s.events.map((e) => e.id)).size === s.events.length,
    "事件编号重复",
  );
  for (const e of s.events)
    assert(
      id(e.id, "EV") &&
        ["team", "personal"].includes(e.workspace) &&
        iso(e.at) &&
        text(e.actor) &&
        text(e.type) &&
        text(e.detail) &&
        (!e.ref ||
          s.judgments.some(
            (j) => j.id === e.ref && j.workspace === e.workspace,
          )),
      "事件结构无效",
    );
  assert(s.reviews.length === 1, "复盘结构无效");
  for (const r of s.reviews) {
    assert(
      text(r.title) &&
        text(r.summary) &&
        text(r.period) &&
        text(r.conclusion) &&
        Array.isArray(r.actions),
      "复盘结构无效",
    );
    for (const a of r.actions)
      assert(
        id(a.id, "A") &&
          text(a.text) &&
          MEMBERS.some((m) => m.id === a.owner && m.id !== "osborn") &&
          /^\d{4}-\d{2}-\d{2}$/.test(a.due) &&
          typeof a.done === "boolean",
        "行动结构无效",
      );
  }
  for (const h of s.hypotheses)
    assert(
      id(h.id, "H") &&
        text(h.project) &&
        text(h.hypothesis) &&
        text(h.evidence) &&
        ["继续研究", "投资", "不投资"].includes(h.decision) &&
        ["待验证", "兑现", "失效", "延期", "无法判断"].includes(h.result) &&
        /^\d{4}-\d{2}-\d{2}$/.test(h.deadline),
      "假设结构无效",
    );
  const f = s.settings;
  assert(
    f &&
      Number.isFinite(f.feeBps) &&
      f.feeBps >= 0 &&
      f.feeBps <= 100 &&
      Number.isSafeInteger(f.ruleVersion) &&
      f.ruleVersion > 0 &&
      ["mention", "prefix", "all"].includes(f.trigger) &&
      (!f.missingTicker ||
        SECURITIES.some((x) => x.ticker === f.missingTicker)),
    "规则配置无效",
  );
  return s;
}
export function recordPM(state, id, choice, reason, actor) {
  assert(actor.role === "manager", "仅 PM 演示身份可记录采纳决定");
  assert(reason.trim(), "请填写采纳或未采纳的理由");
  const j = state.judgments.find((j) => j.id === id);
  assert(j && j.workspace === "team", "机构记录不存在");
  assert(["采纳", "观察", "未采纳"].includes(choice), "未知决定");
  j.pm = { choice, reason, actor: actor.id, at: stamp(state.day) };
  event(state, "PM 决定", `${choice}：${reason}`, id, actor.id, j.workspace);
}
export function addNote(state, id, text, actor) {
  const j = state.judgments.find((j) => j.id === id);
  assert(j, "记录不存在");
  assert(
    (actor.role === "manager" && j.workspace === "team") ||
      (actor.role === "analyst" && actor.id === j.owner),
    "无权更正此记录",
  );
  assert(text.trim(), "请填写更正或补充理由");
  event(state, "观点补充", text, id, actor.id, j.workspace);
}
export function changeSettings(state, fields, actor) {
  assert(actor.role === "admin", "请切换管理员演示身份");
  const fee = Number(fields.feeBps);
  const cap = Number(fields.maxPosition);
  assert(Number.isFinite(fee) && fee >= 0 && fee <= 100, "费用应为 0–100 bps");
  assert(
    Number.isFinite(cap) && cap >= 10 && cap <= 100,
    "总仓位上限应为 10–100%",
  );
  assert(["mention", "prefix", "all"].includes(fields.trigger), "未知触发规则");
  state.settings = {
    ...state.settings,
    ...fields,
    feeBps: fee,
    ruleVersion: state.settings.ruleVersion + 1,
  };
  state.accounts
    .filter(
      (a) =>
        a.workspace === "team" &&
        (!fields.accountId || fields.accountId === a.id),
    )
    .forEach((a) => (a.maxPosition = cap));
  event(
    state,
    "规则更新",
    `新规则 rules-${state.settings.ruleVersion}；仅后续确认生效`,
    null,
    actor.id,
  );
}
export function createState() {
  const state = {
    version: VERSION,
    day: 0,
    sequence: 0,
    settings: {
      feeBps: 5,
      ruleVersion: 1,
      trigger: "mention",
      missingTicker: "",
    },
    accounts: MEMBERS.map((m) => ({
      id: `ACC-${m.id}`,
      owner: m.id,
      workspace: m.id === "osborn" ? "personal" : "team",
      kind: m.id === "osborn" ? "PERSONAL_PAPER" : "INSTITUTION_PAPER",
      initial: 1000000,
      cash: 1000000,
      maxPosition: 90,
      positions: {},
      trades: [],
      history: [{ day: 0, equity: 1000000, nav: 1 }],
    })),
    judgments: [],
    events: [],
    reviews: [
      {
        id: "R-1",
        title: "本周：增长的质量，比增长更重要",
        period: "2026-09-14 — 2026-09-18",
        summary:
          "腾讯与阿里的观点兑现程度值得继续观察；美团补贴强度超出原假设，周会上讨论触发条件。",
        actions: [
          {
            id: "A-1",
            text: "核对腾讯广告业务增长假设",
            owner: "lin",
            due: "2026-09-21",
            done: false,
          },
          {
            id: "A-2",
            text: "补充美团竞争格局的反证",
            owner: "zhou",
            due: "2026-09-22",
            done: false,
          },
        ],
        conclusion: "",
      },
    ],
    hypotheses: [
      {
        id: "H-1",
        project: "海湾科技",
        hypothesis: "未来一季度企业客户续约率达到 90%",
        decision: "继续研究",
        result: "待验证",
        evidence: "虚构访谈样例；尚无经营证据",
        deadline: "2026-12-18",
      },
    ],
  };
  const seeds = [
    ["lin", "00700", 25, 0],
    ["lin", "09988", 20, 0],
    ["chen", "00981", 30, 0],
    ["zhou", "03690", 25, 0],
    ["osborn", "00700", 20, 0],
    ["chen", "01810", 25, 2],
    ["zhou", "02800", 30, 2],
    ["lin", "01810", 15, 3],
    ["osborn", "09988", 15, 3],
  ];
  for (let d = 0; d < 11; d++) {
    for (const [owner, ticker, weight, day] of seeds.filter(
      (x) => x[3] === d,
    )) {
      const s = SECURITIES.find((x) => x.ticker === ticker);
      const { judgment: j } = ingest(state, {
        text: `@判断台 买入${s.name}，目标仓位 ${weight}%。观察期三个月，关注业务增长与竞争格局。`,
        owner,
        workspace: owner === "osborn" ? "personal" : "team",
        origin: owner === "osborn" ? "copilot" : "manual",
      });
      confirm(
        state,
        j.id,
        { ticker, direction: "BUY", weight, mode: "target" },
        { id: owner, role: "analyst" },
      );
      j.observation = ticker === "03690" ? "假设承压" : "持续观察";
    }
    advance(state);
  }
  ingest(state, {
    text: "@判断台 买入腾讯 10 个点，广告业务的增长仍有韧性。",
    owner: "lin",
  });
  ingest(state, {
    text: "@判断台 买入阿里巴巴，目标仓位 20%，观察云业务利润率。",
    owner: "chen",
  });
  ingest(state, {
    text: "@判断台 卖出美团，目标仓位 15%，竞争投入超预期。",
    owner: "zhou",
  });
  ingest(state, { text: "今天大家有空一起聊聊消费板块吗？", owner: "lin" });
  ingest(state, {
    text: "@判断台 买入小米集团，目标仓位 10%，跟踪新业务盈利。",
    owner: "osborn",
    workspace: "personal",
    origin: "copilot",
  });
  const first = state.judgments[0];
  recordPM(
    state,
    first.id,
    "观察",
    "等待下一次财报验证广告增速，先跟踪模拟结果。",
    { id: "pm", role: "manager" },
  );
  return state;
}
