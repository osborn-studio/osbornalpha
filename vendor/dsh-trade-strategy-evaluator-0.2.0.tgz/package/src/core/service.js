/**
 * TradeEvaluationService —— 业务服务的唯一组合点。
 *
 * 它把市场数据、评价引擎、监控、报告、审计事件、权限、持久化组装成 5 个业务插件
 * 共用的服务对象。**任何数值都不在这里计算**：这里只做校验、编排、落库与审计。
 *
 * 三个不变量由本文件强制（并被测试覆盖）：
 *  1. 冻结后不可修改核心决策字段（`assertCoreImmutable` 在每次写库前运行）；
 *  2. 评价只使用提交之后发生的行情（数据层 boundary + `asOf ≥ frozen_at` 双重闸门）；
 *  3. Evaluation 只由确定性 Engine 写入，外部无法调用 `evaluation.write`。
 */

import { evaluateStrategyBars, digest } from '../engine/index.js'
import { createEvaluatorHost } from '../adapters/evaluator-host.js'
import { createLocalEvaluationStore } from '../adapters/local-evaluation-store.js'
import { SerialExecutor } from '../adapters/serial-executor.js'
import { createRepository } from '../storage/repository.js'
import { appendEvent, strategyTimeline } from './audit.js'
import {
  assertCanMutateStrategy,
  assertCanReadStrategy,
  assertCapability,
  resolveActor,
} from './auth.js'
import {
  loadDemoConfig,
  loadEvaluationRules,
  loadMarketUniverse,
  normalizePluginConfig,
  parseEvaluationRules,
} from './config.js'
import { notFound, unauthorized, validation, CODES, TradeEvalError } from './errors.js'
import { normalizeLanguage } from './i18n.js'
import { computeMaxDrawdown } from './evaluation/metrics.js'
import { evaluateFrozenStrategy } from './evaluation/engine.js'
import { ACCOUNTING_VERSION, deriveInstructions, instructionDigest, normalizePortfolioConfig, projectPortfolio } from './portfolio/ledger.js'
import { buildPriceLookup, canonicalSnapshot, compareSnapshots, reconcile, resolveMaxPositionPct, summarizePortfolio } from './portfolio/manager.js'
import { createIdFactory } from './ids.js'
import { MockMarketDataProvider } from './market/mock.js'
import { assertCoreImmutable } from './monitor/immutability.js'
import { computeLivePerformance, monitorStrategy } from './monitor/monitor.js'
import { aggregateByAnalyst, aggregateByTeam, aggregatePerformance, summarizeStrategy } from './report/aggregate.js'
import { buildAnalystReport, buildStrategyReport, buildTeamReport, renderPerformanceReportMarkdown, renderStrategyReportMarkdown } from './report/builder.js'
import { createClock, formatDate, formatIso, formatTimestamp, TradingCalendar } from './time.js'

const ACTIONS = ['BUY', 'SELL']
const TERMINAL_STATUSES = ['COMPLETED', 'STOPPED', 'EXPIRED', 'CANCELLED']

/** 把字符串安全转成正数。 */
function positiveNumber(value, label) {
  const num = typeof value === 'string' ? Number(value) : value
  if (typeof num !== 'number' || !Number.isFinite(num) || num <= 0) {
    throw validation(`${label} must be a positive number, received ${JSON.stringify(value)}`)
  }
  return num
}

function intInRange(value, label, min, max) {
  const num = typeof value === 'string' ? Number(value) : value
  if (!Number.isInteger(num) || num < min || num > max) {
    throw validation(`${label} must be an integer in [${min}, ${max}], received ${JSON.stringify(value)}`)
  }
  return num
}

function nonEmptyString(value, label, maxLength = 4000) {
  if (typeof value !== 'string' || value.trim().length === 0) throw validation(`${label} is required`)
  const trimmed = value.trim()
  if (trimmed.length > maxLength) throw validation(`${label} exceeds ${maxLength} characters`)
  return trimmed
}

export class TradeEvaluationService {
  /**
   * @param {object} options
   * @param {object} options.config normalizePluginConfig 的产物
   * @param {string} options.dataDir
   */
  constructor({ config, dataDir }) {
    this.config = { ...normalizePluginConfig(config), dataDir }
    this.rules = loadEvaluationRules(this.config.rulesPath)
    this.demo = loadDemoConfig(this.config.demoPath)
    this.universe = loadMarketUniverse(this.config.universePath)
    /** 历史起点：demo-config.market.history_epoch 优先，其次 universe 自带值，最后兜底。 */
    this.historyEpoch = this.demo.market?.history_epoch ?? this.universe.history_epoch ?? '2026-01-02'
    this.calendar = new TradingCalendar({ holidays: this.universe.holidays ?? [] })
    this.repository = null
    this.clock = null
    this.provider = null
    this.ids = null
    this.auditLog = []
    const serial = new SerialExecutor()
    for (const key of Object.getOwnPropertyNames(TradeEvaluationService.prototype)) {
      const fn = Object.getOwnPropertyDescriptor(TradeEvaluationService.prototype, key)?.value
      if (fn?.constructor.name === 'AsyncFunction') this[key] = (...args) => serial.run(() => fn.apply(this,args))
    }
  }

  /**
   * 本次调用的身份 —— **所有 actor 的唯一解析点**。
   *
   * 之前 21 个调用点各自写 `this.#actor(options)`，于是：
   *   · 默认身份写死成 DEFAULT_ACTOR（MANAGER），部署者无法改成别的；
   *   · 来源信息（配置给的 / 调用方自述的）当场丢掉，审计里分不清可信与自述；
   *   · `identity.requireVerified` 这类策略无处安放，只能散落到每个调用点。
   * 收敛到这一处之后，上面三件事各只有一个实现。
   *
   * @param {{ actor?: unknown, actorSource?: string }} options
   */
  /**
   * 给"没有建策略权限"的调用方一个**照着做就能成功**的身份。
   *
   * `assertCapability` 只认识角色、不认识数据，所以它没法知道哪些 actor_id 是真实分析师。
   * 这层知识在服务里（`repository` 的 analysts 集合），因此由这里补上。
   */
  async #suggestedCreateActor(actor) {
    const analysts = (await this.listAnalysts())
    const ids = analysts.map((row) => row.analyst_id)
    const actorId = ids.includes(actor.actor_id) ? actor.actor_id : ids[0]
    return actorId === undefined ? undefined : { actor_id: actorId, role: 'ANALYST' }
  }

  #actor(options = {}) {
    return resolveActor({
      actor: options.actor,
      fallback: this.config.identity?.actor,
      policy: this.config.identity,
      source: options.actorSource ?? options.actor?.source,
    })
  }

  /** 异步初始化：建库 → 恢复时钟 → 建行情 provider → 恢复计数序号。 */
  async initialize() {
    this.repository = await createRepository({ dataDir: this.config.dataDir, driver: this.config.storage })
    this.evaluatorHost = createEvaluatorHost({ ...this.config.evaluator, localStore: createLocalEvaluationStore(this.repository) })
    const clockState = (await this.repository.readMeta('clock'))
    this.clock = createClock(clockState?.mode === 'simulated' ? { ...this.demo.clock, start_date: clockState.start ?? this.demo.clock.start_date } : this.demo.clock, this.calendar)
    if (clockState?.mode === 'simulated' && typeof clockState.now === 'string') {
      this.clock.current = new Date(clockState.now)
    } else {
      ;(await this.#persistClock())
    }
    this.provider = new MockMarketDataProvider({ universe: { ...this.universe, history_epoch: this.historyEpoch }, now: () => this.clock.tradingNow() })
    this.ids = createIdFactory({ nextSequence: async (kind, dayKey) => (await this.repository.nextSequence(kind, dayKey)) })

    // 保证 Demo 分析师存在，并**让 config 里的参考数据真的生效**。
    //
    // 只"缺失才插入"是不够的：分析师是**只读参考数据**（`config/demo-config.json` 是它的
    // 唯一来源），因此改配置里的 `team` / `max_position_pct` 必须对已有安装生效，
    // 否则部署者会遇到"我改了配置但什么都没发生"。
    // 而 `max_position_pct` 是**仓位上限**（C3），不生效意味着超限挤出永不触发 ——
    // 一个静默失效的功能。`created_at` 保留首次写入的时间，不覆盖。
    for (const analyst of this.demo.analysts) {
      const existing = (await this.repository.get('analysts', analyst.analyst_id))
      if (existing === null) {
        ;(await this.repository.put('analysts', { ...analyst, created_at: formatIso(this.clock.now()) }))
        continue
      }
      const { created_at: createdAt, ...reference } = existing
      const next = { ...reference, ...analyst, created_at: createdAt }
      if (JSON.stringify(next) !== JSON.stringify(existing)) (await this.repository.put('analysts', next))
    }
    this.auditLog = (await this.repository.list('events'))
    return this
  }

  async close() {
    ;(await this.repository?.close())
  }

  async #persistClock() {
    ;(await this.repository.writeMeta('clock', { mode: this.demo.clock?.mode ?? 'simulated', start: this.demo.clock?.start_date ?? null, now: formatIso(this.clock.now()) }))
  }

  async #emit(event) {
    const record = (await appendEvent(this.repository, event))
    this.auditLog.push(record)
    return record
  }

  #now() {
    return this.clock.now()
  }

  get driver() {
    return this.repository?.driver ?? 'uninitialized'
  }

  async stats() {
    return {
      driver: this.driver,
      evaluator: this.evaluatorHost.status(),
      storage: (await this.repository?.stats()) ?? null,
      rules_version: this.rules.version,
      rules: this.rules,
      language: this.resolveLanguage(),
      clock: this.clock.toJSON(),
      market: { provider: this.provider.name, boundary: this.provider.boundary(), tickers: this.provider.listTickers(), benchmarks: this.provider.listBenchmarks() },
      calendar_epoch: this.historyEpoch,
    }
  }

  async evaluateObservation(request, options = {}) {
    assertCapability(this.#actor(options), 'evaluation.run')
    return this.evaluatorHost.evaluate(request)
  }

  // ─────────────────────────────────────────────────────────── strategy plugin

  /**
   * 创建策略（实施方案 §15）。默认创建即冻结，因为分析师"提交"这个动作本身就是固化决策。
   * @param {object} input 策略输入
   * @param {{ actor?: object, sessionId?: string|null, autoFreeze?: boolean }} [options]
   */
  async createStrategy(input, options = {}) {
    const actor = this.#actor(options)
    // `strategy.create` 只允许 ANALYST / ADMIN，而 `actor_id` 还必须是一个**真实存在的分析师**。
    // 因此这里给的"照做就能成功"的身份必须是库里的分析师，否则调用方照着重试会撞上
    // `unknown analyst` —— 报错等于没说，甚至更糟（把人引到第二个错误上）。
    assertCapability(actor, 'strategy.create', { suggestedActor: (await this.#suggestedCreateActor(actor)) })
    if (typeof input !== 'object' || input === null) throw validation('strategy payload must be an object')

    const rawAnalystId = nonEmptyString(input.analyst_id, 'analyst_id', 120)
    // ANALYST 只能为自己创建策略；ADMIN 可以为任意分析师代录。
    if (actor.role === 'ANALYST' && rawAnalystId !== actor.actor_id) {
      // ⚠️ 这里曾经复用 `assertCapability(actor, 'strategy.read.any')`，
      // 于是"替别人建策略"报的是**读权限**错误 —— 连能力都对不上，
      // 调用方（尤其 Agent）会朝着完全错误的方向修。跨人代录是 create 的语义问题，
      // 就该用 create 的说法讲清楚。
      throw unauthorized(`analyst ${actor.actor_id} may not create a strategy for "${rawAnalystId}"`, {
        capability: 'strategy.create',
        actingAnalyst: actor.actor_id,
        targetAnalyst: rawAnalystId,
        hint: `create it as yourself: set analyst_id="${actor.actor_id}"`,
        howToFix: 'ANALYST may only create strategies for their own analyst_id; an ADMIN may submit on another analyst\'s behalf.',
        ...(actor.source === undefined ? {} : { actor_source: actor.source }),
      })
    }
    const analyst = (await this.repository.get('analysts', rawAnalystId))
    if (analyst === null && actor.role !== 'ADMIN') {
      throw validation(`unknown analyst "${rawAnalystId}"`, { knownAnalysts: (await this.listAnalysts()).map((a) => a.analyst_id) })
    }

    const ticker = nonEmptyString(input.ticker, 'ticker', 16).toUpperCase()
    if (!this.provider.listTickers().includes(ticker)) {
      throw validation(`unknown ticker "${ticker}"`, { knownTickers: this.provider.listTickers() })
    }
    const action = nonEmptyString(input.action, 'action', 8).toUpperCase()
    if (!ACTIONS.includes(action)) throw validation(`action must be one of ${ACTIONS.join(', ')}`)

    const entryPrice = positiveNumber(input.entry_price, 'entry_price')
    const targetPrice = positiveNumber(input.target_price, 'target_price')
    const stopLoss = positiveNumber(input.stop_loss, 'stop_loss')
    const holdingPeriod = intInRange(input.holding_period, 'holding_period', 1, 504)
    const positionBefore = Number.isFinite(Number(input.position_before)) ? Number(input.position_before) : 0
    // 组合层建仓权重（C2：以权重/百分比建仓）。缺省时由组合层用配置默认值，
    // 因此这里允许 undefined —— 但给了就必须是正数且不超过该分析师的上限。
    const weightPct = input.weight_pct === undefined || input.weight_pct === null
      ? null
      : positiveNumber(input.weight_pct, 'weight_pct')
    if (weightPct !== null && weightPct > 100) throw validation(`weight_pct must be a percentage between 0 and 100, received ${weightPct}`)
    const quantity = input.quantity === undefined ? this.demo.defaults.quantity : intInRange(input.quantity, 'quantity', 1, 1_000_000)
    const benchmark = input.benchmark === undefined ? this.demo.defaults.benchmark : nonEmptyString(input.benchmark, 'benchmark', 16).toUpperCase()
    if (!this.provider.listBenchmarks().includes(benchmark)) {
      throw validation(`unknown benchmark "${benchmark}"`, { knownBenchmarks: this.provider.listBenchmarks() })
    }

    // 方向一致性：BUY 必须"止损低于入场、目标高于入场"；SELL 相反。
    // 这条校验把"明显自相矛盾的策略"挡在门外，并且它是**结构性的**，不是风格建议。
    if (action === 'BUY' && !(stopLoss < entryPrice && targetPrice > entryPrice)) {
      throw validation(`BUY strategy requires stop_loss < entry_price < target_price, received stop=${stopLoss} entry=${entryPrice} target=${targetPrice}`)
    }
    if (action === 'SELL' && !(stopLoss > entryPrice && targetPrice < entryPrice)) {
      throw validation(`SELL strategy requires target_price < entry_price < stop_loss, received stop=${stopLoss} entry=${entryPrice} target=${targetPrice}`)
    }

    const reason = nonEmptyString(input.reason, 'reason')

    // Market Snapshot 必须在创建时固化（§6 规则 3）。
    const snapshot = await this.provider.getSnapshot(ticker, formatDate(this.clock.tradingNow()))
    const createdAt = formatTimestamp(this.#now())
    const strategyId = (await this.ids.strategy(this.#now()))
    const autoFreeze = options.autoFreeze !== false

    const record = {
      strategy_id: strategyId,
      analyst_id: rawAnalystId,
      ticker,
      action,
      position_before: positionBefore,
      quantity,
      // 组合层建仓权重。`weight_pct` 在 CORE_FIELDS 里，冻结后不可改
      // —— 它决定模拟盘的建仓规模，改它等于改测评结果。
      weight_pct: weightPct,
      entry_price: entryPrice,
      target_price: targetPrice,
      stop_loss: stopLoss,
      holding_period: holdingPeriod,
      benchmark,
      reason,
      created_at: createdAt,
      created_by: actor.actor_id,
      market_snapshot: { price: snapshot.price, timestamp: snapshot.timestamp, volume: snapshot.volume, as_of: snapshot.as_of, source: snapshot.source },
      status: autoFreeze ? 'ACTIVE' : 'DRAFT',
      frozen: autoFreeze,
      frozen_at: autoFreeze ? createdAt : null,
      frozen_by: autoFreeze ? actor.actor_id : null,
      updated_at: createdAt,
      performance: null,
      evaluation_id: null,
      status_reason: null,
      session_id: options.sessionId ?? null,
    }

    ;(await this.repository.put('strategies', record))
    ;(await this.#emit({ at: createdAt, type: 'STRATEGY_CREATED', strategy_id: strategyId, analyst_id: rawAnalystId, actor, session_id: options.sessionId, payload: { ticker, action, entry_price: entryPrice, target_price: targetPrice, stop_loss: stopLoss, holding_period: holdingPeriod, benchmark, position_before: positionBefore, quantity } }))
    ;(await this.#emit({ at: formatTimestamp(this.#now()), type: 'MARKET_SNAPSHOT_CAPTURED', strategy_id: strategyId, analyst_id: rawAnalystId, actor, session_id: options.sessionId, payload: { ...record.market_snapshot } }))
    if (autoFreeze) {
      ;(await this.#emit({ at: record.frozen_at, type: 'STRATEGY_FROZEN', strategy_id: strategyId, analyst_id: rawAnalystId, actor, session_id: options.sessionId, payload: { status: 'ACTIVE', frozen: true } }))
    }
    return record
  }

  async getStrategy(strategyId, options = {}) {
    const actor = this.#actor(options)
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanReadStrategy(actor, strategy)
    return { ...strategy, evaluation: (await this.repository.get('evaluations', strategy.evaluation_id ?? '')) ?? (await this.findLatestEvaluation(strategyId)) }
  }

  async listStrategies(options = {}) {
    const actor = this.#actor(options)
    const { analyst_id: analystId, status, ticker, limit } = options
    let rows = (await this.repository.list('strategies'))
    if (actor.role === 'ANALYST') {
      rows = rows.filter((row) => row.analyst_id === actor.actor_id)
    } else if (typeof analystId === 'string' && analystId.length > 0) {
      rows = rows.filter((row) => row.analyst_id === analystId)
    }
    if (typeof status === 'string' && status.length > 0) rows = rows.filter((row) => row.status === status.toUpperCase())
    if (typeof ticker === 'string' && ticker.length > 0) rows = rows.filter((row) => row.ticker === ticker.toUpperCase())
    rows.sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
    if (typeof limit === 'number' && limit > 0) rows = rows.slice(0, limit)
    return (await Promise.all(rows.map(async (strategy) => summarizeStrategy(strategy, (await this.repository.get('evaluations', strategy.evaluation_id ?? '')) ?? (await this.findLatestEvaluation(strategy.strategy_id))))))
  }

  /**
   * 修改策略。冻结后**必须失败**（§18 关键测试）。
   * 允许的修改只有 DRAFT 状态下的决策字段与自由文本。
   */
  async updateStrategy(strategyId, patch, options = {}) {
    const actor = this.#actor(options)
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanMutateStrategy(actor, strategy)
    if (strategy.frozen === true) {
      // 明确区分"改动核心字段"和"改动生命周期字段"的原因，便于测试断言。
      assertCoreImmutable(strategy, { ...strategy, ...patch })
      throw new TradeEvalError(CODES.FROZEN_IMMUTABLE, `frozen strategy ${strategyId} cannot be modified`, {
        strategyId,
        attemptedFields: Object.keys(patch ?? {}),
      })
    }
    const allowed = ['entry_price', 'target_price', 'stop_loss', 'holding_period', 'benchmark', 'reason', 'quantity', 'position_before', 'ticker', 'action', 'analyst_id']
    const unknown = Object.keys(patch ?? {}).filter((key) => !allowed.includes(key))
    if (unknown.length > 0) throw validation(`fields ${unknown.join(', ')} cannot be updated`, { allowed })
    const next = { ...strategy, ...patch, updated_at: formatTimestamp(this.#now()) }
    ;(await this.repository.put('strategies', next))
    return next
  }

  /** 冻结：DRAFT → ACTIVE，此后核心字段永久不可变。 */
  async freezeStrategy(strategyId, options = {}) {
    const actor = this.#actor(options)
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanMutateStrategy(actor, strategy)
    assertCapability(actor, 'strategy.freeze')
    if (strategy.frozen === true) {
      throw new TradeEvalError(CODES.INVALID_TRANSITION, `strategy ${strategyId} is already frozen at ${strategy.frozen_at}`, { strategyId })
    }
    if (strategy.status !== 'DRAFT') {
      throw new TradeEvalError(CODES.INVALID_TRANSITION, `only DRAFT strategies can be frozen, ${strategyId} is ${strategy.status}`, { strategyId, status: strategy.status })
    }
    const frozenAt = formatTimestamp(this.#now())
    const next = { ...strategy, status: 'ACTIVE', frozen: true, frozen_at: frozenAt, frozen_by: actor.actor_id, updated_at: frozenAt }
    ;(await this.repository.put('strategies', next))
    ;(await this.#emit({ at: frozenAt, type: 'STRATEGY_FROZEN', strategy_id: strategyId, analyst_id: strategy.analyst_id, actor, session_id: options.sessionId, payload: { status: 'ACTIVE', frozen: true } }))
    return next
  }

  async cancelStrategy(strategyId, options = {}) {
    const actor = this.#actor(options)
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanMutateStrategy(actor, strategy)
    assertCapability(actor, 'strategy.cancel')
    if (TERMINAL_STATUSES.includes(strategy.status) && strategy.status !== 'CANCELLED') {
      throw new TradeEvalError(CODES.INVALID_TRANSITION, `cannot cancel ${strategyId} in terminal status ${strategy.status}`, { strategyId, status: strategy.status })
    }
    const at = formatTimestamp(this.#now())
    const next = { ...strategy, status: 'CANCELLED', cancelled_at: at, cancelled_by: actor.actor_id, cancel_reason: options.reason ?? null, updated_at: at }
    ;(await this.repository.put('strategies', next))
    ;(await this.#emit({ at, type: 'STRATEGY_CANCELLED', strategy_id: strategyId, analyst_id: strategy.analyst_id, actor, session_id: options.sessionId, payload: { reason: options.reason ?? null } }))
    return next
  }

  async getStatus(strategyId, options = {}) {
    const actor = this.#actor(options)
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanReadStrategy(actor, strategy)
    return {
      strategy_id: strategy.strategy_id,
      status: strategy.status,
      frozen: strategy.frozen,
      frozen_at: strategy.frozen_at,
      holding_period: strategy.holding_period,
      holding_days: strategy.performance?.holding_days ?? 0,
      unrealized_return: strategy.performance?.unrealized_return ?? null,
      target_reached: strategy.performance?.target_reached ?? null,
      stop_loss_triggered: strategy.performance?.stop_loss_triggered ?? null,
      evaluation_id: strategy.evaluation_id,
      updated_at: strategy.updated_at,
    }
  }

  async #requireStrategy(strategyId) {
    if (typeof strategyId !== 'string' || strategyId.length === 0) throw validation('strategy_id is required')
    const strategy = (await this.repository.get('strategies', strategyId))
    if (strategy === null) throw notFound(`strategy ${strategyId} not found`)
    return strategy
  }

  // ─────────────────────────────────────────────────────────── market plugin

  async getQuote(ticker) {
    return this.provider.getQuote(ticker)
  }

  async getHistory(ticker, from, to) {
    return this.provider.getHistory(ticker, from, to)
  }

  async getBenchmark(ticker, from, to) {
    return this.provider.getBenchmark(ticker, from, to)
  }

  async getMarketSnapshot(ticker) {
    return this.provider.getSnapshot(ticker)
  }

  // ─────────────────────────────────────────────────────────── evaluation plugin

  /**
   * 执行评价。所有数值来自确定性 Engine；重复调用同一窗口得到**完全相同**的结果。
   */
  async evaluateStrategy(strategyId, options = {}) {
    const actor = this.#actor(options)
    assertCapability(actor, 'evaluation.run')
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanReadStrategy(actor, strategy)
    if (strategy.frozen !== true) {
      throw validation(`strategy ${strategyId} must be frozen before evaluation (status ${strategy.status})`)
    }

    const asOf = options.asOf ?? formatDate(this.clock.tradingNow())
    const computed = await evaluateFrozenStrategy({
      strategy,
      provider: this.provider,
      rules: this.rules,
      calendar: this.calendar,
      asOf,
      quantity: strategy.quantity ?? this.demo.defaults.quantity,
    })

    const existing = (await this.repository
      .list('evaluations'))
      .find((row) => row.strategy_id === strategyId && row.window?.to === computed.window.to && row.calculation_version === computed.calculation_version)

    if (existing !== undefined && options.force !== true) {
      const identical = JSON.stringify(stripIdentity(existing)) === JSON.stringify(stripIdentity(computed))
      return { evaluation: existing, reused: true, identical, strategy }
    }

    const evaluationTime = formatTimestamp(this.#now())
    const evaluation = {
      ...computed,
      evaluation_id: (await this.ids.evaluation(this.#now())),
      evaluation_time: evaluationTime,
      evaluated_by: actor.actor_id,
      session_id: options.sessionId ?? null,
    }
    ;(await this.repository.put('evaluations', evaluation))

    const status = evaluation.stop_loss_triggered ? 'STOPPED' : 'COMPLETED'
    const nextStrategy = {
      ...strategy,
      status,
      status_reason: evaluation.stop_loss_triggered ? 'STOP_LOSS' : 'HOLDING_PERIOD_END',
      evaluation_id: evaluation.evaluation_id,
      updated_at: evaluationTime,
    }
    assertCoreImmutable(strategy, nextStrategy)
    ;(await this.repository.put('strategies', nextStrategy))

    ;(await this.#emit({ at: evaluationTime, type: 'EVALUATION_COMPLETED', strategy_id: strategyId, evaluation_id: evaluation.evaluation_id, analyst_id: strategy.analyst_id, actor, session_id: options.sessionId, payload: { strategy_return: evaluation.strategy_return, benchmark_return: evaluation.benchmark_return, alpha: evaluation.alpha, max_drawdown: evaluation.max_drawdown, score: evaluation.score, calculation_version: evaluation.calculation_version, window: evaluation.window } }))
    ;(await this.#emit({ at: evaluationTime, type: status === 'STOPPED' ? 'STRATEGY_STOPPED' : 'STRATEGY_COMPLETED', strategy_id: strategyId, evaluation_id: evaluation.evaluation_id, analyst_id: strategy.analyst_id, actor, session_id: options.sessionId, payload: { status } }))

    return { evaluation, reused: false, identical: existing === undefined ? null : JSON.stringify(stripIdentity(existing)) === JSON.stringify(stripIdentity(computed)), strategy: nextStrategy }
  }

  async getEvaluation(evaluationId) {
    const evaluation = (await this.repository.get('evaluations', evaluationId))
    if (evaluation === null) throw notFound(`evaluation ${evaluationId} not found`)
    return evaluation
  }

  async findLatestEvaluation(strategyId) {
    const rows = (await this.repository.list('evaluations')).filter((row) => row.strategy_id === strategyId)
    if (rows.length === 0) return null
    return rows.sort((a, b) => (a.evaluation_time < b.evaluation_time ? 1 : -1))[0]
  }

  async listEvaluations({ strategyId, analystId, limit = 200 } = {}) {
    let rows = (await this.repository.list('evaluations'))
    if (strategyId !== undefined) rows = rows.filter((row) => row.strategy_id === strategyId)
    if (analystId !== undefined) rows = rows.filter((row) => row.analyst_id === analystId)
    rows.sort((a, b) => (a.evaluation_time < b.evaluation_time ? 1 : -1))
    return rows.slice(0, limit)
  }

  /** 只读的评分规则；改规则需要 ADMIN（§19）。 */
  getRules() {
    return { rules: this.rules, capabilities: { 'rules.write': ['ADMIN'] } }
  }

  /** ADMIN 可调整评分规则。规则是**配置**，不是 Prompt。 */
  async updateRules(patch, options = {}) {
    const actor = this.#actor(options)
    assertCapability(actor, 'rules.write')
    const merged = {
      ...this.rules,
      ...patch,
      weights: { ...this.rules.weights, ...(patch?.weights ?? {}) },
      return_scale: { ...this.rules.returnScale, ...(patch?.return_scale ?? {}) },
      alpha_scale: { ...this.rules.alphaScale, ...(patch?.alpha_scale ?? {}) },
      risk_scale: { ...this.rules.riskScale, ...(patch?.risk_scale ?? {}) },
      target_scale: { ...this.rules.targetScale, ...(patch?.target_scale ?? {}) },
      rounding: { ...this.rules.rounding, ...(patch?.rounding ?? {}) },
    }
    const next = parseEvaluationRules(merged, 'rules patch')
    this.rules = next
    ;(await this.#emit({ at: formatTimestamp(this.#now()), type: 'RULES_UPDATED', actor, payload: { version: next.version, weights: next.weights } }))
    return next
  }

  // ─────────────────────────────────────────────────────────── monitor plugin

  async monitorStrategy(strategyId, options = {}) {
    const actor = this.#actor(options)
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanReadStrategy(actor, strategy)
    const asOf = options.asOf ?? formatDate(this.clock.tradingNow())
    const result = await monitorStrategy({ strategy, provider: this.provider, calendar: this.calendar, asOf, actor })
    if (result.changed) {
      ;(await this.repository.put('strategies', result.strategy))
      for (const event of result.events) {
        ;(await this.#emit({ at: formatTimestamp(this.#now()), type: event.type, strategy_id: strategyId, analyst_id: strategy.analyst_id, actor, session_id: options.sessionId, payload: event.payload }))
      }
    }
    return { ...result, strategy: (await this.repository.get('strategies', strategyId)) }
  }

  /** 监控全部 ACTIVE 策略（§5.4）。 */
  async monitorAllActiveStrategies(options = {}) {
    const actor = this.#actor(options)
    assertCapability(actor, 'monitor.run')
    const asOf = options.asOf ?? formatDate(this.clock.tradingNow())
    const active = (await this.repository.list('strategies')).filter((row) => row.status === 'ACTIVE')
    const results = []
    for (const strategy of active) {
      const result = await monitorStrategy({ strategy, provider: this.provider, calendar: this.calendar, asOf, actor })
      if (result.changed) {
        ;(await this.repository.put('strategies', result.strategy))
        for (const event of result.events) {
          ;(await this.#emit({ at: formatTimestamp(this.#now()), type: event.type, strategy_id: strategy.strategy_id, analyst_id: strategy.analyst_id, actor, session_id: options.sessionId, payload: event.payload }))
        }
      }
      results.push({ strategy_id: strategy.strategy_id, changed: result.changed, status: result.strategy.status, reason: result.reason })
    }
    const summary = {
      as_of: asOf,
      monitored: active.length,
      changed: results.filter((row) => row.changed).length,
      stopped: results.filter((row) => row.status === 'STOPPED').length,
      completed: results.filter((row) => row.status === 'COMPLETED').length,
      results,
    }
    ;(await this.#emit({ at: formatTimestamp(this.#now()), type: 'MONITOR_RUN', actor, payload: { as_of: asOf, monitored: summary.monitored, changed: summary.changed } }))
    return summary
  }

  /** 推进模拟时钟（Demo 用；真实部署不会调用）。 */
  async advanceClock(days, options = {}) {
    const actor = this.#actor(options)
    assertCapability(actor, 'monitor.run')
    const count = intInRange(days, 'days', 1, 260)
    this.clock.advanceTradingDays(count)
    ;(await this.#persistClock())
    const at = formatTimestamp(this.#now())
    ;(await this.#emit({ at, type: 'CLOCK_ADVANCED', actor, payload: { trading_days: count, now: at, boundary: this.provider.boundary() } }))
    return { clock: this.clock.toJSON(), boundary: this.provider.boundary(), advanced_trading_days: count }
  }

  // ────────────────────────────────────────────────── portfolio plugin（批次 1）

  /**
   * 组合层配置。`accounting_version` 随投影一起落库 —— 口径改了历史净值仍可解释
   * （与 Evaluation 的 `calculation_version` 同一个理由）。
   */
  get portfolioConfig() {
    return normalizePortfolioConfig(this.config.portfolio)
  }

  /**
   * 把一个分析师的策略流投影成模拟盘账本（**不落库、不发事件**，纯读）。
   *
   * 输入只有三样，且都是确定性的：
   *   ① 已冻结策略（含 `weight_pct` 与 `entry_price`）
   *   ② 已落库的 Evaluation（提供出场日与出场价）
   *   ③ 确定性 Mock 行情（逐日盯市）
   * 因此同一 `asOf` 重复调用必然得到同一结果，`portfolio_recompute` 才有意义。
   */
  async #projectPortfolio(analystId, asOf) {
    const analysts = (await this.repository.get('analysts', analystId))
    if (analysts === null) {
      throw notFound(`unknown analyst "${analystId}"`, { knownAnalysts: (await this.listAnalysts()).map((row) => row.analyst_id) })
    }
    const config = this.portfolioConfig
    const strategies = (await this.repository.list('strategies')).filter((row) => row.analyst_id === analystId)
    const instructions = deriveInstructions({ strategies, evaluationsById: (await this.#evaluationsById()) })

    const base = {
      analyst_id: analystId,
      as_of: asOf,
      config,
      max_position_pct: resolveMaxPositionPct({ analyst: analysts, config }),
      strategies,
      instructions,
    }

    if (instructions.length === 0) {
      // 还没提交过任何已冻结策略：组合存在但空，净值停在起点。
      // 不能返回 null —— "这个人没有仓位"本身就是要看的结论。
      const projection = projectPortfolio({ instructions: [], tradingDays: [], priceAt: () => 0, config, maxPositionPct: base.max_position_pct })
      return { ...base, projection, digest: instructionDigest({ instructions: [], tradingDays: [], maxPositionPct: base.max_position_pct, config }) }
    }

    // 曲线起点 = 第一条指令所在交易日（不能更早：那时他还没有任何建议可考核）
    const firstDate = instructions[0].date
    const startDay = formatDate(this.calendar.nextTradingDay(firstDate))
    const tradingDays = this.calendar.tradingDaysBetween(startDay, asOf).map((day) => formatDate(day))
    if (tradingDays.length === 0) {
      throw validation(`no trading day between ${startDay} and ${asOf} for analyst ${analystId}`)
    }

    const tickers = [...new Set(instructions.map((row) => row.ticker))].sort()
    const barsByTicker = new Map()
    for (const ticker of tickers) {
      // 多取一段：`buildPriceLookup` 需要"当日或之前最近一根"，起点当天可能没有 bar
      barsByTicker.set(ticker, await this.provider.getHistory(ticker, this.historyEpoch, asOf))
    }
    const priceAt = buildPriceLookup({ barsByTicker, label: `portfolio(${analystId})` })
    const projection = projectPortfolio({ instructions, tradingDays, priceAt, config, maxPositionPct: base.max_position_pct })
    return { ...base, projection, digest: instructionDigest({ instructions, tradingDays, maxPositionPct: base.max_position_pct, config }) }
  }

  /**
   * 把组合的**新事实**写进审计日志。
   *
   * ⚠️ 必须幂等：`getPortfolio` 每次调用都会重投影，而 asOf 推进会让同一批手重新出现。
   * 若不按 `lot_id` 去重，每天都会把全部历史手重发一遍事件，审计日志会被灌满噪声。
   * 因此这里先读出已公告过的 `lot_id`，只发**新增**的那些。
   */
  async #announcePortfolio({ analystId, asOf, digest, projection, actor, sessionId }) {
    const at = formatTimestamp(this.#now())
    const events = (await this.repository.list('events'))
    const announcedLots = new Set()
    const announcedEvictions = new Set()
    const announcedRejections = new Set()
    let navAnnouncedFor = null
    for (const event of events) {
      const payload = event.payload ?? {}
      if (typeof payload.lot_id === 'string') {
        if (event.type === 'POSITION_EVICTED') announcedEvictions.add(`${payload.lot_id}@${payload.at ?? ''}`)
        else announcedLots.add(payload.lot_id)
      }
      if (event.type === 'INSTRUCTION_REJECTED' && typeof payload.strategy_id === 'string') {
        announcedRejections.add(`${payload.strategy_id}@${payload.date ?? ''}`)
      }
      if (event.type === 'NAV_UPDATED' && payload.analyst_id === analystId && payload.as_of === asOf) navAnnouncedFor = event
    }

    for (const entry of projection.applied) {
      if (announcedLots.has(entry.lot_id)) continue
      const lot = projection.lots.find((row) => row.lot_id === entry.lot_id)
      if (lot === undefined) continue
      const common = { at, analyst_id: analystId, actor, session_id: sessionId ?? null, strategy_id: lot.strategy_id }
      if (entry.kind === 'OPEN') {
        ;(await this.#emit({ ...common, type: 'POSITION_OPENED', payload: { lot_id: lot.lot_id, ticker: lot.ticker, action: lot.action, weight_pct: lot.weight_pct, entry_price: lot.entry_price, nav_at_open: lot.nav_at_open, notional_nav: lot.notional_nav, opened_date: lot.opened_date, accounting_version: ACCOUNTING_VERSION } }))
      } else {
        ;(await this.#emit({ ...common, type: 'POSITION_CLOSED', payload: { lot_id: lot.lot_id, ticker: lot.ticker, action: lot.action, weight_pct: lot.weight_pct, close_reason: lot.close_reason, exit_price: lot.exit_price, closed_date: lot.closed_date, realized_return: lot.realized_return, realized_pnl_nav: lot.realized_pnl_nav } }))
      }
    }

    for (const eviction of projection.evictions) {
      const key = `${eviction.lot_id}@${eviction.at}`
      if (announcedEvictions.has(key)) continue
      ;(await this.#emit({
        at,
        type: 'POSITION_EVICTED',
        analyst_id: analystId,
        strategy_id: eviction.strategy_id,
        actor,
        session_id: sessionId ?? null,
        // 挤出是**系统做的决定**，必须记清楚：谁被挤掉、为谁腾位置、按什么策略。
        // 已冻结策略本身一个字节都不会被改（immutability 守卫独立保证）。
        payload: { lot_id: eviction.lot_id, at: eviction.at, date: eviction.date, ticker: eviction.ticker, action: eviction.action, weight_pct: eviction.weight_pct, evicted_for: eviction.evicted_for, reason: eviction.reason, eviction_strategy: projection.eviction_strategy },
      }))
    }

    for (const rejection of projection.rejections) {
      const key = `${rejection.strategy_id}@${rejection.date}`
      if (announcedRejections.has(key)) continue
      ;(await this.#emit({ at, type: 'INSTRUCTION_REJECTED', analyst_id: analystId, strategy_id: rejection.strategy_id, actor, session_id: sessionId ?? null, payload: { date: rejection.date, ticker: rejection.ticker, weight_pct: rejection.weight_pct, reason: rejection.reason, max_position_pct: rejection.max_position_pct } }))
    }

    if (navAnnouncedFor === null) {
      ;(await this.#emit({ at, type: 'NAV_UPDATED', analyst_id: analystId, actor, session_id: sessionId ?? null, payload: { analyst_id: analystId, as_of: asOf, nav: projection.nav, total_return: projection.total_return, gross_exposure_pct: projection.gross_exposure_pct, open_lots: projection.counts.lots_open, accounting_version: ACCOUNTING_VERSION, instruction_digest: digest } }))
    }
  }

  /**
   * 读取某个分析师的模拟盘（并落快照 + 公告新事实）。
   * 同一 `(analyst, as_of, 口径版本, 指令指纹)` 重复调用会返回同一份落库结果（`reused: true`）。
   */
  async getPortfolio(analystId, options = {}) {
    const actor = this.#actor(options)
    assertCapability(actor, 'report.read')
    // ANALYST 只能看自己的模拟盘（与策略读权限同一口径）
    if (actor.role === 'ANALYST' && actor.actor_id !== analystId) {
      throw unauthorized(`analyst ${actor.actor_id} may not read portfolio of ${analystId}`, {
        capability: 'report.read',
        actingAnalyst: actor.actor_id,
        targetAnalyst: analystId,
        hint: `read your own: portfolio_get with analyst_id="${actor.actor_id}"`,
        howToFix: 'ANALYST may only read their own portfolio; MANAGER/ADMIN may read any.',
      })
    }

    const asOf = options.asOf ?? formatDate(this.clock.tradingNow())
    const { projection, digest, max_position_pct: maxPositionPct, config } = await this.#projectPortfolio(analystId, asOf)

    const snapshotId = `PORT-${analystId}-${asOf}`
    const existing = (await this.repository.get('portfolio_snapshots', snapshotId))
    const canonical = canonicalSnapshot(projection)
    const reused = existing !== null
      && existing.digest === digest
      && existing.accounting_version === projection.accounting_version

    if (reused) return { portfolio: existing, projection, reused: true, digest }

    const record = {
      snapshot_id: snapshotId,
      analyst_id: analystId,
      as_of: asOf,
      accounting_version: projection.accounting_version,
      max_position_pct: maxPositionPct,
      eviction_strategy: config.evictionStrategy,
      digest,
      previous_digest: existing?.digest ?? null,
      computed_at: formatTimestamp(this.#now()),
      computed_by: actor.actor_id,
      session_id: options.sessionId ?? null,
      ...canonical,
    }
    ;(await this.repository.put('portfolio_snapshots', record))
    ;(await this.#announcePortfolio({ analystId, asOf, digest, projection, actor, sessionId: options.sessionId }))
    return { portfolio: record, projection, reused: false, digest }
  }

  /** 净值曲线（可切片），供 UI 与工具画图。 */
  async getPortfolioNav(analystId, options = {}) {
    const result = await this.getPortfolio(analystId, options)
    const from = options.from ?? null
    const to = options.to ?? null
    const curve = result.projection.curve.filter((point) => (from === null || point.date >= from) && (to === null || point.date <= to))
    return {
      analyst_id: analystId,
      as_of: result.portfolio.as_of,
      accounting_version: result.projection.accounting_version,
      start_nav: result.projection.start_nav,
      nav: result.projection.nav,
      total_return: result.projection.total_return,
      max_drawdown: computeMaxDrawdown({ prices: result.projection.curve.map((point) => point.nav) }),
      curve,
      reused: result.reused,
    }
  }

  /**
   * **从零重算**并和落库快照逐字段比对 —— 组合层的 `strategy_verify_replay`。
   *
   * 这是"所有结果可以重复计算并得到相同结果"在组合层的可执行证明：
   * 同一份策略流 + 同一份确定性行情 + 同一套口径 ⇒ 必须得到同一条净值曲线与同一批持仓。
   */
  async recomputePortfolio(analystId, options = {}) {
    const actor = this.#actor(options)
    assertCapability(actor, 'report.read')
    if (actor.role === 'ANALYST' && actor.actor_id !== analystId) {
      throw unauthorized(`analyst ${actor.actor_id} may not recompute portfolio of ${analystId}`, { capability: 'report.read', actingAnalyst: actor.actor_id, targetAnalyst: analystId })
    }
    const stored = await this.getPortfolio(analystId, options)
    // 再投影一次（不落库路径），用来与刚读到的快照比对
    const fresh = await this.#projectPortfolio(analystId, stored.portfolio.as_of)
    const differences = compareSnapshots(canonicalSnapshot(stored.projection), canonicalSnapshot(fresh.projection))
    const digestMatches = stored.digest === fresh.digest
    if (!digestMatches) differences.unshift(`instruction_digest: ${stored.digest} !== ${fresh.digest}`)
    return {
      analyst_id: analystId,
      snapshot_id: stored.portfolio.snapshot_id,
      as_of: stored.portfolio.as_of,
      accounting_version: fresh.projection.accounting_version,
      instruction_digest: fresh.digest,
      matches: differences.length === 0,
      differences,
      // 对账恒等式：组合层与逐笔层必须能对上
      reconciliation: reconcile(fresh.projection),
      recomputed: { nav: fresh.projection.nav, total_return: fresh.projection.total_return, lots: fresh.projection.counts.lots_opened, curve_points: fresh.projection.curve.length },
      stored: { nav: stored.projection.nav, total_return: stored.projection.total_return, lots: stored.projection.counts.lots_opened, curve_points: stored.projection.curve.length },
    }
  }

  /** 全体分析师的模拟盘汇总（Dashboard 与工具用）。 */
  async listPortfolios(options = {}) {
    const actor = this.#actor(options)
    assertCapability(actor, 'report.read')
    const asOf = options.asOf ?? formatDate(this.clock.tradingNow())
    const rows = []
    for (const analyst of (await this.listAnalysts())) {
      if (actor.role === 'ANALYST' && actor.actor_id !== analyst.analyst_id) continue
      const { projection, portfolio } = await this.getPortfolio(analyst.analyst_id, { ...options, asOf })
      rows.push({
        analyst_id: analyst.analyst_id,
        name: analyst.name,
        team: analyst.team ?? 'unassigned',
        portfolio_id: portfolio.snapshot_id,
        max_position_pct: portfolio.max_position_pct,
        ...summarizePortfolio(projection),
      })
    }
    return { as_of: asOf, accounting_version: ACCOUNTING_VERSION, portfolios: rows }
  }

  async listPortfolioSnapshots({ analystId, limit = 50 } = {}) {
    return (await this.repository
      .list('portfolio_snapshots'))
      .filter((row) => analystId === undefined || row.analyst_id === analystId)
      .sort((a, b) => (a.as_of < b.as_of ? 1 : a.as_of > b.as_of ? -1 : 0))
      .slice(0, limit)
  }

  // ─────────────────────────────────────────────────────────── report plugin

  async listAnalysts() {
    return (await this.repository.list('analysts')).sort((a, b) => (a.analyst_id < b.analyst_id ? -1 : 1))
  }

  async #evaluationsById() {
    const map = new Map()
    for (const evaluation of (await this.repository.list('evaluations'))) {
      const current = map.get(evaluation.strategy_id)
      if (current === undefined || current.evaluation_time < evaluation.evaluation_time) map.set(evaluation.strategy_id, evaluation)
    }
    return map
  }

  async buildStrategyReportFor(strategyId, options = {}) {
    const actor = this.#actor(options)
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanReadStrategy(actor, strategy)
    const evaluation = (await this.repository.get('evaluations', strategy.evaluation_id ?? '')) ?? (await this.findLatestEvaluation(strategyId))
    const analyst = (await this.repository.get('analysts', strategy.analyst_id))
    return buildStrategyReport({
      strategy,
      evaluation,
      analyst,
      timeline: (await strategyTimeline(this.repository, strategyId)),
      sessionId: options.sessionId ?? strategy.session_id ?? null,
      language: this.resolveLanguage(options.language),
    })
  }

  async renderStrategyReport(strategyId, options = {}) {
    const report = (await this.buildStrategyReportFor(strategyId, options))
    return { report, markdown: renderStrategyReportMarkdown(report, options.commentary ?? null, report.language) }
  }

  /**
   * 解析本次调用的报告语言：显式入参 → 插件配置默认 → 'zh'。
   * 语言只影响文案，绝不影响任何数值或判定。
   */
  resolveLanguage(input) {
    return normalizeLanguage(input ?? this.config.language, this.config.language ?? 'zh')
  }

  async getAnalystPerformance(analystId, options = {}) {
    const actor = this.#actor(options)
    // ANALYST 只能看自己。
    if (actor.role === 'ANALYST' && analystId !== actor.actor_id) assertCapability(actor, 'strategy.read.any')
    const analyst = (await this.repository.get('analysts', analystId)) ?? { analyst_id: analystId, name: analystId, team: 'unassigned' }
    const strategies = (await this.repository.list('strategies')).filter((row) => row.analyst_id === analystId)
    const aggregate = aggregatePerformance({ strategies, evaluationsById: (await this.#evaluationsById()) })
    return { analyst, aggregate }
  }

  async buildAnalystReportFor(analystId, options = {}) {
    const { analyst, aggregate } = (await this.getAnalystPerformance(analystId, options))
    const report = buildAnalystReport({ analyst, aggregate, generatedAt: formatTimestamp(this.#now()), language: this.resolveLanguage(options.language) })
    const record = (await this.#persistReport('analyst', analystId, report, options))
    return { report, markdown: renderPerformanceReportMarkdown(report, options.commentary ?? null, report.language), report_id: record.report_id }
  }

  /** 全部团队名（含每人所属团队），供深链与下拉使用。 */
  async listTeams() {
    const analysts = (await this.listAnalysts())
    const byTeam = new Map()
    for (const analyst of analysts) {
      const team = analyst.team ?? 'unassigned'
      if (!byTeam.has(team)) byTeam.set(team, [])
      byTeam.get(team).push({ analyst_id: analyst.analyst_id, name: analyst.name })
    }
    return [...byTeam.entries()]
      .map(([team, members]) => ({ team, analyst_count: members.length, members }))
      .sort((a, b) => a.team.localeCompare(b.team))
  }

  /**
   * 单个团队的明细：团队汇总指标 + **该团队内按分析师分组**的策略。
   *
   * 这是 Dashboard 上"点团队一行"背后的数据。刻意返回分组结构而不是平铺列表：
   * 团队绩效的用途就是横向比较成员，平铺会让前端再算一次，且两处口径容易分叉。
   */
  async getTeamPerformance(teamName, options = {}) {
    const actor = this.#actor(options)
    // 与团队报告同一权限：ANALYST 不能看别人的团队
    if (actor.role === 'ANALYST') assertCapability(actor, 'strategy.read.any')

    const team = typeof teamName === 'string' ? teamName.trim() : ''
    if (team.length === 0) throw validation('team is required')

    const analysts = (await this.listAnalysts())
    const members = analysts.filter((analyst) => (analyst.team ?? 'unassigned') === team)
    if (members.length === 0) {
      throw notFound(`unknown team "${team}"`, { knownTeams: (await this.listTeams()).map((row) => row.team) })
    }

    const memberIds = new Set(members.map((member) => member.analyst_id))
    const strategies = (await this.repository.list('strategies')).filter((row) => memberIds.has(row.analyst_id))
    const evaluationsById = (await this.#evaluationsById())

    return {
      team,
      analyst_count: members.length,
      aggregate: aggregatePerformance({ strategies, evaluationsById }),
      // 按分析师分组；没有策略的成员也会出现（表为空），这样"谁没有产出"也看得见
      analysts: aggregateByAnalyst({ strategies, evaluationsById, analysts: members }),
    }
  }

  async buildTeamReportFor(options = {}) {
    const actor = this.#actor(options)
    if (actor.role === 'ANALYST') assertCapability(actor, 'strategy.read.any')
    const teams = aggregateByTeam({
      strategies: (await this.repository.list('strategies')),
      evaluationsById: (await this.#evaluationsById()),
      analysts: (await this.listAnalysts()),
    })
    const report = buildTeamReport({ teams, generatedAt: formatTimestamp(this.#now()), language: this.resolveLanguage(options.language) })
    const record = (await this.#persistReport('team', 'all', report, options))
    return { report, markdown: renderPerformanceReportMarkdown(report, options.commentary ?? null, report.language), report_id: record.report_id }
  }

  async #persistReport(kind, subjectId, report, options) {
    // 身份在这里解析而不是由调用方传入：报告落库需要 `generated_by`，
    // 而 `#persistReport` 是所有报告的唯一落库点 —— 让身份解析跟着落库点走，
    // 就不会出现"某个报告忘了传 actor"的漏洞。
    const actor = this.#actor(options)
    const at = formatTimestamp(this.#now())
    const record = {
      report_id: (await this.ids.report(this.#now())),
      report_type: kind,
      subject_id: subjectId,
      generated_at: at,
      generated_by: actor.actor_id,
      session_id: options.sessionId ?? null,
      language: report.language,
      factual: report.factual,
      commentary: options.commentary ?? null,
      commentary_disclaimer: report.commentary_disclaimer,
    }
    ;(await this.repository.put('reports', record))
    ;(await this.#emit({ at, type: 'REPORT_GENERATED', actor, session_id: options.sessionId, payload: { report_id: record.report_id, report_type: kind, subject_id: subjectId } }))
    return record
  }

  async listReports({ limit = 50 } = {}) {
    return (await this.repository.list('reports')).sort((a, b) => (a.generated_at < b.generated_at ? 1 : -1)).slice(0, limit)
  }

  // ─────────────────────────────────────────────────────────── dashboard

  /**
   * Manager Dashboard 数据（§12）：分析师列表 + 团队汇总。
   * 只读，且所有数字来自聚合函数。
   */
  async getDashboard(options = {}) {
    const actor = this.#actor(options)
    const strategies = actor.role === 'ANALYST'
      ? (await this.repository.list('strategies')).filter((row) => row.analyst_id === actor.actor_id)
      : (await this.repository.list('strategies'))
    const evaluationsById = (await this.#evaluationsById())
    const analysts = actor.role === 'ANALYST'
      ? (await this.listAnalysts()).filter((analyst) => analyst.analyst_id === actor.actor_id)
      : (await this.listAnalysts())
    const analystRows = aggregateByAnalyst({ strategies, evaluationsById, analysts }).map((row) => ({
      analyst_id: row.analyst_id,
      name: row.name,
      team: row.team,
      strategies: row.strategies,
      evaluated: row.evaluated,
      active: row.active,
      completed: row.completed,
      stopped: row.stopped,
      win_rate: row.win_rate,
      average_return: row.average_return,
      average_alpha: row.average_alpha,
      max_drawdown: row.max_drawdown,
      average_score: row.average_score,
      total_pnl: row.total_pnl,
      hit_rate_vs_benchmark: row.hit_rate_vs_benchmark,
    }))
    const teams = aggregateByTeam({ strategies, evaluationsById, analysts }).map((row) => ({ ...row, rows: undefined }))
    for (const team of teams) delete team.rows
    const total = aggregatePerformance({ strategies, evaluationsById })
    const { rows, ...totalMetrics } = total

    return {
      generated_at: formatTimestamp(this.#now()),
      role: actor.role,
      clock: this.clock.toJSON(),
      market_boundary: this.provider.boundary(),
      totals: totalMetrics,
      analysts: analystRows,
      teams,
      recent_events: (await this.repository.list('events')).sort((a, b) => b.sequence - a.sequence).slice(0, 20),
      rules_version: this.rules.version,
    }
  }

  // ─────────────────────────────────────────────────────────── replay

  /**
   * Strategy Replay（§11）。
   *
   * 输出完整生命周期：提交 → 快照 → 冻结 → 每日价格推进 → 评价，并**直接回答**
   * §11 要求的 11 个问题，便于 UI/Agent 一字不差地复述。
   */
  async replayStrategy(strategyId, options = {}) {
    const actor = this.#actor(options)
    const strategy = (await this.#requireStrategy(strategyId))
    assertCanReadStrategy(actor, strategy)
    const events = (await strategyTimeline(this.repository, strategyId))
    const evaluation = (await this.repository.get('evaluations', strategy.evaluation_id ?? '')) ?? (await this.findLatestEvaluation(strategyId))
    const analyst = (await this.repository.get('analysts', strategy.analyst_id))

    const timeline = events.map((event) => ({ sequence: event.sequence, at: event.at, label: event.label, type: event.type, actor: event.actor, payload: event.payload }))

    // 价格推进：在时间线上插入每个交易日的收盘价，形成"Day N Price = X"的可读序列。
    const priceSteps = (evaluation?.price_timeline ?? []).map((point, index) => ({ day: index + 1, date: point.date, price: point.close }))

    return {
      strategy_id: strategyId,
      analyst: { analyst_id: strategy.analyst_id, name: analyst?.name ?? strategy.analyst_id },
      status: strategy.status,
      frozen: strategy.frozen,
      timeline,
      price_steps: priceSteps,
      benchmark_steps: (evaluation?.benchmark_timeline ?? []).map((point, index) => ({ day: index + 1, date: point.date, price: point.close })),
      evaluation,
      answers: {
        '1_who_submitted': `${analyst?.name ?? strategy.analyst_id} (${strategy.analyst_id})`,
        '2_submitted_at': strategy.created_at,
        '3_price_at_submission': strategy.market_snapshot?.price ?? null,
        '4_position_before': strategy.position_before,
        '5_rationale': strategy.reason,
        '6_price_evolution': priceSteps,
        '7_target_reached': evaluation?.target_reached ?? null,
        '8_stop_loss_triggered': evaluation?.stop_loss_triggered ?? null,
        '9_strategy_return': evaluation?.strategy_return ?? null,
        '10_benchmark': evaluation === null ? null : { benchmark: strategy.benchmark, benchmark_return: evaluation.benchmark_return, alpha: evaluation.alpha },
        '11_final_score': evaluation?.score ?? null,
      },
      replay_consistent: evaluation === null ? null : this.#verifyReplayConsistency(strategy, evaluation),
    }
  }

  /**
   * Replay 一致性校验：用同一份历史数据重新计算，结果必须与落库评价完全一致。
   * 这是"所有评价结果可以重复计算并得到相同结果"（§26）的可执行证明。
   */
  async verifyReplay(strategyId, options = {}) {
    const strategy = (await this.#requireStrategy(strategyId))
    const evaluation = (await this.repository.get('evaluations', strategy.evaluation_id ?? '')) ?? (await this.findLatestEvaluation(strategyId))
    if (evaluation === null) throw validation(`strategy ${strategyId} has no evaluation to verify`)
    if (!evaluation.replay_input || digest(evaluation.replay_input) !== evaluation.replay_sha256) {
      throw new TradeEvalError('data_insufficient', 'legacy evaluation has no verified frozen Replay input; do not refetch or rewrite it')
    }
    const recomputed = { ...evaluateStrategyBars(evaluation.replay_input), replay_input: evaluation.replay_input, replay_sha256: evaluation.replay_sha256 }
    const matches = JSON.stringify(stripIdentity(recomputed)) === JSON.stringify(stripIdentity(evaluation))
    return {
      strategy_id: strategyId,
      evaluation_id: evaluation.evaluation_id,
      matches,
      recomputed,
      differences: matches ? [] : diffKeys(stripIdentity(evaluation), stripIdentity(recomputed)),
      calculation_version: evaluation.calculation_version,
    }
  }

  #verifyReplayConsistency(strategy, evaluation) {
    // 同步版：只比较可由落库数据推导的部分，完整重算由 verifyReplay() 提供。
    const derivedReturn = strategy.action === 'SELL'
      ? (strategy.entry_price - evaluation.exit_price) / strategy.entry_price
      : (evaluation.exit_price - strategy.entry_price) / strategy.entry_price
    return Math.abs(derivedReturn - evaluation.strategy_return) < 1e-6
  }

  // ─────────────────────────────────────────────────────────── admin / demo

  /** 清空并重新灌入 Demo Seed（ADMIN）。 */
  async resetDemo(options = {}) {
    const actor = this.#actor(options)
    assertCapability(actor, 'analyst.manage')
    const { seedDemoData } = await import('../../seed/demo-data.js')
    ;(await this.repository.reset())
    const result = await seedDemoData(this, { actor, sessionId: options.sessionId })
    this.auditLog = (await this.repository.list('events'))
    return result
  }

  async listEvents({ strategyId, limit = 200 } = {}) {
    let rows = (await this.repository.list('events'))
    if (strategyId !== undefined) rows = rows.filter((row) => row.strategy_id === strategyId)
    return rows.sort((a, b) => b.sequence - a.sequence).slice(0, limit)
  }
}

/**
 * 去掉"身份与记账"字段，只留下 Engine 真正计算出来的内容，用于重算比对。
 * 任何非计算字段（ID、时间戳、操作者、seed 标记）都不应影响"结果是否一致"的判定。
 */
function stripIdentity(evaluation) {
  const {
    evaluation_id: _id,
    evaluation_time: _time,
    evaluated_by: _by,
    session_id: _session,
    seeded: _seeded,
    ...rest
  } = evaluation
  return rest
}


function diffKeys(left, right) {
  const keys = new Set([...Object.keys(left), ...Object.keys(right)])
  const differences = []
  for (const key of keys) {
    if (JSON.stringify(left[key]) !== JSON.stringify(right[key])) differences.push(key)
  }
  return differences
}

export { positiveNumber, intInRange, nonEmptyString }
