/**
 * Skill / Agent 指令文件的装载。
 *
 * 单一真源原则：Skill 内容来自磁盘上的 `skills/<name>/SKILL.md`，Agent 指令来自
 * `agents/<name>/AGENT.md`。插件在 apply 时把它们读进来，注册进 Harness 的
 * Skill registry 与 System Prompt section —— 因此**改文件即改行为**，
 * 不会出现"文档说一套、Prompt 里是另一套"的漂移。
 */

import { readFileSync } from 'node:fs'
import { join } from 'node:path'

export const SKILL_NAME = 'trade-strategy-evaluation'
export const AGENT_NAME = 'trade-strategy-evaluator'

/**
 * 解析 SKILL.md 的 YAML frontmatter。
 *
 * 刻意只支持三个简单标量（name / description / whenToUse）：Skill 的 frontmatter 是
 * 受控格式，为此引入 YAML 依赖不值得；解析不出的字段会被忽略而不是猜。
 * @param {string} raw SKILL.md 全文
 * @returns {{meta: Record<string, string>, body: string}}
 */
export function parseSkillFrontmatter(raw) {
  const match = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/.exec(raw)
  if (match === null) return { meta: {}, body: raw.trim() }
  const meta = {}
  for (const line of match[1].split(/\r?\n/)) {
    const kv = /^([A-Za-z][A-Za-z0-9_-]*):\s*(.*)$/.exec(line)
    if (kv === null) continue
    let value = kv[2].trim()
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1)
    }
    meta[kv[1]] = value
  }
  return { meta, body: match[2].trim() }
}

function readText(path, label) {
  try {
    return readFileSync(path, 'utf8')
  } catch (error) {
    throw new Error(`trade-strategy-evaluator: cannot read ${label} at ${path}: ${error.message}`)
  }
}

/**
 * 装载 Skill。返回的 `directory` 用作 `resourceBase`，模型因此知道
 * SKILL.md 里的相对路径应该相对哪个目录解析。
 *
 * ⚠️ `source` 是**必填**的，不是可选装饰。
 * `SkillRegistry.get()` 在返回正文前会跑 `validateDefinition()`，它要求
 * `source` / `provider` / `content` 都是字符串 —— 少一个 `source` 的后果是：
 * 技能目录里**列得出来**（`list()` 只看 name/description），但模型一调用
 * `skill` 工具就报 `loaded skill "..." source must be a string`。
 * 也就是说"看起来注册成功了，实际用不了"。这里显式给出来源标识，便于审计。
 *
 * @param {string} packageRoot 包根目录
 */
export function loadSkill(packageRoot) {
  const directory = join(packageRoot, 'skills', SKILL_NAME)
  const skillPath = join(directory, 'SKILL.md')
  const { meta, body } = parseSkillFrontmatter(readText(skillPath, 'SKILL.md'))
  if (typeof meta.name !== 'string' || !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(meta.name)) {
    throw new Error(`trade-strategy-evaluator: SKILL.md frontmatter has an invalid name (${meta.name})`)
  }
  if (typeof meta.description !== 'string' || meta.description.length === 0) {
    throw new Error('trade-strategy-evaluator: SKILL.md frontmatter requires a description')
  }
  return {
    name: meta.name,
    description: meta.description,
    ...(meta.whenToUse === undefined ? {} : { whenToUse: meta.whenToUse }),
    content: body,
    resourceBase: { kind: 'directory', path: directory },
    provider: 'trade-strategy-evaluator',
    // validateDefinition() 要求 source 为字符串；用它标明"这个技能由哪个包提供"。
    source: 'plugin:trade-strategy-evaluator',
    // 便于排错时直接定位到磁盘上的原文（可选字段，但很有用）。
    path: skillPath,
  }
}

/** 装载 Agent 指令（AGENT.md），用作系统提示词段落。 */
export function loadAgentInstructions(packageRoot) {
  return readText(join(packageRoot, 'agents', AGENT_NAME, 'AGENT.md'), 'AGENT.md')
}
