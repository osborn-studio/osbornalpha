/**
 * 时间与交易日历。
 *
 * 两条时间轴严格分离：
 *  - **交易日历**（`TradingCalendar`）：行情只存在于交易日，周末与节假日无 bar。
 *  - **时钟**（`Clock`）：策略提交、冻结、评价发生在哪个"当下"。
 *
 * POC 默认使用 `SimulatedClock`，从 `demo-config.clock.start_date` 出发按**交易日**推进，
 * 这样 3~5 分钟的 Demo 能完整演示 20 个交易日的策略生命周期，并且每次运行结果完全一致。
 * `STEP_DAYS=N` 环境变量可一次性把模拟时钟前推 N 个交易日。
 */

import { validation } from './errors.js'

const MS_PER_DAY = 86400000

/** 解析 `YYYY-MM-DD` 为 UTC 零点 Date。 */
export function parseDate(value) {
  if (value instanceof Date) return new Date(Date.UTC(value.getUTCFullYear(), value.getUTCMonth(), value.getUTCDate()))
  if (typeof value !== 'string') throw validation(`expected a date string, received ${typeof value}`)
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(value)
  if (match === null) throw validation(`invalid date "${value}", expected YYYY-MM-DD`)
  const [, y, m, d] = match
  const date = new Date(Date.UTC(Number(y), Number(m) - 1, Number(d)))
  if (Number.isNaN(date.getTime())) throw validation(`invalid date "${value}"`)
  return date
}

/** 格式化为 `YYYY-MM-DD`。 */
export function formatDate(date) {
  return date.toISOString().slice(0, 10)
}

/** 格式化为 `YYYY-MM-DDTHH:mm:ssZ`（秒精度 ISO，落库与 API 一致）。 */
export function formatTimestamp(date) {
  return `${date.toISOString().slice(0, 19)}Z`
}

/** 时间戳字符串（含毫秒）用于审计字段的单调排序。 */
export function formatIso(date) {
  return date.toISOString()
}

export function addDays(date, days) {
  return new Date(date.getTime() + days * MS_PER_DAY)
}

export function addMinutes(date, minutes) {
  return new Date(date.getTime() + minutes * 60000)
}

export function compareDates(a, b) {
  const left = a instanceof Date ? a.getTime() : parseDate(a).getTime()
  const right = b instanceof Date ? b.getTime() : parseDate(b).getTime()
  return left === right ? 0 : left < right ? -1 : 1
}

/**
 * 交易日历：工作日减去节假日集合。
 */
export class TradingCalendar {
  /** @param {{ holidays?: string[] }} [options] */
  constructor(options = {}) {
    this.holidays = new Set(options.holidays ?? [])
  }

  /** 是否交易日。 */
  isTradingDay(date) {
    const day = date.getUTCDay()
    if (day === 0 || day === 6) return false
    return !this.holidays.has(formatDate(date))
  }

  /** 返回 date 当天（含）之后最近的交易日；已是交易日则返回自身。 */
  nextTradingDay(date) {
    let cursor = parseDate(date)
    for (let i = 0; i < 400; i += 1) {
      if (this.isTradingDay(cursor)) return cursor
      cursor = addDays(cursor, 1)
    }
    throw validation('no trading day found within 400 days')
  }

  /** 返回 date 当天（含）之前最近的交易日。 */
  previousTradingDay(date) {
    let cursor = parseDate(date)
    for (let i = 0; i < 400; i += 1) {
      if (this.isTradingDay(cursor)) return cursor
      cursor = addDays(cursor, -1)
    }
    throw validation('no trading day found within 400 days back')
  }

  /** 从 from 起推进 n 个交易日，返回第 n 个交易日（n=0 返回 from 所在/之后的交易日）。 */
  advanceTradingDays(from, n) {
    let cursor = this.nextTradingDay(from)
    for (let i = 0; i < n; i += 1) cursor = this.nextTradingDay(addDays(cursor, 1))
    return cursor
  }

  /** [from, to] 闭区间内的全部交易日。 */
  tradingDaysBetween(from, to) {
    const start = this.nextTradingDay(from)
    const end = parseDate(to)
    const days = []
    let cursor = start
    while (cursor.getTime() <= end.getTime()) {
      if (this.isTradingDay(cursor)) days.push(new Date(cursor.getTime()))
      cursor = addDays(cursor, 1)
    }
    return days
  }
}

/** 使用真实系统时间的时钟（生产姿态；Demo 不用）。 */
export class SystemClock {
  /** @param {Date} [now] 便于测试注入 */
  constructor(now = new Date()) {
    this.current = now
  }

  now() {
    return new Date(this.current.getTime())
  }

  /** 结算口径：当前时间所在/之前最近的交易日。 */
  tradingNow(calendar) {
    return calendar.previousTradingDay(this.now())
  }

  advanceTradingDays() {
    throw validation('SystemClock does not support time travel')
  }

  toJSON() {
    return { mode: 'system', now: formatIso(this.current) }
  }
}

/**
 * 模拟时钟：只在交易日上推进，且在同一交易日内按"分钟"推进，用于制造
 * "09:30 提交 → 09:31 冻结 → 后续按日推进"的 Replay 时间线。
 */
export class SimulatedClock {
  /**
   * @param {Date|string} start 起始时刻
   * @param {TradingCalendar} calendar 交易日历
   */
  constructor(start, calendar) {
    this.calendar = calendar
    const base = parseDate(start)
    // Demo 起点固定为交易日 09:30（美东开盘的简化表示，统一用 UTC 表示）。
    this.current = new Date(Date.UTC(base.getUTCFullYear(), base.getUTCMonth(), base.getUTCDate(), 9, 30, 0))
  }

  now() {
    return new Date(this.current.getTime())
  }

  /** 同一交易日内推进分钟（用于提交/冻结/评价的时间戳分离）。 */
  advanceMinutes(minutes) {
    this.current = addMinutes(this.current, minutes)
    return this.now()
  }

  /** 推进 n 个交易日，落在新交易日 09:30。 */
  advanceTradingDays(n) {
    const day = this.calendar.advanceTradingDays(this.current, n)
    this.current = new Date(Date.UTC(day.getUTCFullYear(), day.getUTCMonth(), day.getUTCDate(), 9, 30, 0))
    return this.now()
  }

  /** 结算口径：当前模拟时间所在/之前最近的交易日。 */
  tradingNow() {
    return this.calendar.previousTradingDay(this.current)
  }

  toJSON() {
    return { mode: 'simulated', now: formatIso(this.current) }
  }

  /** 从持久化状态恢复。 */
  static restore(state, calendar) {
    const clock = new SimulatedClock(state.start ?? state.now, calendar)
    clock.current = new Date(state.now)
    return clock
  }
}

/**
 * 构造时钟。`mode: 'system'` 用真实时间，否则用模拟时钟。
 * @param {object} clockConfig demo-config 的 clock 段
 * @param {TradingCalendar} calendar
 */
export function createClock(clockConfig, calendar) {
  if (clockConfig?.mode === 'system') return new SystemClock()
  return new SimulatedClock(clockConfig?.start_date ?? '2026-09-16', calendar)
}
