import { createHash } from 'node:crypto'

export class InputError extends Error {
  constructor(code, reason) { super(reason); this.code = code; this.reason = reason }
}
export function requireInput(condition, code = 'invalid_schema', reason = code) {
  if (!condition) throw new InputError(code, reason)
}
/** RFC 8785 JSON subset: UTF-16 sorted keys, ECMAScript numbers, no normalization. */
export function canonical(value) {
  if (value === null || typeof value === 'boolean') return JSON.stringify(value)
  if (typeof value === 'number') {
    requireInput(Number.isFinite(value) && (!Number.isInteger(value) || Number.isSafeInteger(value)), 'invalid_schema', 'invalid_number')
    return JSON.stringify(value)
  }
  if (typeof value === 'string') {
    requireInput(!/[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(value), 'invalid_schema', 'invalid_unicode')
    return JSON.stringify(value)
  }
  if (Array.isArray(value)) return '[' + Array.from(value, canonical).join(',') + ']'
  requireInput(typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype, 'invalid_schema', 'not_json')
  return '{' + Object.keys(value).sort().map(k => canonical(k) + ':' + canonical(value[k])).join(',') + '}'
}
export const digest = value => createHash('sha256').update(canonical(value), 'utf8').digest('hex')
export const bytesDigest = bytes => createHash('sha256').update(bytes).digest('hex')
export function timestamp(value) {
  const m = typeof value === 'string' && /^(\d{4}-\d{2}-\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{3})?Z$/.exec(value)
  requireInput(m && Number.isFinite(Date.parse(value)) && new Date(m[1]).toISOString().slice(0,10) === m[1] && +m[2] < 24 && +m[3] < 60 && +m[4] < 60, 'invalid_schema', 'invalid_timestamp')
  return Date.parse(value)
}
/** Reject duplicate members before JSON.parse, including escaped equivalent keys. */
export function parseStrict(text, maxBytes = 2_000_000) {
  requireInput(typeof text === 'string' && Buffer.byteLength(text) <= maxBytes, 'input_limit')
  let p = 0
  const ws = () => { while (/[\x20\t\r\n]/.test(text[p] ?? '') && p < text.length) p++ }
  const string = () => { const start = p++; while (p < text.length) { const c = text[p++]; if (c === '"') return JSON.parse(text.slice(start,p)); if (c === '\\') p++ } throw new InputError('invalid_schema','invalid_json') }
  function value(depth = 0) {
    requireInput(depth < 64, 'input_limit'); ws()
    if (text[p] === '"') { string(); return }
    if (text[p] === '{' || text[p] === '[') {
      const object = text[p++] === '{', end = object ? '}' : ']', keys = new Set(); ws()
      if (text[p] === end) { p++; return }
      while (p < text.length) {
        ws(); if (object) { requireInput(text[p] === '"'); const k = string(); requireInput(!keys.has(k),'invalid_schema','duplicate_key'); keys.add(k); ws(); requireInput(text[p++] === ':') }
        value(depth+1); ws(); if (text[p] === end) { p++; return } requireInput(text[p++] === ',')
      }
      throw new InputError('invalid_schema','invalid_json')
    }
    const m = /^(?:null|true|false|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(text.slice(p)); requireInput(m); p += m[0].length
  }
  try { value(); ws(); requireInput(p === text.length); const parsed = JSON.parse(text); canonical(parsed); return parsed }
  catch (e) { if (e instanceof InputError) throw e; throw new InputError('invalid_schema','invalid_json') }
}
