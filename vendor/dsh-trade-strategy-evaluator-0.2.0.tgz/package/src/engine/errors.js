/**
 * 统一错误类型。所有业务失败都带稳定 `code`，让 API 层能映射 HTTP 状态码，
 * 也让测试可以断言"必须失败"的确切原因。
 */

export class TradeEvalError extends Error {
  /**
   * @param {string} code 稳定错误码
   * @param {string} message 人类可读说明
   * @param {object} [details] 附加上下文
   */
  constructor(code, message, details = undefined) {
    super(message)
    this.name = 'TradeEvalError'
    this.code = code
    if (details !== undefined) this.details = details
  }
}

export const CODES = {
  VALIDATION: 'VALIDATION_ERROR',
  NOT_FOUND: 'NOT_FOUND',
  FROZEN_IMMUTABLE: 'FROZEN_STRATEGY_IMMUTABLE',
  INVALID_TRANSITION: 'INVALID_STATUS_TRANSITION',
  LOOKAHEAD: 'LOOKAHEAD_VIOLATION',
  IMMUTABLE_EVALUATION: 'EVALUATION_IMMUTABLE',
  UNAUTHORIZED: 'UNAUTHORIZED',
  MARKET_DATA: 'MARKET_DATA_ERROR',
  STORAGE: 'STORAGE_ERROR',
  CONFLICT: 'CONFLICT',
}

export function validation(message, details) {
  return new TradeEvalError(CODES.VALIDATION, message, details)
}

export function notFound(message, details) {
  return new TradeEvalError(CODES.NOT_FOUND, message, details)
}

export function frozenImmutable(message, details) {
  return new TradeEvalError(CODES.FROZEN_IMMUTABLE, message, details)
}

export function invalidTransition(message, details) {
  return new TradeEvalError(CODES.INVALID_TRANSITION, message, details)
}

export function lookahead(message, details) {
  return new TradeEvalError(CODES.LOOKAHEAD, message, details)
}

export function immutableEvaluation(message, details) {
  return new TradeEvalError(CODES.IMMUTABLE_EVALUATION, message, details)
}

export function unauthorized(message, details) {
  return new TradeEvalError(CODES.UNAUTHORIZED, message, details)
}

/** HTTP 状态码映射（API 层使用）。 */
export const HTTP_STATUS_BY_CODE = {
  [CODES.VALIDATION]: 400,
  [CODES.NOT_FOUND]: 404,
  [CODES.FROZEN_IMMUTABLE]: 409,
  [CODES.INVALID_TRANSITION]: 409,
  [CODES.LOOKAHEAD]: 422,
  [CODES.IMMUTABLE_EVALUATION]: 409,
  [CODES.UNAUTHORIZED]: 403,
  [CODES.MARKET_DATA]: 502,
  [CODES.STORAGE]: 500,
  [CODES.CONFLICT]: 409,
}
