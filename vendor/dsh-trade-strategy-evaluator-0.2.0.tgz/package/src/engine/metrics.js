/**
 * 确定性指标计算（实施方案 §5.3 / §8 / §10）。
 *
 * 铁律：**所有数值指标由本模块计算，LLM 不得计算也不得修改**。
 * 本模块是纯函数集合：同一输入必然得到同一输出，且不读系统时间、不读随机数。
 */

function assertFiniteNumber(value, label) {
  if (typeof value !== 'number' || !Number.isFinite(value)) {
    throw new TypeError(`${label} must be a finite number, received ${JSON.stringify(value)}`)
  }
  return value
}

/** 按小数位四舍五入，避免浮点噪声进入落库结果。 */
export function roundTo(value, decimals) {
  const factor = 10 ** decimals
  return Math.round((value + Number.EPSILON) * factor) / factor
}

/**
 * 策略收益率。
 *   BUY:  (exit - entry) / entry
 *   SELL: (entry - exit) / entry
 */
export function computeReturn({ action, entryPrice, exitPrice, decimals = 6 }) {
  assertFiniteNumber(entryPrice, 'entryPrice')
  assertFiniteNumber(exitPrice, 'exitPrice')
  if (entryPrice <= 0) throw new TypeError('entryPrice must be positive')
  const raw = action === 'SELL' ? (entryPrice - exitPrice) / entryPrice : (exitPrice - entryPrice) / entryPrice
  return roundTo(raw, decimals)
}

/** 盈亏金额：价格变动 × 数量（BUY 做多、SELL 做空方向相反）。 */
export function computePnl({ action, entryPrice, exitPrice, quantity = 1, decimals = 2 }) {
  assertFiniteNumber(quantity, 'quantity')
  const delta = action === 'SELL' ? entryPrice - exitPrice : exitPrice - entryPrice
  return roundTo(delta * quantity, decimals)
}

/** Benchmark 收益率，与策略收益同一口径（同区间、同方向无关，始终按多头持有计）。 */
export function computeBenchmarkReturn({ benchmarkEntry, benchmarkExit, decimals = 6 }) {
  assertFiniteNumber(benchmarkEntry, 'benchmarkEntry')
  assertFiniteNumber(benchmarkExit, 'benchmarkExit')
  if (benchmarkEntry <= 0) throw new TypeError('benchmarkEntry must be positive')
  return roundTo((benchmarkExit - benchmarkEntry) / benchmarkEntry, decimals)
}

/**
 * Alpha = 策略收益 − Benchmark 收益（§5.3 / §10）。
 * 这是 POC 的 Alpha 定义：不做风险调整，只剥离市场整体涨跌，
 * 避免"市场普涨导致所有分析师看起来都很好"。
 */
export function computeAlpha({ strategyReturn, benchmarkReturn, decimals = 6 }) {
  assertFiniteNumber(strategyReturn, 'strategyReturn')
  assertFiniteNumber(benchmarkReturn, 'benchmarkReturn')
  return roundTo(strategyReturn - benchmarkReturn, decimals)
}

/**
 * 最大回撤：持有区间内从任意历史峰值到之后谷值的最大跌幅（负数或 0）。
 * 用**持有期间的 bar 序列**计算，而不是只比较首尾。
 */
export function computeMaxDrawdown({ prices, decimals = 6 }) {
  if (!Array.isArray(prices) || prices.length === 0) throw new TypeError('prices must be a non-empty array')
  let peak = prices[0]
  let maxDrawdown = 0
  for (const price of prices) {
    assertFiniteNumber(price, 'price')
    if (price > peak) peak = price
    const drawdown = peak === 0 ? 0 : (price - peak) / peak
    if (drawdown < maxDrawdown) maxDrawdown = drawdown
  }
  return roundTo(maxDrawdown, decimals)
}

/**
 * 目标价达成判定。
 * BUY：期间最高价 ≥ target；SELL：期间最低价 ≤ target（做空目标价是下跌目标）。
 * 返回 `hitDay`（首次达成的 bar 下标）以便 Replay 展示"第几天达成"。
 */
export function detectTarget({ action, prices, targetPrice, decimals = 6 }) {
  assertFiniteNumber(targetPrice, 'targetPrice')
  if (!Array.isArray(prices) || prices.length === 0) return { reached: false, reachedAt: null, reachedPrice: null, distance: null }
  const extreme = action === 'SELL' ? Math.min(...prices) : Math.max(...prices)
  const reached = action === 'SELL' ? extreme <= targetPrice : extreme >= targetPrice
  const index = reached ? prices.findIndex((price) => (action === 'SELL' ? price <= targetPrice : price >= targetPrice)) : -1
  const last = prices.at(-1)
  return {
    reached,
    reachedAt: index >= 0 ? index : null,
    reachedPrice: index >= 0 ? prices[index] : null,
    distance: roundTo((targetPrice - last) / last, decimals),
  }
}

/**
 * 止损触发判定。
 * BUY：期间最低价 ≤ stopLoss；SELL：期间最高价 ≥ stopLoss。
 */
export function detectStopLoss({ action, prices, stopLoss, decimals = 6 }) {
  assertFiniteNumber(stopLoss, 'stopLoss')
  if (!Array.isArray(prices) || prices.length === 0) return { triggered: false, triggeredAt: null, triggeredPrice: null, distance: null }
  const extreme = action === 'SELL' ? Math.max(...prices) : Math.min(...prices)
  const triggered = action === 'SELL' ? extreme >= stopLoss : extreme <= stopLoss
  const index = triggered ? prices.findIndex((price) => (action === 'SELL' ? price >= stopLoss : price <= stopLoss)) : -1
  const last = prices.at(-1)
  return {
    triggered,
    triggeredAt: index >= 0 ? index : null,
    triggeredPrice: index >= 0 ? prices[index] : null,
    distance: roundTo((last - stopLoss) / last, decimals),
  }
}

/**
 * 计划盈亏比 R/R = |目标 − 入场| / |入场 − 止损|。
 * 这是**提交时即可确定**的风险收益结构，与后续行情无关，
 * 因此它是"策略质量"的一部分，而不是"结果"的一部分。
 */
export function computeRiskReward({ action, entryPrice, targetPrice, stopLoss, decimals = 6 }) {
  assertFiniteNumber(entryPrice, 'entryPrice')
  assertFiniteNumber(targetPrice, 'targetPrice')
  assertFiniteNumber(stopLoss, 'stopLoss')
  const reward = action === 'SELL' ? entryPrice - targetPrice : targetPrice - entryPrice
  const risk = action === 'SELL' ? stopLoss - entryPrice : entryPrice - stopLoss
  if (risk <= 0) throw new TypeError(`invalid stop loss ${stopLoss} for ${action} entry ${entryPrice}`)
  return { ratio: roundTo(Math.max(reward, 0) / risk, decimals), reward: roundTo(reward, decimals), risk: roundTo(risk, decimals) }
}

/** 持仓交易日数（按交易日历计，而非自然日）。 */
export function computeHoldingDays({ entryDate, exitDate, tradingDays }) {
  if (Array.isArray(tradingDays)) return tradingDays.length
  if (entryDate === exitDate) return 0
  return null
}

/** 波动率（持有区间日收益标准差，年化）。仅用于报告中标注风险，不参与评分。 */
export function computeVolatility({ prices, decimals = 6, annualize = 252 }) {
  if (!Array.isArray(prices) || prices.length < 3) return 0
  const returns = []
  for (let i = 1; i < prices.length; i += 1) returns.push(prices[i] / prices[i - 1] - 1)
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length
  const variance = returns.reduce((acc, r) => acc + (r - mean) ** 2, 0) / (returns.length - 1)
  return roundTo(Math.sqrt(variance * annualize), decimals)
}
