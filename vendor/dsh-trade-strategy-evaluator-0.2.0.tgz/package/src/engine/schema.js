import { canonical, requireInput } from './canonical.js'
/** Validator for the finite JSON Schema vocabulary used by the frozen S4 contract. */
export function validateSchema(value, schema) {
  if (schema.oneOf) {
    requireInput(schema.oneOf.filter(s => { try { validateSchema(value,s); return true } catch { return false } }).length === 1)
    return
  }
  if (schema.anyOf) {
    requireInput(schema.anyOf.some(s => { try { validateSchema(value,s); return true } catch { return false } }))
    return
  }
  if ('const' in schema) requireInput(canonical(value) === canonical(schema.const))
  if (schema.enum) requireInput(schema.enum.some(x => canonical(value) === canonical(x)))
  if (Array.isArray(schema.type)) {
    requireInput(schema.type.some(type => { try { validateSchema(value,{type}); return true } catch { return false } }))
  } else if (schema.type) requireInput(schema.type === 'null' ? value === null : schema.type === 'array' ? Array.isArray(value) : schema.type === 'integer' ? Number.isSafeInteger(value) : schema.type === 'object' ? value !== null && !Array.isArray(value) && typeof value === 'object' : typeof value === schema.type)
  if (typeof value === 'string') {
    if (schema.pattern) requireInput(new RegExp(schema.pattern).test(value))
    requireInput(value.length >= (schema.minLength ?? 0) && value.length <= (schema.maxLength ?? Infinity))
  }
  if (Array.isArray(value)) {
    requireInput(value.length >= (schema.minItems ?? 0) && value.length <= (schema.maxItems ?? Infinity))
    if (schema.items) for (const v of value) validateSchema(v,schema.items)
  } else if (value !== null && typeof value === 'object') {
    for (const k of schema.required ?? []) requireInput(Object.hasOwn(value,k))
    for (const k of Object.keys(value)) {
      if (schema.additionalProperties === false) requireInput(Object.hasOwn(schema.properties ?? {},k))
      if (schema.properties?.[k]) validateSchema(value[k],schema.properties[k])
    }
  }
}
export function exactKeys(value, required, optional = []) {
  requireInput(value !== null && typeof value === 'object' && !Array.isArray(value))
  requireInput(required.every(k => Object.hasOwn(value,k)) && Object.keys(value).every(k => [...required,...optional].includes(k)))
}
