/**
 * 可配置评分模型（实施方案 §9）。
 *
 * Total Score =
 *   return 权重 × Return 得分
 * + alpha  权重 × Alpha 得分
 * + risk   权重 × Risk 得分
 * + target 权重 × Target 得分
 *
 * 每个子分数先由分段线性映射归一到 0-100，再按权重加权。
 * 具体阈值**全部来自 `config/evaluation-rules.json`**，不硬编码在代码或 Prompt 里。
 * 规则 `version` 会写进 Evaluation 的 `calculation_version`，保证公式演进后历史结果仍可解释。
 */

import { roundTo } from './metrics.js'

function clamp(value, min = 0, max = 100) {
  if (Number.isNaN(value)) return min
  return Math.min(max, Math.max(min, value))
}

/** 分段线性映射：value ≤ zero → 0 分；value ≥ full → 100 分；中间线性插值。 */
export function piecewiseScore(value, zero, full) {
  if (full === zero) return value >= full ? 100 : 0
  return clamp(((value - zero) / (full - zero)) * 100)
}

/**
 * 计算各子分数与总分。
 *
 * @param {object} input
 * @param {number} input.strategyReturn 策略收益（已由 metrics 计算）
 * @param {number} input.alpha Alpha
 * @param {number} input.maxDrawdown 最大回撤（负数或 0）
 * @param {boolean} input.targetReached 是否达到目标价
 * @param {boolean} input.stopLossTriggered 是否触发止损
 * @param {object} rules 评分规则（parseEvaluationRules 的产物）
 * @returns {{total: number, components: object, weights: object, version: string}}
 */
export function scoreEvaluation(input, rules) {
  const { strategyReturn, alpha, maxDrawdown, targetReached, stopLossTriggered } = input
  const decimals = rules.rounding.ratioDecimals

  const returnScore = piecewiseScore(strategyReturn, rules.returnScale.zero_score_return, rules.returnScale.full_score_return)
  const alphaScore = piecewiseScore(alpha, rules.alphaScale.zero_score_alpha, rules.alphaScale.full_score_alpha)

  const tolerance = rules.riskScale.max_drawdown_tolerance
  const drawdownPenalty = clamp((Math.abs(maxDrawdown) / tolerance) * 100)
  let riskScore = 100 - drawdownPenalty
  if (stopLossTriggered) riskScore -= rules.riskScale.stop_loss_penalty_points
  riskScore = clamp(riskScore)

  let targetScore
  if (stopLossTriggered) targetScore = rules.targetScale.stop_loss_triggered
  else if (targetReached) targetScore = rules.targetScale.target_reached
  else targetScore = rules.targetScale.holding_ended_without_target

  const components = {
    return: roundTo(returnScore, decimals),
    alpha: roundTo(alphaScore, decimals),
    risk: roundTo(riskScore, decimals),
    target: roundTo(targetScore, decimals),
  }

  const weights = rules.weights
  const total =
    weights.return * components.return
    + weights.alpha * components.alpha
    + weights.risk * components.risk
    + weights.target * components.target

  return {
    total: roundTo(clamp(total), rules.rounding.scoreDecimals),
    components,
    weights: { ...weights },
    version: rules.version,
  }
}
