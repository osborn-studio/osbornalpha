/**
 * Evaluation Engine —— 策略评价的确定性执行体（实施方案 §5.3 / §8 / §10）。
 *
 * 职责边界：
 *  - 只使用 **冻结之后、评价时点之前** 的行情（`frozen_at` ≤ 窗口 ≤ `as_of`）；
 *  - 全部数值来自 `metrics.js` + `scoring.js`，本模块不含任何主观判断；
 *  - 输出带 `calculation_version`，历史结果在公式演进后仍可解释。
 *
 * 退出语义（POC 明确定义，写入 README）：
 *  - 触发止损   → 视为仓位在止损价被平掉，`exit_price = stop_loss`，`exit_reason = STOP_LOSS`；
 *  - 未触发止损 → 持有到评价交易日收盘，`exit_price = 该日收盘价`，`exit_reason = PERIOD_END`。
 *  - 达到目标价是"目标事件"，不强制平仓，但会影响 Target 子分数。
 *  - Benchmark 使用与策略**完全相同的窗口与口径**，保证 Alpha 可比。
 */

import {
  computeAlpha,
  computeBenchmarkReturn,
  computeMaxDrawdown,
  computePnl,
  computeReturn,
  computeRiskReward,
  computeVolatility,
  detectStopLoss,
  detectTarget,
  roundTo,
} from './metrics.js'
import { scoreEvaluation } from './scoring.js'
import { lookahead, validation } from './errors.js'
const formatDate = date => date.toISOString().slice(0, 10)

/**
 * 计算持有窗口内的 mark-to-market 序列，使多头与空头的回撤口径一致。
 *
 * 多头的仓位价值随价格同向变动，直接用收盘价即可。
 * 空头的仓位价值与价格反向变动，但如果直接把"价值"取成 `-price` 会得到负数，
 * 负的峰值会让 `(price - peak) / peak` 的符号翻转，回撤恒为 0（一个真实的坑）。
 * 因此空头以入场价为轴做镜像：`2·entry − price`，起点等于入场价、量纲与多头一致，
 * 峰谷回撤的百分比含义与多头完全相同。
 */
function markSeries(action, prices, entryPrice) {
  if (action !== 'SELL') return prices.slice()
  return prices.map((price) => 2 * entryPrice - price)
}

/**
 * 执行一次评价。**纯确定性**：不读系统时间、不写库、不改策略。
 *
 * @param {object} input
 * @param {object} input.strategy 已冻结的策略（含 market_snapshot / frozen_at）
 * @param {object[]} input.bars 冻结的持有窗口行情
 * @param {object[]} input.benchmarkBars 同窗口基准行情
 * @param {object} input.rules 评分规则
 * @param {string} input.asOf 评价交易日（YYYY-MM-DD）；宿主负责边界验证
 * @param {number} [input.quantity] 数量，用于 P&L
 * @returns {object} Evaluation 记录体（未分配 evaluation_id）
 */
export function evaluateStrategyBars({ strategy, bars, benchmarkBars, rules, asOf, quantity = 1 }) {
  if (strategy?.frozen !== true) {
    throw validation(`strategy ${strategy?.strategy_id ?? '(unknown)'} must be frozen before evaluation`)
  }
  if (typeof asOf !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(asOf)) {
    throw validation(`as_of must be a YYYY-MM-DD date, received ${JSON.stringify(asOf)}`)
  }

  const frozenDate = formatDate(new Date(strategy.frozen_at))
  if (asOf < frozenDate) {
    throw lookahead(
      `cannot evaluate ${strategy.strategy_id} as of ${asOf}: the strategy was frozen at ${frozenDate}`,
      { strategyId: strategy.strategy_id, asOf, frozenAt: strategy.frozen_at },
    )
  }

  // 宿主已验证行情边界；内核只计算传入的冻结序列。
  if (bars.length === 0) {
    throw validation(`no market data for ${strategy.ticker} between ${frozenDate} and ${asOf}`)
  }
  if (benchmarkBars.length === 0) {
    throw validation(`no benchmark data for ${strategy.benchmark} between ${frozenDate} and ${asOf}`)
  }

  const action = strategy.action
  const closes = bars.map((bar) => bar.close)
  const highs = bars.map((bar) => bar.high)
  const lows = bars.map((bar) => bar.low)

  // 止损/目标判定使用期间极值，而不是只看收盘，避免漏掉盘中触发。
  const extremes = action === 'SELL' ? highs : lows
  const stop = detectStopLoss({ action, prices: extremes, stopLoss: strategy.stop_loss, decimals: rules.rounding.ratioDecimals })
  const targetExtremes = action === 'SELL' ? lows : highs
  const target = detectTarget({ action, prices: targetExtremes, targetPrice: strategy.target_price, decimals: rules.rounding.ratioDecimals })

  const stopTriggered = stop.triggered
  const exitIndex = stopTriggered && stop.triggeredAt !== null ? stop.triggeredAt : bars.length - 1
  const exitBar = bars[exitIndex]
  const exitPrice = stopTriggered ? strategy.stop_loss : exitBar.close
  const exitReason = stopTriggered ? 'STOP_LOSS' : target.reached ? 'TARGET_AND_PERIOD_END' : 'PERIOD_END'

  const windowBars = bars.slice(0, exitIndex + 1)
  const windowBenchmark = benchmarkBars.slice(0, Math.min(exitIndex + 1, benchmarkBars.length))
  const windowCloses = windowBars.map((bar) => bar.close)

  // 入场价使用分析师提交时声明的 entry_price（那是被冻结的决策），
  // 同时记录当时的市场快照价，便于审计"声明价 vs 市场价"的差异。
  const strategyReturn = computeReturn({ action, entryPrice: strategy.entry_price, exitPrice, decimals: rules.rounding.ratioDecimals })
  const benchmarkEntry = windowBenchmark[0].close
  const benchmarkExit = windowBenchmark.at(-1).close
  const benchmarkReturn = computeBenchmarkReturn({ benchmarkEntry, benchmarkExit, decimals: rules.rounding.ratioDecimals })
  const alpha = computeAlpha({ strategyReturn, benchmarkReturn, decimals: rules.rounding.ratioDecimals })
  const maxDrawdown = computeMaxDrawdown({ prices: markSeries(action, windowCloses, strategy.entry_price), decimals: rules.rounding.ratioDecimals })
  const pnl = computePnl({ action, entryPrice: strategy.entry_price, exitPrice, quantity, decimals: 2 })
  const riskReward = computeRiskReward({
    action,
    entryPrice: strategy.entry_price,
    targetPrice: strategy.target_price,
    stopLoss: strategy.stop_loss,
    decimals: rules.rounding.ratioDecimals,
  })

  const score = scoreEvaluation(
    { strategyReturn, alpha, maxDrawdown, targetReached: target.reached, stopLossTriggered: stopTriggered },
    rules,
  )

  return {
    strategy_id: strategy.strategy_id,
    analyst_id: strategy.analyst_id,
    ticker: strategy.ticker,
    action,
    benchmark: strategy.benchmark,

    entry_price: strategy.entry_price,
    exit_price: roundTo(exitPrice, 4),
    quantity,

    strategy_return: strategyReturn,
    benchmark_return: benchmarkReturn,
    alpha,
    max_drawdown: maxDrawdown,
    pnl,

    target_price: strategy.target_price,
    target_reached: target.reached,
    target_reached_on: target.reachedAt === null ? null : bars[target.reachedAt].date,
    stop_loss: strategy.stop_loss,
    stop_loss_triggered: stopTriggered,
    stop_loss_triggered_on: stopTriggered && stop.triggeredAt !== null ? bars[stop.triggeredAt].date : null,

    holding_days: windowBars.length,
    holding_period_planned: strategy.holding_period,
    risk_reward_ratio: riskReward.ratio,
    volatility: computeVolatility({ prices: windowCloses, decimals: rules.rounding.ratioDecimals }),

    exit_reason: exitReason,
    exit_date: exitBar.date,
    entry_date: bars[0].date,
    window: { from: bars[0].date, to: exitBar.date, as_of: asOf },

    score: score.total,
    score_components: score.components,
    score_weights: score.weights,
    calculation_version: score.version,

    price_timeline: windowBars.map((bar) => ({ date: bar.date, close: bar.close })),
    benchmark_timeline: windowBenchmark.map((bar) => ({ date: bar.date, close: bar.close })),
    benchmark_entry_price: roundTo(benchmarkEntry, 4),
    benchmark_exit_price: roundTo(benchmarkExit, 4),
    market_snapshot_price: strategy.market_snapshot?.price ?? null,
  }
}

/** 判定策略在给定交易日应处于什么状态（供 monitor 使用）。 */
export function deriveStatusFromPerformance({ strategy, targetReached, stopLossTriggered, holdingDays }) {
  if (stopLossTriggered) return 'STOPPED'
  if (holdingDays >= strategy.holding_period) return 'COMPLETED'
  if (targetReached) return 'ACTIVE'
  return 'ACTIVE'
}
