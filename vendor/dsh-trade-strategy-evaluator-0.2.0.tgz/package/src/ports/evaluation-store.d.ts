import type { EvaluationInput, EvaluationResult, Observation, MarketSnapshot } from '../engine/index.js';
export interface OwnerScope { user_id: string; workspace_id: null }
export interface FrozenEnvelope<T> { schema_version: 'evaluator-rpc/1.0'; owner_scope: OwnerScope; revision: number; sha256: string }
export type ObservationEnvelope = FrozenEnvelope<Observation> & { observation: Observation };
export type MarketEnvelope = FrozenEnvelope<MarketSnapshot> & { snapshot: MarketSnapshot };
export interface EvaluationCommit {
 schema_version: 'evaluator-rpc/1.0'; observation_ref: {id:string;sha256:string};
 market_snapshot_refs: {id:string;sha256:string}[]; engine_version:string;rule_version:string;
 input_sha256:string;input:EvaluationInput;result:EvaluationResult;result_sha256:string;
 expected_revision:number;idempotency_key:string;request_key:string;
}
export interface EvaluationReceipt {
 schema_version:'evaluator-rpc/1.0';owner_scope:OwnerScope;status:'accepted'|'duplicate';
 observation_ref:string;revision:number;idempotency_key:string;input_sha256:string;
 result_sha256:string;evaluation_ref:string;
}
/** No methods can create or update an Alpha decision, thesis, observation or source. */
export interface EvaluationStore {
 readObservation(id:string):Promise<ObservationEnvelope>;
 readMarketSnapshot(id:string):Promise<MarketEnvelope>;
 commitEvaluationResult(body:EvaluationCommit):Promise<EvaluationReceipt>;
}
export interface MarketProvider {
 /** Obtain a frozen snapshot, including adjustment/availability evidence; never fabricate prices. */
 getFrozenSnapshot(request:{security:MarketSnapshot['security'];from:string;to:string;as_of:string}):Promise<MarketSnapshot>;
}
export type EvaluatorTokenProvider = (request:{audience:'alpha-evaluator';purpose:'observation:read'|'evaluation:append';signal:AbortSignal})=>Promise<string>;
