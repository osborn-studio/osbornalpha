/** Promise-only local DSH storage port. Schema-v1 document bodies remain readable. */
export interface RepositoryPort {
  readonly driver: string;
  list(collection: string): Promise<Record<string, unknown>[]>;
  get(collection: string, key: string): Promise<Record<string, unknown> | null>;
  put(collection: string, record: Record<string, unknown>, options?: { expectedRevision?: number }): Promise<Record<string, unknown>>;
  delete(collection: string, key: string): Promise<boolean>;
  readMeta(key: string): Promise<unknown>;
  writeMeta(key: string, value: unknown): Promise<unknown>;
  nextSequence(kind: string, dayKey: string): Promise<number>;
  appendEvent(event: Record<string, unknown>): Promise<Record<string, unknown>>;
  stats(): Promise<unknown>;
  reset(): Promise<void>;
  close(): Promise<void>;
}
