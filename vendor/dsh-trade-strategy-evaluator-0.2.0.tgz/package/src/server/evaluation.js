/**
 * evaluation 插件（实施方案 §5.3 / §9）——所有确定性指标计算。
 *
 * 强制边界：
 *  - **禁止 LLM 直接计算最终绩效指标**。工具只负责调用 Engine 并返回结果；
 *    模型没有"写入 Evaluation"的能力（`evaluation.write` 能力对任何角色都为空）。
 *  - 所有计算可重复：同一 (策略, asOf, 规则版本) 必然得到同一结果，
 *    `strategy_verify_replay` 可以把落库结果与重算结果逐字段对比。
 */

import { businessTool, PARAM, registerTools } from './toolkit.js'

export const name = 'evaluation'

export async function apply(ctx, { service }) {
  const tools = [
    businessTool({
      name: 'observation_evaluate',
      description: '评价已冻结的单证券 Observation。只追加 descriptive 结果；alpha-connected 模式无本地回退，不能编辑 Alpha 决定。',
      parameters: {type:'object',properties:{request:{type:'object'},actor:PARAM.actor},required:['request'],additionalProperties:false},
      execute: async (args) => service.evaluateObservation(args.request,{actor:args.actor}),
    }),
    businessTool({
      name: 'evaluation_run',
      description:
        '对一条已冻结的策略执行确定性评价：计算 Return / P&L / Benchmark Return / Alpha / Maximum Drawdown /'
        + ' Target Achievement / Stop Loss / Holding Days / Risk-Reward / Score。'
        + '严禁自己计算这些数字——必须调用本工具。同一窗口重复调用会返回同一份结果（reused=true）。',
      parameters: {
        type: 'object',
        properties: { strategy_id: PARAM.strategyId, as_of: PARAM.asOf, actor: PARAM.actor },
        required: ['strategy_id'],
        additionalProperties: false,
      },
      async execute(args, exec) {
        const result = await service.evaluateStrategy(args.strategy_id, { asOf: args.as_of, actor: args.actor, sessionId: exec?.sessionId })
        const evaluation = result.evaluation
        return {
          __text: [
            `Strategy ${evaluation.strategy_id} (${evaluation.ticker} ${evaluation.action})`,
            `Return:        ${pct(evaluation.strategy_return)}   (entry ${evaluation.entry_price} → exit ${evaluation.exit_price})`,
            `Benchmark:     ${pct(evaluation.benchmark_return)}   (${evaluation.benchmark})`,
            `Alpha:         ${pct(evaluation.alpha)}`,
            `Max Drawdown:  ${pct(evaluation.max_drawdown, 1)}`,
            `P&L:           ${evaluation.pnl}`,
            `Holding Days:  ${evaluation.holding_days} (planned ${evaluation.holding_period_planned})`,
            `Target:        ${evaluation.target_reached ? `reached on ${evaluation.target_reached_on}` : 'not reached'}`,
            `Stop Loss:     ${evaluation.stop_loss_triggered ? `triggered on ${evaluation.stop_loss_triggered_on}` : 'not triggered'}`,
            `Exit Reason:   ${evaluation.exit_reason}`,
            `Score:         ${evaluation.score} / 100  (${evaluation.calculation_version})`,
            `Evaluation ID: ${evaluation.evaluation_id}${result.reused ? ' (reused existing identical evaluation)' : ''}`,
            '',
            '以上数值全部由确定性 Evaluation Engine 计算，可重复验证。',
          ].join('\n'),
          evaluation,
          reused: result.reused,
          identical_to_previous: result.identical,
          score_components: evaluation.score_components,
          score_weights: evaluation.score_weights,
        }
      },
    }),

    businessTool({
      name: 'evaluation_get',
      description: '按 Evaluation ID 读取一条已落库的评价记录（只读）。',
      parameters: { type: 'object', properties: { evaluation_id: { type: 'string', description: '例如 EVAL-20261016-001' } }, required: ['evaluation_id'], additionalProperties: false },
      async execute(args) {
        return (await service.getEvaluation(args.evaluation_id))
      },
    }),

    businessTool({
      name: 'evaluation_list',
      description: '列出评价记录（可按策略或分析师过滤）。',
      parameters: {
        type: 'object',
        properties: { strategy_id: PARAM.strategyId, analyst_id: PARAM.analystId, limit: PARAM.limit },
        additionalProperties: false,
      },
      async execute(args) {
        return (await service.listEvaluations({ strategyId: args.strategy_id, analystId: args.analyst_id, limit: args.limit }))
      },
    }),

    businessTool({
      name: 'evaluation_rules_get',
      description:
        '读取当前评分规则（权重与各分项映射阈值）以及规则版本。规则来自 config/evaluation-rules.json，'
        + '不硬编码在 Prompt 里，管理员可调整。',
      parameters: { type: 'object', properties: {}, additionalProperties: false },
      async execute() {
        return service.getRules()
      },
    }),

    businessTool({
      name: 'evaluation_rules_update',
      description:
        '更新评分规则（仅 ADMIN）。可改 weights（return/alpha/risk/target，必须和为 1）与各分项的映射阈值。'
        + '注意：新版本只影响之后的评价；历史 Evaluation 保留其 calculation_version，因此仍然可解释。',
      parameters: {
        type: 'object',
        properties: {
          version: { type: 'string', description: '新的规则版本号，例如 v2' },
          weights: {
            type: 'object',
            properties: { return: { type: 'number' }, alpha: { type: 'number' }, risk: { type: 'number' }, target: { type: 'number' } },
            required: ['return', 'alpha', 'risk', 'target'],
            additionalProperties: false,
          },
          actor: PARAM.actor,
        },
        required: ['weights'],
        additionalProperties: false,
      },
      async execute(args) {
        const rules = (await service.updateRules({ version: args.version, weights: args.weights }, { actor: args.actor }))
        return { version: rules.version, weights: rules.weights, note: '后续评价将使用新规则；历史 Evaluation 的 calculation_version 不变。' }
      },
    }),

    businessTool({
      name: 'strategy_verify_replay',
      description:
        '用同一份历史数据**重新计算**一次评价，并与落库结果逐字段比对。'
        + '这是"所有评价结果可以重复计算并得到相同结果"的可执行证明，也是审计要求的证据。',
      parameters: { type: 'object', properties: { strategy_id: PARAM.strategyId }, required: ['strategy_id'], additionalProperties: false },
      async execute(args) {
        const result = await service.verifyReplay(args.strategy_id)
        return {
          __text: result.matches
            ? `Replay 一致：${result.strategy_id} 的 ${result.evaluation_id} 重算结果与落库结果逐字段相同（${result.calculation_version}）。`
            : `Replay 不一致：差异字段 ${result.differences.join(', ')} —— 这是必须调查的缺陷。`,
          ...result,
        }
      },
    }),
  ]

  return registerTools(ctx, tools)
}

function pct(value, decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return `${value > 0 ? '+' : ''}${(value * 100).toFixed(decimals)}%`
}
