/**
 * market-data 插件（实施方案 §5.2）——市场数据。
 *
 * 接口：market.get_quote / market.get_history / market.get_benchmark / market.get_snapshot
 * POC 使用 MockMarketDataProvider；业务层只依赖 MarketDataProvider 抽象，
 * 未来换成 Polygon / Alpha Vantage / Yahoo / Bloomberg / 内部行情服务时，业务代码零改动。
 *
 * 重要：行情一律受 `boundary()` 硬闸约束，任何"读取未来"的请求都会抛
 * LOOKAHEAD_VIOLATION，因此本插件无法被用来偷看未来价格。
 */

import { businessTool, PARAM, registerTools } from './toolkit.js'

export const name = 'market-data'

export async function apply(ctx, { service }) {
  const tools = [
    businessTool({
      name: 'market_get_quote',
      description:
        '读取一个标的的最新报价（Mock Provider 为最近一个交易日收盘价）。'
        + '返回 ticker / price / timestamp / volume。行情只到当前模拟时钟的交易日为止，不能读取未来。',
      parameters: { type: 'object', properties: { ticker: { ...PARAM.ticker, description: `${PARAM.ticker.description}；可用标的见 market_universe` } }, required: ['ticker'], additionalProperties: false },
      async execute(args, exec) {
        const quote = await service.getQuote(args.ticker)
        return { ...quote, provider: service.provider.name, boundary: service.provider.boundary(), note: `Mock 行情，数据上界 ${service.provider.boundary()}` }
      },
    }),

    businessTool({
      name: 'market_get_history',
      description: '读取某个标的在 [from, to] 区间内的日线序列（按时间升序）。不得请求晚于数据上界的日期。',
      parameters: {
        type: 'object',
        properties: { ticker: PARAM.ticker, from: PARAM.date, to: PARAM.date },
        required: ['ticker'],
        additionalProperties: false,
      },
      async execute(args) {
        const bars = await service.getHistory(args.ticker, args.from, args.to)
        return { ticker: String(args.ticker).toUpperCase(), count: bars.length, data_boundary: service.provider.boundary(), bars }
      },
    }),

    businessTool({
      name: 'market_get_benchmark',
      description: `读取 Benchmark 的日线序列。已配置的 Benchmark：${'QQQ / SPY'}。`,
      parameters: {
        type: 'object',
        properties: { ticker: PARAM.ticker, from: PARAM.date, to: PARAM.date },
        required: ['ticker'],
        additionalProperties: false,
      },
      async execute(args) {
        const bars = await service.getBenchmark(args.ticker, args.from, args.to)
        return { ticker: String(args.ticker).toUpperCase(), count: bars.length, data_boundary: service.provider.boundary(), bars }
      },
    }),

    businessTool({
      name: 'market_get_snapshot',
      description: '捕获一个标的的当前市场快照（创建策略时使用的就是这个快照）。快照会被固化进策略，用于事后审计。',
      parameters: { type: 'object', properties: { ticker: PARAM.ticker }, required: ['ticker'], additionalProperties: false },
      async execute(args) {
        return (await service.getMarketSnapshot(args.ticker))
      },
    }),

    businessTool({
      name: 'market_universe',
      description: '列出可用的 Mock 标的与 Benchmark，以及当前数据上界（最新可用交易日）与 Provider 名称。',
      parameters: { type: 'object', properties: {}, additionalProperties: false },
      async execute() {
        return {
          provider: service.provider.name,
          data_boundary: service.provider.boundary(),
          tickers: service.provider.listTickers(),
          benchmarks: service.provider.listBenchmarks(),
          history_epoch: service.universe.history_epoch,
          note: 'Mock 行情由确定性价格模型生成：同一 (ticker, date) 永远得到同一价格，因此评价与 Replay 可重复。',
        }
      },
    }),
  ]

  return registerTools(ctx, tools)
}
