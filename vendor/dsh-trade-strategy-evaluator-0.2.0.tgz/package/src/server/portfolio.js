/**
 * portfolio 插件（需求 C1/C2/C3/C5/C8/D3）—— 分析师的模拟盘组合。
 *
 * 定位：这是**绩效考评的账本层**，不是交易系统。
 *   · 权重 / 净值式记账（起始净值 100），**只出收益率与净值曲线，绝不出金额**；
 *   · 每条已冻结策略 = 一个"手"，占当时净值的 `weight_pct`；
 *   · 与真实持仓、真实资金完全解耦（C6/F1/F2）。
 *
 * 强制边界（与 evaluation 插件同级）：
 *   · **禁止 LLM 计算净值、收益率、回撤**。工具只调用确定性投影并返回结果；
 *   · 净值曲线**必须能从策略流完全重算**（`portfolio_recompute` 逐字段比对）；
 *   · 超限挤出是系统决定，必须落 `POSITION_EVICTED` 事件，**绝不修改已冻结策略**。
 */

import { businessTool, PARAM, registerTools } from './toolkit.js'

export const name = 'portfolio'

export async function apply(ctx, { service }) {
  const tools = [
    businessTool({
      name: 'portfolio_get',
      description:
        '读取某个分析师的模拟盘组合：净值、累计收益率、当前持仓（按权重）、已平仓明细、'
        + '敞口与仓位上限、超限挤出与被拒指令的记录。'
        + '净值为权重/净值式（起始 100），**只给收益率与净值，不含任何金额**。'
        + '严禁自己计算这些数字——必须调用本工具。',
      parameters: {
        type: 'object',
        properties: { analyst_id: PARAM.analystId, as_of: PARAM.asOf, actor: PARAM.actor },
        required: ['analyst_id'],
        additionalProperties: false,
      },
      async execute(args, exec) {
        const { projection, portfolio, reused } = await service.getPortfolio(args.analyst_id, { asOf: args.as_of, actor: args.actor, sessionId: exec?.sessionId })
        const open = projection.positions
        return {
          __text: [
            `Portfolio ${args.analyst_id}  as of ${portfolio.as_of}  (${projection.accounting_version})`,
            `NAV:            ${projection.nav}   (start ${projection.start_nav})`,
            `Total Return:   ${pct(projection.total_return)}`,
            `Exposure:       ${projection.gross_exposure_pct}%  / limit ${projection.max_position_pct}%   (unallocated ${projection.unallocated_pct}%)`,
            `Lots:           open ${projection.counts.lots_open} / opened ${projection.counts.lots_opened} / closed ${projection.counts.lots_closed}`,
            `Evicted:        ${projection.counts.evictions}   Rejected: ${projection.counts.rejections}   (strategy ${projection.eviction_strategy})`,
            '',
            'Open positions:',
            ...(open.length === 0
              ? ['  (none)']
              : open.map((lot) => `  ${lot.lot_id}  ${lot.ticker.padEnd(6)} ${lot.action.padEnd(4)} ${String(lot.weight_pct).padStart(5)}%  opened ${lot.opened_date} @ ${lot.entry_price}  (strategy ${lot.strategy_id})`)),
            '',
            `所有数值由确定性组合账本计算（${projection.accounting_version}），可重复验证；` +
              `本组合与真实持仓、真实资金无关。${reused ? ' (reused identical snapshot)' : ''}`,
          ].join('\n'),
          analyst_id: args.analyst_id,
          as_of: portfolio.as_of,
          accounting_version: projection.accounting_version,
          start_nav: projection.start_nav,
          nav: projection.nav,
          total_return: projection.total_return,
          gross_exposure_pct: projection.gross_exposure_pct,
          unallocated_pct: projection.unallocated_pct,
          max_position_pct: projection.max_position_pct,
          eviction_strategy: projection.eviction_strategy,
          counts: projection.counts,
          positions: open,
          evictions: projection.evictions,
          rejections: projection.rejections,
          reused,
        }
      },
    }),

    businessTool({
      name: 'portfolio_nav',
      description:
        '读取某个分析师的组合净值曲线（可用 from/to 切片）以及该区间的最大回撤。'
        + '净值可完全从策略流重算，因此这是一条**可验证**的业绩曲线，不是估算。',
      parameters: {
        type: 'object',
        properties: { analyst_id: PARAM.analystId, from: PARAM.date, to: PARAM.date, as_of: PARAM.asOf, actor: PARAM.actor },
        required: ['analyst_id'],
        additionalProperties: false,
      },
      async execute(args, exec) {
        const nav = await service.getPortfolioNav(args.analyst_id, { from: args.from, to: args.to, asOf: args.as_of, actor: args.actor, sessionId: exec?.sessionId })
        const first = nav.curve[0]
        const last = nav.curve.at(-1)
        return {
          __text: [
            `NAV curve ${args.analyst_id}  ${first?.date ?? 'n/a'} → ${last?.date ?? 'n/a'}  (${nav.curve.length} points)`,
            `Start NAV:      ${nav.start_nav}`,
            `Latest NAV:     ${nav.nav}`,
            `Total Return:   ${pct(nav.total_return)}`,
            `Max Drawdown:   ${pct(nav.max_drawdown)}`,
            `Accounting:     ${nav.accounting_version}`,
            '',
            '曲线由确定性账本逐日盯市产出，可由 portfolio_recompute 重算比对。',
          ].join('\n'),
          ...nav,
        }
      },
    }),

    businessTool({
      name: 'portfolio_recompute',
      description:
        '从策略流**重新计算**组合净值曲线与持仓，并与落库快照逐字段比对。'
        + '这是"所有评价结果可重复计算并得到相同结果"在组合层的可执行证明，也是审计要求的证据。'
        + '同时返回对账恒等式（各手盈亏之和 vs 净值变动），用于证明组合层与逐笔层没有各算各的。',
      parameters: {
        type: 'object',
        properties: { analyst_id: PARAM.analystId, as_of: PARAM.asOf, actor: PARAM.actor },
        required: ['analyst_id'],
        additionalProperties: false,
      },
      async execute(args, exec) {
        const result = await service.recomputePortfolio(args.analyst_id, { asOf: args.as_of, actor: args.actor, sessionId: exec?.sessionId })
        return {
          __text: result.matches
            ? `组合重算一致：${args.analyst_id} 的 ${result.snapshot_id} 重算结果与落库结果逐字段相同（${result.accounting_version}，指纹 ${result.instruction_digest}）。\n`
              + `对账：已实现 ${result.reconciliation.realized_pnl_nav} + 浮动 ${result.reconciliation.unrealized_pnl_nav} = 净值变动 ${result.reconciliation.nav_delta}（差额 ${result.reconciliation.gap}）`
            : `组合重算不一致：差异 ${result.differences.join(', ')} —— 这是必须调查的缺陷。`,
          ...result,
        }
      },
    }),
  ]

  return registerTools(ctx, tools)
}

function pct(value, decimals = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return `${value > 0 ? '+' : ''}${(value * 100).toFixed(decimals)}%`
}
