/**
 * report 插件（实施方案 §5.5 / §22）——报告生成。
 *
 * 报告在结构上强制区分：
 *   FACTUAL METRICS  —— 全部来自 Evaluation Engine，只读、可核对、带 calculation_version
 *   LLM COMMENTARY   —— 只放模型生成的解释/摘要/归因，永远附免责声明
 *
 * 工具返回的 Markdown 里两者物理分区，模型无法把主观判断混进事实区：
 * 它只能通过 `commentary` 参数投稿，而投稿会被放进带免责声明的独立小节。
 */

import { businessTool, languageParam, PARAM, registerTools } from './toolkit.js'

export const name = 'report'

export async function apply(ctx, { service }) {
  const tools = [
    businessTool({
      name: 'report_strategy',
      description:
        '生成 Strategy Evaluation Report（§22 模板）：原始策略 / 市场快照 / 实际表现 / 规则判定 / 最终评分。'
        + '事实区数值全部来自 Evaluation Engine。你的解释只能通过 commentary 参数提交，会被放进带免责声明的独立小节。',
      parameters: {
        type: 'object',
        properties: { strategy_id: PARAM.strategyId, commentary: PARAM.commentary, language: languageParam, actor: PARAM.actor },
        required: ['strategy_id'],
        additionalProperties: false,
      },
      async execute(args, exec) {
        const { report, markdown } = (await service.renderStrategyReport(args.strategy_id, { actor: args.actor, commentary: args.commentary, language: args.language, sessionId: exec?.sessionId }))
        return { __text: markdown, report_type: 'strategy', factual: report.factual, commentary: args.commentary ?? null, commentary_disclaimer: report.commentary_disclaimer }
      },
    }),

    businessTool({
      name: 'report_analyst',
      description:
        '生成 Analyst Performance Report：策略数、完成数、胜率、平均收益、平均 Alpha、最大回撤、平均评分与完整策略历史。'
        + '同样区分事实区与模型评论区。',
      parameters: {
        type: 'object',
        properties: { analyst_id: PARAM.analystId, commentary: PARAM.commentary, language: languageParam, actor: PARAM.actor },
        required: ['analyst_id'],
        additionalProperties: false,
      },
      async execute(args, exec) {
        const { report, markdown, report_id } = (await service.buildAnalystReportFor(args.analyst_id, { actor: args.actor, commentary: args.commentary, language: args.language, sessionId: exec?.sessionId }))
        return { __text: markdown, report_id, report_type: 'analyst', factual: report.factual, commentary_disclaimer: report.commentary_disclaimer }
      },
    }),

    businessTool({
      name: 'report_team',
      description: '生成 Team Performance Report：按团队聚合的策略数、胜率、平均收益、平均 Alpha、最大回撤与平均评分。',
      parameters: { type: 'object', properties: { commentary: PARAM.commentary, language: languageParam, actor: PARAM.actor }, additionalProperties: false },
      async execute(args, exec) {
        const { report, markdown, report_id } = (await service.buildTeamReportFor({ actor: args.actor, commentary: args.commentary, language: args.language, sessionId: exec?.sessionId }))
        return { __text: markdown, report_id, report_type: 'team', factual: report.factual, commentary_disclaimer: report.commentary_disclaimer }
      },
    }),

    businessTool({
      name: 'analyst_performance',
      description: '读取单个分析师的绩效聚合（不生成 Markdown）。适合被 Agent 用来做跨分析师对比与排序。',
      parameters: { type: 'object', properties: { analyst_id: PARAM.analystId, actor: PARAM.actor }, required: ['analyst_id'], additionalProperties: false },
      async execute(args) {
        const { analyst, aggregate } = (await service.getAnalystPerformance(args.analyst_id, { actor: args.actor }))
        const { rows, ...metrics } = aggregate
        return { analyst, metrics, strategies: rows }
      },
    }),

    businessTool({
      name: 'team_performance',
      description: '读取单个团队的绩效明细：团队汇总指标 + 该团队内**按分析师分组**的策略列表。'
        + '适合回答"某团队里各成员分别做得怎么样"这类问题。',
      parameters: {
        type: 'object',
        properties: { team: { type: 'string', description: "团队名，例如 'TMT'（可用 manager_dashboard 或 team 列表获取）" }, actor: PARAM.actor },
        required: ['team'],
        additionalProperties: false,
      },
      async execute(args) {
        const result = (await service.getTeamPerformance(args.team, { actor: args.actor }))
        const { rows, ...metrics } = result.aggregate
        return {
          team: result.team,
          analyst_count: result.analyst_count,
          metrics,
          analysts: result.analysts.map((row) => {
            const { rows: analystRows, ...analystMetrics } = row
            return { ...analystMetrics, strategies: analystRows }
          }),
        }
      },
    }),

    businessTool({
      name: 'manager_dashboard',
      description:
        '读取 Manager Dashboard 数据：全部分析师一行一人的绩效汇总（策略数/完成数/胜率/平均收益/平均 Alpha/最大回撤/评分）、'
        + '团队汇总、总体指标、当前模拟时钟与行情上界、最近审计事件。所有数字由代码聚合，模型只能解释。',
      parameters: { type: 'object', properties: { actor: PARAM.actor }, additionalProperties: false },
      async execute(args) {
        return (await service.getDashboard({ actor: args.actor }))
      },
    }),

    businessTool({
      name: 'strategy_replay',
      description:
        '重放一条策略的完整生命周期：提交 → 市场快照 → 冻结 → 每日价格推进 → 目标/止损 → 评价 → 评分。'
        + '并直接回答审计要求的 11 个问题（谁提交、何时提交、当时价格、当时仓位、为什么、后续价格变化、'
        + '是否触发目标、是否触发止损、最终收益、Benchmark 表现、最终评分）。',
      parameters: { type: 'object', properties: { strategy_id: PARAM.strategyId, actor: PARAM.actor }, required: ['strategy_id'], additionalProperties: false },
      async execute(args) {
        const replay = (await service.replayStrategy(args.strategy_id, { actor: args.actor }))
        const answers = replay.answers
        return {
          __text: [
            `# Strategy Replay — ${replay.strategy_id} (${replay.analyst.name})`,
            '',
            '## Timeline',
            ...replay.timeline.map((row) => `${row.at}  ${row.label}${row.actor === null ? '' : `  [${row.actor.role}:${row.actor.actor_id}]`}`),
            '',
            '## Price Evolution',
            ...replay.price_steps.map((row) => `Day ${row.day}  ${row.date}  Price = ${row.price}`),
            '',
            '## Audit Answers',
            `1. 谁提交的:            ${answers['1_who_submitted']}`,
            `2. 什么时间提交:        ${answers['2_submitted_at']}`,
            `3. 当时价格:            ${answers['3_price_at_submission']}`,
            `4. 当时仓位:            ${answers['4_position_before']}`,
            `5. 为什么买/卖:         ${answers['5_rationale']}`,
            `6. 后续价格变化:        ${replay.price_steps.length} 个交易日`,
            `7. 是否触发目标:        ${answers['7_target_reached']}`,
            `8. 是否触发止损:        ${answers['8_stop_loss_triggered']}`,
            `9. 最终收益:            ${answers['9_strategy_return']}`,
            `10. Benchmark 表现:     ${JSON.stringify(answers['10_benchmark'])}`,
            `11. 最终评分:           ${answers['11_final_score']}`,
            '',
            `Replay 一致性（可由落库数据直接推导的收益口径）: ${replay.replay_consistent}`,
          ].join('\n'),
          ...replay,
        }
      },
    }),
  ]

  return registerTools(ctx, tools)
}
