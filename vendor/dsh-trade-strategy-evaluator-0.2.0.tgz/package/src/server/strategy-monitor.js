/**
 * strategy-monitor 插件（实施方案 §5.4）——策略监控。
 *
 * 流程：Scheduler → 取 ACTIVE 策略 → 取最新行情 → 更新 Strategy Performance
 *       → 检查 Target → 检查 Stop Loss → 检查 Expiration → 更新状态。
 *
 * 支持 monitorStrategy(strategyId) 与 monitorAllActiveStrategies()；
 * 根插件会在 `monitor: true` 时用 `ctx.setInterval` 起一个调度（随 fiber 自动清理）。
 */

import { businessTool, PARAM, registerTools } from './toolkit.js'

export const name = 'strategy-monitor'

export async function apply(ctx, { service, config }) {
  const tools = [
    businessTool({
      name: 'strategy_monitor',
      description:
        '监控单条策略：拉取最新行情、更新浮动表现、检查目标价/止损/持仓期满，并在必要时推进状态'
        + '（ACTIVE → STOPPED / COMPLETED / EXPIRED）。只写状态与非决策性的 performance，绝不改核心决策字段。',
      parameters: { type: 'object', properties: { strategy_id: PARAM.strategyId, as_of: PARAM.asOf, actor: PARAM.actor }, required: ['strategy_id'], additionalProperties: false },
      async execute(args, exec) {
        const result = await service.monitorStrategy(args.strategy_id, { asOf: args.as_of, actor: args.actor, sessionId: exec?.sessionId })
        const strategy = result.strategy
        return {
          __text: [
            `Strategy ${strategy.strategy_id} (${strategy.ticker} ${strategy.action})`,
            `Status:        ${strategy.status}${strategy.status_reason === null ? '' : ` (${strategy.status_reason})`}`,
            `As of:         ${result.performance?.as_of ?? args.as_of ?? service.provider.boundary()}`,
            `Price:         ${result.performance?.price ?? 'n/a'}`,
            `Unrealized:    ${fmt(result.performance?.unrealized_return)}`,
            `Holding Days:  ${result.performance?.holding_days ?? 'n/a'}`,
            `Target:        ${result.performance?.target_reached ? 'reached' : 'not reached'}`,
            `Stop Loss:     ${result.performance?.stop_loss_triggered ? 'TRIGGERED' : 'not triggered'}`,
            `Changed:       ${result.changed}`,
          ].join('\n'),
          strategy_id: strategy.strategy_id,
          status: strategy.status,
          status_reason: strategy.status_reason,
          changed: result.changed,
          performance: result.performance,
          events: result.events.map((event) => event.type),
        }
      },
    }),

    businessTool({
      name: 'strategy_monitor_all',
      description: '监控全部 ACTIVE 策略（ADMIN/MANAGER）。返回被监控数量、状态变化数量与每条的结论。',
      parameters: { type: 'object', properties: { as_of: PARAM.asOf, actor: PARAM.actor }, additionalProperties: false },
      async execute(args, exec) {
        const summary = await service.monitorAllActiveStrategies({ asOf: args.as_of, actor: args.actor, sessionId: exec?.sessionId })
        return {
          __text: [
            `Monitor run @ ${summary.as_of}`,
            `Monitored: ${summary.monitored}   Changed: ${summary.changed}   Stopped: ${summary.stopped}   Completed: ${summary.completed}`,
            ...summary.results.slice(0, 20).map((row) => `- ${row.strategy_id}: ${row.status}${row.changed ? ' (updated)' : ''}`),
          ].join('\n'),
          ...summary,
        }
      },
    }),

    businessTool({
      name: 'demo_advance_clock',
      description:
        '【Demo 专用】把模拟时钟向前推进 N 个交易日，然后可以让监控/评价按新的"当下"运行。'
        + '真实部署不会调用本工具（时钟来自系统时间）。推进不会改变任何已冻结的数据。',
      parameters: { type: 'object', properties: { trading_days: { type: 'integer', description: '推进的交易日数，1..260' }, actor: PARAM.actor }, required: ['trading_days'], additionalProperties: false },
      async execute(args, exec) {
        const result = (await service.advanceClock(args.trading_days, { actor: args.actor, sessionId: exec?.sessionId }))
        return {
          __text: `模拟时钟推进了 ${result.advanced_trading_days} 个交易日 → 现在 ${result.clock.now}，行情数据上界 ${result.boundary}。`,
          ...result,
        }
      },
    }),
  ]

  if (config?.monitorIntervalMs !== undefined) {
    // 调度随 fiber 清理；间隔调用全量监控（评估用 60s，Demo 不必更密）。
    ctx.effect(() => {
      const timer = setInterval(async () => {
        ;service.monitorAllActiveStrategies({ actor: { actor_id: 'monitor_scheduler', role: 'MANAGER' } }).catch((error) => {
          ctx.logger?.warn?.(`trade-strategy-evaluator: scheduled monitor failed: ${error.message}`)
        })
      }, config.monitorIntervalMs)
      if (typeof timer.unref === 'function') timer.unref()
      return () => clearInterval(timer)
    }, 'trade-strategy-evaluator: monitor scheduler')
  }

  return registerTools(ctx, tools)
}

function fmt(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'n/a'
  return `${value > 0 ? '+' : ''}${(value * 100).toFixed(2)}%`
}
