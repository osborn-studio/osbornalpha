/**
 * 工具工具箱。
 *
 * 本插件刻意**不 import 任何 `@deepseek-ai/*` 包**：profile 的 node_modules 只暴露了
 * `@deepseek-ai/dsh-client-ui-slots`，直接 import `dsh-tools` 会解析失败。
 * 因此这里直接构造 `ctx.tools.register()` 需要的 ToolDefinition：
 *   { name, description, parameters (JSON Schema), output: { schema, render }, execute }
 * 这与 `defineTool()` 的产物形状一致（defineTool 只是把作者 DSL 编译成 JSON Schema），
 * 但不需要任何构建期/运行期依赖。
 */

/** 支持的 JSON Schema 子集里，用空对象表示"任意 JSON 值"。 */
const ANY_SCHEMA = Object.freeze({})

/**
 * 定义一个业务工具。
 * @param {object} spec
 * @param {string} spec.name 面向模型的工具名
 * @param {string} spec.description 描述（会进入系统提示词的工具目录）
 * @param {object} spec.parameters JSON Schema（object 根）
 * @param {(args: object, exec: object) => Promise<unknown>} spec.execute
 */
export function businessTool({ name, description, parameters, execute }) {
  if (typeof name !== 'string' || name.length === 0) throw new TypeError('tool name is required')
  if (typeof description !== 'string' || description.length === 0) throw new TypeError(`tool ${name} requires a description`)
  if (typeof execute !== 'function') throw new TypeError(`tool ${name} requires an execute function`)
  return {
    name,
    description,
    parameters: parameters ?? { type: 'object', properties: {}, additionalProperties: true },
    output: {
      schema: ANY_SCHEMA,
      /**
       * 模型看到的内容。默认把业务 JSON 渲染成缩进 JSON，
       * 但业务层可以选择在返回值里放 `__text` 直接给模型一段人类可读文本
       * （报告类工具就是这样：模型应该读 Markdown，而不是读一坨 JSON）。
       */
      render: (_args, value) => {
        if (typeof value === 'string') return [{ type: 'text', text: value }]
        if (value !== null && typeof value === 'object' && typeof value.__text === 'string') {
          const { __text: text, ...rest } = value
          const extra = Object.keys(rest).length === 0 ? '' : `\n\n---\n结构化数据：\n${JSON.stringify(rest, null, 2)}`
          return [{ type: 'text', text: `${text}${extra}` }]
        }
        return [{ type: 'text', text: JSON.stringify(value, null, 2) }]
      },
    },
    execute,
  }
}

/** 常用参数片段，减少 schema 重复。 */
/** 报告语言参数（单独导出，避免与其它参数混在一个对象里产生误解）。 */
export const languageParam = {
  type: 'string',
  enum: ['zh', 'en'],
  description: '报告语言：zh（简体中文）或 en（English）。只影响文案，不影响任何数值与判定。缺省用插件配置的语言。',
}

export const PARAM = {
  strategyId: { type: 'string', description: '策略 ID，例如 STR-20260916-001' },
  analystId: { type: 'string', description: '分析师 ID，例如 john' },
  ticker: { type: 'string', description: '股票代码，例如 NVDA' },
  date: { type: 'string', description: '交易日，格式 YYYY-MM-DD' },
  asOf: { type: 'string', description: '评价/监控的截止交易日，格式 YYYY-MM-DD。缺省为当前模拟时钟的交易日。' },
  actor: {
    type: 'object',
    description:
      '调用方身份 { actor_id, role }；role ∈ ANALYST | MANAGER | ADMIN。'
      + '**写操作必须显式传**：strategy_create / strategy_freeze 只允许 ANALYST 或 ADMIN，'
      + 'evaluation_rules_update 只允许 ADMIN，strategy_monitor* 只允许 MANAGER 或 ADMIN；'
      + '缺省身份是 MANAGER，因此不传 actor 的写操作会以 UNAUTHORIZED 失败'
      + '（报错里会带 suggestedActor，照它重试即可）。'
      + 'strategy_create 的 actor_id 还必须是一个真实存在的分析师 ID。',
    properties: {
      actor_id: { type: 'string', description: '身份 ID；role=ANALYST 时必须是真实分析师 ID，如 john' },
      role: { type: 'string', enum: ['ANALYST', 'MANAGER', 'ADMIN'] },
      name: { type: 'string' },
    },
    additionalProperties: false,
  },
  commentary: { type: 'string', description: '模型生成的分析性评论。会与事实数据严格分区呈现，并自动附上免责声明。' },
  limit: { type: 'integer', description: '返回条数上限' },
}

/** 把插件配置解析成调用方身份，供工具层使用。 */
export function actorOf(args) {
  return args?.actor ?? undefined
}

/**
 * 注册一组工具，返回 disposer 数组。
 * @param {object} ctx Cordis 上下文（必须已 inject 'tools'）
 * @param {Array<object>} tools businessTool 的产物
 */
export function registerTools(ctx, tools) {
  return tools.map((tool) => ctx.tools.register(tool))
}
