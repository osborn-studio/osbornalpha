/**
 * trade-strategy 插件（实施方案 §5.1）——策略生命周期。
 *
 * 能力：strategy.create / get / list / freeze / cancel / status
 * 状态：DRAFT ACTIVE COMPLETED STOPPED EXPIRED CANCELLED
 * 核心原则：策略一旦 FREEZE，不允许修改影响评价结果的字段。
 *
 * 本插件只做"暴露能力 + 参数编解码"，所有校验与守卫都在 Service 与 immutability 守卫里，
 * 因此 REST API 与 Agent 工具走的是**同一条**受守卫的路径，不存在绕过面。
 */

import { businessTool, PARAM, registerTools } from './toolkit.js'

export const name = 'trade-strategy'

export async function apply(ctx, { service }) {
  const tools = [
    businessTool({
      name: 'strategy_create',
      description:
        '提交并冻结一条交易策略。会立即捕获当时的市场快照并冻结策略（冻结后核心决策字段永久不可修改）。'
        + '必须提供方向一致的 entry/target/stop：BUY 要求 stop < entry < target，SELL 要求 target < entry < stop。',
      parameters: {
        type: 'object',
        properties: {
          analyst_id: { type: 'string', description: '分析师 ID' },
          ticker: { type: 'string', description: '股票代码，例如 NVDA' },
          action: { type: 'string', enum: ['BUY', 'SELL'] },
          position_before: { type: 'number', description: '提交前仓位' },
          quantity: { type: 'integer', description: '数量，用于 P&L；缺省取 demo 配置的 100' },
          weight_pct: { type: 'number', description: '模拟盘建仓权重（百分点，0–100）。缺省时由组合层用配置默认值。它决定该手占当时净值的比例，冻结后不可修改。' },
          entry_price: { type: 'number' },
          target_price: { type: 'number' },
          stop_loss: { type: 'number' },
          holding_period: { type: 'integer', description: '预期持仓交易日数' },
          benchmark: { type: 'string', description: 'Benchmark 代码，例如 QQQ' },
          reason: { type: 'string', description: '策略理由（原样保存，永不改写）' },
          actor: PARAM.actor,
        },
        required: ['analyst_id', 'ticker', 'action', 'entry_price', 'target_price', 'stop_loss', 'holding_period', 'reason'],
        additionalProperties: false,
      },
      async execute(args, exec) {
        const strategy = await service.createStrategy(args, { actor: args.actor, sessionId: exec?.sessionId })
        return {
          strategy_id: strategy.strategy_id,
          status: strategy.status,
          frozen: strategy.frozen,
          weight_pct: strategy.weight_pct,
          frozen_at: strategy.frozen_at,
          ticker: strategy.ticker,
          action: strategy.action,
          entry_price: strategy.entry_price,
          target_price: strategy.target_price,
          stop_loss: strategy.stop_loss,
          holding_period: strategy.holding_period,
          benchmark: strategy.benchmark,
          market_snapshot: strategy.market_snapshot,
        }
      },
    }),

    businessTool({
      name: 'strategy_get',
      description: '按 Strategy ID 读取策略的完整记录（含当时的市场快照、当前状态与已生成的评价）。',
      parameters: { type: 'object', properties: { strategy_id: PARAM.strategyId, actor: PARAM.actor }, required: ['strategy_id'], additionalProperties: false },
      async execute(args) {
        return (await service.getStrategy(args.strategy_id, { actor: args.actor }))
      },
    }),

    businessTool({
      name: 'strategy_list',
      description: '列出策略（可按分析师、状态、代码过滤）。只返回摘要行，适合在对话里汇总。',
      parameters: {
        type: 'object',
        properties: {
          analyst_id: PARAM.analystId,
          status: { type: 'string', enum: ['DRAFT', 'ACTIVE', 'COMPLETED', 'STOPPED', 'EXPIRED', 'CANCELLED'] },
          ticker: PARAM.ticker,
          limit: PARAM.limit,
          actor: PARAM.actor,
        },
        additionalProperties: false,
      },
      async execute(args) {
        return (await service.listStrategies(args))
      },
    }),

    businessTool({
      name: 'strategy_freeze',
      description: '冻结一条 DRAFT 策略（DRAFT → ACTIVE）。冻结后核心决策字段不可再修改，重复冻结会失败。',
      parameters: { type: 'object', properties: { strategy_id: PARAM.strategyId, actor: PARAM.actor }, required: ['strategy_id'], additionalProperties: false },
      async execute(args, exec) {
        const strategy = (await service.freezeStrategy(args.strategy_id, { actor: args.actor, sessionId: exec?.sessionId }))
        return { strategy_id: strategy.strategy_id, status: strategy.status, frozen: strategy.frozen, frozen_at: strategy.frozen_at }
      },
    }),

    businessTool({
      name: 'strategy_cancel',
      description: '取消一条尚未结束的策略（→ CANCELLED）。已完成/已止损/已过期的策略不能被取消。',
      parameters: {
        type: 'object',
        properties: { strategy_id: PARAM.strategyId, reason: { type: 'string' }, actor: PARAM.actor },
        required: ['strategy_id'],
        additionalProperties: false,
      },
      async execute(args, exec) {
        const strategy = (await service.cancelStrategy(args.strategy_id, { actor: args.actor, reason: args.reason, sessionId: exec?.sessionId }))
        return { strategy_id: strategy.strategy_id, status: strategy.status, cancelled_at: strategy.cancelled_at }
      },
    }),

    businessTool({
      name: 'strategy_status',
      description: '读取策略的生命周期状态：冻结状态、持仓交易日数、浮动收益、是否已达目标/触发止损。',
      parameters: { type: 'object', properties: { strategy_id: PARAM.strategyId, actor: PARAM.actor }, required: ['strategy_id'], additionalProperties: false },
      async execute(args) {
        return (await service.getStatus(args.strategy_id, { actor: args.actor }))
      },
    }),
  ]

  return registerTools(ctx, tools)
}
