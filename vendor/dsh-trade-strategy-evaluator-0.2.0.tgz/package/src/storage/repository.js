/**
 * Repository —— 持久化层。
 *
 * 设计取舍：实施方案 §28 建议 SQLite。宿主 Node 24 提供内置 `node:sqlite`，
 * 但 Electron / 不同运行时的可用性无法穷尽验证，因此这里做**双驱动**：
 *   - `sqlite`：`node:sqlite` 的 DatabaseSync（默认优先）
 *   - `json`  ：原子写的 JSON 文档（回退，零依赖，行为与 sqlite 驱动完全一致）
 * `auto` 会尝试 sqlite，失败则透明回退，并在 `driver` 上报真实选择。
 *
 * 两个驱动实现同一个接口，业务层与测试都只依赖接口，因此切换驱动不改变任何行为。
 * 所有写入都是原子的（sqlite 事务 / JSON 临时文件 rename）。
 */

import { mkdirSync, readFileSync, renameSync, writeFileSync, existsSync, rmSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { CODES, TradeEvalError } from '../core/errors.js'
import { assertCoreImmutable } from '../core/monitor/immutability.js'

/** 领域集合名 —— 一个 Strategy 一条记录，一个 Evaluation 一条记录。 */
export const COLLECTIONS = ['strategies', 'evaluations', 'reports', 'events', 'analysts', 'portfolio_snapshots']

const SNAPSHOT_VERSION = 1

function emptyState() {
  return {
    version: SNAPSHOT_VERSION,
    counters: {},
    meta: { clock: null },
    collections: Object.fromEntries(COLLECTIONS.map((name) => [name, []])),
  }
}

function clone(value) {
  return structuredClone(value)
}

/** JSON 驱动：整份状态一个文件，写入用 `写临时文件 + rename` 保证原子性。 */
class JsonDriver {
  constructor(path) {
    this.path = path
    this.state = existsSync(path) ? JSON.parse(readFileSync(path, 'utf8')) : emptyState()
    this.#normalize()
  }

  get name() {
    return 'json'
  }

  #normalize() {
    if (typeof this.state !== 'object' || this.state === null) this.state = emptyState()
    if (this.state.version !== SNAPSHOT_VERSION) this.state = { ...emptyState(), ...this.state, version: SNAPSHOT_VERSION }
    this.state.counters ??= {}
    this.state.meta ??= { clock: null }
    this.state.collections ??= {}
    for (const name of COLLECTIONS) this.state.collections[name] ??= []
  }

  #change(mutator) {
    const previous = this.state
    this.state = clone(previous)
    try { const result = mutator(); this.#flush(); return result }
    catch (error) { this.state = previous; throw error }
  }

  #flush() {
    mkdirSync(dirname(this.path), { recursive: true })
    const tmp = `${this.path}.tmp-${process.pid}`
    writeFileSync(tmp, JSON.stringify(this.state, null, 2), 'utf8')
    renameSync(tmp, this.path)
  }

  list(collection) {
    return clone(this.state.collections[collection] ?? [])
  }

  put(collection, key, record) {
    return this.#change(() => {
    const rows = this.state.collections[collection] ??= []
    const index = rows.findIndex((row) => row[this.keyField(collection)] === key)
    if (index >= 0) rows[index] = clone(record)
    else rows.push(clone(record))
    return clone(record)
    })
  }

  keyField(collection) {
    return KEY_FIELDS[collection]
  }

  delete(collection, key) {
    return this.#change(() => {
    const rows = this.state.collections[collection] ?? []
    const next = rows.filter((row) => row[this.keyField(collection)] !== key)
    const removed = next.length !== rows.length
    this.state.collections[collection] = next
    return removed
    })
  }

  readMeta(key) {
    return clone(this.state.meta[key] ?? null)
  }

  writeMeta(key, value) {
    return this.#change(() => {
      this.state.meta[key] = clone(value)
      return clone(value)
    })
  }

  nextSequence(kind, dayKey) {
    return this.#change(() => {
    const key = `${kind}:${dayKey}`
    const next = (this.state.counters[key] ?? 0) + 1
    this.state.counters[key] = next
    return next
    })
  }

  reset() {
    this.#change(() => { this.state = emptyState() })
  }

  stats() {
    return {
      driver: 'json',
      path: this.path,
      counts: Object.fromEntries(COLLECTIONS.map((name) => [name, (this.state.collections[name] ?? []).length])),
    }
  }
}

export const KEY_FIELDS = {
  strategies: 'strategy_id',
  // 组合快照按 (分析师, 交易日) 唯一：同一天重复读取是 upsert 而不是追加，
  // 指令指纹不同时才覆盖（见 service 的 getPortfolio）。
  portfolio_snapshots: 'snapshot_id',
  evaluations: 'evaluation_id',
  reports: 'report_id',
  events: 'event_id',
  analysts: 'analyst_id',
}

/**
 * SQLite 驱动。用 JSON 列保存记录体，用主键列保证唯一性与可查询性。
 * 记录体本身仍是文档形式 —— POC 不需要关系建模，但保留了事务与索引能力。
 */
class SqliteDriver {
  constructor(path, DatabaseSync) {
    mkdirSync(dirname(path), { recursive: true })
    this.path = path
    this.db = new DatabaseSync(path)
    this.db.exec('PRAGMA journal_mode = WAL')
    this.db.exec('PRAGMA foreign_keys = ON')
    for (const collection of COLLECTIONS) {
      const keyField = KEY_FIELDS[collection]
      this.db.exec(`CREATE TABLE IF NOT EXISTS ${collection} (key TEXT PRIMARY KEY, body TEXT NOT NULL, updated_at TEXT NOT NULL)`)
      void keyField
    }
    this.db.exec('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, body TEXT NOT NULL)')
    this.db.exec('CREATE TABLE IF NOT EXISTS counters (key TEXT PRIMARY KEY, value INTEGER NOT NULL)')
  }

  get name() {
    return 'sqlite'
  }

  list(collection) {
    return this.db.prepare(`SELECT body FROM ${collection} ORDER BY rowid`).all().map((row) => JSON.parse(row.body))
  }

  put(collection, key, record) {
    this.db
      .prepare(`INSERT INTO ${collection} (key, body, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET body = excluded.body, updated_at = excluded.updated_at`)
      .run(key, JSON.stringify(record), new Date().toISOString())
    return clone(record)
  }

  delete(collection, key) {
    const result = this.db.prepare(`DELETE FROM ${collection} WHERE key = ?`).run(key)
    return result.changes > 0
  }

  readMeta(key) {
    const row = this.db.prepare('SELECT body FROM meta WHERE key = ?').get(key)
    return row === undefined ? null : JSON.parse(row.body)
  }

  writeMeta(key, value) {
    this.db
      .prepare('INSERT INTO meta (key, body) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET body = excluded.body')
      .run(key, JSON.stringify(value))
    return clone(value)
  }

  nextSequence(kind, dayKey) {
    const key = `${kind}:${dayKey}`
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const row = this.db.prepare('SELECT value FROM counters WHERE key = ?').get(key)
      const next = (row?.value ?? 0) + 1
      this.db
        .prepare('INSERT INTO counters (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
        .run(key, next)
      this.db.exec('COMMIT')
      return next
    } catch (error) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  reset() {
    for (const collection of COLLECTIONS) this.db.exec(`DELETE FROM ${collection}`)
    this.db.exec('DELETE FROM meta')
    this.db.exec('DELETE FROM counters')
  }

  /** 幂等关闭：重复调用不会抛 "database is not open"。 */
  close() {
    if (this.closed === true) return
    this.closed = true
    this.db.close()
  }

  stats() {
    return {
      driver: 'sqlite',
      path: this.path,
      counts: Object.fromEntries(
        COLLECTIONS.map((name) => [name, this.db.prepare(`SELECT COUNT(*) AS n FROM ${name}`).get().n]),
      ),
    }
  }
}

/** 尝试装载 node:sqlite；失败返回 undefined（不抛错，交给 auto 回退）。 */
async function tryLoadSqlite() {
  try {
    const mod = await import('node:sqlite')
    return typeof mod.DatabaseSync === 'function' ? mod.DatabaseSync : undefined
  } catch {
    return undefined
  }
}

/**
 * 创建 Repository。
 * @param {{ dataDir: string, driver?: 'auto'|'sqlite'|'json' }} options
 */
export async function createRepository({ dataDir, driver = 'auto' }) {
  if (typeof dataDir !== 'string' || dataDir.length === 0) throw new TradeEvalError(CODES.STORAGE, 'dataDir is required')
  mkdirSync(dataDir, { recursive: true })

  const lock = join(dataDir, '.osanalyst-writer')
  try { mkdirSync(lock) } catch { throw new TradeEvalError(CODES.CONFLICT, 'local database already has a writer; stop it before opening another host') }
  const release = () => rmSync(lock, { recursive: true, force: true })
  try {
  let impl
  let fallbackReason
  if (driver === 'json') {
    impl = new JsonDriver(join(dataDir, 'trade-eval.json'))
  } else {
    const DatabaseSync = await tryLoadSqlite()
    if (DatabaseSync !== undefined) {
      try {
        impl = new SqliteDriver(join(dataDir, 'trade-eval.sqlite'), DatabaseSync)
      } catch (error) {
        if (driver === 'sqlite') throw new TradeEvalError(CODES.STORAGE, `sqlite driver failed: ${error.message}`)
        fallbackReason = error.message
      }
    } else if (driver === 'sqlite') {
      throw new TradeEvalError(CODES.STORAGE, 'node:sqlite is unavailable in this runtime')
    } else {
      fallbackReason = 'node:sqlite is unavailable in this runtime'
    }
    impl ??= new JsonDriver(join(dataDir, 'trade-eval.json'))
  }

  return new Repository(impl, { requestedDriver: driver, fallbackReason, release })
  } catch (error) { release(); throw error }
}

/** 业务层唯一入口：集合读写 + 元数据 + 序号分配，全部经审计事件旁路由 Service 负责。 */
export class Repository {
  constructor(impl, info = {}) {
    this.impl = impl
    this.release = info.release
    this.requestedDriver = info.requestedDriver ?? 'auto'
    this.fallbackReason = info.fallbackReason
  }

  #assertOpen() {
    if (this.closed) throw new TradeEvalError(CODES.STORAGE, 'repository is closed')
  }

  get driver() {
    return this.impl.name
  }

  async list(collection) {
    this.#assertOpen()
    assertCollection(collection)
    return this.impl.list(collection)
  }

  async get(collection, key) {
    this.#assertOpen()
    assertCollection(collection)
    const keyField = KEY_FIELDS[collection]
    return this.impl.list(collection).find((row) => row[keyField] === key) ?? null
  }

  async put(collection, record, options = {}) {
    this.#assertOpen()
    assertCollection(collection)
    const keyField = KEY_FIELDS[collection]
    const key = record?.[keyField]
    if (typeof key !== 'string' || key.length === 0) {
      throw new TradeEvalError(CODES.STORAGE, `record is missing ${keyField}`)
    }
    // 不可篡改守卫装在**写库路径**上，而不是只装在 Service 里。
    //
    // `immutability.js` 的文件头写着"即使未来有人绕过 Service 写库，也会在写库前失败" ——
    // 但守卫原先只在 Service 侧调用，直接 `repository.put('strategies', ...)` 是能改掉
    // 已冻结策略的核心字段的（测试实测证实）。把守卫下沉到这里，那句声明才成立。
    // 代价只是一次约 17 个字段的深比较，相对"冻结不可篡改"这条第一不变量可以忽略。
    if (collection === 'strategies') {
      const existing = this.impl.list(collection).find((row) => row[keyField] === key)
      if (existing !== undefined) assertCoreImmutable(existing, record)
    }
    if (options.expectedRevision !== undefined) {
      const old = this.impl.list(collection).find(row => row[keyField] === key)
      if (!Number.isSafeInteger(options.expectedRevision) || options.expectedRevision < 0 || (old?.revision ?? 0) !== options.expectedRevision) {
        throw new TradeEvalError(CODES.CONFLICT, 'local revision conflict')
      }
      record = { ...record, revision: options.expectedRevision + 1 }
    }
    return this.impl.put(collection, key, record)
  }

  async delete(collection, key) {
    this.#assertOpen()
    assertCollection(collection)
    return this.impl.delete(collection, key)
  }

  async readMeta(key) {
    this.#assertOpen()
    return this.impl.readMeta(key)
  }

  async writeMeta(key, value) {
    this.#assertOpen()
    return this.impl.writeMeta(key, value)
  }

  async nextSequence(kind, dayKey) {
    this.#assertOpen()
    return this.impl.nextSequence(kind, dayKey)
  }

  async reset() {
    this.#assertOpen()
    this.impl.reset()
  }

  async close() {
    if (this.closed) return
    this.closed = true
    try { this.impl.close?.() } finally { this.release?.() }
  }

  async appendEvent(event) {
    this.#assertOpen()
    const sequence = this.impl.list('events').reduce((max,row) => Math.max(max,row.sequence),0) + 1
    const record = { ...event, event_id: `EVT-${String(sequence).padStart(6,'0')}`, sequence }
    return this.impl.put('events',record.event_id,record)
  }

  async stats() {
    this.#assertOpen()
    return { ...this.impl.stats(), requestedDriver: this.requestedDriver, fallbackReason: this.fallbackReason ?? null }
  }
}

function assertCollection(collection) {
  if (!COLLECTIONS.includes(collection)) {
    throw new TradeEvalError(CODES.STORAGE, `unknown collection "${collection}"`, { known: COLLECTIONS })
  }
}

export { JsonDriver, SqliteDriver }
