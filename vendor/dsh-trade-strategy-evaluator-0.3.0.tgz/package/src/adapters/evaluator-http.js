import { digest, canonical, parseStrict, InputError, requireInput } from '../engine/canonical.js'
import { exactKeys, validateSchema } from '../engine/schema.js'
import observationSchema from '../engine/observation-schema.js'
import { evaluateObservation, ENGINE_VERSION, ENGINE_VERSION_V2 } from '../engine/observation.js'
import observationSchemaV2 from '../engine/observation-schema-v2.js'
import { OBSERVATION_V2, SNAPSHOT_V1, SNAPSHOT_V2 } from '../engine/policy.js'
export const RPC_VERSION = 'evaluator-rpc/1.0'
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/
const SHA = /^[0-9a-f]{64}$/
const CODES = new Set(['not_authenticated','scope_denied','policy_blocked','not_found','revision_conflict','idempotency_conflict','invalid_schema','future_input','invalid_timeline','hash_mismatch','data_insufficient','rule_unsupported','source_unavailable','not_configured','input_limit','unsupported_version','internal_error','anchor_integrity_failed','exposure_required','source_version_conflict','observation_scope_conflict','fixture_not_operational','security_unresolved'])
export class EvaluationStoreError extends Error {
  constructor(code,status=0,retryable=false) { super(code); this.name='EvaluationStoreError'; this.code=code; this.status=status; this.retryable=retryable }
}
export function validateCommit(body) {
  if (body && ['owner_scope','subject','scopes','purpose'].some(k=>Object.hasOwn(body,k))) throw new EvaluationStoreError('scope_denied',403)
  exactKeys(body,['schema_version','observation_ref','market_snapshot_refs','engine_version','rule_version','input_sha256','input','result','result_sha256','expected_revision','idempotency_key','request_key'])
  requireInput(body.schema_version===RPC_VERSION,'unsupported_version')
  exactKeys(body.observation_ref,['id','sha256'])
  requireInput(UUID.test(body.observation_ref.id) && SHA.test(body.observation_ref.sha256))
  requireInput(Number.isSafeInteger(body.expected_revision) && body.expected_revision>=0 && typeof body.idempotency_key==='string' && /^[A-Za-z0-9._:-]{1,128}$/.test(body.idempotency_key) && body.request_key===body.idempotency_key)
  // Each contract generation reports its own engine version; the body must name the one the kernel actually applies.
  requireInput([ENGINE_VERSION,ENGINE_VERSION_V2].includes(body.engine_version),'unsupported_version')
  const computed=evaluateObservation(body.input)
  requireInput(computed.ok,computed.error?.code??'invalid_schema',computed.error?.reason??'invalid_result')
  requireInput(computed.result.engine_version===body.engine_version,'unsupported_version')
  requireInput(body.observation_ref.id===body.input.observation.id && body.observation_ref.sha256===body.input.observation_sha256 && body.input_sha256===body.input.input_sha256 && body.rule_version===body.input.observation.market_policy_version,'hash_mismatch')
  requireInput(digest(body.result)===body.result_sha256 && computed.result_sha256===body.result_sha256,'hash_mismatch')
  requireInput(digest(body.market_snapshot_refs)===digest(body.input.market_snapshots.map((m,i)=>({id:m.id,sha256:body.input.market_snapshot_sha256s[i]}))),'hash_mismatch')
  return computed
}
export function createEvaluationHttpClient({baseUrl,tokenProvider,ownerScope,timeoutMs=5000,maxResponseBytes=2_000_000,fetchImpl=globalThis.fetch}={}) {
  let base
  if (baseUrl) {
    try {
      base=new URL(baseUrl)
      if (base.username||base.password||base.search||base.hash||base.pathname!=='/'||!(['https:'].includes(base.protocol)||(base.protocol==='http:'&&['127.0.0.1','localhost','[::1]'].includes(base.hostname)))) throw Error()
    }catch{throw new EvaluationStoreError('invalid_configuration')}
  }
  requireInput(Number.isInteger(timeoutMs)&&timeoutMs>0&&timeoutMs<=60000 && Number.isInteger(maxResponseBytes)&&maxResponseBytes>0&&maxResponseBytes<=10_000_000)
  const scope=ownerScope?structuredClone(ownerScope):null
  if(scope){exactKeys(scope,['user_id','workspace_id']);requireInput(UUID.test(scope.user_id)&&scope.workspace_id===null)}
  async function request(path,purpose,body) {
    if(!base||!scope||typeof tokenProvider!=='function')throw new EvaluationStoreError('not_configured',503)
    const controller=new AbortController();let timer
    const task=(async()=>{
      const token=await tokenProvider({audience:'alpha-evaluator',purpose,signal:controller.signal})
      if(controller.signal.aborted)throw new EvaluationStoreError('timeout',0,true)
      if(typeof token!=='string'||token.length<1||token.length>4096||/[\r\n]/.test(token))throw new EvaluationStoreError('not_authenticated',401)
      const response=await fetchImpl(new URL(path,base),{method:body?'POST':'GET',redirect:'error',signal:controller.signal,headers:{authorization:`Bearer ${token}`,accept:'application/json','x-evaluator-protocol':RPC_VERSION,...(body?{'content-type':'application/json','idempotency-key':body.idempotency_key}:{})},...(body?{body:canonical(body)}:{})})
      if(!response.headers.get('content-type')?.includes('application/json'))throw new EvaluationStoreError('invalid_response',502)
      const chunks=[];let size=0
      if(!response.body)throw new EvaluationStoreError('invalid_response',502)
      for await(const chunk of response.body){size+=chunk.byteLength;if(size>maxResponseBytes){controller.abort();throw new EvaluationStoreError('input_limit',413)}chunks.push(chunk)}
      const data=parseStrict(new TextDecoder('utf-8',{fatal:true}).decode(Buffer.concat(chunks)),maxResponseBytes)
      if(!response.ok)throw new EvaluationStoreError(CODES.has(data.error?.code)?data.error.code:'internal_error',response.status,response.status>=500)
      requireInput(data.schema_version===RPC_VERSION,'unsupported_version')
      if(digest(data.owner_scope)!==digest(scope))throw new EvaluationStoreError('scope_denied',403)
      return data
    })()
    try{return await Promise.race([task,new Promise((_,reject)=>{timer=setTimeout(()=>{controller.abort();reject(new EvaluationStoreError('timeout',0,true))},timeoutMs)})])}
    catch(e){if(e instanceof EvaluationStoreError)throw e;if(e instanceof InputError)throw new EvaluationStoreError(e.code,422);throw new EvaluationStoreError('provider_unavailable',0,true)}
    finally{clearTimeout(timer)}
  }
  async function read(kind,id) {
    requireInput(typeof id==='string'&&/^[A-Za-z0-9._:-]{1,128}$/.test(id))
    const key=kind==='observations'?'observation':'snapshot',data=await request(`/api/evaluator/v1/${kind}/${encodeURIComponent(id)}`,'observation:read')
    exactKeys(data,['schema_version','owner_scope','revision','sha256',key])
    requireInput(Number.isSafeInteger(data.revision)&&data.revision>=0&&SHA.test(data.sha256)&&digest(data[key])===data.sha256,'hash_mismatch')
    requireInput(data[key].id===id,'hash_mismatch')
    if(key==='observation'){validateSchema(data.observation,data.observation?.schema_version===OBSERVATION_V2?observationSchemaV2:observationSchema);requireInput(digest(data.observation.owner_scope)===digest(scope),'scope_denied')}
    else requireInput([SNAPSHOT_V1,SNAPSHOT_V2].includes(data.snapshot?.schema_version),'unsupported_version')
    return data
  }
  return Object.freeze({
    readObservation:id=>read('observations',id),
    readMarketSnapshot:id=>read('market-snapshots',id),
    async commitEvaluationResult(body){
      if(!base||!scope||typeof tokenProvider!=='function')throw new EvaluationStoreError('not_configured',503)
      validateCommit(body)
      requireInput(scope && digest(body.input.observation.owner_scope)===digest(scope),'scope_denied')
      const data=await request('/api/evaluator/v1/evaluation-results','evaluation:append',body)
      exactKeys(data,['schema_version','owner_scope','status','observation_ref','revision','idempotency_key','input_sha256','result_sha256','evaluation_ref'])
      requireInput(['accepted','duplicate'].includes(data.status)&&data.observation_ref===body.observation_ref.id&&data.revision===body.expected_revision+1&&data.idempotency_key===body.idempotency_key&&data.input_sha256===body.input_sha256&&data.result_sha256===body.result_sha256&&typeof data.evaluation_ref==='string'&&data.evaluation_ref.length>0,'hash_mismatch','invalid_receipt')
      return data
    }
  })
}
