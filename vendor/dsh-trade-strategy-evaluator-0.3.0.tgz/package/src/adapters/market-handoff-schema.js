// alpha-market-handoff/1.0 structure (mirror of Alpha docs/handoffs/alpha-s6/market-interface/schema.json), expressed in
// the finite JSON Schema vocabulary the engine validator understands. Numeric bounds are enforced in code.
const text={type:'string',minLength:1,maxLength:500}
const id={type:'string',pattern:'^[A-Za-z0-9][A-Za-z0-9._:-]{0,95}$'}
const date={type:'string',pattern:'^\\d{4}-\\d{2}-\\d{2}$'}
const timestamp={type:'string',pattern:'^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z$'}
const number={type:'number'}
const object=properties=>({type:'object',additionalProperties:false,required:Object.keys(properties),properties})
const array=(items,maxItems=2000)=>({type:'array',items,maxItems})
export default object({
  schema_version:{const:'alpha-market-handoff/1.0'},synthetic:{type:'boolean'},
  provider:object({name:id,version:id}),
  security:object({ticker:{type:'string',pattern:'^[A-Z][A-Z0-9.]{0,15}$'},listing_mic:{type:'string',pattern:'^[A-Z0-9]{4}$'},currency:{const:'USD'},identity_ref:id}),
  calendar_version:text,interval:{const:'1d'},adjustment:{const:'raw'},includes_cash_dividends:{const:false},
  observed_at:timestamp,range:object({from:date,to:date}),
  splits:object({basis_date:date,coverage:object({from:date,to:date,complete:{type:'boolean'},evidence_ref:id}),events:array(object({effective_date:date,new_shares:{type:'integer'},old_shares:{type:'integer'},evidence_ref:id}))}),
  bars:array(object({session_date:date,open:number,high:number,low:number,close:number,volume:number,split_factor:number,available_at:timestamp,price_ref:id,split_ref:id,availability_ref:id})),
  unavailable_sessions:array(object({session_date:date,status:{enum:['suspended','no_valid_close']},available_at:timestamp,evidence_ref:id})),
  evidence:array(object({id,kind:{enum:['prices','splits','identity','availability','session_status']},source_url:text,received_at:timestamp,media_type:{enum:['application/json','text/plain','text/html','text/csv']},content:{type:'string',minLength:1,maxLength:1000000},sha256:{type:'string',pattern:'^[a-f0-9]{64}$'}}),100),
})
