import schema from './market-handoff-schema.js'
import { validateSchema } from '../engine/schema.js'
import { parseStrict, bytesDigest, timestamp, requireInput, InputError } from '../engine/canonical.js'
import { validateMarketSnapshot } from '../engine/observation.js'
import { SNAPSHOT_V2 } from '../engine/policy.js'
export const MARKET_HANDOFF_ADAPTER_VERSION = 'market-handoff-adapter/1.0'
const day = d => { requireInput(typeof d === 'string' && Number.isFinite(Date.parse(d)) && new Date(d).toISOString().slice(0,10) === d); return d }
const positive = v => Number.isFinite(v) && v > 0
/**
 * alpha-market-handoff/1.0 bundle (one leg: target or benchmark) → market-snapshot/2.0.
 * Provider claims are never trusted: evidence hashes are recomputed, split factors are
 * recomputed from the events, every session in range needs a bar or verified unavailable
 * status, and the security identity must be covered by an operator attestation for the
 * exact identity document carried in the bundle. `security` (optional) is the trusted
 * registered identity from the observation: it must agree with the bundle and supplies
 * `company_entity_id` (the benchmark stays entity-less). Availability is conservative local
 * retrieval (bar available_at ≥ session close and ≥ split evidence receipt). Never throws.
 */
export function mapMarketHandoff({raw,calendar,attestations,policy,id,as_of,security}) {
  try {
    const p = parseStrict(raw)
    validateSchema(p,schema)
    requireInput(typeof id === 'string' && id.length > 0 && id.length <= 500)
    requireInput(p.calendar_version === calendar.version,'data_insufficient','market_mismatch')
    const observed = timestamp(p.observed_at)
    requireInput(observed <= timestamp(as_of),'future_input')
    requireInput(day(p.range.from) <= day(p.range.to))
    const sessions = calendar.sessions.filter(s => s.date >= p.range.from && s.date <= p.range.to)
    requireInput(p.range.from >= calendar.range[0] && p.range.to <= calendar.range[1] && sessions.length > 0,'data_insufficient','rule_unsupported')
    requireInput(sessions.every(s => timestamp(s.close) <= observed),'future_input')
    // Splits: coverage must span the whole range and be complete; basis is the range end.
    requireInput(day(p.splits.basis_date) === p.range.to)
    requireInput(day(p.splits.coverage.from) <= p.range.from && day(p.splits.coverage.to) >= p.range.to,'invalid_schema','split_coverage_range')
    requireInput(p.splits.coverage.complete === true,'data_insufficient','missing_split_factors')
    // Evidence: unique ids, hash of the UTF-8 content, received before observation, plain URLs.
    const evidence = new Map()
    for (const e of p.evidence) {
      requireInput(!evidence.has(e.id))
      requireInput(bytesDigest(e.content) === e.sha256,'hash_mismatch')
      requireInput(timestamp(e.received_at) <= observed,'future_input')
      let u; try { u = new URL(e.source_url) } catch { requireInput(false) }
      requireInput(!u.username && !u.password && !u.search && !u.hash && (u.protocol === 'https:' || (p.synthetic && u.protocol === 'synthetic:')))
      evidence.set(e.id,e)
    }
    const reference = (ref,kind,available) => {
      const e = evidence.get(ref); requireInput(e && e.kind === kind,'data_insufficient','missing_evidence')
      if (available !== undefined) requireInput(timestamp(available) >= timestamp(e.received_at),'invalid_timeline')
      return e
    }
    // Identity: the operator attested exactly this identity document for this ticker/venue/currency.
    const identity = reference(p.security.identity_ref,'identity')
    requireInput(Array.isArray(attestations) && attestations.length <= 10000)
    const attested = attestations.some(a => a && typeof a === 'object' && a.ticker === p.security.ticker && a.listing_mic === p.security.listing_mic && a.currency === p.security.currency && a.synthetic === p.synthetic && a.identity_evidence_sha256 === identity.sha256 && typeof a.attested_by === 'string' && a.attested_by.length > 0 && Number.isFinite(Date.parse(a.attested_at ?? '')))
    requireInput(attested,'data_insufficient','identity_unattested')
    const isBenchmark = p.security.ticker === policy.benchmark.ticker
    requireInput(isBenchmark ? p.security.listing_mic === policy.benchmark.listing_mic && p.security.currency === policy.benchmark.currency : policy.target_listing_mics.includes(p.security.listing_mic),'data_insufficient','market_mismatch')
    // Split events: ordered, inside coverage, real ratio changes, evidenced.
    let splitReceivedAt = timestamp(reference(p.splits.coverage.evidence_ref,'splits').received_at), previous = ''
    for (const event of p.splits.events) {
      requireInput(day(event.effective_date) > previous && event.effective_date >= p.splits.coverage.from && event.effective_date <= p.splits.coverage.to); previous = event.effective_date
      requireInput(event.old_shares >= 1 && event.new_shares >= 1 && event.old_shares <= 1e9 && event.new_shares <= 1e9 && event.old_shares !== event.new_shares)
      const received = timestamp(reference(event.evidence_ref,'splits').received_at)
      if (event.effective_date <= p.splits.basis_date) splitReceivedAt = Math.max(splitReceivedAt,received)
    }
    // Bars: calendar sessions in order, sane OHLC, availability after close and after split evidence, factor = product of later splits.
    const filled = new Set(), bars = []; previous = ''
    for (const b of p.bars) {
      const session = sessions.find(s => s.date === day(b.session_date)); requireInput(session && b.session_date > previous,'invalid_schema','invalid_bars'); previous = b.session_date; filled.add(b.session_date)
      requireInput([b.open,b.high,b.low,b.close,b.split_factor].every(positive) && Number.isFinite(b.volume) && b.volume >= 0 && b.low <= Math.min(b.open,b.close) && b.high >= Math.max(b.open,b.close) && b.low <= b.high,'invalid_schema','invalid_bars')
      requireInput(timestamp(b.available_at) >= timestamp(session.close) && timestamp(b.available_at) <= observed,'invalid_timeline')
      const price = reference(b.price_ref,'prices',b.available_at); requireInput(timestamp(price.received_at) >= timestamp(session.close),'invalid_timeline')
      reference(b.split_ref,'splits',b.available_at); reference(b.availability_ref,'availability',b.available_at)
      requireInput(timestamp(b.available_at) >= splitReceivedAt,'invalid_timeline')
      const factor = p.splits.events.filter(e => e.effective_date > b.session_date && e.effective_date <= p.splits.basis_date).reduce((n,e) => n * e.old_shares / e.new_shares, 1)
      requireInput(positive(factor) && Math.abs(b.split_factor - factor) <= 1e-12 * Math.max(factor,b.split_factor),'invalid_schema','split_factor_mismatch')
      bars.push({session_date:b.session_date,open:b.open,high:b.high,low:b.low,close:b.close,volume:b.volume,split_factor:b.split_factor,split_factor_verified:true,available_at:b.available_at,receipt_ref:`${price.id}:${price.sha256.slice(0,16)}`})
    }
    const session_status = []; previous = ''
    for (const missing of p.unavailable_sessions) {
      const session = sessions.find(s => s.date === day(missing.session_date)); requireInput(session && !filled.has(missing.session_date) && missing.session_date > previous,'invalid_schema','invalid_session_status'); previous = missing.session_date; filled.add(missing.session_date)
      requireInput(timestamp(missing.available_at) >= timestamp(session.close) && timestamp(missing.available_at) <= observed,'invalid_timeline')
      const proof = reference(missing.evidence_ref,'session_status',missing.available_at); requireInput(timestamp(proof.received_at) >= timestamp(session.close),'invalid_timeline')
      session_status.push({session_date:missing.session_date,status:missing.status,verified:true,receipt_ref:`${proof.id}:${proof.sha256.slice(0,16)}`,available_at:missing.available_at})
    }
    requireInput(sessions.every(s => filled.has(s.date)),'data_insufficient','missing_sessions')
    let companyEntityId = null
    if (security !== undefined) {
      requireInput(security && typeof security === 'object' && security.ticker === p.security.ticker && security.listing_mic === p.security.listing_mic && security.currency === p.security.currency && security.synthetic === p.synthetic,'invalid_schema','security_scope')
      requireInput(security.company_entity_id === null || (typeof security.company_entity_id === 'string' && security.company_entity_id.length > 0 && security.company_entity_id.length <= 500),'invalid_schema','security_scope')
      requireInput(!isBenchmark || security.company_entity_id === null,'invalid_schema','security_scope')
      companyEntityId = security.company_entity_id
    }
    const snapshot = {schema_version:SNAPSHOT_V2,id,security:{ticker:p.security.ticker,listing_mic:p.security.listing_mic,currency:p.security.currency,company_entity_id:companyEntityId,synthetic:p.synthetic},
      provider:{name:p.provider.name,version:p.provider.version},adapter_version:MARKET_HANDOFF_ADAPTER_VERSION,request:{from:p.range.from,to:p.range.to,interval:'1d'},
      timezone:'America/New_York',currency:'USD',calendar_version:calendar.version,adjustment:'none_with_verified_split_factors',fetched_at:p.observed_at,available_at:p.observed_at,
      coverage:{from:p.range.from,to:p.range.to,complete:true},fallback:false,warnings:p.synthetic?['synthetic_descriptive_only']:[],raw_sha256:bytesDigest(raw),bars,session_status}
    validateMarketSnapshot(snapshot,calendar,as_of,policy)
    return {ok:true,snapshot}
  } catch (e) { return {ok:false,error:{code:e instanceof InputError?e.code:'invalid_schema',reason:e instanceof InputError?e.reason:'invalid_handoff'}} }
}
