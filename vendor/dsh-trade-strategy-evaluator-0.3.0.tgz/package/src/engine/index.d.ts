export type Hash = string;
export interface Security {ticker:string;exchange:'XNYS';currency:'USD';company_entity_id:string|null;synthetic:boolean}
/** market-policy/2.0 (E3a): identity is the listing MIC; the session calendar is separate. */
export interface SecurityV2 {ticker:string;listing_mic:string;currency:'USD';company_entity_id:string|null;synthetic:boolean}
export interface BenchmarkV2 {ticker:'SPY';listing_mic:'ARCX';currency:'USD'}
export interface Session {date:string;open:string;close:string;full:boolean}
export interface FrozenCalendar {version:string;source:string;range:[string,string];sessions:Session[]}
export interface Observation {
 schema_version:'alpha-observation-contract/1.0';id:string;owner_scope:{user_id:string;workspace_id:null};
 decision_or_candidate_ref:string;candidate_ref:string;thesis_revision_ref:string|null;input_snapshot_ref:string;input_snapshot_hash:Hash;
 record_origin:'forward';research_stream:'descriptive';contamination_reasons:string[];actor_kind:'agent'|'human';synthetic:boolean;
 observation_kind:string;securities:Security[];frozen_at:string;recorded_at:string;eligibility_at:string;start_rule:string;
 start_plan:{intendedStart:Session;fallbackCandidates:Session[];waitExpiresAt:string;marketPolicyHash:Hash;calendarHash:Hash};
 actual_start_at:null;windows:{trading_sessions:number;starts_at:null;ends_at:null;result:null}[];benchmarks:string[];
 currency_basis:'USD';return_method:string;market_policy_version:string;market_policy_hash:Hash;market_policy:Record<string,unknown>;
 calendar_version:string;calendar_hash:Hash;status:'pending_start';predecessor_id:string|null;anchor_status:string;provenance_level:string;
}
export type ObservationV2 = Omit<Observation,'schema_version'|'securities'|'benchmarks'|'market_policy_version'> & {
 schema_version:'alpha-observation-contract/2.0';securities:SecurityV2[];benchmarks:BenchmarkV2[];market_policy_version:'market-policy/2.0';
};
export interface FrozenBar {session_date:string;open:number;high:number;low:number;close:number;volume:number;split_factor:number;split_factor_verified:true;available_at:string;receipt_ref:string}
export interface MarketSnapshot {
 schema_version:'market-snapshot/1.0';id:string;security:Security;provider:{name:string;version:string};adapter_version:string;
 request:{from:string;to:string;interval:'1d'};timezone:'America/New_York';currency:'USD';calendar_version:string;
 adjustment:'none_with_verified_split_factors';fetched_at:string;available_at:string;coverage:{from:string;to:string;complete:boolean};
 fallback:false;warnings:string[];raw_sha256:Hash;bars:FrozenBar[];
 session_status:{session_date:string;status:'suspended'|'no_valid_close';verified:true;receipt_ref:string;available_at:string}[];
}
export type MarketSnapshotV2 = Omit<MarketSnapshot,'schema_version'|'security'> & {schema_version:'market-snapshot/2.0';security:SecurityV2};
export interface InformationSet {snapshot_ref:string;snapshot_sha256:Hash;input_cutoff_at:string;versions:{ref:string;sha256:Hash;available_at:string}[]}
export interface EvaluationInput {
 schema_version:'evaluator-input-output/1.0';observation:Observation|ObservationV2;observation_sha256:Hash;calendar:FrozenCalendar;
 market_snapshots:(MarketSnapshot|MarketSnapshotV2)[];market_snapshot_sha256s:Hash[];information_set:InformationSet;as_of:string;input_sha256:Hash;
}
export type WindowStatus='pending_start'|'open'|'resolved'|'data_insufficient';
export interface WindowResult {price_return:number;benchmark_price_return:number;benchmark_difference:number;max_drawdown:number;benchmark:'SPY';currency:'USD';/** present for market-policy/2.0 results */benchmark_listing_mic?:'ARCX'}
export interface EvaluationResult {
 schema_version:'evaluator-input-output/1.0';engine_version:string;rule_version:string;observation_ref:string;observation_sha256:Hash;
 input_sha256:Hash;market_snapshot_refs:{id:string;sha256:Hash;adapter_version:string}[];market_policy_hash:Hash;calendar_hash:Hash;
 computed_at:string;record_origin:'forward';research_stream:'descriptive';synthetic:boolean;contamination_reasons:string[];
 anchor_status:string;provenance_level:string;security:Security|SecurityV2;input_snapshot_ref:string;input_snapshot_hash:Hash;return_method:string;
 portfolio_return:null;status:WindowStatus;reason:string|null;actual_start_at:string|null;
 windows:{trading_sessions:number;starts_at:string|null;ends_at:string|null;status:WindowStatus;reason:string|null;result:WindowResult|null}[];
}
export type EvaluationOutcome = {ok:true;result:EvaluationResult;result_sha256:Hash}|{ok:false;error:{code:string;reason:string}};
export declare function evaluateObservation(input:EvaluationInput):EvaluationOutcome;
export declare function replayObservation(input:EvaluationInput,stored:EvaluationOutcome):{matches:boolean;computed:EvaluationOutcome};
export declare function inputDigest(input:EvaluationInput):Hash;
export declare function digest(input:unknown):Hash;
export declare function canonical(input:unknown):string;
export declare function parseStrict(text:string,maxBytes?:number):unknown;
export declare function bytesDigest(bytes:string|Uint8Array):Hash;
export declare function timestamp(value:string):number;
export declare function validateObservation(observation:Observation|ObservationV2,calendar:FrozenCalendar):Observation|ObservationV2;
export declare function validateMarketSnapshot(snapshot:MarketSnapshot|MarketSnapshotV2,calendar:FrozenCalendar,asOf:string,policy?:Record<string,unknown>):unknown;
export declare function planSessions(observation:Observation|ObservationV2,calendar:FrozenCalendar):Observation['start_plan'];
export declare const ENGINE_VERSION:'osanalyst-engine/1.0.0';
export declare const ENGINE_VERSION_V2:'osanalyst-engine/1.1.0';
export declare const POLICY_HASH:Hash; export declare const POLICY_V2_HASH:Hash; export declare const CALENDAR_HASH:Hash;
export declare const OBSERVATION_V1:'alpha-observation-contract/1.0'; export declare const OBSERVATION_V2:'alpha-observation-contract/2.0';
export declare const SNAPSHOT_V1:'market-snapshot/1.0'; export declare const SNAPSHOT_V2:'market-snapshot/2.0';
export declare const POLICY_V1:'market-policy/1.0'; export declare const POLICY_V2:'market-policy/2.0';
export declare const IO_VERSION:'evaluator-input-output/1.0';
export declare function evaluateStrategyBars(input:Record<string,unknown>):Record<string,unknown>;
export declare function deriveStatusFromPerformance(input:Record<string,unknown>):string;
export declare function scoreEvaluation(input:Record<string,unknown>,rules:Record<string,unknown>):Record<string,unknown>;
export declare function roundTo(value:number,decimals:number):number;
export declare function computeReturn(input:{action?:'BUY'|'SELL';entryPrice:number;exitPrice:number;decimals?:number}):number;
export declare function computePnl(input:{action?:'BUY'|'SELL';entryPrice:number;exitPrice:number;quantity?:number;decimals?:number}):number;
export declare function computeBenchmarkReturn(input:{benchmarkEntry:number;benchmarkExit:number;decimals?:number}):number;
export declare function computeAlpha(input:{strategyReturn:number;benchmarkReturn:number;decimals?:number}):number;
export declare function computeMaxDrawdown(input:{prices:number[];decimals?:number}):number;
export declare function computeVolatility(input:{prices:number[];decimals?:number;annualize?:number}):number;
export declare function detectTarget(input:{action?:'BUY'|'SELL';prices:number[];targetPrice:number;decimals?:number}):{reached:boolean;reachedAt:number|null;reachedPrice:number|null;distance:number|null};
export declare function detectStopLoss(input:{action?:'BUY'|'SELL';prices:number[];stopLoss:number;decimals?:number}):{triggered:boolean;triggeredAt:number|null;triggeredPrice:number|null;distance:number|null};
export declare function computeRiskReward(input:{action?:'BUY'|'SELL';entryPrice:number;targetPrice:number;stopLoss:number;decimals?:number}):{ratio:number;reward:number;risk:number};
export declare function computeHoldingDays(input:{entryDate:string;exitDate:string;tradingDays?:string[]}):number|null;
