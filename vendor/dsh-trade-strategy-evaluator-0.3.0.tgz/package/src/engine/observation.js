import schema from './observation-schema.js'
import schemaV2 from './observation-schema-v2.js'
import { validateSchema, exactKeys } from './schema.js'
import { digest, timestamp, requireInput, InputError } from './canonical.js'
import { computeReturn, computeMaxDrawdown } from './metrics.js'
import { OBSERVATION_V2, SNAPSHOT_V1, SNAPSHOT_V2, POLICY_HASH, POLICY_V2_HASH, CALENDAR_HASH, ENGINE_VERSION, ENGINE_VERSION_V2, isV2Observation, policyHashFor } from './policy.js'
export { ENGINE_VERSION, ENGINE_VERSION_V2, POLICY_HASH, POLICY_V2_HASH, CALENDAR_HASH }
export const IO_VERSION = 'evaluator-input-output/1.0'
const hash = x => typeof x === 'string' && /^[a-f0-9]{64}$/.test(x)
const nonempty = x => typeof x === 'string' && x.length > 0 && x.length <= 500
export function planSessions(observation, calendar) {
  const cutoff = Math.max(timestamp(observation.frozen_at),timestamp(observation.eligibility_at))
  requireInput(cutoff >= Date.parse(calendar.range[0]) && cutoff < Date.parse(calendar.range[1])+86400000,'data_insufficient','rule_unsupported')
  const eligible = calendar.sessions.filter(s => timestamp(s.open) > cutoff)
  const first = eligible.findIndex(s => s.full)
  requireInput(first >= 0,'data_insufficient','rule_unsupported')
  const candidates = eligible.slice(first,first+observation.market_policy.max_wait_trading_sessions)
  requireInput(candidates.length === observation.market_policy.max_wait_trading_sessions,'data_insufficient','rule_unsupported')
  const full = candidates.filter(s => s.full)
  const last = calendar.sessions.findIndex(s => s.date === full.at(-1).date)
  requireInput(calendar.sessions[last+Math.max(...observation.market_policy.windows_trading_sessions)],'data_insufficient','rule_unsupported')
  return { intendedStart: full[0], fallbackCandidates: full.slice(1), waitExpiresAt: candidates.at(-1).close, marketPolicyHash: policyHashFor(observation), calendarHash: CALENDAR_HASH }
}
export function validateObservation(o, calendar) {
  if (o?.schema_version === OBSERVATION_V2) return validateObservationV2(o, calendar)
  requireInput(o?.schema_version === 'alpha-observation-contract/1.0','unsupported_version')
  requireInput(digest(o.market_policy) === o.market_policy_hash && digest(calendar) === o.calendar_hash,'hash_mismatch')
  requireInput(o.market_policy_hash === POLICY_HASH && o.calendar_hash === CALENDAR_HASH,'data_insufficient','rule_unsupported')
  validateSchema(o,schema)
  requireInput(o.market_policy_version === o.market_policy.schema_version && o.calendar_version === calendar.version,'data_insufficient','rule_unsupported')
  requireInput(timestamp(o.recorded_at) >= timestamp(o.frozen_at),'invalid_timeline')
  requireInput(o.securities.length === 1 && o.securities[0].synthetic === o.synthetic,'invalid_schema','security_scope')
  const p = o.market_policy, s = o.securities[0]
  requireInput(s.exchange === p.exchange && s.currency === p.currency && o.currency_basis === p.currency && o.start_rule === p.start_rule && o.return_method === p.return_method && digest(o.benchmarks) === digest([p.benchmark]),'data_insufficient','rule_unsupported')
  requireInput(digest(o.windows.map(w => w.trading_sessions)) === digest(p.windows_trading_sessions),'data_insufficient','rule_unsupported')
  requireInput(digest(planSessions(o,calendar)) === digest(o.start_plan),'invalid_timeline','start_plan_mismatch')
  return o
}
/** 2.0: identity is the listing MIC; the calendar is a separate XNYS session calendar; benchmark SPY/ARCX. */
function validateObservationV2(o, calendar) {
  requireInput(digest(o.market_policy) === o.market_policy_hash && digest(calendar) === o.calendar_hash,'hash_mismatch')
  requireInput(o.market_policy_hash === POLICY_V2_HASH && o.calendar_hash === CALENDAR_HASH,'data_insufficient','rule_unsupported')
  validateSchema(o,schemaV2)
  requireInput(o.market_policy_version === o.market_policy.schema_version && o.calendar_version === calendar.version,'data_insufficient','rule_unsupported')
  requireInput(timestamp(o.recorded_at) >= timestamp(o.frozen_at),'invalid_timeline')
  requireInput(o.securities.length === 1 && o.securities[0].synthetic === o.synthetic,'invalid_schema','security_scope')
  const p = o.market_policy, s = o.securities[0]
  requireInput(p.target_listing_mics.includes(s.listing_mic) && s.currency === p.currency && o.currency_basis === p.currency && o.start_rule === p.start_rule && o.return_method === p.return_method && digest(o.benchmarks) === digest([p.benchmark]),'data_insufficient','rule_unsupported')
  requireInput(s.ticker !== p.benchmark.ticker,'invalid_schema','security_scope')
  requireInput(digest(o.windows.map(w => w.trading_sessions)) === digest(p.windows_trading_sessions),'data_insufficient','rule_unsupported')
  requireInput(digest(planSessions(o,calendar)) === digest(o.start_plan),'invalid_timeline','start_plan_mismatch')
  return o
}
/** Shared bar/session validation for both snapshot versions. Returns the bar and unavailable maps. */
function validateSnapshotBars(m, calendar, asOf) {
  requireInput(Array.isArray(m.warnings) && m.warnings.every(x=>typeof x === 'string') && typeof m.coverage.complete === 'boolean' && m.request.interval === '1d')
  const validDate = d => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d)) && new Date(d).toISOString().slice(0,10) === d
  requireInput([m.request.from,m.request.to,m.coverage.from,m.coverage.to].every(validDate) && m.request.from <= m.coverage.from && m.coverage.from <= m.coverage.to && m.coverage.to <= m.request.to)
  requireInput(timestamp(m.available_at) <= timestamp(m.fetched_at) && timestamp(m.fetched_at) <= timestamp(asOf),'future_input')
  requireInput(Array.isArray(m.bars) && m.bars.length <= 2000 && Array.isArray(m.session_status) && m.session_status.length <= 2000,'input_limit')
  let prior = ''
  const barMap = new Map(), statusMap = new Map(), sessions = new Map(calendar.sessions.map(s=>[s.date,s]))
  for (const b of m.bars) {
    exactKeys(b,['session_date','open','high','low','close','volume','split_factor','split_factor_verified','available_at','receipt_ref'])
    const s = sessions.get(b.session_date)
    requireInput(s && b.session_date > prior && b.session_date >= m.coverage.from && b.session_date <= m.coverage.to,'invalid_schema','invalid_bars'); prior = b.session_date
    requireInput(['open','high','low','close','split_factor'].every(k=>Number.isFinite(b[k]) && b[k]>0) && Number.isFinite(b.volume) && b.volume>=0 && b.low<=Math.min(b.open,b.close) && b.high>=Math.max(b.open,b.close) && b.low<=b.high,'invalid_schema','invalid_bars')
    requireInput(nonempty(b.receipt_ref),'data_insufficient','missing_availability_evidence')
    requireInput(b.split_factor_verified === true,'data_insufficient','missing_split_factors')
    requireInput(timestamp(b.available_at)>=timestamp(s.close) && timestamp(b.available_at)<=timestamp(m.available_at),'future_input')
    barMap.set(b.session_date,b)
  }
  for (const s of m.session_status) {
    exactKeys(s,['session_date','status','verified','receipt_ref','available_at'])
    const session = sessions.get(s.session_date)
    requireInput(session && !statusMap.has(s.session_date) && !barMap.has(s.session_date) && ['suspended','no_valid_close'].includes(s.status) && s.verified === true && nonempty(s.receipt_ref),'invalid_schema','invalid_session_status')
    requireInput(timestamp(s.available_at)>=timestamp(session.close) && timestamp(s.available_at)<=timestamp(m.available_at),'future_input'); statusMap.set(s.session_date,s)
  }
  return { bars:barMap, unavailable:statusMap }
}
/** market-snapshot/2.0. `policy` (market-policy/2.0) is optional: when given, the listing MIC must be a target or the benchmark identity. */
function validateMarketSnapshotV2(m, calendar, asOf, policy) {
  exactKeys(m,['schema_version','id','security','provider','adapter_version','request','timezone','currency','calendar_version','adjustment','fetched_at','available_at','coverage','fallback','warnings','raw_sha256','bars','session_status'])
  exactKeys(m.security,['ticker','listing_mic','currency','company_entity_id','synthetic'])
  exactKeys(m.provider,['name','version']); exactKeys(m.request,['from','to','interval']); exactKeys(m.coverage,['from','to','complete'])
  requireInput(nonempty(m.id) && nonempty(m.provider.name) && nonempty(m.provider.version) && nonempty(m.adapter_version) && hash(m.raw_sha256))
  requireInput(typeof m.security.listing_mic === 'string' && /^[A-Z0-9]{4}$/.test(m.security.listing_mic),'invalid_schema','invalid_listing_mic')
  requireInput(m.currency === 'USD' && m.security.currency === 'USD' && m.timezone === 'America/New_York' && m.calendar_version === calendar.version,'data_insufficient','market_mismatch')
  if (policy) requireInput(policy.target_listing_mics.includes(m.security.listing_mic) || (m.security.ticker === policy.benchmark.ticker && m.security.listing_mic === policy.benchmark.listing_mic),'data_insufficient','market_mismatch')
  requireInput(typeof m.security.synthetic === 'boolean' && nonempty(m.security.ticker) && (m.security.company_entity_id === null || nonempty(m.security.company_entity_id)))
  requireInput(m.adjustment === 'none_with_verified_split_factors','data_insufficient','missing_split_factors')
  requireInput(m.fallback === false,'data_insufficient','fallback_not_allowed')
  return validateSnapshotBars(m, calendar, asOf)
}
export function validateMarketSnapshot(m, calendar, asOf, policy) {
  if (m?.schema_version === SNAPSHOT_V2) return validateMarketSnapshotV2(m, calendar, asOf, policy)
  exactKeys(m,['schema_version','id','security','provider','adapter_version','request','timezone','currency','calendar_version','adjustment','fetched_at','available_at','coverage','fallback','warnings','raw_sha256','bars','session_status'])
  requireInput(m.schema_version === 'market-snapshot/1.0','unsupported_version')
  exactKeys(m.security,['ticker','exchange','currency','company_entity_id','synthetic'])
  exactKeys(m.provider,['name','version']); exactKeys(m.request,['from','to','interval']); exactKeys(m.coverage,['from','to','complete'])
  requireInput(nonempty(m.id) && nonempty(m.provider.name) && nonempty(m.provider.version) && nonempty(m.adapter_version) && hash(m.raw_sha256))
  requireInput(m.security.exchange === 'XNYS' && m.currency === 'USD' && m.security.currency === 'USD' && m.timezone === 'America/New_York' && m.calendar_version === calendar.version,'data_insufficient','market_mismatch')
  requireInput(typeof m.security.synthetic === 'boolean' && nonempty(m.security.ticker) && (m.security.company_entity_id === null || nonempty(m.security.company_entity_id)))
  requireInput(m.adjustment === 'none_with_verified_split_factors','data_insufficient','missing_split_factors')
  requireInput(m.fallback === false,'data_insufficient','fallback_not_allowed')
  requireInput(Array.isArray(m.warnings) && m.warnings.every(x=>typeof x === 'string') && typeof m.coverage.complete === 'boolean' && m.request.interval === '1d')
  const validDate = d => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d)) && new Date(d).toISOString().slice(0,10) === d
  requireInput([m.request.from,m.request.to,m.coverage.from,m.coverage.to].every(validDate) && m.request.from <= m.coverage.from && m.coverage.from <= m.coverage.to && m.coverage.to <= m.request.to)
  requireInput(timestamp(m.available_at) <= timestamp(m.fetched_at) && timestamp(m.fetched_at) <= timestamp(asOf),'future_input')
  requireInput(Array.isArray(m.bars) && m.bars.length <= 2000 && Array.isArray(m.session_status) && m.session_status.length <= 2000,'input_limit')
  let prior = ''
  const barMap = new Map(), statusMap = new Map(), sessions = new Map(calendar.sessions.map(s=>[s.date,s]))
  for (const b of m.bars) {
    exactKeys(b,['session_date','open','high','low','close','volume','split_factor','split_factor_verified','available_at','receipt_ref'])
    const s = sessions.get(b.session_date)
    requireInput(s && b.session_date > prior && b.session_date >= m.coverage.from && b.session_date <= m.coverage.to,'invalid_schema','invalid_bars'); prior = b.session_date
    requireInput(['open','high','low','close','split_factor'].every(k=>Number.isFinite(b[k]) && b[k]>0) && Number.isFinite(b.volume) && b.volume>=0 && b.low<=Math.min(b.open,b.close) && b.high>=Math.max(b.open,b.close) && b.low<=b.high,'invalid_schema','invalid_bars')
    requireInput(nonempty(b.receipt_ref),'data_insufficient','missing_availability_evidence')
    requireInput(b.split_factor_verified === true,'data_insufficient','missing_split_factors')
    requireInput(timestamp(b.available_at)>=timestamp(s.close) && timestamp(b.available_at)<=timestamp(m.available_at),'future_input')
    barMap.set(b.session_date,b)
  }
  for (const s of m.session_status) {
    exactKeys(s,['session_date','status','verified','receipt_ref','available_at'])
    const session = sessions.get(s.session_date)
    requireInput(session && !statusMap.has(s.session_date) && !barMap.has(s.session_date) && ['suspended','no_valid_close'].includes(s.status) && s.verified === true && nonempty(s.receipt_ref),'invalid_schema','invalid_session_status')
    requireInput(timestamp(s.available_at)>=timestamp(session.close) && timestamp(s.available_at)<=timestamp(m.available_at),'future_input'); statusMap.set(s.session_date,s)
  }
  return { bars:barMap, unavailable:statusMap }
}
export const inputDigest = input => { const {input_sha256:_hash,...body}=input; return digest(body) }
export function evaluateObservation(input) {
  try {
    exactKeys(input,['schema_version','observation','observation_sha256','calendar','market_snapshots','market_snapshot_sha256s','information_set','as_of','input_sha256'])
    requireInput(input.schema_version === IO_VERSION,'unsupported_version')
    requireInput(hash(input.input_sha256) && inputDigest(input) === input.input_sha256 && digest(input.observation) === input.observation_sha256,'hash_mismatch')
    const {observation:o,calendar,as_of:asOf} = input
    validateObservation(o,calendar)
    requireInput(timestamp(asOf)>=Math.max(timestamp(o.frozen_at),timestamp(o.eligibility_at)),'invalid_timeline')
    const info = input.information_set
    exactKeys(info,['snapshot_ref','snapshot_sha256','input_cutoff_at','versions'])
    requireInput(info.snapshot_ref === o.input_snapshot_ref && info.snapshot_sha256 === o.input_snapshot_hash,'hash_mismatch')
    requireInput(timestamp(info.input_cutoff_at)<=timestamp(o.frozen_at),'future_input')
    requireInput(Array.isArray(info.versions) && info.versions.length<=2000,'input_limit')
    for (const v of info.versions) {
      exactKeys(v,['ref','sha256','available_at']); requireInput(nonempty(v.ref) && hash(v.sha256))
      requireInput(timestamp(v.available_at)<=timestamp(info.input_cutoff_at),'future_input')
    }
    requireInput(new Set(info.versions.map(v=>v.ref)).size === info.versions.length)
    requireInput(Array.isArray(input.market_snapshots) && input.market_snapshots.length<=2 && Array.isArray(input.market_snapshot_sha256s) && input.market_snapshots.length === input.market_snapshot_sha256s.length)
    const market = new Map()
    // 2.0: benchmark identity comes from the policy (SPY/ARCX); snapshots must be 2.0. 1.0 keeps its literal rules.
    const v2=isV2Observation(o), policy=v2?o.market_policy:null, benchmarkTicker=v2?policy.benchmark.ticker:'SPY'
    const benchmarkIdentity=v2?{ticker:policy.benchmark.ticker,listing_mic:policy.benchmark.listing_mic,currency:policy.benchmark.currency,company_entity_id:null,synthetic:o.synthetic}:null
    input.market_snapshots.forEach((m,i)=>{
      requireInput(digest(m) === input.market_snapshot_sha256s[i],'hash_mismatch')
      // Snapshot version must match the observation's contract generation before any identity comparison.
      requireInput(m?.schema_version === (v2?SNAPSHOT_V2:SNAPSHOT_V1),'unsupported_version')
      requireInput(m.security?.synthetic === o.synthetic,'invalid_schema','synthetic_mismatch')
      requireInput(!market.has(m.security.ticker) && [o.securities[0].ticker,benchmarkTicker].includes(m.security.ticker),'invalid_schema','security_scope')
      if (m.security.ticker === o.securities[0].ticker) requireInput(digest(m.security) === digest(o.securities[0]),'invalid_schema','security_scope')
      if (v2 && m.security.ticker === benchmarkTicker) requireInput(digest(m.security) === digest(benchmarkIdentity),'invalid_schema','security_scope')
      market.set(m.security.ticker,validateMarketSnapshot(m,calendar,asOf,policy))
    })
    const stock=market.get(o.securities[0].ticker), benchmark=market.get(benchmarkTicker)
    const plan=planSessions(o,calendar), candidates=[plan.intendedStart,...plan.fallbackCandidates]
    let start=null, reason=null
    for (const c of candidates) {
      if (timestamp(c.close)>timestamp(asOf)) break
      if (stock?.bars.has(c.date)) { start=c; break }
      if (!stock?.unavailable.has(c.date)) { reason='missing_start_evidence'; break }
    }
    const base={schema_version:IO_VERSION,engine_version:v2?ENGINE_VERSION_V2:ENGINE_VERSION,rule_version:o.market_policy_version,observation_ref:o.id,observation_sha256:input.observation_sha256,input_sha256:input.input_sha256,market_snapshot_refs:input.market_snapshots.map((m,i)=>({id:m.id,sha256:input.market_snapshot_sha256s[i],adapter_version:m.adapter_version})),market_policy_hash:o.market_policy_hash,calendar_hash:o.calendar_hash,computed_at:asOf,record_origin:o.record_origin,research_stream:o.research_stream,synthetic:o.synthetic,contamination_reasons:[...o.contamination_reasons],anchor_status:o.anchor_status,provenance_level:o.provenance_level,security:structuredClone(o.securities[0]),input_snapshot_ref:o.input_snapshot_ref,input_snapshot_hash:o.input_snapshot_hash,return_method:o.return_method,portfolio_return:null}
    let status, windows
    if (!start) {
      status=(reason !== null || timestamp(asOf)>=timestamp(plan.waitExpiresAt))?'data_insufficient':'pending_start'
      reason ??= status === 'data_insufficient'?'max_wait_exceeded':null
      windows=o.windows.map(w=>({trading_sessions:w.trading_sessions,starts_at:null,ends_at:null,status,reason,result:null}))
    } else {
      const pos=calendar.sessions.findIndex(s=>s.date===start.date)
      windows=o.windows.map(w=>{
        const end=calendar.sessions[pos+w.trading_sessions]
        const row={trading_sessions:w.trading_sessions,starts_at:start.close,ends_at:end?.close??null,status:'open',reason:null,result:null}
        if (!end) return {...row,status:'data_insufficient',reason:'rule_unsupported'}
        if (timestamp(end.close)>timestamp(asOf)) return row
        const sessions=calendar.sessions.slice(pos,pos+w.trading_sessions+1)
        if (!sessions.every(s=>stock.bars.has(s.date))) return {...row,status:'data_insufficient',reason:'missing_close'}
        if (!sessions.every(s=>benchmark?.bars.has(s.date))) return {...row,status:'data_insufficient',reason:'missing_benchmark'}
        const prices=sessions.map(s=>{const b=stock.bars.get(s.date);return b.close*b.split_factor})
        const bases=sessions.map(s=>{const b=benchmark.bars.get(s.date);return b.close*b.split_factor})
        const priceReturn=computeReturn({entryPrice:prices[0],exitPrice:prices.at(-1),decimals:10})
        const benchmarkReturn=computeReturn({entryPrice:bases[0],exitPrice:bases.at(-1),decimals:10})
        requireInput([...prices,...bases,priceReturn,benchmarkReturn].every(Number.isFinite),'invalid_schema','invalid_adjusted_price')
        return {...row,status:'resolved',result:{price_return:priceReturn,benchmark_price_return:benchmarkReturn,benchmark_difference:Math.round((priceReturn-benchmarkReturn)*1e10)/1e10,max_drawdown:computeMaxDrawdown({prices,decimals:10}),benchmark:benchmarkTicker,currency:'USD',...(v2?{benchmark_listing_mic:policy.benchmark.listing_mic}:{})}}
      })
      status=windows.every(w=>w.status==='resolved')?'resolved':windows.some(w=>w.status==='data_insufficient')?'data_insufficient':'open'
    }
    const result={...base,status,reason,actual_start_at:start?.close??null,windows}
    return {ok:true,result,result_sha256:digest(result)}
  } catch(e) {
    if (e instanceof InputError) return {ok:false,error:{code:e.code,reason:e.reason}}
    return {ok:false,error:{code:'invalid_schema',reason:'invalid_input'}}
  }
}
export function replayObservation(input, stored) {
  const computed=evaluateObservation(input)
  return {matches:computed.ok && stored?.ok === true && digest(computed)===digest(stored),computed}
}
