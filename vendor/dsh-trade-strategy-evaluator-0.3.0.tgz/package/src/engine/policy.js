// Versioned rule constants. 1.0 values are frozen S4 hashes; 2.0 (E3a) separates the
// security's listing MIC from the session calendar so SPY/ARCX can be the benchmark
// for XNYS targets. Old observations keep the old hashes and the old engine version.
export const OBSERVATION_V1 = 'alpha-observation-contract/1.0'
export const OBSERVATION_V2 = 'alpha-observation-contract/2.0'
export const SNAPSHOT_V1 = 'market-snapshot/1.0'
export const SNAPSHOT_V2 = 'market-snapshot/2.0'
export const POLICY_V1 = 'market-policy/1.0'
export const POLICY_V2 = 'market-policy/2.0'
export const POLICY_HASH = '9f31b8c1ad67aa62fa6b9743044763b530f1a69e6f5ebdb468e33597fddb5089'
export const POLICY_V2_HASH = '9d7c851c81343ad77420c5302fea30fb6056b7b15231a3019fae7df0eafc566c'
export const CALENDAR_HASH = '9c81226f191c390e69478a9651025254d789d671c72b9aef2b78bc941af302a4'
export const ENGINE_VERSION = 'osanalyst-engine/1.0.0'
export const ENGINE_VERSION_V2 = 'osanalyst-engine/1.1.0'
export const isV2Observation = o => o?.schema_version === OBSERVATION_V2 || o?.market_policy_version === POLICY_V2
export const policyHashFor = o => (isV2Observation(o) ? POLICY_V2_HASH : POLICY_HASH)
